// require 3rd party js

// import css
import 'semantic/dist/semantic.min.css';

import 'core-js/fn/object/assign';
import React from 'react';
import ReactDOM from 'react-dom';
import { Provider } from 'react-redux';
import App from './components/Main';
import OrderApp from './components/Orders';
import configureStore from './stores/configureStore';
import orderStore from './stores/orderStore';

// Render the main component into the dom

let app = document.getElementById('app'),
    orderApp = document.getElementById("app-order");
if (app) {
    let store = configureStore();
    ReactDOM.render(
        <Provider store={store}>
            <App />
        </Provider>, app
    );
}

if (orderApp) {
    let store = orderStore()
    ReactDOM.render(
        <Provider store={store}>
            <OrderApp />
        </Provider>, orderApp
    );
}
