// require 3rd party js

// import css
import 'semantic/dist/semantic.min.css';

import 'core-js/fn/object/assign';
import React from 'react';
import ReactDOM from 'react-dom';
import {Provider} from 'react-redux';
import App from './components/Main';
import configureStore from './stores/configureStore'

// Render the main component into the dom

let store = configureStore();

ReactDOM.render(
    <Provider store={store}>
        <App />
    </Provider>,
    document.getElementById('app'));

