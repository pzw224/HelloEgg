export const TIME_INTERVAL = 5000;
export const MAX_LENGTH = 60 * 15;
// get x minute data
export const TIME_INIT_GAP = MAX_LENGTH * 1000;
// get sometime before now
export const TIME_RECALL = 1000 * 60 * 20;