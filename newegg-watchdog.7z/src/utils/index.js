import _ from 'lodash';

export var getMin = function (arrObj, key) {
    if (arrObj instanceof Array && arrObj.length > 0) {
        if (arrObj[0].toString() === "[object Object]") {
            let illegal = false;
            arrObj.map(function (obj, index) {
                if (obj.toString() !== "[object Object]" || !obj.hasOwnProperty(key)) {
                    illegal = true;
                }
            });
            if (illegal) {
                return null;
            }
            return Math.min.apply(null, arrObj.map(i => i[key]));
        } else if (typeof arrObj[0] === 'number') {
            return Math.min.apply(null, arrObj);
        }
        return null;
    }
}

export var getMax = function (arrObj, key) {
    if (arrObj instanceof Array && arrObj.length > 0) {
        if (arrObj[0].toString() === "[object Object]") {
            let illegal = false;
            arrObj.map(function (obj, index) {
                if (obj.toString() !== "[object Object]" || !obj.hasOwnProperty(key)) {
                    illegal = true;
                }
            });
            if (illegal) {
                return null;
            }
            return Math.max.apply(null, arrObj.map(i => i[key]));
        } else if (typeof arrObj[0] === 'number') {
            return Math.max.apply(null, arrObj);
        }
        return null;
    }
}


export var timeFormater = function (timespan) {
    var t = new Date(timespan);
    return encodeURIComponent(t.toLocaleTimeString("en-US", { timeZoneName: "short", hour12: false, year: "numeric", month: "numeric", day: "numeric" }).replace(/\,/, ""));
}

export var dataFormater = function (array) {
    var dictionary = {}, start_x, end_x;

    // const defaultPoints = array.map((a) => { return { x: a.timespan, y: 0 } });


    array.map((timespanItem, index) => {
        timespanItem.data.map((item, idx) => {
            let _t = { x: timespanItem.timespan, y: item.count };
            if (dictionary.hasOwnProperty(item['keyword'])) {
                dictionary[item['keyword']].push(_t)
            } else {
                dictionary[item['keyword']] = [_t];
            }
        });
    });

    if (array.length > 0) {
        start_x = array[0].tiemspan;
        end_x = array[array.length - 1].timespan;
        Object.keys(dictionary).map(key => {
            let obj = dictionary[key];
        });
    }

    return Object.keys(dictionary).map(key => {
        let obj = dictionary[key],
            dist = obj.sort((a, b) => { return a.x - b.x; });
        if (start_x && dist[0].x !== start_x) {
            dist.unshift({ x: start_x, y: 0 });
        }
        if (end_x && dist[dist.length - 1].x !== end_x) {
            dist.push({ x: end_x, y: 0 });
        }
        return {
            keyword: key,
            values://dist,
            obj//.concat(
                // defaultPoints
                // .filter((a) => { return obj.findIndex((b) => { return a.x == b.x; }) < 0; }))
                .sort((a, b) => { return a.x - b.x; }),
            totalCount: obj.reduce((pre, cur) => { return pre + cur.y; }, 0)
        };
    }).sort((a, b) => { return b.totalCount - a.totalCount; });
};