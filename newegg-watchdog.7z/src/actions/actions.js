import fetch from 'isomorphic-fetch'
import { timeFormater } from '../utils/'
export const REQUEST_POSTS = 'REQUEST_POSTS'
export const RECEIVE_POSTS = 'RECEIVE_POSTS'
export const INVALIDATE_SUBREDDIT = 'INVALIDATE_SUBREDDIT '

export function invalidateSubreddit() {
    return {
        type: INVALIDATE_SUBREDDIT
    };
}

function requestPosts() {
    return {
        type: REQUEST_POSTS
    };
}

function receivePosts(json, lastUpdateTime) {
    return {
        type: RECEIVE_POSTS,
        data: json,
        lastUpdateTime: lastUpdateTime
    };
}

function fetchPosts(startTime, endTime) {
    let time1 = timeFormater(startTime),
        time2 = timeFormater(endTime);
    return function (dispatch) {
        return fetch(`/data/${time1}/${time2}/`)
            .then(response => response.json())
            .then(json => dispatch(receivePosts(json, endTime)))
    }
}

function fetchOrders(startTime, endTime) {
    return function (dispatch) {
        return fetch(`/ssl/${startTime}/${endTime}/`)
            .then(response => response.json())
            .then(json => dispatch(receivePosts(json, endTime)))
    }
}

export function fetchPostsIfNeeded(startTime, endTime) {
    return (dispatch, getState) => {
        return dispatch(fetchPosts(startTime, endTime));
    }
}

export function fetchOrdersIfNeeded(startTime, endTime) {
    return (dispatch, getState) => {
        return dispatch(fetchOrders(startTime, endTime));
    }
}
