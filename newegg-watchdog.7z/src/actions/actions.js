import fetch from 'isomorphic-fetch'
import { timeFormater } from '../utils/'
export const REQUEST_POSTS = 'REQUEST_POSTS'
export const RECEIVE_POSTS = 'RECEIVE_POSTS'
export const INVALIDATE_SUBREDDIT = 'INVALIDATE_SUBREDDIT'
export const REQUEST_HEADER = 'REQUEST_HEADER'

export function invalidateSubreddit() {
    return {
        type: INVALIDATE_SUBREDDIT
    };
}

function requestPosts() {
    return {
        type: REQUEST_POSTS
    };
}

function receivePosts(json, lastUpdateTime) {
    return {
        type: RECEIVE_POSTS,
        data: json,
        lastUpdateTime: lastUpdateTime
    };
}

function requestHeader(data) {
    return {
        type: REQUEST_HEADER,
        data: data
    };
}

function fetchPosts(startTime, endTime) {
    let time1 = timeFormater(startTime),
        time2 = timeFormater(endTime);
    return function(dispatch) {
        return sendRequest(dispatch, { url: `/data/${time1}/${time2}/`, timeStamp: endTime, cache: false });
    }
}

function fetchOrders(startTime, endTime) {
    return function(dispatch) {
        return sendRequest(dispatch, { url: `/USA/ssl/orders`, timeStamp: endTime, cache: false });
    }
}

function fetchCANOrders(startTime, endTime) {
    return function(dispatch) {
        return sendRequest(dispatch, { url: `/CAN/ssl/orders`, timeStamp: endTime, cache: false });
    }
}

function fetchHeader() {
    return function(dispatch) {
        return fetch(`/header/?timespan=${Date.now()}`)
            .then(response => response.json())
            .then(json => dispatch(requestHeader(json)))
    }
}

function sendRequest(dispatch, opt) {
    return fetch(`${opt.url}${opt.cache ? '' : `?${Date.now()}`}`)
        .then(response => response.json())
        .then(json => dispatch(receivePosts(json, opt.timeStamp)));
}


export function fetchPostsIfNeeded(startTime, endTime) {
    return (dispatch, getState) => {
        return dispatch(fetchPosts(startTime, endTime));
    }
}

export function fetchOrdersIfNeeded(startTime, endTime) {
    return (dispatch, getState) => {
        return dispatch(fetchOrders(startTime, endTime));
    }
}

export function fetchHeaderIfNeeded() {
    return (dispatch, getState) => {
        return dispatch(fetchHeader());
    }
}

export function fetchCANOrderIfNeeded(startTime, endTime) {
    return (dispatch, getState) => {
        return dispatch(fetchCANOrders(startTime, endTime));
    }
}
