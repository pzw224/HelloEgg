import {
    INVALIDATE_SUBREDDIT,
    REQUEST_POSTS,
    RECEIVE_POSTS
} from '../actions/actions'

export default (state = {
    lastUpdateTime: '',
    isLoading: false,
    didInvalidate: false
}, action) => {
    switch (action.type) {
        case INVALIDATE_SUBREDDIT:
            return Object.assign({}, state, {
                lastUpdateTime: state.lastUpdateTime,
                isLoading: false,
                didInvalidate: true
            });
        case REQUEST_POSTS:
            return Object.assign({}, state, {
                lastUpdateTime: state.lastUpdateTime,
                isLoading: true,
                didInvalidate: false
            });
        case RECEIVE_POSTS:
            return Object.assign({}, state, {
                lastUpdateTime: action.lastUpdateTime,
                isLoading: false,
                didInvalidate: false
            })
        default:
            return state;
    }
}