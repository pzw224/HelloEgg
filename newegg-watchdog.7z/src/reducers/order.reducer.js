import {
    INVALIDATE_SUBREDDIT,
    REQUEST_POSTS,
    RECEIVE_POSTS
} from '../actions/actions';

export default (state = {
    map: {},
    orders: {
        money: 0,
        orderCount: 0
    }
}, action) => {
    switch (action.type) {
        case RECEIVE_POSTS:
            let result = Object.assign({}, state);
            Object.keys(result).map((key) => {
                if (key === "map") {
                    action.data[key].map((obj, idx) => {
                        let {State, OrderAmount, OrderCount} = obj;
                        State = State.replace(/\s+/g, "")
                        if (result.map.hasOwnProperty(State)) {
                            result.map[State].orderAmount = parseInt(OrderAmount);
                            result.map[State].orderCount = parseInt(OrderCount);
                        } else {
                            result.map[State] = {
                                orderAmount: parseInt(OrderAmount),
                                orderCount: parseInt(OrderCount)
                            };
                        }
                    });

                } else if (key === "orders") {
                    let info = action.data[key][action.data[key].length - 1].split('|');
                    result[key] = {
                        money: info[0],
                        orderCount: info[1]
                    };
                } else {
                    result[key] = action.data[key];
                }
            });
            return result;
        default:
            return state;

    }
}

