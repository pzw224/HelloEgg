import { combineReducers } from 'redux';
import data from './data.reducer';
import network from './network.reducer';
import header from './header.reducer';

export default combineReducers({
    data,
    network,
    header
})