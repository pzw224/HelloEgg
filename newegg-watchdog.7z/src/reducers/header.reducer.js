import { REQUEST_HEADER } from '../actions/actions'

export default (state = {
    timeSpan: [{
        startTime: "2016-11-26 00:00:00 GMT-8", 
        pageTitle: "BLACK FRIDAY",
        endTime: "2016-11-27 00:00:00 GMT-8" 
    }]
}, action) => {
    switch (action.type) {
        case REQUEST_HEADER:
            {
                let result = Object.assign({},state,action.data);
                return result;
            }
        default:
            return state;
    }
}