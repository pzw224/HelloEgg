import { combineReducers } from 'redux';
import data from './order.reducer';
import network from './network.reducer';

export default combineReducers({
    data,
    network
})