import { combineReducers } from 'redux';
import data from './order.reducer';
import network from './network.reducer';
import header from './header.reducer';

export default combineReducers({
    data,
    network,
    header,
})