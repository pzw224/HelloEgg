import {
    INVALIDATE_SUBREDDIT,
    REQUEST_POSTS,
    RECEIVE_POSTS
} from '../actions/actions';


import { MAX_LENGTH } from '../config/time';

export default (state = {
    map: [],
    keyword: [],
    pvuv: [],
    itemNumber: [],
    orders: {
        money: 0,
        orderCount: 0
    }
}, action) => {
    switch (action.type) {

        case RECEIVE_POSTS:
            let result = Object.assign({}, state);
            Object.keys(result).map((key) => {
                if (key !== "orders" && key !== "itemNumber" && key !== "keyword") {
                    result[key] = Array.prototype.concat(result[key], action.data[key]);
                    if (result[key].length > MAX_LENGTH) {
                        result[key] = Array.prototype.slice.call(result[key], -MAX_LENGTH);
                    }
                } else if (key === "orders") {
                    let info = action.data[key][action.data[key].length - 1].split('|');
                    result[key] = {
                        money: info[0],
                        orderCount: info[1]
                    };
                } else {
                    result[key] = action.data[key];
                }
            });
            return result;
        default:
            return state;

    }
}