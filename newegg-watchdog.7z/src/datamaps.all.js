(function() {
  var svg;

  //save off default references
  var d3 = window.d3, topojson = window.topojson;

  var defaultOptions = {
    scope: 'world',
    responsive: false,
    aspectRatio: 0.5625,
    setProjection: setProjection,
    projection: 'equirectangular',
    dataType: 'json',
    data: {},
    done: function() {},
    fills: {
      defaultFill: '#ABDDA4'
    },
    filters: {},
    geographyConfig: {
        dataUrl: null,
        hideAntarctica: true,
        hideHawaiiAndAlaska : false,
        borderWidth: 1,
        borderColor: '#FDFDFD',
        popupTemplate: function(geography, data) {
          return '<div class="hoverinfo"><strong>' + geography.properties.name + '</strong></div>';
        },
        popupOnHover: true,
        highlightOnHover: true,
        highlightFillColor: '#FC8D59',
        highlightBorderColor: 'rgba(250, 15, 160, 0.2)',
        highlightBorderWidth: 2
    },
    projectionConfig: {
      rotation: [97, 0]
    },
    bubblesConfig: {
        borderWidth: 2,
        borderColor: '#FFFFFF',
        popupOnHover: true,
        radius: null,
        popupTemplate: function(geography, data) {
          return '<div class="hoverinfo"><strong>' + data.name + '</strong></div>';
        },
        fillOpacity: 0.75,
        animate: true,
        highlightOnHover: true,
        highlightFillColor: '#FC8D59',
        highlightBorderColor: 'rgba(250, 15, 160, 0.2)',
        highlightBorderWidth: 2,
        highlightFillOpacity: 0.85,
        exitDelay: 100,
        key: JSON.stringify
    },
    arcConfig: {
      strokeColor: '#DD1C77',
      strokeWidth: 1,
      arcSharpness: 1,
      animationSpeed: 600
    }
  };

  /*
    Getter for value. If not declared on datumValue, look up the chain into optionsValue
  */
  function val( datumValue, optionsValue, context ) {
    if ( typeof context === 'undefined' ) {
      context = optionsValue;
      optionsValues = undefined;
    }
    var value = typeof datumValue !== 'undefined' ? datumValue : optionsValue;

    if (typeof value === 'undefined') {
      return  null;
    }

    if ( typeof value === 'function' ) {
      var fnContext = [context];
      if ( context.geography ) {
        fnContext = [context.geography, context.data];
      }
      return value.apply(null, fnContext);
    }
    else {
      return value;
    }
  }

  function addContainer( element, height, width ) {
    this.svg = d3.select( element ).append('svg')
      .attr('width', width || element.offsetWidth)
      .attr('data-width', width || element.offsetWidth)
      .attr('class', 'datamap')
      .attr('height', height || element.offsetHeight)
      .style('overflow', 'hidden'); // IE10+ doesn't respect height/width when map is zoomed in

    if (this.options.responsive) {
      d3.select(this.options.element).style({'position': 'relative', 'padding-bottom': (this.options.aspectRatio*100) + '%'});
      d3.select(this.options.element).select('svg').style({'position': 'absolute', 'width': '100%', 'height': '100%'});
      d3.select(this.options.element).select('svg').select('g').selectAll('path').style('vector-effect', 'non-scaling-stroke');

    }

    return this.svg;
  }

  // setProjection takes the svg element and options
  function setProjection( element, options ) {
    var width = options.width || element.offsetWidth;
    var height = options.height || element.offsetHeight;
    var projection, path;
    var svg = this.svg;

    if ( options && typeof options.scope === 'undefined') {
      options.scope = 'world';
    }

    if ( options.scope === 'usa' ) {
      projection = d3.geo.albersUsa()
        .scale(width)
        .translate([width / 2, height / 2]);
    }
    else if ( options.scope === 'world' ) {
      projection = d3.geo[options.projection]()
        .scale((width + 1) / 2 / Math.PI)
        .translate([width / 2, height / (options.projection === "mercator" ? 1.45 : 1.8)]);
    }

    if ( options.projection === 'orthographic' ) {

      svg.append("defs").append("path")
        .datum({type: "Sphere"})
        .attr("id", "sphere")
        .attr("d", path);

      svg.append("use")
          .attr("class", "stroke")
          .attr("xlink:href", "#sphere");

      svg.append("use")
          .attr("class", "fill")
          .attr("xlink:href", "#sphere");
      projection.scale(250).clipAngle(90).rotate(options.projectionConfig.rotation)
    }

    path = d3.geo.path()
      .projection( projection );

    return {path: path, projection: projection};
  }

  function addStyleBlock() {
    if ( d3.select('.datamaps-style-block').empty() ) {
      d3.select('head').append('style').attr('class', 'datamaps-style-block')
      .html('.datamap path.datamaps-graticule { fill: none; stroke: #777; stroke-width: 0.5px; stroke-opacity: .5; pointer-events: none; } .datamap .labels {pointer-events: none;} .datamap path {stroke: #FFFFFF; stroke-width: 1px;} .datamaps-legend dt, .datamaps-legend dd { float: left; margin: 0 3px 0 0;} .datamaps-legend dd {width: 20px; margin-right: 6px; border-radius: 3px;} .datamaps-legend {padding-bottom: 20px; z-index: 1001; position: absolute; left: 4px; font-size: 12px; font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;} .datamaps-hoverover {display: none; font-family: "Helvetica Neue", Helvetica, Arial, sans-serif; } .hoverinfo {padding: 4px; border-radius: 1px; background-color: #FFF; box-shadow: 1px 1px 5px #CCC; font-size: 12px; border: 1px solid #CCC; } .hoverinfo hr {border:1px dotted #CCC; }');
    }
  }

  function drawSubunits( data ) {
    var fillData = this.options.fills,
        colorCodeData = this.options.data || {},
        geoConfig = this.options.geographyConfig;


    var subunits = this.svg.select('g.datamaps-subunits');
    if ( subunits.empty() ) {
      subunits = this.addLayer('datamaps-subunits', null, true);
    }

    var geoData = topojson.feature( data, data.objects[ this.options.scope ] ).features;
    if ( geoConfig.hideAntarctica ) {
      geoData = geoData.filter(function(feature) {
        return feature.id !== "ATA";
      });
    }

    if ( geoConfig.hideHawaiiAndAlaska ) {
      geoData = geoData.filter(function(feature) {
        return feature.id !== "HI" && feature.id !== 'AK';
      });
    }

    var geo = subunits.selectAll('path.datamaps-subunit').data( geoData );

    geo.enter()
      .append('path')
      .attr('d', this.path)
      .attr('class', function(d) {
        return 'datamaps-subunit ' + d.id;
      })
      .attr('data-info', function(d) {
        return JSON.stringify( colorCodeData[d.id]);
      })
      .style('fill', function(d) {
        //if fillKey - use that
        //otherwise check 'fill'
        //otherwise check 'defaultFill'
        var fillColor;

        var datum = colorCodeData[d.id];
        if ( datum && datum.fillKey ) {
          fillColor = fillData[ val(datum.fillKey, {data: colorCodeData[d.id], geography: d}) ];
        }

        if ( typeof fillColor === 'undefined' ) {
          fillColor = val(datum && datum.fillColor, fillData.defaultFill, {data: colorCodeData[d.id], geography: d});
        }

        return fillColor;
      })
      .style('stroke-width', geoConfig.borderWidth)
      .style('stroke', geoConfig.borderColor);
  }

  function handleGeographyConfig () {
    var hoverover;
    var svg = this.svg;
    var self = this;
    var options = this.options.geographyConfig;

    if ( options.highlightOnHover || options.popupOnHover ) {
      svg.selectAll('.datamaps-subunit')
        .on('mouseover', function(d) {
          var $this = d3.select(this);
          var datum = self.options.data[d.id] || {};
          if ( options.highlightOnHover ) {
            var previousAttributes = {
              'fill':  $this.style('fill'),
              'stroke': $this.style('stroke'),
              'stroke-width': $this.style('stroke-width'),
              'fill-opacity': $this.style('fill-opacity')
            };

            $this
              .style('fill', val(datum.highlightFillColor, options.highlightFillColor, datum))
              .style('stroke', val(datum.highlightBorderColor, options.highlightBorderColor, datum))
              .style('stroke-width', val(datum.highlightBorderWidth, options.highlightBorderWidth, datum))
              .style('fill-opacity', val(datum.highlightFillOpacity, options.highlightFillOpacity, datum))
              .attr('data-previousAttributes', JSON.stringify(previousAttributes));

            //as per discussion on https://github.com/markmarkoh/datamaps/issues/19
            if ( ! /((MSIE)|(Trident))/.test(navigator.userAgent) ) {
             moveToFront.call(this);
            }
          }

          if ( options.popupOnHover ) {
            self.updatePopup($this, d, options, svg);
          }
        })
        .on('mouseout', function() {
          var $this = d3.select(this);

          if (options.highlightOnHover) {
            //reapply previous attributes
            var previousAttributes = JSON.parse( $this.attr('data-previousAttributes') );
            for ( var attr in previousAttributes ) {
              $this.style(attr, previousAttributes[attr]);
            }
          }
          $this.on('mousemove', null);
          d3.selectAll('.datamaps-hoverover').style('display', 'none');
        });
    }

    function moveToFront() {
      this.parentNode.appendChild(this);
    }
  }

  //plugin to add a simple map legend
  function addLegend(layer, data, options) {
    data = data || {};
    if ( !this.options.fills ) {
      return;
    }

    var html = '<dl>';
    var label = '';
    if ( data.legendTitle ) {
      html = '<h2>' + data.legendTitle + '</h2>' + html;
    }
    for ( var fillKey in this.options.fills ) {

      if ( fillKey === 'defaultFill') {
        if (! data.defaultFillName ) {
          continue;
        }
        label = data.defaultFillName;
      } else {
        if (data.labels && data.labels[fillKey]) {
          label = data.labels[fillKey];
        } else {
          label= fillKey + ': ';
        }
      }
      html += '<dt>' + label + '</dt>';
      html += '<dd style="background-color:' +  this.options.fills[fillKey] + '">&nbsp;</dd>';
    }
    html += '</dl>';

    var hoverover = d3.select( this.options.element ).append('div')
      .attr('class', 'datamaps-legend')
      .html(html);
  }

    function addGraticule ( layer, options ) {
      var graticule = d3.geo.graticule();
      this.svg.insert("path", '.datamaps-subunits')
        .datum(graticule)
        .attr("class", "datamaps-graticule")
        .attr("d", this.path);
  }

  function handleArcs (layer, data, options) {
    var self = this,
        svg = this.svg;

    if ( !data || (data && !data.slice) ) {
      throw "Datamaps Error - arcs must be an array";
    }

    // For some reason arc options were put in an `options` object instead of the parent arc
    // I don't like this, so to match bubbles and other plugins I'm moving it
    // This is to keep backwards compatability
    for ( var i = 0; i < data.length; i++ ) {
      data[i] = defaults(data[i], data[i].options);
      delete data[i].options;
    }

    if ( typeof options === "undefined" ) {
      options = defaultOptions.arcConfig;
    }

    var arcs = layer.selectAll('path.datamaps-arc').data( data, JSON.stringify );

    var path = d3.geo.path()
        .projection(self.projection);

    arcs
      .enter()
        .append('svg:path')
        .attr('class', 'datamaps-arc')
        .style('stroke-linecap', 'round')
        .style('stroke', function(datum) {
          return val(datum.strokeColor, options.strokeColor, datum);
        })
        .style('fill', 'none')
        .style('stroke-width', function(datum) {
            return val(datum.strokeWidth, options.strokeWidth, datum);
        })
        .attr('d', function(datum) {
            var originXY = self.latLngToXY(val(datum.origin.latitude, datum), val(datum.origin.longitude, datum))
            var destXY = self.latLngToXY(val(datum.destination.latitude, datum), val(datum.destination.longitude, datum));
            var midXY = [ (originXY[0] + destXY[0]) / 2, (originXY[1] + destXY[1]) / 2];
            if (options.greatArc) {
                  // TODO: Move this to inside `if` clause when setting attr `d`
              var greatArc = d3.geo.greatArc()
                  .source(function(d) { return [val(d.origin.longitude, d), val(d.origin.latitude, d)]; })
                  .target(function(d) { return [val(d.destination.longitude, d), val(d.destination.latitude, d)]; });

              return path(greatArc(datum))
            }
            var sharpness = val(datum.arcSharpness, options.arcSharpness, datum);
            return "M" + originXY[0] + ',' + originXY[1] + "S" + (midXY[0] + (50 * sharpness)) + "," + (midXY[1] - (75 * sharpness)) + "," + destXY[0] + "," + destXY[1];
        })
        .transition()
          .delay(100)
          .style('fill', function(datum) {
            /*
              Thank you Jake Archibald, this is awesome.
              Source: http://jakearchibald.com/2013/animated-line-drawing-svg/
            */
            var length = this.getTotalLength();
            this.style.transition = this.style.WebkitTransition = 'none';
            this.style.strokeDasharray = length + ' ' + length;
            this.style.strokeDashoffset = length;
            this.getBoundingClientRect();
            this.style.transition = this.style.WebkitTransition = 'stroke-dashoffset ' + val(datum.animationSpeed, options.animationSpeed, datum) + 'ms ease-out';
            this.style.strokeDashoffset = '0';
            return 'none';
          })

    arcs.exit()
      .transition()
      .style('opacity', 0)
      .remove();
  }

  function handleLabels ( layer, options ) {
    var self = this;
    options = options || {};
    var labelStartCoodinates = this.projection([-67.707617, 42.722131]);
    this.svg.selectAll(".datamaps-subunit")
      .attr("data-foo", function(d) {
        var center = self.path.centroid(d);
        var xOffset = 7.5, yOffset = 5;

        if ( ["FL", "KY", "MI"].indexOf(d.id) > -1 ) xOffset = -2.5;
        if ( d.id === "NY" ) xOffset = -1;
        if ( d.id === "MI" ) yOffset = 18;
        if ( d.id === "LA" ) xOffset = 13;
        if ( d.id === "NU" ) xOffset = 30,yOffset = 65;

        var x,y;

        x = center[0] - xOffset;
        y = center[1] + yOffset;

        var smallStateIndex = ["VT", "NH", "MA", "RI", "CT", "NJ", "DE", "MD", "DC"].indexOf(d.id);
        if ( smallStateIndex > -1) {
          var yStart = labelStartCoodinates[1];
          x = labelStartCoodinates[0];
          y = yStart + (smallStateIndex * (2+ (options.fontSize || 12)));
          layer.append("line")
            .attr("x1", x - 3)
            .attr("y1", y - 5)
            .attr("x2", center[0])
            .attr("y2", center[1])
            .style("stroke", options.labelColor || "#000")
            .style("stroke-width", options.lineWidth || 1)
        }

        layer.append("text")
          .attr("x", x)
          .attr("y", y)
          .style("font-size", (options.fontSize || 10) + 'px')
          .style("font-family", options.fontFamily || "Verdana")
          .style("fill", options.labelColor || "#000")
          .text( d.id );
        return "bar";
      });
  }


  function handleBubbles (layer, data, options ) {
    var self = this,
        fillData = this.options.fills,
        filterData = this.options.filters,
        svg = this.svg;

    if ( !data || (data && !data.slice) ) {
      throw "Datamaps Error - bubbles must be an array";
    }

    var bubbles = layer.selectAll('circle.datamaps-bubble').data( data, options.key );

    bubbles
      .enter()
        .append('svg:circle')
        .attr('class', 'datamaps-bubble')
        .attr('cx', function ( datum ) {
          var latLng;
          if ( datumHasCoords(datum) ) {
            latLng = self.latLngToXY(datum.latitude, datum.longitude);
          }
          else if ( datum.centered ) {
            latLng = self.path.centroid(svg.select('path.' + datum.centered).data()[0]);
          }
          if ( latLng ) return latLng[0];
        })
        .attr('cy', function ( datum ) {
          var latLng;
          if ( datumHasCoords(datum) ) {
            latLng = self.latLngToXY(datum.latitude, datum.longitude);
          }
          else if ( datum.centered ) {
            latLng = self.path.centroid(svg.select('path.' + datum.centered).data()[0]);
          }
          if ( latLng ) return latLng[1];
        })
        .attr('r', function(datum) {
          // if animation enabled start with radius 0, otherwise use full size.
          return options.animate ? 0 : val(datum.radius, options.radius, datum);
        })
        .attr('data-info', function(d) {
          return JSON.stringify(d);
        })
        .attr('filter', function (datum) {
          var filterKey = filterData[ val(datum.filterKey, options.filterKey, datum) ];

          if (filterKey) {
            return filterKey;
          }
        })
        .style('stroke', function ( datum ) {
          return val(datum.borderColor, options.borderColor, datum);
        })
        .style('stroke-width', function ( datum ) {
          return val(datum.borderWidth, options.borderWidth, datum);
        })
        .style('fill-opacity', function ( datum ) {
          return val(datum.fillOpacity, options.fillOpacity, datum);
        })
        .style('fill', function ( datum ) {
          var fillColor = fillData[ val(datum.fillKey, options.fillKey, datum) ];
          return fillColor || fillData.defaultFill;
        })
        .on('mouseover', function ( datum ) {
          var $this = d3.select(this);

          if (options.highlightOnHover) {
            //save all previous attributes for mouseout
            var previousAttributes = {
              'fill':  $this.style('fill'),
              'stroke': $this.style('stroke'),
              'stroke-width': $this.style('stroke-width'),
              'fill-opacity': $this.style('fill-opacity')
            };

            $this
              .style('fill', val(datum.highlightFillColor, options.highlightFillColor, datum))
              .style('stroke', val(datum.highlightBorderColor, options.highlightBorderColor, datum))
              .style('stroke-width', val(datum.highlightBorderWidth, options.highlightBorderWidth, datum))
              .style('fill-opacity', val(datum.highlightFillOpacity, options.highlightFillOpacity, datum))
              .attr('data-previousAttributes', JSON.stringify(previousAttributes));
          }

          if (options.popupOnHover) {
            self.updatePopup($this, datum, options, svg);
          }
        })
        .on('mouseout', function ( datum ) {
          var $this = d3.select(this);

          if (options.highlightOnHover) {
            //reapply previous attributes
            var previousAttributes = JSON.parse( $this.attr('data-previousAttributes') );
            for ( var attr in previousAttributes ) {
              $this.style(attr, previousAttributes[attr]);
            }
          }

          d3.selectAll('.datamaps-hoverover').style('display', 'none');
        })

    bubbles.transition()
      .duration(400)
      .attr('r', function ( datum ) {
        return val(datum.radius, options.radius, datum);
      });

    bubbles.exit()
      .transition()
        .delay(options.exitDelay)
        .attr("r", 0)
        .remove();

    function datumHasCoords (datum) {
      return typeof datum !== 'undefined' && typeof datum.latitude !== 'undefined' && typeof datum.longitude !== 'undefined';
    }
  }

  //stolen from underscore.js
  function defaults(obj) {
    Array.prototype.slice.call(arguments, 1).forEach(function(source) {
      if (source) {
        for (var prop in source) {
          if (obj[prop] == null) obj[prop] = source[prop];
        }
      }
    });
    return obj;
  }
  /**************************************
             Public Functions
  ***************************************/

  function Datamap( options ) {

    if ( typeof d3 === 'undefined' || typeof topojson === 'undefined' ) {
      throw new Error('Include d3.js (v3.0.3 or greater) and topojson on this page before creating a new map');
   }
    //set options for global use
    this.options = defaults(options, defaultOptions);
    this.options.geographyConfig = defaults(options.geographyConfig, defaultOptions.geographyConfig);
    this.options.projectionConfig = defaults(options.projectionConfig, defaultOptions.projectionConfig);
    this.options.bubblesConfig = defaults(options.bubblesConfig, defaultOptions.bubblesConfig);
    this.options.arcConfig = defaults(options.arcConfig, defaultOptions.arcConfig);

    //add the SVG container
    if ( d3.select( this.options.element ).select('svg').length > 0 ) {
      addContainer.call(this, this.options.element, this.options.height, this.options.width );
    }

    /* Add core plugins to this instance */
    this.addPlugin('bubbles', handleBubbles);
    this.addPlugin('legend', addLegend);
    this.addPlugin('arc', handleArcs);
    this.addPlugin('labels', handleLabels);
    this.addPlugin('graticule', addGraticule);

    //append style block with basic hoverover styles
    if ( ! this.options.disableDefaultStyles ) {
      addStyleBlock();
    }

    return this.draw();
  }

  // resize map
  Datamap.prototype.resize = function () {

    var self = this;
    var options = self.options;

    if (options.responsive) {
      var newsize = options.element.clientWidth,
          oldsize = d3.select( options.element).select('svg').attr('data-width');

      d3.select(options.element).select('svg').selectAll('g').attr('transform', 'scale(' + (newsize / oldsize) + ')');
    }
  }

  // actually draw the features(states & countries)
  Datamap.prototype.draw = function() {
    //save off in a closure
    var self = this;
    var options = self.options;

    //set projections and paths based on scope
    var pathAndProjection = options.setProjection.apply(self, [options.element, options] );

    this.path = pathAndProjection.path;
    this.projection = pathAndProjection.projection;

    //if custom URL for topojson data, retrieve it and render
    if ( options.geographyConfig.dataUrl ) {
      d3.json( options.geographyConfig.dataUrl, function(error, results) {
        if ( error ) throw new Error(error);
        self.customTopo = results;
        draw( results );
      });
    }
    else {
      draw( this[options.scope + 'Topo'] || options.geographyConfig.dataJson);
    }

    return this;

      function draw (data) {
        // if fetching remote data, draw the map first then call `updateChoropleth`
        if ( self.options.dataUrl ) {
          //allow for csv or json data types
          d3[self.options.dataType](self.options.dataUrl, function(data) {
            //in the case of csv, transform data to object
            if ( self.options.dataType === 'csv' && (data && data.slice) ) {
              var tmpData = {};
              for(var i = 0; i < data.length; i++) {
                tmpData[data[i].id] = data[i];
              }
              data = tmpData;
            }
            Datamaps.prototype.updateChoropleth.call(self, data);
          });
        }
        drawSubunits.call(self, data);
        handleGeographyConfig.call(self);

        if ( self.options.geographyConfig.popupOnHover || self.options.bubblesConfig.popupOnHover) {
          d3.select( self.options.element ).append('div')
            .attr('class', 'datamaps-hoverover')
            .style('z-index', 10001)
            .style('position', 'absolute');
        }

        //fire off finished callback
        self.options.done(self);
      }
  };
  /**************************************
                TopoJSON
  ***************************************/
  Datamap.prototype.worldTopo = {
    "type": "Topology",
    "objects": {
        "world": {
            "type": "GeometryCollection",
            "geometries": [{
                "type": "Polygon",
                "properties": {
                    "name": "Afghanistan"
                },
                "id": "AFG",
                "arcs": [
                    [0, 1, 2, 3, 4, 5]
                ]
            }, {
                "type": "MultiPolygon",
                "properties": {
                    "name": "Angola"
                },
                "id": "AGO",
                "arcs": [
                    [
                        [6, 7, 8, 9]
                    ],
                    [
                        [10, 11, 12]
                    ]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Albania"
                },
                "id": "ALB",
                "arcs": [
                    [13, 14, 15, 16, 17]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "United Arab Emirates"
                },
                "id": "ARE",
                "arcs": [
                    [18, 19, 20, 21, 22]
                ]
            }, {
                "type": "MultiPolygon",
                "properties": {
                    "name": "Argentina"
                },
                "id": "ARG",
                "arcs": [
                    [
                        [23, 24]
                    ],
                    [
                        [25, 26, 27, 28, 29, 30]
                    ]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Armenia"
                },
                "id": "ARM",
                "arcs": [
                    [31, 32, 33, 34, 35]
                ]
            }, {
                "type": "MultiPolygon",
                "properties": {
                    "name": "Antarctica"
                },
                "id": "ATA",
                "arcs": [
                    [
                        [36]
                    ],
                    [
                        [37]
                    ],
                    [
                        [38]
                    ],
                    [
                        [39]
                    ],
                    [
                        [40]
                    ],
                    [
                        [41]
                    ],
                    [
                        [42]
                    ],
                    [
                        [43]
                    ]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "French Southern and Antarctic Lands"
                },
                "id": "ATF",
                "arcs": [
                    [44]
                ]
            }, {
                "type": "MultiPolygon",
                "properties": {
                    "name": "Australia"
                },
                "id": "AUS",
                "arcs": [
                    [
                        [45]
                    ],
                    [
                        [46]
                    ]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Austria"
                },
                "id": "AUT",
                "arcs": [
                    [47, 48, 49, 50, 51, 52, 53]
                ]
            }, {
                "type": "MultiPolygon",
                "properties": {
                    "name": "Azerbaijan"
                },
                "id": "AZE",
                "arcs": [
                    [
                        [54, -35]
                    ],
                    [
                        [55, 56, -33, 57, 58]
                    ]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Burundi"
                },
                "id": "BDI",
                "arcs": [
                    [59, 60, 61]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Belgium"
                },
                "id": "BEL",
                "arcs": [
                    [62, 63, 64, 65, 66]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Benin"
                },
                "id": "BEN",
                "arcs": [
                    [67, 68, 69, 70, 71]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Burkina Faso"
                },
                "id": "BFA",
                "arcs": [
                    [72, 73, 74, -70, 75, 76]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Bangladesh"
                },
                "id": "BGD",
                "arcs": [
                    [77, 78, 79]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Bulgaria"
                },
                "id": "BGR",
                "arcs": [
                    [80, 81, 82, 83, 84, 85]
                ]
            }, {
                "type": "MultiPolygon",
                "properties": {
                    "name": "The Bahamas"
                },
                "id": "BHS",
                "arcs": [
                    [
                        [86]
                    ],
                    [
                        [87]
                    ],
                    [
                        [88]
                    ]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Bosnia and Herzegovina"
                },
                "id": "BIH",
                "arcs": [
                    [89, 90, 91]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Belarus"
                },
                "id": "BLR",
                "arcs": [
                    [92, 93, 94, 95, 96]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Belize"
                },
                "id": "BLZ",
                "arcs": [
                    [97, 98, 99]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Bolivia"
                },
                "id": "BOL",
                "arcs": [
                    [100, 101, 102, 103, -31]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Brazil"
                },
                "id": "BRA",
                "arcs": [
                    [-27, 104, -103, 105, 106, 107, 108, 109, 110, 111, 112]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Brunei"
                },
                "id": "BRN",
                "arcs": [
                    [113, 114]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Bhutan"
                },
                "id": "BTN",
                "arcs": [
                    [115, 116]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Botswana"
                },
                "id": "BWA",
                "arcs": [
                    [117, 118, 119, 120]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Central African Republic"
                },
                "id": "CAF",
                "arcs": [
                    [121, 122, 123, 124, 125, 126, 127]
                ]
            }, {
                "type": "MultiPolygon",
                "properties": {
                    "name": "Canada"
                },
                "id": "CAN",
                "arcs": [
                    [
                        [128]
                    ],
                    [
                        [129]
                    ],
                    [
                        [130]
                    ],
                    [
                        [131]
                    ],
                    [
                        [132]
                    ],
                    [
                        [133]
                    ],
                    [
                        [134]
                    ],
                    [
                        [135]
                    ],
                    [
                        [136]
                    ],
                    [
                        [137]
                    ],
                    [
                        [138, 139, 140, 141]
                    ],
                    [
                        [142]
                    ],
                    [
                        [143]
                    ],
                    [
                        [144]
                    ],
                    [
                        [145]
                    ],
                    [
                        [146]
                    ],
                    [
                        [147]
                    ],
                    [
                        [148]
                    ],
                    [
                        [149]
                    ],
                    [
                        [150]
                    ],
                    [
                        [151]
                    ],
                    [
                        [152]
                    ],
                    [
                        [153]
                    ],
                    [
                        [154]
                    ],
                    [
                        [155]
                    ],
                    [
                        [156]
                    ],
                    [
                        [157]
                    ],
                    [
                        [158]
                    ],
                    [
                        [159]
                    ],
                    [
                        [160]
                    ]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Switzerland"
                },
                "id": "CHE",
                "arcs": [
                    [-51, 161, 162, 163]
                ]
            }, {
                "type": "MultiPolygon",
                "properties": {
                    "name": "Chile"
                },
                "id": "CHL",
                "arcs": [
                    [
                        [-24, 164]
                    ],
                    [
                        [-30, 165, 166, -101]
                    ]
                ]
            }, {
                "type": "MultiPolygon",
                "properties": {
                    "name": "China"
                },
                "id": "CHN",
                "arcs": [
                    [
                        [167]
                    ],
                    [
                        [168, 169, 170, 171, 172, 173, -117, 174, 175, 176, 177, -4, 178, 179, 180, 181, 182, 183]
                    ]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Ivory Coast"
                },
                "id": "CIV",
                "arcs": [
                    [184, 185, 186, 187, -73, 188]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Cameroon"
                },
                "id": "CMR",
                "arcs": [
                    [189, 190, 191, 192, 193, 194, -128, 195]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Democratic Republic of the Congo"
                },
                "id": "COD",
                "arcs": [
                    [196, 197, -60, 198, 199, -10, 200, -13, 201, -126, 202]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Republic of the Congo"
                },
                "id": "COG",
                "arcs": [
                    [-12, 203, 204, -196, -127, -202]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Colombia"
                },
                "id": "COL",
                "arcs": [
                    [205, 206, 207, 208, 209, -107, 210]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Costa Rica"
                },
                "id": "CRI",
                "arcs": [
                    [211, 212, 213, 214]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Cuba"
                },
                "id": "CUB",
                "arcs": [
                    [215]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Northern Cyprus"
                },
                "id": "-99",
                "arcs": [
                    [216, 217]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Cyprus"
                },
                "id": "CYP",
                "arcs": [
                    [218, -218]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Czech Republic"
                },
                "id": "CZE",
                "arcs": [
                    [-53, 219, 220, 221]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Germany"
                },
                "id": "DEU",
                "arcs": [
                    [222, 223, -220, -52, -164, 224, 225, -64, 226, 227, 228]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Djibouti"
                },
                "id": "DJI",
                "arcs": [
                    [229, 230, 231, 232]
                ]
            }, {
                "type": "MultiPolygon",
                "properties": {
                    "name": "Denmark"
                },
                "id": "DNK",
                "arcs": [
                    [
                        [233]
                    ],
                    [
                        [-229, 234]
                    ]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Dominican Republic"
                },
                "id": "DOM",
                "arcs": [
                    [235, 236]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Algeria"
                },
                "id": "DZA",
                "arcs": [
                    [237, 238, 239, 240, 241, 242, 243, 244]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Ecuador"
                },
                "id": "ECU",
                "arcs": [
                    [245, -206, 246]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Egypt"
                },
                "id": "EGY",
                "arcs": [
                    [247, 248, 249, 250, 251]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Eritrea"
                },
                "id": "ERI",
                "arcs": [
                    [252, 253, 254, -233]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Spain"
                },
                "id": "ESP",
                "arcs": [
                    [255, 256, 257, 258]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Estonia"
                },
                "id": "EST",
                "arcs": [
                    [259, 260, 261]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Ethiopia"
                },
                "id": "ETH",
                "arcs": [
                    [-232, 262, 263, 264, 265, 266, 267, -253]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Finland"
                },
                "id": "FIN",
                "arcs": [
                    [268, 269, 270, 271]
                ]
            }, {
                "type": "MultiPolygon",
                "properties": {
                    "name": "Fiji"
                },
                "id": "FJI",
                "arcs": [
                    [
                        [272]
                    ],
                    [
                        [273, 274]
                    ],
                    [
                        [275, -275]
                    ]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Falkland Islands"
                },
                "id": "FLK",
                "arcs": [
                    [276]
                ]
            }, {
                "type": "MultiPolygon",
                "properties": {
                    "name": "France"
                },
                "id": "FRA",
                "arcs": [
                    [
                        [277]
                    ],
                    [
                        [278, -225, -163, 279, 280, -257, 281, -66]
                    ]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "French Guiana"
                },
                "id": "GUF",
                "arcs": [
                    [282, 283, 284, 285, -111]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Gabon"
                },
                "id": "GAB",
                "arcs": [
                    [286, 287, -190, -205]
                ]
            }, {
                "type": "MultiPolygon",
                "properties": {
                    "name": "United Kingdom"
                },
                "id": "GBR",
                "arcs": [
                    [
                        [288, 289]
                    ],
                    [
                        [290]
                    ]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Georgia"
                },
                "id": "GEO",
                "arcs": [
                    [291, 292, -58, -32, 293]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Ghana"
                },
                "id": "GHA",
                "arcs": [
                    [294, -189, -77, 295]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Guinea"
                },
                "id": "GIN",
                "arcs": [
                    [296, 297, 298, 299, 300, 301, -187]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Gambia"
                },
                "id": "GMB",
                "arcs": [
                    [302, 303]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Guinea Bissau"
                },
                "id": "GNB",
                "arcs": [
                    [304, 305, -300]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Equatorial Guinea"
                },
                "id": "GNQ",
                "arcs": [
                    [306, -191, -288]
                ]
            }, {
                "type": "MultiPolygon",
                "properties": {
                    "name": "Greece"
                },
                "id": "GRC",
                "arcs": [
                    [
                        [307]
                    ],
                    [
                        [308, -15, 309, -84, 310]
                    ]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Greenland"
                },
                "id": "GRL",
                "arcs": [
                    [311]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Guatemala"
                },
                "id": "GTM",
                "arcs": [
                    [312, 313, -100, 314, 315, 316]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Guyana"
                },
                "id": "GUY",
                "arcs": [
                    [317, 318, -109, 319]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Honduras"
                },
                "id": "HND",
                "arcs": [
                    [320, 321, -316, 322, 323]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Croatia"
                },
                "id": "HRV",
                "arcs": [
                    [324, -92, 325, 326, 327, 328]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Haiti"
                },
                "id": "HTI",
                "arcs": [
                    [-237, 329]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Hungary"
                },
                "id": "HUN",
                "arcs": [
                    [-48, 330, 331, 332, 333, -329, 334]
                ]
            }, {
                "type": "MultiPolygon",
                "properties": {
                    "name": "Indonesia"
                },
                "id": "IDN",
                "arcs": [
                    [
                        [335]
                    ],
                    [
                        [336, 337]
                    ],
                    [
                        [338]
                    ],
                    [
                        [339]
                    ],
                    [
                        [340]
                    ],
                    [
                        [341]
                    ],
                    [
                        [342]
                    ],
                    [
                        [343]
                    ],
                    [
                        [344, 345]
                    ],
                    [
                        [346]
                    ],
                    [
                        [347]
                    ],
                    [
                        [348, 349]
                    ],
                    [
                        [350]
                    ]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "India"
                },
                "id": "IND",
                "arcs": [
                    [-177, 351, -175, -116, -174, 352, -80, 353, 354]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Ireland"
                },
                "id": "IRL",
                "arcs": [
                    [355, -289]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Iran"
                },
                "id": "IRN",
                "arcs": [
                    [356, -6, 357, 358, 359, 360, -55, -34, -57, 361]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Iraq"
                },
                "id": "IRQ",
                "arcs": [
                    [362, 363, 364, 365, 366, 367, -360]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Iceland"
                },
                "id": "ISL",
                "arcs": [
                    [368]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Israel"
                },
                "id": "ISR",
                "arcs": [
                    [369, 370, 371, -252, 372, 373, 374]
                ]
            }, {
                "type": "MultiPolygon",
                "properties": {
                    "name": "Italy"
                },
                "id": "ITA",
                "arcs": [
                    [
                        [375]
                    ],
                    [
                        [376]
                    ],
                    [
                        [377, 378, -280, -162, -50]
                    ]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Jamaica"
                },
                "id": "JAM",
                "arcs": [
                    [379]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Jordan"
                },
                "id": "JOR",
                "arcs": [
                    [-370, 380, -366, 381, 382, -372, 383]
                ]
            }, {
                "type": "MultiPolygon",
                "properties": {
                    "name": "Japan"
                },
                "id": "JPN",
                "arcs": [
                    [
                        [384]
                    ],
                    [
                        [385]
                    ],
                    [
                        [386]
                    ]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Kazakhstan"
                },
                "id": "KAZ",
                "arcs": [
                    [387, 388, 389, 390, -181, 391]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Kenya"
                },
                "id": "KEN",
                "arcs": [
                    [392, 393, 394, 395, -265, 396]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Kyrgyzstan"
                },
                "id": "KGZ",
                "arcs": [
                    [-392, -180, 397, 398]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Cambodia"
                },
                "id": "KHM",
                "arcs": [
                    [399, 400, 401, 402]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "South Korea"
                },
                "id": "KOR",
                "arcs": [
                    [403, 404]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Kosovo"
                },
                "id": "-99",
                "arcs": [
                    [-18, 405, 406, 407]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Kuwait"
                },
                "id": "KWT",
                "arcs": [
                    [408, 409, -364]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Laos"
                },
                "id": "LAO",
                "arcs": [
                    [410, 411, -172, 412, -401]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Lebanon"
                },
                "id": "LBN",
                "arcs": [
                    [-374, 413, 414]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Liberia"
                },
                "id": "LBR",
                "arcs": [
                    [415, 416, -297, -186]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Libya"
                },
                "id": "LBY",
                "arcs": [
                    [417, -245, 418, 419, -250, 420, 421]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Sri Lanka"
                },
                "id": "LKA",
                "arcs": [
                    [422]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Lesotho"
                },
                "id": "LSO",
                "arcs": [
                    [423]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Lithuania"
                },
                "id": "LTU",
                "arcs": [
                    [424, 425, 426, -93, 427]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Luxembourg"
                },
                "id": "LUX",
                "arcs": [
                    [-226, -279, -65]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Latvia"
                },
                "id": "LVA",
                "arcs": [
                    [428, -262, 429, -94, -427]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Morocco"
                },
                "id": "MAR",
                "arcs": [
                    [-242, 430, 431]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Moldova"
                },
                "id": "MDA",
                "arcs": [
                    [432, 433]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Madagascar"
                },
                "id": "MDG",
                "arcs": [
                    [434]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Mexico"
                },
                "id": "MEX",
                "arcs": [
                    [435, -98, -314, 436, 437]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Macedonia"
                },
                "id": "MKD",
                "arcs": [
                    [-408, 438, -85, -310, -14]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Mali"
                },
                "id": "MLI",
                "arcs": [
                    [439, -239, 440, -74, -188, -302, 441]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Myanmar"
                },
                "id": "MMR",
                "arcs": [
                    [442, -78, -353, -173, -412, 443]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Montenegro"
                },
                "id": "MNE",
                "arcs": [
                    [444, -326, -91, 445, -406, -17]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Mongolia"
                },
                "id": "MNG",
                "arcs": [
                    [446, -183]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Mozambique"
                },
                "id": "MOZ",
                "arcs": [
                    [447, 448, 449, 450, 451, 452, 453, 454]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Mauritania"
                },
                "id": "MRT",
                "arcs": [
                    [455, 456, 457, -240, -440]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Malawi"
                },
                "id": "MWI",
                "arcs": [
                    [-455, 458, 459]
                ]
            }, {
                "type": "MultiPolygon",
                "properties": {
                    "name": "Malaysia"
                },
                "id": "MYS",
                "arcs": [
                    [
                        [460, 461]
                    ],
                    [
                        [-349, 462, -115, 463]
                    ]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Namibia"
                },
                "id": "NAM",
                "arcs": [
                    [464, -8, 465, -119, 466]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "New Caledonia"
                },
                "id": "NCL",
                "arcs": [
                    [467]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Niger"
                },
                "id": "NER",
                "arcs": [
                    [-75, -441, -238, -418, 468, -194, 469, -71]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Nigeria"
                },
                "id": "NGA",
                "arcs": [
                    [470, -72, -470, -193]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Nicaragua"
                },
                "id": "NIC",
                "arcs": [
                    [471, -324, 472, -213]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Netherlands"
                },
                "id": "NLD",
                "arcs": [
                    [-227, -63, 473]
                ]
            }, {
                "type": "MultiPolygon",
                "properties": {
                    "name": "Norway"
                },
                "id": "NOR",
                "arcs": [
                    [
                        [474, -272, 475, 476]
                    ],
                    [
                        [477]
                    ],
                    [
                        [478]
                    ],
                    [
                        [479]
                    ]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Nepal"
                },
                "id": "NPL",
                "arcs": [
                    [-352, -176]
                ]
            }, {
                "type": "MultiPolygon",
                "properties": {
                    "name": "New Zealand"
                },
                "id": "NZL",
                "arcs": [
                    [
                        [480]
                    ],
                    [
                        [481]
                    ]
                ]
            }, {
                "type": "MultiPolygon",
                "properties": {
                    "name": "Oman"
                },
                "id": "OMN",
                "arcs": [
                    [
                        [482, 483, -22, 484]
                    ],
                    [
                        [-20, 485]
                    ]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Pakistan"
                },
                "id": "PAK",
                "arcs": [
                    [-178, -355, 486, -358, -5]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Panama"
                },
                "id": "PAN",
                "arcs": [
                    [487, -215, 488, -208]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Peru"
                },
                "id": "PER",
                "arcs": [
                    [-167, 489, -247, -211, -106, -102]
                ]
            }, {
                "type": "MultiPolygon",
                "properties": {
                    "name": "Philippines"
                },
                "id": "PHL",
                "arcs": [
                    [
                        [490]
                    ],
                    [
                        [491]
                    ],
                    [
                        [492]
                    ],
                    [
                        [493]
                    ],
                    [
                        [494]
                    ],
                    [
                        [495]
                    ],
                    [
                        [496]
                    ]
                ]
            }, {
                "type": "MultiPolygon",
                "properties": {
                    "name": "Papua New Guinea"
                },
                "id": "PNG",
                "arcs": [
                    [
                        [497]
                    ],
                    [
                        [498]
                    ],
                    [
                        [-345, 499]
                    ],
                    [
                        [500]
                    ]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Poland"
                },
                "id": "POL",
                "arcs": [
                    [-224, 501, 502, -428, -97, 503, 504, -221]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Puerto Rico"
                },
                "id": "PRI",
                "arcs": [
                    [505]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "North Korea"
                },
                "id": "PRK",
                "arcs": [
                    [506, 507, -405, 508, -169]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Portugal"
                },
                "id": "PRT",
                "arcs": [
                    [-259, 509]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Paraguay"
                },
                "id": "PRY",
                "arcs": [
                    [-104, -105, -26]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Qatar"
                },
                "id": "QAT",
                "arcs": [
                    [510, 511]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Romania"
                },
                "id": "ROU",
                "arcs": [
                    [512, -434, 513, 514, -81, 515, -333]
                ]
            }, {
                "type": "MultiPolygon",
                "properties": {
                    "name": "Russia"
                },
                "id": "RUS",
                "arcs": [
                    [
                        [516]
                    ],
                    [
                        [-503, 517, -425]
                    ],
                    [
                        [518, 519]
                    ],
                    [
                        [520]
                    ],
                    [
                        [521]
                    ],
                    [
                        [522]
                    ],
                    [
                        [523]
                    ],
                    [
                        [524]
                    ],
                    [
                        [525]
                    ],
                    [
                        [526, -507, -184, -447, -182, -391, 527, -59, -293, 528, 529, -95, -430, -261, 530, -269, -475, 531, -520]
                    ],
                    [
                        [532]
                    ],
                    [
                        [533]
                    ],
                    [
                        [534]
                    ]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Rwanda"
                },
                "id": "RWA",
                "arcs": [
                    [535, -61, -198, 536]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Western Sahara"
                },
                "id": "ESH",
                "arcs": [
                    [-241, -458, 537, -431]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Saudi Arabia"
                },
                "id": "SAU",
                "arcs": [
                    [538, -382, -365, -410, 539, -512, 540, -23, -484, 541]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Sudan"
                },
                "id": "SDN",
                "arcs": [
                    [542, 543, -123, 544, -421, -249, 545, -254, -268, 546]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "South Sudan"
                },
                "id": "SSD",
                "arcs": [
                    [547, -266, -396, 548, -203, -125, 549, -543]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Senegal"
                },
                "id": "SEN",
                "arcs": [
                    [550, -456, -442, -301, -306, 551, -304]
                ]
            }, {
                "type": "MultiPolygon",
                "properties": {
                    "name": "Solomon Islands"
                },
                "id": "SLB",
                "arcs": [
                    [
                        [552]
                    ],
                    [
                        [553]
                    ],
                    [
                        [554]
                    ],
                    [
                        [555]
                    ],
                    [
                        [556]
                    ]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Sierra Leone"
                },
                "id": "SLE",
                "arcs": [
                    [557, -298, -417]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "El Salvador"
                },
                "id": "SLV",
                "arcs": [
                    [558, -317, -322]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Somaliland"
                },
                "id": "-99",
                "arcs": [
                    [-263, -231, 559, 560]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Somalia"
                },
                "id": "SOM",
                "arcs": [
                    [-397, -264, -561, 561]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Republic of Serbia"
                },
                "id": "SRB",
                "arcs": [
                    [-86, -439, -407, -446, -90, -325, -334, -516]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Suriname"
                },
                "id": "SUR",
                "arcs": [
                    [562, -285, 563, -283, -110, -319]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Slovakia"
                },
                "id": "SVK",
                "arcs": [
                    [-505, 564, -331, -54, -222]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Slovenia"
                },
                "id": "SVN",
                "arcs": [
                    [-49, -335, -328, 565, -378]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Sweden"
                },
                "id": "SWE",
                "arcs": [
                    [-476, -271, 566]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Swaziland"
                },
                "id": "SWZ",
                "arcs": [
                    [567, -451]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Syria"
                },
                "id": "SYR",
                "arcs": [
                    [-381, -375, -415, 568, 569, -367]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Chad"
                },
                "id": "TCD",
                "arcs": [
                    [-469, -422, -545, -122, -195]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Togo"
                },
                "id": "TGO",
                "arcs": [
                    [570, -296, -76, -69]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Thailand"
                },
                "id": "THA",
                "arcs": [
                    [571, -462, 572, -444, -411, -400]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Tajikistan"
                },
                "id": "TJK",
                "arcs": [
                    [-398, -179, -3, 573]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Turkmenistan"
                },
                "id": "TKM",
                "arcs": [
                    [-357, 574, -389, 575, -1]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "East Timor"
                },
                "id": "TLS",
                "arcs": [
                    [576, -337]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Trinidad and Tobago"
                },
                "id": "TTO",
                "arcs": [
                    [577]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Tunisia"
                },
                "id": "TUN",
                "arcs": [
                    [-244, 578, -419]
                ]
            }, {
                "type": "MultiPolygon",
                "properties": {
                    "name": "Turkey"
                },
                "id": "TUR",
                "arcs": [
                    [
                        [-294, -36, -361, -368, -570, 579]
                    ],
                    [
                        [-311, -83, 580]
                    ]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Taiwan"
                },
                "id": "TWN",
                "arcs": [
                    [581]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "United Republic of Tanzania"
                },
                "id": "TZA",
                "arcs": [
                    [-394, 582, -448, -460, 583, -199, -62, -536, 584]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Uganda"
                },
                "id": "UGA",
                "arcs": [
                    [-537, -197, -549, -395, -585]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Ukraine"
                },
                "id": "UKR",
                "arcs": [
                    [-530, 585, -514, -433, -513, -332, -565, -504, -96]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Uruguay"
                },
                "id": "URY",
                "arcs": [
                    [-113, 586, -28]
                ]
            }, {
                "type": "MultiPolygon",
                "properties": {
                    "name": "United States of America"
                },
                "id": "USA",
                "arcs": [
                    [
                        [587]
                    ],
                    [
                        [588]
                    ],
                    [
                        [589]
                    ],
                    [
                        [590]
                    ],
                    [
                        [591]
                    ],
                    [
                        [592, -438, 593, -139]
                    ],
                    [
                        [594]
                    ],
                    [
                        [595]
                    ],
                    [
                        [596]
                    ],
                    [
                        [-141, 597]
                    ]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Uzbekistan"
                },
                "id": "UZB",
                "arcs": [
                    [-576, -388, -399, -574, -2]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Venezuela"
                },
                "id": "VEN",
                "arcs": [
                    [598, -320, -108, -210]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Vietnam"
                },
                "id": "VNM",
                "arcs": [
                    [599, -402, -413, -171]
                ]
            }, {
                "type": "MultiPolygon",
                "properties": {
                    "name": "Vanuatu"
                },
                "id": "VUT",
                "arcs": [
                    [
                        [600]
                    ],
                    [
                        [601]
                    ]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "West Bank"
                },
                "id": "PSE",
                "arcs": [
                    [-384, -371]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Yemen"
                },
                "id": "YEM",
                "arcs": [
                    [602, -542, -483]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "South Africa"
                },
                "id": "ZAF",
                "arcs": [
                    [-467, -118, 603, -452, -568, -450, 604],
                    [-424]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Zambia"
                },
                "id": "ZMB",
                "arcs": [
                    [-459, -454, 605, -120, -466, -7, -200, -584]
                ]
            }, {
                "type": "Polygon",
                "properties": {
                    "name": "Zimbabwe"
                },
                "id": "ZWE",
                "arcs": [
                    [-604, -121, -606, -453]
                ]
            }]
        }
    },
    "arcs": [
        [
            [6700, 7164],
            [28, -23],
            [21, 8],
            [6, 27],
            [22, 9],
            [15, 18],
            [6, 47],
            [23, 11],
            [5, 21],
            [13, -15],
            [8, -2]
        ],
        [
            [6847, 7265],
            [16, -1],
            [20, -12]
        ],
        [
            [6883, 7252],
            [9, -7],
            [20, 19],
            [9, -12],
            [9, 27],
            [17, -1],
            [4, 9],
            [3, 24],
            [12, 20],
            [15, -13],
            [-3, -18],
            [9, -3],
            [-3, -50],
            [11, -19],
            [10, 12],
            [12, 6],
            [17, 27],
            [19, -5],
            [29, 0]
        ],
        [
            [7082, 7268],
            [5, -17]
        ],
        [
            [7087, 7251],
            [-16, -6],
            [-14, -11],
            [-32, -7],
            [-30, -13],
            [-16, -25],
            [6, -25],
            [4, -30],
            [-14, -25],
            [1, -22],
            [-8, -22],
            [-26, 2],
            [11, -39],
            [-18, -15],
            [-12, -35],
            [2, -36],
            [-11, -16],
            [-10, 5],
            [-22, -8],
            [-3, -16],
            [-20, 0],
            [-16, -34],
            [-1, -50],
            [-36, -24],
            [-19, 5],
            [-6, -13],
            [-16, 7],
            [-28, -8],
            [-47, 30]
        ],
        [
            [6690, 6820],
            [25, 53],
            [-2, 38],
            [-21, 10],
            [-2, 38],
            [-9, 47],
            [12, 32],
            [-12, 9],
            [7, 43],
            [12, 74]
        ],
        [
            [5664, 4412],
            [3, -18],
            [-4, -29],
            [5, -28],
            [-4, -22],
            [3, -20],
            [-58, 1],
            [-2, -188],
            [19, -49],
            [18, -37]
        ],
        [
            [5644, 4022],
            [-51, -24],
            [-67, 9],
            [-19, 28],
            [-113, -3],
            [-4, -4],
            [-17, 27],
            [-18, 2],
            [-16, -10],
            [-14, -12]
        ],
        [
            [5325, 4035],
            [-2, 38],
            [4, 51],
            [9, 55],
            [2, 25],
            [9, 53],
            [6, 24],
            [16, 39],
            [9, 26],
            [3, 44],
            [-1, 34],
            [-9, 21],
            [-7, 36],
            [-7, 35],
            [2, 12],
            [8, 24],
            [-8, 57],
            [-6, 39],
            [-14, 38],
            [3, 11]
        ],
        [
            [5342, 4697],
            [11, 8],
            [8, -1],
            [10, 7],
            [82, -1],
            [7, -44],
            [8, -35],
            [6, -19],
            [11, -31],
            [18, 5],
            [9, 8],
            [16, -8],
            [4, 14],
            [7, 35],
            [17, 2],
            [2, 10],
            [14, 1],
            [-3, -22],
            [34, 1],
            [1, -37],
            [5, -23],
            [-4, -36],
            [2, -36],
            [9, -22],
            [-1, -70],
            [7, 5],
            [12, -1],
            [17, 8],
            [13, -3]
        ],
        [
            [5338, 4715],
            [-8, 45]
        ],
        [
            [5330, 4760],
            [12, 25],
            [8, 10],
            [10, -20]
        ],
        [
            [5360, 4775],
            [-10, -12],
            [-4, -16],
            [-1, -25],
            [-7, -7]
        ],
        [
            [5571, 7530],
            [-3, -20],
            [4, -25],
            [11, -15]
        ],
        [
            [5583, 7470],
            [0, -15],
            [-9, -9],
            [-2, -19],
            [-13, -29]
        ],
        [
            [5559, 7398],
            [-5, 5],
            [0, 13],
            [-15, 19],
            [-3, 29],
            [2, 40],
            [4, 18],
            [-4, 10]
        ],
        [
            [5538, 7532],
            [-2, 18],
            [12, 29],
            [1, -11],
            [8, 6]
        ],
        [
            [5557, 7574],
            [6, -16],
            [7, -6],
            [1, -22]
        ],
        [
            [6432, 6490],
            [5, 3],
            [1, -16],
            [22, 9],
            [23, -2],
            [17, -1],
            [19, 39],
            [20, 38],
            [18, 37]
        ],
        [
            [6557, 6597],
            [5, -20]
        ],
        [
            [6562, 6577],
            [4, -47]
        ],
        [
            [6566, 6530],
            [-14, 0],
            [-3, -39],
            [5, -8],
            [-12, -12],
            [0, -24],
            [-8, -24],
            [-1, -24]
        ],
        [
            [6533, 6399],
            [-6, -12],
            [-83, 29],
            [-11, 60],
            [-1, 14]
        ],
        [
            [3140, 1814],
            [-17, 2],
            [-30, 0],
            [0, 132]
        ],
        [
            [3093, 1948],
            [11, -27],
            [14, -45],
            [36, -35],
            [39, -15],
            [-13, -30],
            [-26, -2],
            [-14, 20]
        ],
        [
            [3258, 3743],
            [51, -96],
            [23, -9],
            [34, -44],
            [29, -23],
            [4, -26],
            [-28, -90],
            [28, -16],
            [32, -9],
            [22, 10],
            [25, 45],
            [4, 52]
        ],
        [
            [3482, 3537],
            [14, 11],
            [14, -34],
            [-1, -47],
            [-23, -33],
            [-19, -24],
            [-31, -57],
            [-37, -81]
        ],
        [
            [3399, 3272],
            [-7, -47],
            [-7, -61],
            [0, -58],
            [-6, -14],
            [-2, -38]
        ],
        [
            [3377, 3054],
            [-2, -31],
            [35, -50],
            [-4, -41],
            [18, -26],
            [-2, -29],
            [-26, -75],
            [-42, -32],
            [-55, -12],
            [-31, 6],
            [6, -36],
            [-6, -44],
            [5, -30],
            [-16, -20],
            [-29, -8],
            [-26, 21],
            [-11, -15],
            [4, -59],
            [18, -18],
            [16, 19],
            [8, -31],
            [-26, -18],
            [-22, -37],
            [-4, -59],
            [-7, -32],
            [-26, 0],
            [-22, -31],
            [-8, -44],
            [28, -43],
            [26, -12],
            [-9, -53],
            [-33, -33],
            [-18, -70],
            [-25, -23],
            [-12, -28],
            [9, -61],
            [19, -34],
            [-12, 3]
        ],
        [
            [3095, 1968],
            [-26, 9],
            [-67, 8],
            [-11, 34],
            [0, 45],
            [-18, -4],
            [-10, 21],
            [-3, 63],
            [22, 26],
            [9, 37],
            [-4, 30],
            [15, 51],
            [10, 78],
            [-3, 35],
            [12, 11],
            [-3, 22],
            [-13, 12],
            [10, 25],
            [-13, 22],
            [-6, 68],
            [11, 12],
            [-5, 72],
            [7, 61],
            [7, 52],
            [17, 22],
            [-9, 58],
            [0, 54],
            [21, 38],
            [-1, 50],
            [16, 57],
            [0, 55],
            [-7, 11],
            [-13, 102],
            [17, 60],
            [-2, 58],
            [10, 53],
            [18, 56],
            [20, 36],
            [-9, 24],
            [6, 19],
            [-1, 98],
            [30, 29],
            [10, 62],
            [-3, 14]
        ],
        [
            [3136, 3714],
            [23, 54],
            [36, -15],
            [16, -42],
            [11, 47],
            [32, -2],
            [4, -13]
        ],
        [
            [6210, 7485],
            [39, 9]
        ],
        [
            [6249, 7494],
            [5, -15],
            [11, -10],
            [-6, -15],
            [15, -21],
            [-8, -18],
            [12, -16],
            [13, -10],
            [0, -41]
        ],
        [
            [6291, 7348],
            [-10, -2]
        ],
        [
            [6281, 7346],
            [-11, 34],
            [0, 10],
            [-12, -1],
            [-9, 16],
            [-5, -1]
        ],
        [
            [6244, 7404],
            [-11, 17],
            [-21, 15],
            [3, 28],
            [-5, 21]
        ],
        [
            [3345, 329],
            [-8, -30],
            [-8, -27],
            [-59, 8],
            [-62, -3],
            [-34, 20],
            [0, 2],
            [-16, 17],
            [63, -2],
            [60, -6],
            [20, 24],
            [15, 21],
            [29, -24]
        ],
        [
            [577, 361],
            [-53, -8],
            [-36, 21],
            [-17, 21],
            [-1, 3],
            [-18, 16],
            [17, 22],
            [52, -9],
            [28, -18],
            [21, -21],
            [7, -27]
        ],
        [
            [3745, 447],
            [35, -26],
            [12, -36],
            [3, -25],
            [1, -30],
            [-43, -19],
            [-45, -15],
            [-52, -14],
            [-59, -11],
            [-65, 3],
            [-37, 20],
            [5, 24],
            [59, 16],
            [24, 20],
            [18, 26],
            [12, 22],
            [17, 20],
            [18, 25],
            [14, 0],
            [41, 12],
            [42, -12]
        ],
        [
            [1633, 715],
            [36, -9],
            [33, 10],
            [-16, -20],
            [-26, -15],
            [-39, 4],
            [-27, 21],
            [6, 20],
            [33, -11]
        ],
        [
            [1512, 716],
            [43, -23],
            [-17, 3],
            [-36, 5],
            [-38, 17],
            [20, 12],
            [28, -14]
        ],
        [
            [2250, 808],
            [31, -8],
            [30, 7],
            [17, -34],
            [-22, 5],
            [-34, -2],
            [-34, 2],
            [-38, -4],
            [-28, 12],
            [-15, 24],
            [18, 11],
            [35, -8],
            [40, -5]
        ],
        [
            [3098, 866],
            [4, -27],
            [-5, -23],
            [-8, -22],
            [-33, -8],
            [-31, -12],
            [-36, 1],
            [14, 24],
            [-33, -9],
            [-31, -8],
            [-21, 18],
            [-2, 24],
            [30, 23],
            [20, 7],
            [32, -2],
            [8, 30],
            [1, 22],
            [0, 47],
            [16, 28],
            [25, 9],
            [15, -22],
            [6, -22],
            [12, -26],
            [10, -26],
            [7, -26]
        ],
        [
            [3371, 1268],
            [-11, -13],
            [-21, 9],
            [-23, -6],
            [-19, -14],
            [-20, -15],
            [-14, -17],
            [-4, -23],
            [2, -22],
            [13, -20],
            [-19, -14],
            [-26, -4],
            [-15, -20],
            [-17, -19],
            [-17, -25],
            [-4, -22],
            [9, -24],
            [15, -19],
            [23, -14],
            [21, -18],
            [12, -23],
            [6, -22],
            [8, -24],
            [13, -19],
            [8, -22],
            [4, -55],
            [8, -22],
            [2, -23],
            [9, -23],
            [-4, -31],
            [-15, -24],
            [-17, -20],
            [-37, -8],
            [-12, -21],
            [-17, -20],
            [-42, -22],
            [-37, -9],
            [-35, -13],
            [-37, -13],
            [-22, -24],
            [-45, -2],
            [-49, 2],
            [-44, -4],
            [-47, 0],
            [9, -24],
            [42, -10],
            [31, -16],
            [18, -21],
            [-31, -19],
            [-48, 6],
            [-40, -15],
            [-2, -24],
            [-1, -23],
            [33, -20],
            [6, -22],
            [35, -22],
            [59, -9],
            [50, -16],
            [40, -19],
            [50, -18],
            [70, -10],
            [68, -16],
            [47, -17],
            [52, -20],
            [27, -28],
            [13, -22],
            [34, 21],
            [46, 17],
            [48, 19],
            [58, 15],
            [49, 16],
            [69, 1],
            [68, -8],
            [56, -14],
            [18, 26],
            [39, 17],
            [70, 1],
            [55, 13],
            [52, 13],
            [58, 8],
            [62, 10],
            [43, 15],
            [-20, 21],
            [-12, 21],
            [0, 22],
            [-54, -2],
            [-57, -10],
            [-54, 0],
            [-8, 22],
            [4, 44],
            [12, 13],
            [40, 14],
            [47, 14],
            [34, 17],
            [33, 18],
            [25, 23],
            [38, 10],
            [38, 8],
            [19, 5],
            [43, 2],
            [41, 8],
            [34, 12],
            [34, 14],
            [30, 14],
            [39, 18],
            [24, 20],
            [26, 17],
            [9, 24],
            [-30, 13],
            [10, 25],
            [18, 18],
            [29, 12],
            [31, 14],
            [28, 18],
            [22, 23],
            [13, 28],
            [21, 16],
            [33, -3],
            [13, -20],
            [34, -2],
            [1, 22],
            [14, 23],
            [30, -6],
            [7, -22],
            [33, -3],
            [36, 10],
            [35, 7],
            [31, -3],
            [12, -25],
            [31, 20],
            [28, 10],
            [31, 9],
            [31, 8],
            [29, 14],
            [31, 9],
            [24, 13],
            [17, 20],
            [20, -15],
            [29, 8],
            [20, -27],
            [16, -21],
            [32, 11],
            [12, 24],
            [28, 16],
            [37, -4],
            [11, -22],
            [22, 22],
            [30, 7],
            [33, 3],
            [29, -2],
            [31, -7],
            [30, -3],
            [13, -20],
            [18, -17],
            [31, 10],
            [32, 3],
            [32, 0],
            [31, 1],
            [28, 8],
            [29, 7],
            [25, 16],
            [26, 11],
            [28, 5],
            [21, 17],
            [15, 32],
            [16, 20],
            [29, -10],
            [11, -21],
            [24, -13],
            [29, 4],
            [19, -21],
            [21, -15],
            [28, 14],
            [10, 26],
            [25, 10],
            [29, 20],
            [27, 8],
            [33, 11],
            [22, 13],
            [22, 14],
            [22, 13],
            [26, -7],
            [25, 21],
            [18, 16],
            [26, -1],
            [23, 14],
            [6, 21],
            [23, 16],
            [23, 11],
            [28, 10],
            [25, 4],
            [25, -3],
            [26, -6],
            [22, -16],
            [3, -26],
            [24, -19],
            [17, -17],
            [33, -7],
            [19, -16],
            [23, -16],
            [26, -3],
            [23, 11],
            [24, 24],
            [26, -12],
            [27, -7],
            [26, -7],
            [27, -5],
            [28, 0],
            [23, -61],
            [-1, -15],
            [-4, -27],
            [-26, -15],
            [-22, -22],
            [4, -23],
            [31, 1],
            [-4, -23],
            [-14, -22],
            [-13, -24],
            [21, -19],
            [32, -6],
            [32, 11],
            [15, 23],
            [10, 22],
            [15, 18],
            [17, 18],
            [7, 21],
            [15, 29],
            [18, 5],
            [31, 3],
            [28, 7],
            [28, 9],
            [14, 23],
            [8, 22],
            [19, 22],
            [27, 15],
            [23, 12],
            [16, 19],
            [15, 11],
            [21, 9],
            [27, -6],
            [25, 6],
            [28, 7],
            [30, -4],
            [20, 17],
            [14, 39],
            [11, -16],
            [13, -28],
            [23, -12],
            [27, -4],
            [26, 7],
            [29, -5],
            [26, -1],
            [17, 6],
            [24, -4],
            [21, -12],
            [25, 8],
            [30, 0],
            [25, 8],
            [29, -8],
            [19, 19],
            [14, 20],
            [19, 16],
            [35, 44],
            [18, -8],
            [21, -16],
            [18, -21],
            [36, -36],
            [27, -1],
            [25, 0],
            [30, 7],
            [30, 8],
            [23, 16],
            [19, 18],
            [31, 2],
            [21, 13],
            [22, -12],
            [14, -18],
            [19, -19],
            [31, 2],
            [19, -15],
            [33, -15],
            [35, -5],
            [29, 4],
            [21, 19],
            [19, 18],
            [25, 5],
            [25, -8],
            [29, -6],
            [26, 9],
            [25, 0],
            [24, -6],
            [26, -5],
            [25, 10],
            [30, 9],
            [28, 3],
            [32, 0],
            [25, 5],
            [25, 5],
            [8, 29],
            [1, 24],
            [17, -16],
            [5, -27],
            [10, -24],
            [11, -20],
            [23, -10],
            [32, 4],
            [36, 1],
            [25, 3],
            [37, 0],
            [26, 1],
            [36, -2],
            [31, -5],
            [20, -18],
            [-5, -22],
            [18, -18],
            [30, -13],
            [31, -15],
            [35, -11],
            [38, -9],
            [28, -9],
            [32, -2],
            [18, 20],
            [24, -16],
            [21, -19],
            [25, -13],
            [34, -6],
            [32, -7],
            [13, -23],
            [32, -14],
            [21, -21],
            [31, -9],
            [32, 1],
            [30, -4],
            [33, 1],
            [34, -4],
            [31, -8],
            [28, -14],
            [29, -12],
            [20, -17],
            [-3, -23],
            [-15, -21],
            [-13, -27],
            [-9, -21],
            [-14, -24],
            [-36, -9],
            [-16, -21],
            [-36, -13],
            [-13, -23],
            [-19, -22],
            [-20, -18],
            [-11, -25],
            [-7, -22],
            [-3, -26],
            [0, -22],
            [16, -23],
            [6, -22],
            [13, -21],
            [52, -8],
            [11, -26],
            [-50, -9],
            [-43, -13],
            [-52, -2],
            [-24, -34],
            [-5, -27],
            [-12, -22],
            [-14, -22],
            [37, -20],
            [14, -24],
            [24, -22],
            [33, -20],
            [39, -19],
            [42, -18],
            [64, -19],
            [14, -29],
            [80, -12],
            [5, -5],
            [21, -17],
            [77, 15],
            [63, -19],
            [48, -14],
            [-9997, -1],
            [24, 35],
            [50, -19],
            [3, 2],
            [30, 19],
            [4, 0],
            [3, -1],
            [40, -25],
            [35, 25],
            [7, 3],
            [81, 11],
            [27, -14],
            [13, -7],
            [41, -20],
            [79, -15],
            [63, -18],
            [107, -14],
            [80, 16],
            [118, -11],
            [67, -19],
            [73, 17],
            [78, 17],
            [6, 27],
            [-110, 3],
            [-89, 14],
            [-24, 23],
            [-74, 12],
            [5, 27],
            [10, 24],
            [10, 22],
            [-5, 25],
            [-46, 16],
            [-22, 21],
            [-43, 18],
            [68, -3],
            [64, 9],
            [40, -20],
            [50, 18],
            [45, 22],
            [23, 19],
            [-10, 25],
            [-36, 16],
            [-41, 17],
            [-57, 4],
            [-50, 8],
            [-54, 6],
            [-18, 22],
            [-36, 18],
            [-21, 21],
            [-9, 67],
            [14, -6],
            [25, -18],
            [45, 6],
            [44, 8],
            [23, -26],
            [44, 6],
            [37, 13],
            [35, 16],
            [32, 20],
            [41, 5],
            [-1, 22],
            [-9, 22],
            [8, 21],
            [36, 11],
            [16, -20],
            [42, 12],
            [32, 15],
            [40, 1],
            [38, 6],
            [37, 13],
            [30, 13],
            [34, 13],
            [22, -4],
            [19, -4],
            [41, 8],
            [37, -10],
            [38, 1],
            [37, 8],
            [37, -6],
            [41, -6],
            [39, 3],
            [40, -2],
            [42, -1],
            [38, 3],
            [28, 17],
            [34, 9],
            [35, -13],
            [33, 11],
            [30, 21],
            [18, -19],
            [9, -21],
            [18, -19],
            [29, 17],
            [33, -22],
            [38, -7],
            [32, -16],
            [39, 3],
            [36, 11],
            [41, -3],
            [38, -8],
            [38, -10],
            [15, 25],
            [-18, 20],
            [-14, 21],
            [-36, 5],
            [-15, 22],
            [-6, 22],
            [-10, 43],
            [21, -8],
            [36, -3],
            [36, 3],
            [33, -9],
            [28, -17],
            [12, -21],
            [38, -4],
            [36, 9],
            [38, 11],
            [34, 7],
            [28, -14],
            [37, 5],
            [24, 45],
            [23, -27],
            [32, -10],
            [34, 6],
            [23, -23],
            [37, -3],
            [33, -7],
            [34, -12],
            [21, 22],
            [11, 20],
            [28, -23],
            [38, 6],
            [28, -13],
            [19, -19],
            [37, 5],
            [29, 13],
            [29, 15],
            [33, 8],
            [39, 7],
            [36, 8],
            [27, 13],
            [16, 19],
            [7, 25],
            [-3, 24],
            [-9, 24],
            [-10, 23],
            [-9, 23],
            [-7, 21],
            [-1, 23],
            [2, 23],
            [13, 22],
            [11, 24],
            [5, 23],
            [-6, 26],
            [-3, 23],
            [14, 27],
            [15, 17],
            [18, 22],
            [19, 19],
            [22, 17],
            [11, 25],
            [15, 17],
            [18, 15],
            [26, 3],
            [18, 19],
            [19, 11],
            [23, 7],
            [20, 15],
            [16, 19],
            [22, 7],
            [16, -15],
            [-10, -20],
            [-29, -17]
        ],
        [
            [6914, 2185],
            [18, -19],
            [26, -7],
            [1, -11],
            [-7, -27],
            [-43, -4],
            [-1, 31],
            [4, 25],
            [2, 12]
        ],
        [
            [9038, 2648],
            [27, -21],
            [15, 8],
            [22, 12],
            [16, -4],
            [2, -70],
            [-9, -21],
            [-3, -47],
            [-10, 16],
            [-19, -41],
            [-6, 3],
            [-17, 2],
            [-17, 50],
            [-4, 39],
            [-16, 52],
            [1, 27],
            [18, -5]
        ],
        [
            [8987, 4244],
            [10, -46],
            [18, 22],
            [9, -25],
            [13, -23],
            [-3, -26],
            [6, -51],
            [5, -29],
            [7, -7],
            [7, -51],
            [-3, -30],
            [9, -40],
            [31, -31],
            [19, -28],
            [19, -26],
            [-4, -14],
            [16, -37],
            [11, -64],
            [11, 13],
            [11, -26],
            [7, 9],
            [5, -63],
            [19, -36],
            [13, -22],
            [22, -48],
            [8, -48],
            [1, -33],
            [-2, -37],
            [13, -50],
            [-2, -52],
            [-5, -28],
            [-7, -52],
            [1, -34],
            [-6, -43],
            [-12, -53],
            [-21, -29],
            [-10, -46],
            [-9, -29],
            [-8, -51],
            [-11, -30],
            [-7, -44],
            [-4, -41],
            [2, -18],
            [-16, -21],
            [-31, -2],
            [-26, -24],
            [-13, -23],
            [-17, -26],
            [-23, 27],
            [-17, 10],
            [5, 31],
            [-15, -11],
            [-25, -43],
            [-24, 16],
            [-15, 9],
            [-16, 4],
            [-27, 17],
            [-18, 37],
            [-5, 45],
            [-7, 30],
            [-13, 24],
            [-27, 7],
            [9, 28],
            [-7, 44],
            [-13, -41],
            [-25, -11],
            [14, 33],
            [5, 34],
            [10, 29],
            [-2, 44],
            [-22, -50],
            [-18, -21],
            [-10, -47],
            [-22, 25],
            [1, 31],
            [-18, 43],
            [-14, 22],
            [5, 14],
            [-36, 35],
            [-19, 2],
            [-27, 29],
            [-50, -6],
            [-36, -21],
            [-31, -20],
            [-27, 4],
            [-29, -30],
            [-24, -14],
            [-6, -31],
            [-10, -24],
            [-23, -1],
            [-18, -5],
            [-24, 10],
            [-20, -6],
            [-19, -3],
            [-17, -31],
            [-8, 2],
            [-14, -16],
            [-13, -19],
            [-21, 2],
            [-18, 0],
            [-30, 38],
            [-15, 11],
            [1, 34],
            [14, 8],
            [4, 14],
            [-1, 21],
            [4, 41],
            [-3, 35],
            [-15, 60],
            [-4, 33],
            [1, 34],
            [-11, 38],
            [-1, 18],
            [-12, 23],
            [-4, 47],
            [-16, 46],
            [-4, 26],
            [13, -26],
            [-10, 55],
            [14, -17],
            [8, -23],
            [0, 30],
            [-14, 47],
            [-3, 18],
            [-6, 18],
            [3, 34],
            [6, 15],
            [4, 29],
            [-3, 35],
            [11, 42],
            [2, -45],
            [12, 41],
            [22, 20],
            [14, 25],
            [21, 22],
            [13, 4],
            [7, -7],
            [22, 22],
            [17, 6],
            [4, 13],
            [8, 6],
            [15, -2],
            [29, 18],
            [15, 26],
            [7, 31],
            [17, 30],
            [1, 24],
            [1, 32],
            [19, 50],
            [12, -51],
            [12, 12],
            [-10, 28],
            [9, 29],
            [12, -13],
            [3, 45],
            [15, 29],
            [7, 23],
            [14, 10],
            [0, 17],
            [13, -7],
            [0, 15],
            [12, 8],
            [14, 8],
            [20, -27],
            [16, -35],
            [17, 0],
            [18, -6],
            [-6, 33],
            [13, 47],
            [13, 15],
            [-5, 15],
            [12, 34],
            [17, 21],
            [14, -7],
            [24, 11],
            [-1, 30],
            [-20, 19],
            [15, 9],
            [18, -15],
            [15, -24],
            [23, -15],
            [8, 6],
            [17, -18],
            [17, 17],
            [10, -5],
            [7, 11],
            [12, -29],
            [-7, -32],
            [-11, -24],
            [-9, -2],
            [3, -23],
            [-8, -30],
            [-10, -29],
            [2, -17],
            [22, -32],
            [21, -19],
            [15, -20],
            [20, -35],
            [8, 0],
            [14, -15],
            [4, -19],
            [27, -20],
            [18, 20],
            [6, 32],
            [5, 26],
            [4, 33],
            [8, 47],
            [-4, 28],
            [2, 17],
            [-3, 34],
            [4, 45],
            [5, 12],
            [-4, 20],
            [7, 31],
            [5, 32],
            [1, 17],
            [10, 22],
            [8, -29],
            [2, -37],
            [7, -7],
            [1, -25],
            [10, -30],
            [2, -33],
            [-1, -22]
        ],
        [
            [5471, 7900],
            [-2, -24],
            [-16, 0],
            [6, -13],
            [-9, -38]
        ],
        [
            [5450, 7825],
            [-6, -10],
            [-24, -1],
            [-14, -13],
            [-23, 4]
        ],
        [
            [5383, 7805],
            [-40, 15],
            [-6, 21],
            [-27, -10],
            [-4, -12],
            [-16, 9]
        ],
        [
            [5290, 7828],
            [-15, 1],
            [-12, 11],
            [4, 15],
            [-1, 10]
        ],
        [
            [5266, 7865],
            [8, 3],
            [14, -16],
            [4, 16],
            [25, -3],
            [20, 11],
            [13, -2],
            [9, -12],
            [2, 10],
            [-4, 38],
            [10, 8],
            [10, 27]
        ],
        [
            [5377, 7945],
            [21, -19],
            [15, 24],
            [10, 5],
            [22, -18],
            [13, 3],
            [13, -12]
        ],
        [
            [5471, 7928],
            [-3, -7],
            [3, -21]
        ],
        [
            [6281, 7346],
            [-19, 8],
            [-14, 27],
            [-4, 23]
        ],
        [
            [6349, 7527],
            [15, -31],
            [14, -42],
            [13, -2],
            [8, -16],
            [-23, -5],
            [-5, -46],
            [-4, -21],
            [-11, -13],
            [1, -30]
        ],
        [
            [6357, 7321],
            [-7, -3],
            [-17, 31],
            [10, 30],
            [-9, 17],
            [-10, -4],
            [-33, -44]
        ],
        [
            [6249, 7494],
            [6, 10],
            [21, -17],
            [15, -4],
            [4, 7],
            [-14, 32],
            [7, 9]
        ],
        [
            [6288, 7531],
            [8, -2],
            [19, -36],
            [13, -4],
            [4, 15],
            [17, 23]
        ],
        [
            [5814, 4792],
            [-1, 71],
            [-7, 27]
        ],
        [
            [5806, 4890],
            [17, -5],
            [8, 34],
            [15, -4]
        ],
        [
            [5846, 4915],
            [1, -23],
            [6, -14],
            [1, -19],
            [-7, -12],
            [-11, -31],
            [-10, -22],
            [-12, -2]
        ],
        [
            [5092, 8091],
            [20, -5],
            [26, 12],
            [17, -25],
            [16, -14]
        ],
        [
            [5171, 8059],
            [-4, -40]
        ],
        [
            [5167, 8019],
            [-7, -2],
            [-3, -33]
        ],
        [
            [5157, 7984],
            [-24, 26],
            [-14, -4],
            [-20, 28],
            [-13, 23],
            [-13, 1],
            [-4, 21]
        ],
        [
            [5069, 8079],
            [23, 12]
        ],
        [
            [5074, 5427],
            [-23, -7]
        ],
        [
            [5051, 5420],
            [-7, 41],
            [2, 136],
            [-6, 12],
            [-1, 29],
            [-10, 21],
            [-8, 17],
            [3, 31]
        ],
        [
            [5024, 5707],
            [10, 7],
            [6, 26],
            [13, 5],
            [6, 18]
        ],
        [
            [5059, 5763],
            [10, 17],
            [10, 0],
            [21, -34]
        ],
        [
            [5100, 5746],
            [-1, -19],
            [6, -35],
            [-6, -24],
            [3, -16],
            [-13, -37],
            [-9, -18],
            [-5, -37],
            [1, -38],
            [-2, -95]
        ],
        [
            [4921, 5627],
            [-19, 15],
            [-13, -2],
            [-10, -15],
            [-12, 13],
            [-5, 19],
            [-13, 13]
        ],
        [
            [4849, 5670],
            [-1, 34],
            [7, 26],
            [-1, 20],
            [23, 48],
            [4, 41],
            [7, 14],
            [14, -8],
            [11, 12],
            [4, 16],
            [22, 26],
            [5, 19],
            [26, 24],
            [15, 9],
            [7, -12],
            [18, 0]
        ],
        [
            [5010, 5939],
            [-2, -28],
            [3, -27],
            [16, -39],
            [1, -28],
            [32, -14],
            [-1, -40]
        ],
        [
            [5024, 5707],
            [-24, 1]
        ],
        [
            [5000, 5708],
            [-13, 5],
            [-9, -9],
            [-12, 4],
            [-48, -3],
            [-1, -33],
            [4, -45]
        ],
        [
            [7573, 6360],
            [0, -43],
            [-10, 9],
            [2, -47]
        ],
        [
            [7565, 6279],
            [-8, 30],
            [-1, 31],
            [-6, 28],
            [-11, 34],
            [-26, 3],
            [3, -25],
            [-9, -32],
            [-12, 12],
            [-4, -11],
            [-8, 6],
            [-11, 5]
        ],
        [
            [7472, 6360],
            [-4, 49],
            [-10, 45],
            [5, 35],
            [-17, 16],
            [6, 22],
            [18, 22],
            [-20, 31],
            [9, 40],
            [22, -26],
            [14, -3],
            [2, -41],
            [26, -8],
            [26, 1],
            [16, -10],
            [-13, -50],
            [-12, -3],
            [-9, -34],
            [16, -31],
            [4, 38],
            [8, 0],
            [14, -93]
        ],
        [
            [5629, 7671],
            [8, -25],
            [11, 5],
            [21, -9],
            [41, -4],
            [13, 16],
            [33, 13],
            [20, -21],
            [17, -6]
        ],
        [
            [5793, 7640],
            [-15, -25],
            [-10, -42],
            [9, -34]
        ],
        [
            [5777, 7539],
            [-24, 8],
            [-28, -18]
        ],
        [
            [5725, 7529],
            [0, -30],
            [-26, -5],
            [-19, 20],
            [-22, -16],
            [-21, 2]
        ],
        [
            [5637, 7500],
            [-2, 39],
            [-14, 19]
        ],
        [
            [5621, 7558],
            [5, 8],
            [-3, 7],
            [4, 19],
            [11, 18],
            [-14, 26],
            [-2, 21],
            [7, 14]
        ],
        [
            [2846, 6461],
            [-7, -3],
            [-7, 34],
            [-10, 17],
            [6, 38],
            [8, -3],
            [10, -49],
            [0, -34]
        ],
        [
            [2838, 6628],
            [-30, -10],
            [-2, 22],
            [13, 5],
            [18, -2],
            [1, -15]
        ],
        [
            [2861, 6628],
            [-5, -42],
            [-5, 8],
            [0, 31],
            [-12, 23],
            [0, 7],
            [22, -27]
        ],
        [
            [5527, 7708],
            [10, 0],
            [-7, -26],
            [14, -23],
            [-4, -28],
            [-7, -2]
        ],
        [
            [5533, 7629],
            [-5, -6],
            [-9, -13],
            [-4, -33]
        ],
        [
            [5515, 7577],
            [-25, 23],
            [-10, 24],
            [-11, 13],
            [-12, 22],
            [-6, 19],
            [-14, 27],
            [6, 25],
            [10, -14],
            [6, 12],
            [13, 2],
            [24, -10],
            [19, 1],
            [12, -13]
        ],
        [
            [5652, 8242],
            [27, 0],
            [30, 22],
            [6, 34],
            [23, 19],
            [-3, 26]
        ],
        [
            [5735, 8343],
            [17, 10],
            [30, 23]
        ],
        [
            [5782, 8376],
            [29, -15],
            [4, -15],
            [15, 7],
            [27, -14],
            [3, -27],
            [-6, -16],
            [17, -39],
            [12, -11],
            [-2, -11],
            [19, -10],
            [8, -16],
            [-11, -13],
            [-23, 2],
            [-5, -5],
            [7, -20],
            [6, -37]
        ],
        [
            [5882, 8136],
            [-23, -4],
            [-9, -13],
            [-2, -30],
            [-11, 6],
            [-25, -3],
            [-7, 14],
            [-11, -10],
            [-10, 8],
            [-22, 1],
            [-31, 15],
            [-28, 4],
            [-22, -1],
            [-15, -16],
            [-13, -2]
        ],
        [
            [5653, 8105],
            [-1, 26],
            [-8, 27],
            [17, 12],
            [0, 24],
            [-8, 22],
            [-1, 26]
        ],
        [
            [2524, 6110],
            [-1, 8],
            [4, 3],
            [5, -7],
            [10, 36],
            [5, 0]
        ],
        [
            [2547, 6150],
            [0, -8],
            [5, -1],
            [0, -16],
            [-5, -25],
            [3, -9],
            [-3, -21],
            [2, -6],
            [-4, -30],
            [-5, -16],
            [-5, -1],
            [-6, -21]
        ],
        [
            [2529, 5996],
            [-8, 0],
            [2, 67],
            [1, 47]
        ],
        [
            [3136, 3714],
            [-20, -8],
            [-11, 82],
            [-15, 66],
            [9, 57],
            [-15, 25],
            [-4, 43],
            [-13, 40]
        ],
        [
            [3067, 4019],
            [17, 64],
            [-12, 49],
            [7, 20],
            [-5, 22],
            [10, 30],
            [1, 50],
            [1, 41],
            [6, 20],
            [-24, 96]
        ],
        [
            [3068, 4411],
            [21, -5],
            [14, 1],
            [6, 18],
            [25, 24],
            [14, 22],
            [37, 10],
            [-3, -44],
            [3, -23],
            [-2, -40],
            [30, -53],
            [31, -9],
            [11, -23],
            [19, -11],
            [11, -17],
            [18, 0],
            [16, -17],
            [1, -34],
            [6, -18],
            [0, -25],
            [-8, -1],
            [11, -69],
            [53, -2],
            [-4, -35],
            [3, -23],
            [15, -16],
            [6, -37],
            [-4, -47],
            [-8, -26],
            [3, -33],
            [-9, -12]
        ],
        [
            [3384, 3866],
            [-1, 18],
            [-25, 30],
            [-26, 1],
            [-49, -17],
            [-13, -52],
            [-1, -32],
            [-11, -71]
        ],
        [
            [3482, 3537],
            [6, 34],
            [3, 35],
            [1, 32],
            [-10, 11],
            [-11, -9],
            [-10, 2],
            [-4, 23],
            [-2, 54],
            [-5, 18],
            [-19, 16],
            [-11, -12],
            [-30, 11],
            [2, 81],
            [-8, 33]
        ],
        [
            [3068, 4411],
            [-15, -11],
            [-13, 7],
            [2, 90],
            [-23, -35],
            [-24, 2],
            [-11, 31],
            [-18, 4],
            [5, 25],
            [-15, 36],
            [-11, 53],
            [7, 11],
            [0, 25],
            [17, 17],
            [-3, 32],
            [7, 20],
            [2, 28],
            [32, 40],
            [22, 11],
            [4, 9],
            [25, -2]
        ],
        [
            [3058, 4804],
            [13, 162],
            [0, 25],
            [-4, 34],
            [-12, 22],
            [0, 42],
            [15, 10],
            [6, -6],
            [1, 23],
            [-16, 6],
            [-1, 37],
            [54, -2],
            [10, 21],
            [7, -19],
            [6, -35],
            [5, 8]
        ],
        [
            [3142, 5132],
            [15, -32],
            [22, 4],
            [5, 18],
            [21, 14],
            [11, 10],
            [4, 25],
            [19, 17],
            [-1, 12],
            [-24, 5],
            [-3, 37],
            [1, 40],
            [-13, 15],
            [5, 6],
            [21, -8],
            [22, -15],
            [8, 14],
            [20, 9],
            [31, 23],
            [10, 22],
            [-3, 17]
        ],
        [
            [3313, 5365],
            [14, 2],
            [7, -13],
            [-4, -26],
            [9, -9],
            [7, -28],
            [-8, -20],
            [-4, -51],
            [7, -30],
            [2, -27],
            [17, -28],
            [14, -3],
            [3, 12],
            [8, 3],
            [13, 10],
            [9, 16],
            [15, -5],
            [7, 2]
        ],
        [
            [3429, 5170],
            [15, -5],
            [3, 12],
            [-5, 12],
            [3, 17],
            [11, -5],
            [13, 6],
            [16, -13]
        ],
        [
            [3485, 5194],
            [12, -12],
            [9, 16],
            [6, -3],
            [4, -16],
            [13, 4],
            [11, 22],
            [8, 44],
            [17, 54]
        ],
        [
            [3565, 5303],
            [9, 3],
            [7, -33],
            [16, -103],
            [14, -10],
            [1, -41],
            [-21, -48],
            [9, -18],
            [49, -9],
            [1, -60],
            [21, 39],
            [35, -21],
            [46, -36],
            [14, -35],
            [-5, -32],
            [33, 18],
            [54, -32],
            [41, 3],
            [41, -49],
            [36, -66],
            [21, -17],
            [24, -3],
            [10, -18],
            [9, -76],
            [5, -35],
            [-11, -98],
            [-14, -39],
            [-39, -82],
            [-18, -67],
            [-21, -51],
            [-7, -1],
            [-7, -43],
            [2, -111],
            [-8, -91],
            [-3, -39],
            [-9, -23],
            [-5, -79],
            [-28, -77],
            [-5, -61],
            [-22, -26],
            [-7, -35],
            [-30, 0],
            [-44, -23],
            [-19, -26],
            [-31, -18],
            [-33, -47],
            [-23, -58],
            [-5, -44],
            [5, -33],
            [-5, -60],
            [-6, -28],
            [-20, -33],
            [-31, -104],
            [-24, -47],
            [-19, -27],
            [-13, -57],
            [-18, -33]
        ],
        [
            [3517, 3063],
            [-8, 33],
            [13, 28],
            [-16, 40],
            [-22, 33],
            [-29, 38],
            [-10, -2],
            [-28, 46],
            [-18, -7]
        ],
        [
            [8172, 5325],
            [11, 22],
            [23, 32]
        ],
        [
            [8206, 5379],
            [-1, -29],
            [-2, -37],
            [-13, 1],
            [-6, -20],
            [-12, 31]
        ],
        [
            [7546, 6698],
            [12, -19],
            [-2, -36],
            [-23, -2],
            [-23, 4],
            [-18, -9],
            [-25, 22],
            [-1, 12]
        ],
        [
            [7466, 6670],
            [19, 44],
            [15, 15],
            [20, -14],
            [14, -1],
            [12, -16]
        ],
        [
            [5817, 3752],
            [-39, -43],
            [-25, -44],
            [-10, -40],
            [-8, -22],
            [-15, -4],
            [-5, -29],
            [-3, -18],
            [-17, -14],
            [-23, 3],
            [-13, 17],
            [-12, 7],
            [-14, -14],
            [-6, -28],
            [-14, -18],
            [-13, -26],
            [-20, -6],
            [-6, 20],
            [2, 36],
            [-16, 56],
            [-8, 9]
        ],
        [
            [5552, 3594],
            [0, 173],
            [27, 2],
            [1, 210],
            [21, 2],
            [43, 21],
            [10, -24],
            [18, 23],
            [9, 0],
            [15, 13]
        ],
        [
            [5696, 4014],
            [5, -4]
        ],
        [
            [5701, 4010],
            [11, -48],
            [5, -10],
            [9, -34],
            [32, -65],
            [12, -7],
            [0, -20],
            [8, -38],
            [21, -9],
            [18, -27]
        ],
        [
            [5424, 5496],
            [23, 4],
            [5, 16],
            [5, -2],
            [7, -13],
            [34, 23],
            [12, 23],
            [15, 20],
            [-3, 21],
            [8, 6],
            [27, -4],
            [26, 27],
            [20, 65],
            [14, 24],
            [18, 10]
        ],
        [
            [5635, 5716],
            [3, -26],
            [16, -36],
            [0, -25],
            [-5, -24],
            [2, -18],
            [10, -18]
        ],
        [
            [5661, 5569],
            [21, -25]
        ],
        [
            [5682, 5544],
            [15, -24],
            [0, -19],
            [19, -31],
            [12, -26],
            [7, -35],
            [20, -24],
            [5, -18]
        ],
        [
            [5760, 5367],
            [-9, -7],
            [-18, 2],
            [-21, 6],
            [-10, -5],
            [-5, -14],
            [-9, -2],
            [-10, 12],
            [-31, -29],
            [-13, 6],
            [-4, -5],
            [-8, -35],
            [-21, 11],
            [-20, 6],
            [-18, 22],
            [-23, 20],
            [-15, -19],
            [-10, -30],
            [-3, -41]
        ],
        [
            [5512, 5265],
            [-18, 3],
            [-19, 10],
            [-16, -32],
            [-15, -55]
        ],
        [
            [5444, 5191],
            [-3, 18],
            [-1, 27],
            [-13, 19],
            [-10, 30],
            [-2, 21],
            [-13, 31],
            [2, 18],
            [-3, 25],
            [2, 45],
            [7, 11],
            [14, 60]
        ],
        [
            [3231, 7808],
            [20, -8],
            [26, 1],
            [-14, -24],
            [-10, -4],
            [-35, 25],
            [-7, 20],
            [10, 18],
            [10, -28]
        ],
        [
            [3283, 7958],
            [-14, -1],
            [-36, 19],
            [-26, 28],
            [10, 5],
            [37, -15],
            [28, -25],
            [1, -11]
        ],
        [
            [1569, 7923],
            [-14, -8],
            [-46, 27],
            [-8, 21],
            [-25, 21],
            [-5, 16],
            [-28, 11],
            [-11, 32],
            [2, 14],
            [30, -13],
            [17, -9],
            [26, -6],
            [9, -21],
            [14, -28],
            [28, -24],
            [11, -33]
        ],
        [
            [3440, 8052],
            [-18, -52],
            [18, 20],
            [19, -12],
            [-10, -21],
            [25, -16],
            [12, 14],
            [28, -18],
            [-8, -43],
            [19, 10],
            [4, -32],
            [8, -36],
            [-11, -52],
            [-13, -2],
            [-18, 11],
            [6, 48],
            [-8, 8],
            [-32, -52],
            [-17, 2],
            [20, 28],
            [-27, 14],
            [-30, -3],
            [-54, 2],
            [-4, 17],
            [17, 21],
            [-12, 16],
            [24, 36],
            [28, 94],
            [18, 33],
            [24, 21],
            [13, -3],
            [-6, -16],
            [-15, -37]
        ],
        [
            [1313, 8250],
            [27, 5],
            [-8, -67],
            [24, -48],
            [-11, 0],
            [-17, 27],
            [-10, 27],
            [-14, 19],
            [-5, 26],
            [1, 19],
            [13, -8]
        ],
        [
            [2798, 8730],
            [-11, -31],
            [-12, 5],
            [-8, 17],
            [2, 4],
            [10, 18],
            [12, -1],
            [7, -12]
        ],
        [
            [2725, 8762],
            [-33, -32],
            [-19, 1],
            [-6, 16],
            [20, 27],
            [38, 0],
            [0, -12]
        ],
        [
            [2634, 8936],
            [5, -26],
            [15, 9],
            [16, -15],
            [30, -20],
            [32, -19],
            [2, -28],
            [21, 5],
            [20, -20],
            [-25, -18],
            [-43, 14],
            [-16, 26],
            [-27, -31],
            [-40, -31],
            [-9, 35],
            [-38, -6],
            [24, 30],
            [4, 46],
            [9, 54],
            [20, -5]
        ],
        [
            [2892, 9024],
            [-31, -3],
            [-7, 29],
            [12, 34],
            [26, 8],
            [21, -17],
            [1, -25],
            [-4, -8],
            [-18, -18]
        ],
        [
            [2343, 9140],
            [-17, -21],
            [-38, 18],
            [-22, -6],
            [-38, 26],
            [24, 19],
            [19, 25],
            [30, -16],
            [17, -11],
            [8, -11],
            [17, -23]
        ],
        [
            [3135, 7724],
            [-18, 33],
            [0, 81],
            [-13, 17],
            [-18, -10],
            [-10, 16],
            [-21, -45],
            [-8, -46],
            [-10, -27],
            [-12, -9],
            [-9, -3],
            [-3, -15],
            [-51, 0],
            [-42, 0],
            [-12, -11],
            [-30, -42],
            [-3, -5],
            [-9, -23],
            [-26, 0],
            [-27, 0],
            [-12, -10],
            [4, -11],
            [2, -18],
            [0, -6],
            [-36, -30],
            [-29, -9],
            [-32, -31],
            [-7, 0],
            [-10, 9],
            [-3, 8],
            [1, 6],
            [6, 21],
            [13, 33],
            [8, 35],
            [-5, 51],
            [-6, 53],
            [-29, 28],
            [3, 11],
            [-4, 7],
            [-8, 0],
            [-5, 9],
            [-2, 14],
            [-5, -6],
            [-7, 2],
            [1, 6],
            [-6, 6],
            [-3, 15],
            [-21, 19],
            [-23, 20],
            [-27, 23],
            [-26, 21],
            [-25, -17],
            [-9, 0],
            [-34, 15],
            [-23, -8],
            [-27, 19],
            [-28, 9],
            [-19, 4],
            [-9, 10],
            [-5, 32],
            [-9, 0],
            [-1, -23],
            [-57, 0],
            [-95, 0],
            [-94, 0],
            [-84, 0],
            [-83, 0],
            [-82, 0],
            [-85, 0],
            [-27, 0],
            [-82, 0],
            [-79, 0]
        ],
        [
            [1588, 7952],
            [-4, 0],
            [-54, 58],
            [-20, 26],
            [-50, 24],
            [-15, 53],
            [3, 36],
            [-35, 25],
            [-5, 48],
            [-34, 43],
            [0, 30]
        ],
        [
            [1374, 8295],
            [15, 29],
            [0, 37],
            [-48, 37],
            [-28, 68],
            [-17, 42],
            [-26, 27],
            [-19, 24],
            [-14, 31],
            [-28, -20],
            [-27, -33],
            [-25, 39],
            [-19, 26],
            [-27, 16],
            [-28, 2],
            [0, 337],
            [1, 219]
        ],
        [
            [1084, 9176],
            [51, -14],
            [44, -29],
            [29, -5],
            [24, 24],
            [34, 19],
            [41, -7],
            [42, 26],
            [45, 14],
            [20, -24],
            [20, 14],
            [6, 27],
            [20, -6],
            [47, -53],
            [37, 40],
            [3, -45],
            [34, 10],
            [11, 17],
            [34, -3],
            [42, -25],
            [65, -22],
            [38, -10],
            [28, 4],
            [37, -30],
            [-39, -29],
            [50, -13],
            [75, 7],
            [24, 11],
            [29, -36],
            [31, 30],
            [-29, 25],
            [18, 20],
            [34, 3],
            [22, 6],
            [23, -14],
            [28, -32],
            [31, 5],
            [49, -27],
            [43, 9],
            [40, -1],
            [-3, 37],
            [25, 10],
            [43, -20],
            [0, -56],
            [17, 47],
            [23, -1],
            [12, 59],
            [-30, 36],
            [-32, 24],
            [2, 65],
            [33, 43],
            [37, -9],
            [28, -26],
            [38, -67],
            [-25, -29],
            [52, -12],
            [-1, -60],
            [38, 46],
            [33, -38],
            [-9, -44],
            [27, -40],
            [29, 43],
            [21, 51],
            [1, 65],
            [40, -5],
            [41, -8],
            [37, -30],
            [2, -29],
            [-21, -31],
            [20, -32],
            [-4, -29],
            [-54, -41],
            [-39, -9],
            [-29, 18],
            [-8, -30],
            [-27, -50],
            [-8, -26],
            [-32, -40],
            [-40, -4],
            [-22, -25],
            [-2, -38],
            [-32, -7],
            [-34, -48],
            [-30, -67],
            [-11, -46],
            [-1, -69],
            [40, -10],
            [13, -55],
            [13, -45],
            [39, 12],
            [51, -26],
            [28, -22],
            [20, -28],
            [35, -17],
            [29, -24],
            [46, -4],
            [30, -6],
            [-4, -51],
            [8, -59],
            [21, -66],
            [41, -56],
            [21, 19],
            [15, 61],
            [-14, 93],
            [-20, 31],
            [45, 28],
            [31, 41],
            [16, 41],
            [-3, 40],
            [-19, 50],
            [-33, 44],
            [32, 62],
            [-12, 54],
            [-9, 92],
            [19, 14],
            [48, -16],
            [29, -6],
            [23, 15],
            [25, -20],
            [35, -34],
            [8, -23],
            [50, -4],
            [-1, -50],
            [9, -74],
            [25, -10],
            [21, -35],
            [40, 33],
            [26, 65],
            [19, 28],
            [21, -53],
            [36, -75],
            [31, -71],
            [-11, -37],
            [37, -33],
            [25, -34],
            [44, -15],
            [18, -19],
            [11, -50],
            [22, -8],
            [11, -22],
            [2, -67],
            [-20, -22],
            [-20, -21],
            [-46, -21],
            [-35, -48],
            [-47, -10],
            [-59, 13],
            [-42, 0],
            [-29, -4],
            [-23, -43],
            [-35, -26],
            [-40, -78],
            [-32, -54],
            [23, 9],
            [45, 78],
            [58, 49],
            [42, 6],
            [24, -29],
            [-26, -40],
            [9, -63],
            [9, -45],
            [36, -29],
            [46, 8],
            [28, 67],
            [2, -43],
            [17, -22],
            [-34, -38],
            [-61, -36],
            [-28, -23],
            [-31, -43],
            [-21, 4],
            [-1, 50],
            [48, 49],
            [-44, -2],
            [-31, -7]
        ],
        [
            [1829, 9377],
            [-14, -27],
            [61, 17],
            [39, -29],
            [31, 30],
            [26, -20],
            [23, -58],
            [14, 25],
            [-20, 60],
            [24, 9],
            [28, -9],
            [31, -24],
            [17, -58],
            [9, -41],
            [47, -30],
            [50, -28],
            [-3, -26],
            [-46, -4],
            [18, -23],
            [-9, -22],
            [-51, 9],
            [-48, 16],
            [-32, -3],
            [-52, -20],
            [-70, -9],
            [-50, -6],
            [-15, 28],
            [-38, 16],
            [-24, -6],
            [-35, 47],
            [19, 6],
            [43, 10],
            [39, -3],
            [36, 11],
            [-54, 13],
            [-59, -4],
            [-39, 1],
            [-15, 22],
            [64, 23],
            [-42, -1],
            [-49, 16],
            [23, 44],
            [20, 24],
            [74, 36],
            [29, -12]
        ],
        [
            [2097, 9395],
            [-24, -39],
            [-44, 41],
            [10, 9],
            [37, 2],
            [21, -13]
        ],
        [
            [2879, 9376],
            [3, -16],
            [-30, 2],
            [-30, 1],
            [-30, -8],
            [-8, 3],
            [-31, 32],
            [1, 21],
            [14, 4],
            [63, -6],
            [48, -33]
        ],
        [
            [2595, 9379],
            [22, -36],
            [26, 47],
            [70, 24],
            [48, -61],
            [-4, -38],
            [55, 17],
            [26, 23],
            [62, -30],
            [38, -28],
            [3, -25],
            [52, 13],
            [29, -38],
            [67, -23],
            [24, -24],
            [26, -55],
            [-51, -28],
            [66, -38],
            [44, -13],
            [40, -55],
            [44, -3],
            [-9, -42],
            [-49, -69],
            [-34, 26],
            [-44, 57],
            [-36, -8],
            [-3, -34],
            [29, -34],
            [38, -27],
            [11, -16],
            [18, -58],
            [-9, -43],
            [-35, 16],
            [-70, 47],
            [39, -51],
            [29, -35],
            [5, -21],
            [-76, 24],
            [-59, 34],
            [-34, 29],
            [10, 17],
            [-42, 30],
            [-40, 29],
            [0, -18],
            [-80, -9],
            [-23, 20],
            [18, 44],
            [52, 1],
            [57, 7],
            [-9, 21],
            [10, 30],
            [36, 57],
            [-8, 27],
            [-11, 20],
            [-42, 29],
            [-57, 20],
            [18, 15],
            [-29, 36],
            [-25, 4],
            [-22, 20],
            [-14, -18],
            [-51, -7],
            [-101, 13],
            [-59, 17],
            [-45, 9],
            [-23, 21],
            [29, 27],
            [-39, 0],
            [-9, 60],
            [21, 53],
            [29, 24],
            [72, 16],
            [-21, -39]
        ],
        [
            [2212, 9420],
            [33, -12],
            [50, 7],
            [7, -17],
            [-26, -28],
            [42, -26],
            [-5, -53],
            [-45, -23],
            [-27, 5],
            [-19, 23],
            [-69, 45],
            [0, 19],
            [57, -7],
            [-31, 38],
            [33, 29]
        ],
        [
            [2411, 9357],
            [-30, -45],
            [-32, 3],
            [-17, 52],
            [1, 29],
            [14, 25],
            [28, 16],
            [58, -2],
            [53, -14],
            [-42, -53],
            [-33, -11]
        ],
        [
            [1654, 9275],
            [-73, -29],
            [-15, 26],
            [-64, 31],
            [12, 25],
            [19, 43],
            [24, 39],
            [-27, 36],
            [94, 10],
            [39, -13],
            [71, -3],
            [27, -17],
            [30, -25],
            [-35, -15],
            [-68, -41],
            [-34, -42],
            [0, -25]
        ],
        [
            [2399, 9487],
            [-15, -23],
            [-40, 5],
            [-34, 15],
            [15, 27],
            [40, 16],
            [24, -21],
            [10, -19]
        ],
        [
            [2264, 9590],
            [21, -27],
            [1, -31],
            [-13, -44],
            [-46, -6],
            [-30, 10],
            [1, 34],
            [-45, -4],
            [-2, 45],
            [30, -2],
            [41, 21],
            [40, -4],
            [2, 8]
        ],
        [
            [1994, 9559],
            [11, -21],
            [25, 10],
            [29, -2],
            [5, -29],
            [-17, -28],
            [-94, -10],
            [-70, -25],
            [-43, -2],
            [-3, 20],
            [57, 26],
            [-125, -7],
            [-39, 10],
            [38, 58],
            [26, 17],
            [78, -20],
            [50, -35],
            [48, -5],
            [-40, 57],
            [26, 21],
            [29, -7],
            [9, -28]
        ],
        [
            [2370, 9612],
            [30, -19],
            [55, 0],
            [24, -19],
            [-6, -22],
            [32, -14],
            [17, -14],
            [38, -2],
            [40, -5],
            [44, 13],
            [57, 5],
            [45, -5],
            [30, -22],
            [6, -24],
            [-17, -16],
            [-42, -13],
            [-35, 8],
            [-80, -10],
            [-57, -1],
            [-45, 8],
            [-74, 19],
            [-9, 32],
            [-4, 29],
            [-27, 26],
            [-58, 7],
            [-32, 19],
            [10, 24],
            [58, -4]
        ],
        [
            [1772, 9645],
            [-4, -46],
            [-21, -20],
            [-26, -3],
            [-52, -26],
            [-44, -9],
            [-38, 13],
            [47, 44],
            [57, 39],
            [43, -1],
            [38, 9]
        ],
        [
            [2393, 9637],
            [-13, -2],
            [-52, 4],
            [-7, 17],
            [56, -1],
            [19, -11],
            [-3, -7]
        ],
        [
            [1939, 9648],
            [-52, -17],
            [-41, 19],
            [23, 19],
            [40, 6],
            [39, -10],
            [-9, -17]
        ],
        [
            [1954, 9701],
            [-34, -11],
            [-46, 0],
            [0, 8],
            [29, 18],
            [14, -3],
            [37, -12]
        ],
        [
            [2338, 9669],
            [-41, -12],
            [-23, 13],
            [-12, 23],
            [-2, 24],
            [36, -2],
            [16, -4],
            [33, -21],
            [-7, -21]
        ],
        [
            [2220, 9685],
            [11, -25],
            [-45, 7],
            [-46, 19],
            [-62, 2],
            [27, 18],
            [-34, 14],
            [-2, 22],
            [55, -8],
            [75, -21],
            [21, -28]
        ],
        [
            [2583, 9764],
            [33, -20],
            [-38, -17],
            [-51, -45],
            [-50, -4],
            [-57, 8],
            [-30, 24],
            [0, 21],
            [22, 16],
            [-50, 0],
            [-31, 19],
            [-18, 27],
            [20, 26],
            [19, 18],
            [28, 4],
            [-12, 14],
            [65, 3],
            [35, -32],
            [47, -12],
            [46, -11],
            [22, -39]
        ],
        [
            [3097, 9967],
            [74, -4],
            [60, -8],
            [51, -16],
            [-2, -16],
            [-67, -25],
            [-68, -12],
            [-25, -14],
            [61, 1],
            [-66, -36],
            [-45, -17],
            [-48, -48],
            [-57, -10],
            [-18, -12],
            [-84, -6],
            [39, -8],
            [-20, -10],
            [23, -29],
            [-26, -21],
            [-43, -16],
            [-13, -24],
            [-39, -17],
            [4, -14],
            [48, 3],
            [0, -15],
            [-74, -35],
            [-73, 16],
            [-81, -9],
            [-42, 7],
            [-52, 3],
            [-4, 29],
            [52, 13],
            [-14, 43],
            [17, 4],
            [74, -26],
            [-38, 38],
            [-45, 11],
            [23, 23],
            [49, 14],
            [8, 21],
            [-39, 23],
            [-12, 31],
            [76, -3],
            [22, -6],
            [43, 21],
            [-62, 7],
            [-98, -4],
            [-49, 20],
            [-23, 24],
            [-32, 17],
            [-6, 21],
            [41, 11],
            [32, 2],
            [55, 9],
            [41, 22],
            [34, -3],
            [30, -16],
            [21, 32],
            [37, 9],
            [50, 7],
            [85, 2],
            [14, -6],
            [81, 10],
            [60, -4],
            [60, -4]
        ],
        [
            [5290, 7828],
            [-3, -24],
            [-12, -10],
            [-20, 7],
            [-6, -24],
            [-14, -2],
            [-5, 10],
            [-15, -20],
            [-13, -3],
            [-12, 13]
        ],
        [
            [5190, 7775],
            [-10, 25],
            [-13, -9],
            [0, 27],
            [21, 33],
            [-1, 15],
            [12, -5],
            [8, 10]
        ],
        [
            [5207, 7871],
            [24, -1],
            [5, 13],
            [30, -18]
        ],
        [
            [3140, 1814],
            [-10, -24],
            [-23, -18],
            [-14, 2],
            [-16, 5],
            [-21, 18],
            [-29, 8],
            [-35, 33],
            [-28, 32],
            [-38, 66],
            [23, -12],
            [39, -40],
            [36, -21],
            [15, 27],
            [9, 41],
            [25, 24],
            [20, -7]
        ],
        [
            [3095, 1968],
            [-25, 0],
            [-13, -14],
            [-25, -22],
            [-5, -55],
            [-11, -1],
            [-32, 19],
            [-32, 41],
            [-34, 34],
            [-9, 37],
            [8, 35],
            [-14, 39],
            [-4, 101],
            [12, 57],
            [30, 45],
            [-43, 18],
            [27, 52],
            [9, 98],
            [31, -21],
            [15, 123],
            [-19, 15],
            [-9, -73],
            [-17, 8],
            [9, 84],
            [9, 110],
            [13, 40],
            [-8, 58],
            [-2, 66],
            [11, 2],
            [17, 96],
            [20, 94],
            [11, 88],
            [-6, 89],
            [8, 49],
            [-3, 72],
            [16, 73],
            [5, 114],
            [9, 123],
            [9, 132],
            [-2, 96],
            [-6, 84]
        ],
        [
            [3045, 3974],
            [14, 15],
            [8, 30]
        ],
        [
            [8064, 6161],
            [-24, -28],
            [-23, 18],
            [0, 51],
            [13, 26],
            [31, 17],
            [16, -1],
            [6, -23],
            [-12, -26],
            [-7, -34]
        ],
        [
            [8628, 7562],
            [-18, 35],
            [-11, -33],
            [-43, -26],
            [4, -31],
            [-24, 2],
            [-13, 19],
            [-19, -42],
            [-30, -32],
            [-23, -38]
        ],
        [
            [8451, 7416],
            [-39, -17],
            [-20, -27],
            [-30, -17],
            [15, 28],
            [-6, 23],
            [22, 40],
            [-15, 30],
            [-24, -20],
            [-32, -41],
            [-17, -39],
            [-27, -2],
            [-14, -28],
            [15, -40],
            [22, -10],
            [1, -26],
            [22, -17],
            [31, 42],
            [25, -23],
            [18, -2],
            [4, -31],
            [-39, -16],
            [-13, -32],
            [-27, -30],
            [-14, -41],
            [30, -33],
            [11, -58],
            [17, -54],
            [18, -45],
            [0, -44],
            [-17, -16],
            [6, -32],
            [17, -18],
            [-5, -48],
            [-7, -47],
            [-15, -5],
            [-21, -64],
            [-22, -78],
            [-26, -70],
            [-38, -55],
            [-39, -50],
            [-31, -6],
            [-17, -27],
            [-10, 20],
            [-15, -30],
            [-39, -29],
            [-29, -9],
            [-10, -63],
            [-15, -3],
            [-8, 43],
            [7, 22],
            [-37, 19],
            [-13, -9]
        ],
        [
            [8001, 6331],
            [-28, 15],
            [-14, 24],
            [5, 34],
            [-26, 11],
            [-13, 22],
            [-24, -31],
            [-27, -7],
            [-22, 0],
            [-15, -14]
        ],
        [
            [7837, 6385],
            [-14, -9],
            [4, -68],
            [-15, 2],
            [-2, 14]
        ],
        [
            [7810, 6324],
            [-1, 24],
            [-20, -17],
            [-12, 11],
            [-21, 22],
            [8, 49],
            [-18, 12],
            [-6, 54],
            [-30, -10],
            [4, 70],
            [26, 50],
            [1, 48],
            [-1, 46],
            [-12, 14],
            [-9, 35],
            [-16, -5]
        ],
        [
            [7703, 6727],
            [-30, 9],
            [9, 25],
            [-13, 36],
            [-20, -24],
            [-23, 14],
            [-32, -37],
            [-25, -44],
            [-23, -8]
        ],
        [
            [7466, 6670],
            [-2, 47],
            [-17, -13]
        ],
        [
            [7447, 6704],
            [-32, 6],
            [-32, 14],
            [-22, 26],
            [-22, 11],
            [-9, 29],
            [-16, 8],
            [-28, 39],
            [-22, 18],
            [-12, -14]
        ],
        [
            [7252, 6841],
            [-38, 41],
            [-28, 37],
            [-7, 65],
            [20, -7],
            [1, 30],
            [-12, 30],
            [3, 48],
            [-30, 69]
        ],
        [
            [7161, 7154],
            [-45, 24],
            [-8, 46],
            [-21, 27]
        ],
        [
            [7082, 7268],
            [-4, 34],
            [1, 23],
            [-17, 13],
            [-9, -6],
            [-7, 55]
        ],
        [
            [7046, 7387],
            [8, 13],
            [-4, 14],
            [26, 28],
            [20, 12],
            [29, -8],
            [11, 38],
            [35, 7],
            [10, 23],
            [44, 32],
            [4, 13]
        ],
        [
            [7229, 7559],
            [-2, 34],
            [19, 15],
            [-25, 103],
            [55, 24],
            [14, 13],
            [20, 106],
            [55, -20],
            [15, 27],
            [2, 59],
            [23, 6],
            [21, 39]
        ],
        [
            [7426, 7965],
            [11, 5]
        ],
        [
            [7437, 7970],
            [7, -41],
            [23, -32],
            [40, -22],
            [19, -47],
            [-10, -70],
            [10, -25],
            [33, -10],
            [37, -8],
            [33, -37],
            [18, -7],
            [12, -54],
            [17, -35],
            [30, 1],
            [58, -13],
            [36, 8],
            [28, -9],
            [41, -36],
            [34, 0],
            [12, -18],
            [32, 32],
            [45, 20],
            [42, 2],
            [32, 21],
            [20, 32],
            [20, 20],
            [-5, 19],
            [-9, 23],
            [15, 38],
            [15, -5],
            [29, -12],
            [28, 31],
            [42, 23],
            [20, 39],
            [20, 17],
            [40, 8],
            [22, -7],
            [3, 21],
            [-25, 41],
            [-22, 19],
            [-22, -22],
            [-27, 10],
            [-16, -8],
            [-7, 24],
            [20, 59],
            [13, 45]
        ],
        [
            [8240, 8005],
            [34, -23],
            [39, 38],
            [-1, 26],
            [26, 62],
            [15, 19],
            [0, 33],
            [-16, 14],
            [23, 29],
            [35, 11],
            [37, 2],
            [41, -18],
            [25, -22],
            [17, -59],
            [10, -26],
            [10, -36],
            [10, -58],
            [49, -19],
            [32, -42],
            [12, -55],
            [42, 0],
            [24, 23],
            [46, 17],
            [-15, -53],
            [-11, -21],
            [-9, -65],
            [-19, -58],
            [-33, 11],
            [-24, -21],
            [7, -51],
            [-4, -69],
            [-14, -2],
            [0, -30]
        ],
        [
            [4920, 5353],
            [-12, -1],
            [-20, 12],
            [-18, -1],
            [-33, -10],
            [-19, -18],
            [-27, -21],
            [-6, 1]
        ],
        [
            [4785, 5315],
            [2, 49],
            [3, 7],
            [-1, 24],
            [-12, 24],
            [-8, 4],
            [-8, 17],
            [6, 26],
            [-3, 28],
            [1, 18]
        ],
        [
            [4765, 5512],
            [5, 0],
            [1, 25],
            [-2, 12],
            [3, 8],
            [10, 7],
            [-7, 47],
            [-6, 25],
            [2, 20],
            [5, 4]
        ],
        [
            [4776, 5660],
            [4, 6],
            [8, -9],
            [21, -1],
            [5, 18],
            [5, -1],
            [8, 6],
            [4, -25],
            [7, 7],
            [11, 9]
        ],
        [
            [4921, 5627],
            [7, -84],
            [-11, -50],
            [-8, -66],
            [12, -51],
            [-1, -23]
        ],
        [
            [5363, 5191],
            [-4, 4],
            [-16, -8],
            [-17, 8],
            [-13, -4]
        ],
        [
            [5313, 5191],
            [-45, 1]
        ],
        [
            [5268, 5192],
            [4, 47],
            [-11, 39],
            [-13, 10],
            [-6, 27],
            [-7, 8],
            [1, 16]
        ],
        [
            [5236, 5339],
            [7, 42],
            [13, 57],
            [8, 1],
            [17, 34],
            [10, 1],
            [16, -24],
            [19, 20],
            [2, 25],
            [7, 23],
            [4, 30],
            [15, 25],
            [5, 41],
            [6, 13],
            [4, 31],
            [7, 37],
            [24, 46],
            [1, 20],
            [3, 10],
            [-11, 24]
        ],
        [
            [5393, 5795],
            [1, 19],
            [8, 3]
        ],
        [
            [5402, 5817],
            [11, -38],
            [2, -39],
            [-1, -39],
            [15, -54],
            [-15, 1],
            [-8, -4],
            [-13, 6],
            [-6, -28],
            [16, -35],
            [13, -10],
            [3, -24],
            [9, -41],
            [-4, -16]
        ],
        [
            [5444, 5191],
            [-2, -31],
            [-22, 14],
            [-22, 15],
            [-35, 2]
        ],
        [
            [5856, 5265],
            [-2, -69],
            [11, -8],
            [-9, -21],
            [-10, -16],
            [-11, -31],
            [-6, -27],
            [-1, -48],
            [-7, -22],
            [0, -45]
        ],
        [
            [5821, 4978],
            [-8, -16],
            [-1, -35],
            [-4, -5],
            [-2, -32]
        ],
        [
            [5814, 4792],
            [5, -55],
            [-2, -30],
            [5, -35],
            [16, -33],
            [15, -74]
        ],
        [
            [5853, 4565],
            [-11, 6],
            [-37, -10],
            [-7, -7],
            [-8, -38],
            [6, -26],
            [-5, -70],
            [-3, -59],
            [7, -11],
            [19, -23],
            [8, 11],
            [2, -64],
            [-21, 1],
            [-11, 32],
            [-10, 25],
            [-22, 9],
            [-6, 31],
            [-17, -19],
            [-22, 8],
            [-10, 27],
            [-17, 6],
            [-13, -2],
            [-2, 19],
            [-9, 1]
        ],
        [
            [5342, 4697],
            [-4, 18]
        ],
        [
            [5360, 4775],
            [8, -6],
            [9, 23],
            [15, -1],
            [2, -17],
            [11, -10],
            [16, 37],
            [16, 29],
            [7, 19],
            [-1, 48],
            [12, 58],
            [13, 30],
            [18, 29],
            [3, 18],
            [1, 22],
            [5, 21],
            [-2, 33],
            [4, 52],
            [5, 37],
            [8, 32],
            [2, 36]
        ],
        [
            [5760, 5367],
            [17, -49],
            [12, -7],
            [8, 10],
            [12, -4],
            [16, 12],
            [6, -25],
            [25, -39]
        ],
        [
            [5330, 4760],
            [-22, 62]
        ],
        [
            [5308, 4822],
            [21, 33],
            [-11, 39],
            [10, 15],
            [19, 7],
            [2, 26],
            [15, -28],
            [24, -2],
            [9, 27],
            [3, 40],
            [-3, 46],
            [-13, 35],
            [12, 68],
            [-7, 12],
            [-21, -5],
            [-7, 31],
            [2, 25]
        ],
        [
            [2906, 5049],
            [-12, 14],
            [-14, 19],
            [-7, -9],
            [-24, 8],
            [-7, 25],
            [-5, -1],
            [-28, 34]
        ],
        [
            [2809, 5139],
            [-3, 18],
            [10, 5],
            [-1, 29],
            [6, 22],
            [14, 4],
            [12, 37],
            [10, 31],
            [-10, 14],
            [5, 34],
            [-6, 54],
            [6, 16],
            [-4, 50],
            [-12, 31]
        ],
        [
            [2836, 5484],
            [4, 29],
            [9, -4],
            [5, 17],
            [-6, 35],
            [3, 9]
        ],
        [
            [2851, 5570],
            [14, -2],
            [21, 41],
            [12, 6],
            [0, 20],
            [5, 50],
            [16, 27],
            [17, 1],
            [3, 13],
            [21, -5],
            [22, 30],
            [11, 13],
            [14, 28],
            [9, -3],
            [8, -16],
            [-6, -20]
        ],
        [
            [3018, 5753],
            [-18, -10],
            [-7, -29],
            [-10, -17],
            [-8, -22],
            [-4, -42],
            [-8, -35],
            [15, -4],
            [3, -27],
            [6, -13],
            [3, -24],
            [-4, -22],
            [1, -12],
            [7, -5],
            [7, -20],
            [36, 5],
            [16, -7],
            [19, -51],
            [11, 6],
            [20, -3],
            [16, 7],
            [10, -10],
            [-5, -32],
            [-6, -20],
            [-2, -42],
            [5, -40],
            [8, -17],
            [1, -13],
            [-14, -30],
            [10, -13],
            [8, -21],
            [8, -58]
        ],
        [
            [3058, 4804],
            [-14, 31],
            [-8, 1],
            [18, 61],
            [-21, 27],
            [-17, -5],
            [-10, 10],
            [-15, -15],
            [-21, 7],
            [-16, 62],
            [-13, 15],
            [-9, 28],
            [-19, 28],
            [-7, -5]
        ],
        [
            [2695, 5543],
            [-15, 14],
            [-6, 12],
            [4, 10],
            [-1, 13],
            [-8, 14],
            [-11, 12],
            [-10, 8],
            [-1, 17],
            [-8, 10],
            [2, -17],
            [-5, -14],
            [-7, 17],
            [-9, 5],
            [-4, 12],
            [1, 18],
            [3, 19],
            [-8, 8],
            [7, 12]
        ],
        [
            [2619, 5713],
            [4, 7],
            [18, -15],
            [7, 7],
            [9, -5],
            [4, -12],
            [8, -4],
            [7, 13]
        ],
        [
            [2676, 5704],
            [7, -32],
            [11, -24],
            [13, -25]
        ],
        [
            [2707, 5623],
            [-11, -6],
            [0, -23],
            [6, -9],
            [-4, -7],
            [1, -11],
            [-2, -12],
            [-2, -12]
        ],
        [
            [2715, 6427],
            [23, -4],
            [22, 0],
            [26, -21],
            [11, -21],
            [26, 6],
            [10, -13],
            [24, -37],
            [17, -27],
            [9, 1],
            [17, -12],
            [-2, -17],
            [20, -2],
            [21, -24],
            [-3, -14],
            [-19, -7],
            [-18, -3],
            [-19, 4],
            [-40, -5],
            [18, 32],
            [-11, 16],
            [-18, 4],
            [-9, 17],
            [-7, 33],
            [-16, -2],
            [-26, 16],
            [-8, 12],
            [-36, 10],
            [-10, 11],
            [11, 15],
            [-28, 3],
            [-20, -31],
            [-11, -1],
            [-4, -14],
            [-14, -7],
            [-12, 6],
            [15, 18],
            [6, 22],
            [13, 13],
            [14, 11],
            [21, 6],
            [7, 6]
        ],
        [
            [5909, 7133],
            [2, 1],
            [4, 14],
            [20, -1],
            [25, 18],
            [-19, -25],
            [2, -11]
        ],
        [
            [5943, 7129],
            [-3, 2],
            [-5, -5],
            [-4, 1],
            [-2, -2],
            [0, 6],
            [-2, 4],
            [-6, 0],
            [-7, -5],
            [-5, 3]
        ],
        [
            [5943, 7129],
            [1, -5],
            [-28, -24],
            [-14, 8],
            [-7, 23],
            [14, 2]
        ],
        [
            [5377, 7945],
            [-16, 25],
            [-14, 15],
            [-3, 25],
            [-5, 17],
            [21, 13],
            [10, 15],
            [20, 11],
            [7, 11],
            [7, -6],
            [13, 6]
        ],
        [
            [5417, 8077],
            [13, -19],
            [21, -5],
            [-2, -17],
            [15, -12],
            [4, 15],
            [19, -6],
            [3, -19],
            [20, -3],
            [13, -29]
        ],
        [
            [5523, 7982],
            [-8, 0],
            [-4, -11],
            [-7, -3],
            [-2, -13],
            [-5, -3],
            [-1, -5],
            [-9, -7],
            [-12, 1],
            [-4, -13]
        ],
        [
            [5275, 8306],
            [1, -23],
            [28, -14],
            [-1, -21],
            [29, 11],
            [15, 16],
            [32, -23],
            [13, -19]
        ],
        [
            [5392, 8233],
            [6, -30],
            [-8, -16],
            [11, -21],
            [6, -31],
            [-2, -21],
            [12, -37]
        ],
        [
            [5207, 7871],
            [3, 42],
            [14, 40],
            [-40, 11],
            [-13, 16]
        ],
        [
            [5171, 7980],
            [2, 26],
            [-6, 13]
        ],
        [
            [5171, 8059],
            [-5, 62],
            [17, 0],
            [7, 22],
            [6, 54],
            [-5, 20]
        ],
        [
            [5191, 8217],
            [6, 13],
            [23, 3],
            [5, -13],
            [19, 29],
            [-6, 22],
            [-2, 34]
        ],
        [
            [5236, 8305],
            [21, -8],
            [18, 9]
        ],
        [
            [6196, 5808],
            [7, -19],
            [-1, -24],
            [-16, -14],
            [12, -16]
        ],
        [
            [6198, 5735],
            [-10, -32]
        ],
        [
            [6188, 5703],
            [-7, 11],
            [-6, -5],
            [-16, 1],
            [0, 18],
            [-2, 17],
            [9, 27],
            [10, 26]
        ],
        [
            [6176, 5798],
            [12, -5],
            [8, 15]
        ],
        [
            [5352, 8343],
            [-17, -48],
            [-29, 33],
            [-4, 25],
            [41, 19],
            [9, -29]
        ],
        [
            [5236, 8305],
            [-11, 32],
            [-1, 61],
            [5, 16],
            [8, 17],
            [24, 4],
            [10, 16],
            [22, 17],
            [-1, -30],
            [-8, -20],
            [4, -16],
            [15, -9],
            [-7, -22],
            [-8, 6],
            [-20, -42],
            [7, -29]
        ],
        [
            [3008, 6222],
            [3, 10],
            [22, 0],
            [16, -15],
            [8, 1],
            [5, -21],
            [15, 1],
            [-1, -17],
            [12, -2],
            [14, -22],
            [-10, -24],
            [-14, 13],
            [-12, -3],
            [-9, 3],
            [-5, -11],
            [-11, -3],
            [-4, 14],
            [-10, -8],
            [-11, -41],
            [-7, 10],
            [-1, 17]
        ],
        [
            [3008, 6124],
            [0, 16],
            [-7, 17],
            [7, 10],
            [2, 23],
            [-2, 32]
        ],
        [
            [5333, 6444],
            [-95, -112],
            [-81, -117],
            [-39, -26]
        ],
        [
            [5118, 6189],
            [-31, -6],
            [0, 38],
            [-13, 10],
            [-17, 16],
            [-7, 28],
            [-94, 129],
            [-93, 129]
        ],
        [
            [4863, 6533],
            [-105, 143]
        ],
        [
            [4758, 6676],
            [1, 11],
            [0, 4]
        ],
        [
            [4759, 6691],
            [0, 70],
            [44, 44],
            [28, 9],
            [23, 16],
            [11, 29],
            [32, 24],
            [1, 44],
            [16, 5],
            [13, 22],
            [36, 9],
            [5, 23],
            [-7, 13],
            [-10, 62],
            [-1, 36],
            [-11, 38]
        ],
        [
            [4939, 7135],
            [27, 32],
            [30, 11],
            [17, 24],
            [27, 18],
            [47, 11],
            [46, 4],
            [14, -8],
            [26, 23],
            [30, 0],
            [11, -13],
            [19, 3]
        ],
        [
            [5233, 7240],
            [-5, -30],
            [4, -56],
            [-6, -49],
            [-18, -33],
            [3, -45],
            [23, -35],
            [0, -14],
            [17, -24],
            [12, -106]
        ],
        [
            [5263, 6848],
            [9, -52],
            [1, -28],
            [-5, -48],
            [2, -27],
            [-3, -32],
            [2, -37],
            [-11, -25],
            [17, -43],
            [1, -25],
            [10, -33],
            [13, 11],
            [22, -28],
            [12, -37]
        ],
        [
            [2769, 4856],
            [15, 45],
            [-6, 25],
            [-11, -27],
            [-16, 26],
            [5, 16],
            [-4, 54],
            [9, 9],
            [5, 37],
            [11, 38],
            [-2, 24],
            [15, 13],
            [19, 23]
        ],
        [
            [2906, 5049],
            [4, -45],
            [-9, -39],
            [-30, -62],
            [-33, -23],
            [-17, -51],
            [-6, -40],
            [-15, -24],
            [-12, 29],
            [-11, 7],
            [-12, -5],
            [-1, 22],
            [8, 14],
            [-3, 24]
        ],
        [
            [5969, 6800],
            [-7, -23],
            [-6, -45],
            [-8, -31],
            [-6, -10],
            [-10, 19],
            [-12, 26],
            [-20, 85],
            [-3, -5],
            [12, -63],
            [17, -59],
            [21, -92],
            [10, -32],
            [9, -34],
            [25, -65],
            [-6, -10],
            [1, -39],
            [33, -53],
            [4, -12]
        ],
        [
            [6023, 6357],
            [-110, 0],
            [-107, 0],
            [-112, 0]
        ],
        [
            [5694, 6357],
            [0, 218],
            [0, 210],
            [-8, 47],
            [7, 37],
            [-5, 25],
            [10, 29]
        ],
        [
            [5698, 6923],
            [37, 0],
            [27, -15],
            [28, -18],
            [13, -9],
            [21, 19],
            [11, 17],
            [25, 5],
            [20, -8],
            [7, -29],
            [7, 19],
            [22, -14],
            [22, -3],
            [13, 15]
        ],
        [
            [5951, 6902],
            [18, -102]
        ],
        [
            [6176, 5798],
            [-10, 20],
            [-11, 34],
            [-12, 19],
            [-8, 21],
            [-24, 23],
            [-19, 1],
            [-7, 12],
            [-16, -14],
            [-17, 27],
            [-8, -44],
            [-33, 13]
        ],
        [
            [6011, 5910],
            [-3, 23],
            [12, 87],
            [3, 39],
            [9, 18],
            [20, 10],
            [14, 34]
        ],
        [
            [6066, 6121],
            [16, -69],
            [8, -54],
            [15, -29],
            [38, -55],
            [16, -34],
            [15, -34],
            [8, -20],
            [14, -18]
        ],
        [
            [4749, 7532],
            [1, 42],
            [-11, 25],
            [39, 43],
            [34, -11],
            [37, 1],
            [30, -10],
            [23, 3],
            [45, -2]
        ],
        [
            [4947, 7623],
            [11, -23],
            [51, -27],
            [10, 13],
            [31, -27],
            [32, 8]
        ],
        [
            [5082, 7567],
            [2, -35],
            [-26, -39],
            [-36, -12],
            [-2, -20],
            [-18, -33],
            [-10, -48],
            [11, -34],
            [-16, -26],
            [-6, -39],
            [-21, -11],
            [-20, -46],
            [-35, -1],
            [-27, 1],
            [-17, -21],
            [-11, -22],
            [-13, 5],
            [-11, 20],
            [-8, 34],
            [-26, 9]
        ],
        [
            [4792, 7249],
            [-2, 20],
            [10, 22],
            [4, 16],
            [-9, 17],
            [7, 39],
            [-11, 36],
            [12, 5],
            [1, 27],
            [5, 9],
            [0, 46],
            [13, 16],
            [-8, 30],
            [-16, 2],
            [-5, -8],
            [-16, 0],
            [-7, 29],
            [-11, -8],
            [-10, -15]
        ],
        [
            [5675, 8472],
            [3, 35],
            [-10, -8],
            [-18, 21],
            [-2, 34],
            [35, 17],
            [35, 8],
            [30, -10],
            [29, 2]
        ],
        [
            [5777, 8571],
            [4, -10],
            [-20, -34],
            [8, -55],
            [-12, -19]
        ],
        [
            [5757, 8453],
            [-22, 0],
            [-24, 22],
            [-13, 7],
            [-23, -10]
        ],
        [
            [6188, 5703],
            [-6, -21],
            [10, -32],
            [10, -29],
            [11, -21],
            [90, -70],
            [24, 0]
        ],
        [
            [6327, 5530],
            [-79, -177],
            [-36, -3],
            [-25, -41],
            [-17, -1],
            [-8, -19]
        ],
        [
            [6162, 5289],
            [-19, 0],
            [-11, 20],
            [-26, -25],
            [-8, -24],
            [-18, 4],
            [-6, 7],
            [-7, -1],
            [-9, 0],
            [-35, 50],
            [-19, 0],
            [-10, 20],
            [0, 33],
            [-14, 10]
        ],
        [
            [5980, 5383],
            [-17, 64],
            [-12, 14],
            [-5, 23],
            [-14, 29],
            [-17, 4],
            [9, 34],
            [15, 2],
            [4, 18]
        ],
        [
            [5943, 5571],
            [0, 53]
        ],
        [
            [5943, 5624],
            [8, 62],
            [13, 16],
            [3, 24],
            [12, 45],
            [17, 30],
            [11, 58],
            [4, 51]
        ],
        [
            [5794, 9138],
            [-4, -42],
            [42, -39],
            [-26, -45],
            [33, -67],
            [-19, -51],
            [25, -43],
            [-11, -39],
            [41, -40],
            [-11, -31],
            [-25, -34],
            [-60, -75]
        ],
        [
            [5779, 8632],
            [-50, -5],
            [-49, -21],
            [-45, -13],
            [-16, 32],
            [-27, 20],
            [6, 58],
            [-14, 53],
            [14, 35],
            [25, 37],
            [63, 64],
            [19, 12],
            [-3, 25],
            [-39, 28]
        ],
        [
            [5663, 8957],
            [-9, 23],
            [-1, 91],
            [-43, 40],
            [-37, 29]
        ],
        [
            [5573, 9140],
            [17, 16],
            [30, -32],
            [37, 3],
            [30, -14],
            [26, 26],
            [14, 44],
            [43, 20],
            [35, -24],
            [-11, -41]
        ],
        [
            [9954, 4033],
            [9, -17],
            [-4, -31],
            [-17, -8],
            [-16, 7],
            [-2, 26],
            [10, 21],
            [13, -8],
            [7, 10]
        ],
        [
            [0, 4079],
            [9981, -14],
            [-17, -13],
            [-4, 23],
            [14, 12],
            [9, 3],
            [-9983, 18]
        ],
        [
            [0, 4108],
            [0, -29]
        ],
        [
            [0, 4108],
            [6, 3],
            [-4, -28],
            [-2, -4]
        ],
        [
            [3300, 1994],
            [33, 36],
            [24, -15],
            [16, 24],
            [22, -27],
            [-8, -21],
            [-37, -17],
            [-13, 20],
            [-23, -26],
            [-14, 26]
        ],
        [
            [5265, 7548],
            [-9, -46],
            [-13, 12],
            [-6, 40],
            [5, 22],
            [18, 22],
            [5, -50]
        ],
        [
            [5157, 7984],
            [6, -6],
            [8, 2]
        ],
        [
            [5190, 7775],
            [-2, -17],
            [9, -22],
            [-10, -18],
            [7, -46],
            [15, -8],
            [-3, -25]
        ],
        [
            [5206, 7639],
            [-25, -34],
            [-55, 16],
            [-40, -19],
            [-4, -35]
        ],
        [
            [4947, 7623],
            [14, 35],
            [5, 118],
            [-28, 62],
            [-21, 30],
            [-42, 23],
            [-3, 43],
            [36, 12],
            [47, -15],
            [-9, 67],
            [26, -25],
            [65, 46],
            [8, 48],
            [24, 12]
        ],
        [
            [3485, 5194],
            [7, 25],
            [3, 27]
        ],
        [
            [3495, 5246],
            [4, 26],
            [-10, 34]
        ],
        [
            [3489, 5306],
            [-3, 41],
            [15, 51]
        ],
        [
            [3501, 5398],
            [9, -7],
            [21, -14],
            [29, -50],
            [5, -24]
        ],
        [
            [5308, 4822],
            [-29, 60],
            [-18, 49],
            [-17, 61],
            [1, 19],
            [6, 19],
            [7, 43],
            [5, 44]
        ],
        [
            [5263, 5117],
            [10, 4],
            [40, -1],
            [0, 71]
        ],
        [
            [4827, 8240],
            [-21, 12],
            [-17, -1],
            [6, 32],
            [-6, 32]
        ],
        [
            [4789, 8315],
            [23, 2],
            [30, -37],
            [-15, -40]
        ],
        [
            [4916, 8521],
            [-30, -63],
            [29, 8],
            [30, -1],
            [-7, -48],
            [-25, -53],
            [29, -4],
            [2, -6],
            [25, -69],
            [19, -10],
            [17, -67],
            [8, -24],
            [33, -11],
            [-3, -38],
            [-14, -17],
            [11, -30],
            [-25, -31],
            [-37, 0],
            [-48, -16],
            [-13, 12],
            [-18, -28],
            [-26, 7],
            [-19, -23],
            [-15, 12],
            [41, 62],
            [25, 13],
            [-1, 0],
            [-43, 9],
            [-8, 24],
            [29, 18],
            [-15, 32],
            [5, 39],
            [42, -6],
            [4, 35],
            [-19, 36],
            [0, 1],
            [-34, 10],
            [-7, 16],
            [10, 27],
            [-9, 16],
            [-15, -28],
            [-1, 57],
            [-14, 30],
            [10, 61],
            [21, 48],
            [23, -4],
            [33, 4]
        ],
        [
            [6154, 7511],
            [4, 26],
            [-7, 40],
            [-16, 22],
            [-16, 6],
            [-10, 19]
        ],
        [
            [6109, 7624],
            [4, 6],
            [23, -10],
            [41, -9],
            [38, -28],
            [5, -11],
            [17, 9],
            [25, -13],
            [9, -24],
            [17, -13]
        ],
        [
            [6210, 7485],
            [-27, 29],
            [-29, -3]
        ],
        [
            [5029, 5408],
            [-44, -35],
            [-15, -20],
            [-25, -17],
            [-25, 17]
        ],
        [
            [5000, 5708],
            [-2, -18],
            [12, -30],
            [0, -43],
            [2, -47],
            [7, -21],
            [-6, -54],
            [2, -29],
            [8, -37],
            [6, -21]
        ],
        [
            [4765, 5512],
            [-8, 1],
            [-5, -24],
            [-8, 1],
            [-6, 12],
            [2, 24],
            [-11, 36],
            [-8, -7],
            [-6, -1]
        ],
        [
            [4715, 5554],
            [-7, -3],
            [0, 21],
            [-4, 16],
            [0, 17],
            [-6, 25],
            [-7, 21],
            [-23, 0],
            [-6, -11],
            [-8, -1],
            [-4, -13],
            [-4, -17],
            [-14, -26]
        ],
        [
            [4632, 5583],
            [-13, 35],
            [-10, 24],
            [-8, 7],
            [-6, 12],
            [-4, 26],
            [-4, 13],
            [-8, 10]
        ],
        [
            [4579, 5710],
            [13, 29],
            [8, -2],
            [7, 10],
            [6, 0],
            [5, 8],
            [-3, 20],
            [3, 6],
            [1, 20]
        ],
        [
            [4619, 5801],
            [13, -1],
            [20, -14],
            [6, 1],
            [3, 7],
            [15, -5],
            [4, 4]
        ],
        [
            [4680, 5793],
            [1, -22],
            [5, 0],
            [7, 8],
            [5, -2],
            [7, -15],
            [12, -5],
            [8, 13],
            [9, 8],
            [6, 8],
            [6, -1],
            [6, -13],
            [3, -17],
            [12, -24],
            [-6, -16],
            [-1, -19],
            [6, 6],
            [3, -7],
            [-1, -17],
            [8, -18]
        ],
        [
            [4532, 5834],
            [3, 27]
        ],
        [
            [4535, 5861],
            [31, 1],
            [6, 14],
            [9, 1],
            [11, -14],
            [8, -1],
            [9, 10],
            [6, -17],
            [-12, -13],
            [-12, 1],
            [-12, 13],
            [-10, -14],
            [-5, -1],
            [-7, -8],
            [-25, 1]
        ],
        [
            [4579, 5710],
            [-15, 24],
            [-11, 4],
            [-7, 17],
            [1, 9],
            [-9, 13],
            [-2, 12]
        ],
        [
            [4536, 5789],
            [15, 10],
            [9, -2],
            [8, 7],
            [51, -3]
        ],
        [
            [5263, 5117],
            [-5, 9],
            [10, 66]
        ],
        [
            [5658, 7167],
            [15, -20],
            [22, 3],
            [20, -4],
            [0, -10],
            [15, 7],
            [-4, -18],
            [-40, -5],
            [1, 10],
            [-34, 12],
            [5, 25]
        ],
        [
            [5723, 7469],
            [-17, 2],
            [-14, 6],
            [-34, -16],
            [19, -33],
            [-14, -10],
            [-15, 0],
            [-15, 31],
            [-5, -13],
            [6, -36],
            [14, -27],
            [-10, -13],
            [15, -27],
            [14, -18],
            [0, -33],
            [-25, 16],
            [8, -30],
            [-18, -7],
            [11, -52],
            [-19, -1],
            [-23, 26],
            [-10, 47],
            [-5, 40],
            [-11, 27],
            [-14, 34],
            [-2, 16]
        ],
        [
            [5583, 7470],
            [18, 6],
            [11, 13],
            [15, -2],
            [5, 11],
            [5, 2]
        ],
        [
            [5725, 7529],
            [13, -16],
            [-8, -37],
            [-7, -7]
        ],
        [
            [3701, 9939],
            [93, 35],
            [97, -2],
            [36, 21],
            [98, 6],
            [222, -7],
            [174, -47],
            [-52, -23],
            [-106, -3],
            [-150, -5],
            [14, -11],
            [99, 7],
            [83, -21],
            [54, 18],
            [23, -21],
            [-30, -34],
            [71, 22],
            [135, 23],
            [83, -12],
            [15, -25],
            [-113, -42],
            [-16, -14],
            [-88, -10],
            [64, -3],
            [-32, -43],
            [-23, -38],
            [1, -66],
            [33, -38],
            [-43, -3],
            [-46, -19],
            [52, -31],
            [6, -50],
            [-30, -6],
            [36, -50],
            [-61, -5],
            [32, -24],
            [-9, -20],
            [-39, -10],
            [-39, 0],
            [35, -40],
            [0, -26],
            [-55, 24],
            [-14, -15],
            [37, -15],
            [37, -36],
            [10, -48],
            [-49, -11],
            [-22, 22],
            [-34, 34],
            [10, -40],
            [-33, -31],
            [73, -2],
            [39, -3],
            [-75, -52],
            [-75, -46],
            [-81, -21],
            [-31, 0],
            [-29, -23],
            [-38, -62],
            [-60, -42],
            [-19, -2],
            [-37, -15],
            [-40, -13],
            [-24, -37],
            [0, -41],
            [-15, -39],
            [-45, -47],
            [11, -47],
            [-12, -48],
            [-14, -58],
            [-39, -4],
            [-41, 49],
            [-56, 0],
            [-27, 32],
            [-18, 58],
            [-49, 73],
            [-14, 39],
            [-3, 53],
            [-39, 54],
            [10, 44],
            [-18, 21],
            [27, 69],
            [42, 22],
            [11, 25],
            [6, 46],
            [-32, -21],
            [-15, -9],
            [-25, -8],
            [-34, 19],
            [-2, 40],
            [11, 31],
            [25, 1],
            [57, -15],
            [-48, 37],
            [-24, 20],
            [-28, -8],
            [-23, 15],
            [31, 55],
            [-17, 22],
            [-22, 41],
            [-34, 62],
            [-35, 23],
            [0, 25],
            [-74, 34],
            [-59, 5],
            [-74, -3],
            [-68, -4],
            [-32, 19],
            [-49, 37],
            [73, 19],
            [56, 3],
            [-119, 15],
            [-62, 24],
            [3, 23],
            [106, 28],
            [101, 29],
            [11, 21],
            [-75, 22],
            [24, 23],
            [97, 41],
            [40, 7],
            [-12, 26],
            [66, 16],
            [86, 9],
            [85, 1],
            [30, -19],
            [74, 33],
            [66, -22],
            [39, -5],
            [58, -19],
            [-66, 32],
            [4, 25]
        ],
        [
            [2497, 5869],
            [-14, 10],
            [-17, 1],
            [-13, 12],
            [-15, 24]
        ],
        [
            [2438, 5916],
            [1, 18],
            [3, 13],
            [-4, 12],
            [13, 48],
            [36, 0],
            [1, 20],
            [-5, 4],
            [-3, 12],
            [-10, 14],
            [-11, 20],
            [13, 0],
            [0, 33],
            [26, 0],
            [26, 0]
        ],
        [
            [2529, 5996],
            [10, -11],
            [2, 9],
            [8, -7]
        ],
        [
            [2549, 5987],
            [-13, -23],
            [-13, -16],
            [-2, -12],
            [2, -11],
            [-5, -15]
        ],
        [
            [2518, 5910],
            [-7, -4],
            [2, -7],
            [-6, -6],
            [-9, -15],
            [-1, -9]
        ],
        [
            [3340, 5552],
            [18, -22],
            [17, -38],
            [1, -31],
            [10, -1],
            [15, -29],
            [11, -21]
        ],
        [
            [3412, 5410],
            [-4, -53],
            [-17, -15],
            [1, -14],
            [-5, -31],
            [13, -42],
            [9, -1],
            [3, -33],
            [17, -51]
        ],
        [
            [3313, 5365],
            [-19, 45],
            [7, 16],
            [0, 27],
            [17, 10],
            [7, 11],
            [-10, 22],
            [3, 21],
            [22, 35]
        ],
        [
            [2574, 5825],
            [-5, 18],
            [-8, 5]
        ],
        [
            [2561, 5848],
            [2, 24],
            [-4, 6],
            [-6, 4],
            [-12, -7],
            [-1, 8],
            [-8, 10],
            [-6, 12],
            [-8, 5]
        ],
        [
            [2549, 5987],
            [3, -3],
            [6, 11],
            [8, 1],
            [3, -5],
            [4, 3],
            [13, -6],
            [13, 2],
            [9, 6],
            [3, 7],
            [9, -3],
            [6, -4],
            [8, 1],
            [5, 5],
            [13, -8],
            [4, -1],
            [9, -11],
            [8, -13],
            [10, -9],
            [7, -17]
        ],
        [
            [2690, 5943],
            [-9, 2],
            [-4, -8],
            [-10, -8],
            [-7, 0],
            [-6, -8],
            [-6, 3],
            [-4, 9],
            [-3, -2],
            [-4, -14],
            [-3, 1],
            [0, -12],
            [-10, -17],
            [-5, -7],
            [-3, -7],
            [-8, 12],
            [-6, -16],
            [-6, 1],
            [-6, -2],
            [0, -29],
            [-4, 0],
            [-3, -14],
            [-9, -2]
        ],
        [
            [5522, 7770],
            [7, -23],
            [9, -17],
            [-11, -22]
        ],
        [
            [5515, 7577],
            [-3, -10]
        ],
        [
            [5512, 7567],
            [-26, 22],
            [-16, 21],
            [-26, 18],
            [-23, 43],
            [6, 5],
            [-13, 25],
            [-1, 19],
            [-17, 10],
            [-9, -26],
            [-8, 20],
            [0, 21],
            [1, 1]
        ],
        [
            [5380, 7746],
            [20, -2],
            [5, 9],
            [9, -9],
            [11, -1],
            [0, 16],
            [10, 6],
            [2, 24],
            [23, 16]
        ],
        [
            [5460, 7805],
            [8, -7],
            [21, -26],
            [23, -11],
            [10, 9]
        ],
        [
            [3008, 6124],
            [-19, 10],
            [-13, -5],
            [-17, 5],
            [-13, -11],
            [-15, 18],
            [3, 19],
            [25, -8],
            [21, -5],
            [10, 13],
            [-12, 26],
            [0, 23],
            [-18, 9],
            [7, 16],
            [17, -3],
            [24, -9]
        ],
        [
            [5471, 7900],
            [14, -15],
            [10, -6],
            [24, 7],
            [2, 12],
            [11, 2],
            [14, 9],
            [3, -4],
            [13, 8],
            [6, 13],
            [9, 4],
            [30, -18],
            [6, 6]
        ],
        [
            [5613, 7918],
            [15, -16],
            [2, -16]
        ],
        [
            [5630, 7886],
            [-17, -12],
            [-13, -40],
            [-17, -40],
            [-22, -11]
        ],
        [
            [5561, 7783],
            [-17, 2],
            [-22, -15]
        ],
        [
            [5460, 7805],
            [-6, 20],
            [-4, 0]
        ],
        [
            [8352, 4453],
            [-11, -2],
            [-37, 42],
            [26, 11],
            [14, -18],
            [10, -17],
            [-2, -16]
        ],
        [
            [8471, 4532],
            [2, -11],
            [1, -18]
        ],
        [
            [8474, 4503],
            [-18, -45],
            [-24, -13],
            [-3, 8],
            [2, 20],
            [12, 36],
            [28, 23]
        ],
        [
            [8274, 4579],
            [10, -16],
            [17, 5],
            [7, -25],
            [-32, -12],
            [-19, -8],
            [-15, 1],
            [10, 34],
            [15, 0],
            [7, 21]
        ],
        [
            [8413, 4579],
            [-4, -32],
            [-42, -17],
            [-37, 7],
            [0, 22],
            [22, 12],
            [18, -18],
            [18, 5],
            [25, 21]
        ],
        [
            [8017, 4657],
            [53, -6],
            [6, 25],
            [51, -29],
            [10, -38],
            [42, -11],
            [34, -35],
            [-31, -23],
            [-31, 24],
            [-25, -1],
            [-29, 4],
            [-26, 11],
            [-32, 22],
            [-21, 6],
            [-11, -7],
            [-51, 24],
            [-5, 25],
            [-25, 5],
            [19, 56],
            [34, -3],
            [22, -23],
            [12, -5],
            [4, -21]
        ],
        [
            [8741, 4690],
            [-14, -40],
            [-3, 45],
            [5, 21],
            [6, 20],
            [7, -17],
            [-1, -29]
        ],
        [
            [8534, 4853],
            [-11, -19],
            [-19, 10],
            [-5, 26],
            [28, 3],
            [7, -20]
        ],
        [
            [8623, 4875],
            [10, -45],
            [-23, 24],
            [-23, 5],
            [-16, -4],
            [-19, 2],
            [6, 33],
            [35, 2],
            [30, -17]
        ],
        [
            [8916, 4904],
            [0, -193],
            [1, -192]
        ],
        [
            [8917, 4519],
            [-25, 48],
            [-28, 12],
            [-7, -17],
            [-35, -1],
            [12, 48],
            [17, 16],
            [-7, 64],
            [-14, 50],
            [-53, 50],
            [-23, 5],
            [-42, 54],
            [-8, -28],
            [-11, -5],
            [-6, 21],
            [0, 26],
            [-21, 29],
            [29, 21],
            [20, -1],
            [-2, 16],
            [-41, 0],
            [-11, 35],
            [-25, 11],
            [-11, 29],
            [37, 14],
            [14, 20],
            [45, -25],
            [4, -22],
            [8, -95],
            [29, -35],
            [23, 62],
            [32, 36],
            [25, 0],
            [23, -21],
            [21, -21],
            [30, -11]
        ],
        [
            [8478, 5141],
            [-22, -58],
            [-21, -12],
            [-27, 12],
            [-46, -3],
            [-24, -8],
            [-4, -45],
            [24, -53],
            [15, 27],
            [52, 20],
            [-2, -27],
            [-12, 9],
            [-12, -35],
            [-25, -23],
            [27, -76],
            [-5, -20],
            [25, -68],
            [-1, -39],
            [-14, -17],
            [-11, 20],
            [13, 49],
            [-27, -23],
            [-7, 16],
            [3, 23],
            [-20, 35],
            [3, 57],
            [-19, -18],
            [2, -69],
            [1, -84],
            [-17, -9],
            [-12, 18],
            [8, 54],
            [-4, 57],
            [-12, 1],
            [-9, 40],
            [12, 39],
            [4, 47],
            [14, 89],
            [5, 24],
            [24, 44],
            [22, -18],
            [35, -8],
            [32, 3],
            [27, 43],
            [5, -14]
        ],
        [
            [8574, 5124],
            [-2, -51],
            [-14, 6],
            [-4, -36],
            [11, -32],
            [-8, -7],
            [-11, 38],
            [-8, 75],
            [6, 47],
            [9, 22],
            [2, -32],
            [16, -5],
            [3, -25]
        ],
        [
            [8045, 5176],
            [5, -39],
            [19, -34],
            [18, 12],
            [18, -4],
            [16, 30],
            [13, 5],
            [26, -17],
            [23, 13],
            [14, 82],
            [11, 21],
            [10, 67],
            [32, 0],
            [24, -10]
        ],
        [
            [8274, 5302],
            [-16, -53],
            [20, -56],
            [-5, -28],
            [32, -54],
            [-33, -7],
            [-10, -40],
            [2, -54],
            [-27, -40],
            [-1, -59],
            [-10, -91],
            [-5, 21],
            [-31, -26],
            [-11, 36],
            [-20, 3],
            [-14, 19],
            [-33, -21],
            [-10, 29],
            [-18, -4],
            [-23, 7],
            [-4, 79],
            [-14, 17],
            [-13, 50],
            [-4, 52],
            [3, 55],
            [16, 39]
        ],
        [
            [7939, 4712],
            [-31, -1],
            [-24, 49],
            [-35, 48],
            [-12, 36],
            [-21, 48],
            [-14, 44],
            [-21, 83],
            [-24, 49],
            [-9, 51],
            [-10, 46],
            [-25, 37],
            [-14, 51],
            [-21, 33],
            [-29, 65],
            [-3, 30],
            [18, -2],
            [43, -12],
            [25, -57],
            [21, -40],
            [16, -25],
            [26, -63],
            [28, -1],
            [23, -41],
            [16, -49],
            [22, -27],
            [-12, -49],
            [16, -20],
            [10, -2],
            [5, -41],
            [10, -33],
            [20, -5],
            [14, -37],
            [-7, -74],
            [-1, -91]
        ],
        [
            [7252, 6841],
            [-17, -27],
            [-11, -55],
            [27, -23],
            [26, -29],
            [36, -33],
            [38, -8],
            [16, -30],
            [22, -5],
            [33, -14],
            [23, 1],
            [4, 23],
            [-4, 38],
            [2, 25]
        ],
        [
            [7703, 6727],
            [2, -22],
            [-10, -11],
            [2, -36],
            [-19, 10],
            [-36, -41],
            [0, -33],
            [-15, -50],
            [-1, -29],
            [-13, -48],
            [-21, 13],
            [-1, -61],
            [-7, -20],
            [3, -25],
            [-14, -14]
        ],
        [
            [7472, 6360],
            [-4, -21],
            [-19, 1],
            [-34, -13],
            [2, -44],
            [-15, -35],
            [-40, -40],
            [-31, -69],
            [-21, -38],
            [-28, -38],
            [0, -27],
            [-13, -15],
            [-26, -21],
            [-12, -3],
            [-9, -45],
            [6, -77],
            [1, -49],
            [-11, -56],
            [0, -101],
            [-15, -2],
            [-12, -46],
            [8, -19],
            [-25, -17],
            [-10, -40],
            [-11, -17],
            [-26, 55],
            [-13, 83],
            [-11, 60],
            [-9, 28],
            [-15, 56],
            [-7, 74],
            [-5, 37],
            [-25, 81],
            [-12, 115],
            [-8, 75],
            [0, 72],
            [-5, 55],
            [-41, -35],
            [-19, 7],
            [-36, 71],
            [13, 22],
            [-8, 23],
            [-33, 50]
        ],
        [
            [6893, 6457],
            [19, 40],
            [61, -1],
            [-6, 51],
            [-15, 30],
            [-4, 46],
            [-18, 26],
            [31, 62],
            [32, -4],
            [29, 61],
            [18, 60],
            [27, 60],
            [-1, 42],
            [24, 34],
            [-23, 29],
            [-9, 40],
            [-10, 52],
            [14, 25],
            [42, -14],
            [31, 9],
            [26, 49]
        ],
        [
            [4827, 8240],
            [5, -42],
            [-21, -53],
            [-49, -35],
            [-40, 9],
            [23, 62],
            [-15, 60],
            [38, 46],
            [21, 28]
        ],
        [
            [6497, 7255],
            [25, 12],
            [19, 33],
            [19, -1],
            [12, 11],
            [20, -6],
            [31, -30],
            [22, -6],
            [31, -53],
            [21, -2],
            [3, -49]
        ],
        [
            [6690, 6820],
            [14, -31],
            [11, -36],
            [27, -26],
            [1, -52],
            [13, -10],
            [2, -27],
            [-40, -30],
            [-10, -69]
        ],
        [
            [6708, 6539],
            [-53, 18],
            [-30, 13],
            [-31, 8],
            [-12, 73],
            [-13, 10],
            [-22, -11],
            [-28, -28],
            [-34, 20],
            [-28, 45],
            [-27, 17],
            [-18, 56],
            [-21, 79],
            [-15, -10],
            [-17, 20],
            [-11, -24]
        ],
        [
            [6348, 6825],
            [-15, 32],
            [0, 31],
            [-9, 0],
            [5, 43],
            [-15, 45],
            [-34, 32],
            [-19, 56],
            [6, 46],
            [14, 21],
            [-2, 34],
            [-18, 18],
            [-18, 70]
        ],
        [
            [6243, 7253],
            [-15, 48],
            [5, 18],
            [-8, 68],
            [19, 17]
        ],
        [
            [6357, 7321],
            [9, -43],
            [26, -13],
            [20, -29],
            [39, -10],
            [44, 15],
            [2, 14]
        ],
        [
            [6348, 6825],
            [-16, 3]
        ],
        [
            [6332, 6828],
            [-19, 5],
            [-20, -56]
        ],
        [
            [6293, 6777],
            [-52, 4],
            [-78, 119],
            [-41, 41],
            [-34, 16]
        ],
        [
            [6088, 6957],
            [-11, 72]
        ],
        [
            [6077, 7029],
            [61, 62],
            [11, 71],
            [-3, 43],
            [16, 15],
            [14, 37]
        ],
        [
            [6176, 7257],
            [12, 9],
            [32, -8],
            [10, -15],
            [13, 10]
        ],
        [
            [4597, 8984],
            [-7, -39],
            [31, -40],
            [-36, -45],
            [-80, -41],
            [-24, -10],
            [-36, 8],
            [-78, 19],
            [28, 26],
            [-61, 29],
            [49, 12],
            [-1, 17],
            [-58, 14],
            [19, 38],
            [42, 9],
            [43, -40],
            [42, 32],
            [35, -17],
            [45, 32],
            [47, -4]
        ],
        [
            [5992, 6990],
            [-5, -19]
        ],
        [
            [5987, 6971],
            [-10, 8],
            [-6, -39],
            [7, -7],
            [-7, -8],
            [-1, -15],
            [13, 8]
        ],
        [
            [5983, 6918],
            [0, -23],
            [-14, -95]
        ],
        [
            [5951, 6902],
            [8, 19],
            [-2, 4],
            [8, 27],
            [5, 45],
            [4, 15],
            [1, 0]
        ],
        [
            [5975, 7012],
            [9, 0],
            [3, 11],
            [7, 0]
        ],
        [
            [5994, 7023],
            [1, -24],
            [-4, -9],
            [1, 0]
        ],
        [
            [5431, 7316],
            [-10, -46],
            [4, -19],
            [-6, -30],
            [-21, 22],
            [-14, 7],
            [-39, 30],
            [4, 30],
            [32, -6],
            [28, 7],
            [22, 5]
        ],
        [
            [5255, 7492],
            [17, -42],
            [-4, -78],
            [-13, 4],
            [-11, -20],
            [-10, 16],
            [-2, 71],
            [-6, 34],
            [15, -3],
            [14, 18]
        ],
        [
            [5383, 7805],
            [-3, -29],
            [7, -25]
        ],
        [
            [5387, 7751],
            [-22, 8],
            [-23, -20],
            [1, -30],
            [-3, -17],
            [9, -30],
            [26, -29],
            [14, -49],
            [31, -48],
            [22, 0],
            [7, -13],
            [-8, -11],
            [25, -22],
            [20, -18],
            [24, -30],
            [3, -11],
            [-5, -22],
            [-16, 28],
            [-24, 10],
            [-12, -39],
            [20, -21],
            [-3, -31],
            [-11, -4],
            [-15, -50],
            [-12, -5],
            [0, 18],
            [6, 32],
            [6, 12],
            [-11, 35],
            [-8, 29],
            [-12, 8],
            [-8, 25],
            [-18, 11],
            [-12, 24],
            [-21, 4],
            [-21, 26],
            [-26, 39],
            [-19, 34],
            [-8, 58],
            [-14, 7],
            [-23, 20],
            [-12, -8],
            [-16, -28],
            [-12, -4]
        ],
        [
            [2845, 6150],
            [19, -5],
            [14, -15],
            [5, -16],
            [-19, -1],
            [-9, -10],
            [-15, 10],
            [-16, 21],
            [3, 14],
            [12, 4],
            [6, -2]
        ],
        [
            [5992, 6990],
            [31, -24],
            [54, 63]
        ],
        [
            [6088, 6957],
            [-5, -8],
            [-56, -30],
            [28, -59],
            [-9, -10],
            [-5, -20],
            [-21, -8],
            [-7, -21],
            [-12, -19],
            [-31, 10]
        ],
        [
            [5970, 6792],
            [-1, 8]
        ],
        [
            [5983, 6918],
            [4, 17],
            [0, 36]
        ],
        [
            [8739, 7075],
            [4, -20],
            [-16, -36],
            [-11, 19],
            [-15, -14],
            [-7, -34],
            [-18, 16],
            [0, 28],
            [15, 36],
            [16, -7],
            [12, 25],
            [20, -13]
        ],
        [
            [8915, 7252],
            [-10, -47],
            [4, -30],
            [-14, -42],
            [-35, -27],
            [-49, -4],
            [-40, -67],
            [-19, 22],
            [-1, 44],
            [-48, -13],
            [-33, -27],
            [-32, -2],
            [28, -43],
            [-19, -101],
            [-18, -24],
            [-13, 23],
            [7, 53],
            [-18, 17],
            [-11, 41],
            [26, 18],
            [15, 37],
            [28, 30],
            [20, 41],
            [55, 17],
            [30, -12],
            [29, 105],
            [19, -28],
            [40, 59],
            [16, 23],
            [18, 72],
            [-5, 67],
            [11, 37],
            [30, 11],
            [15, -82],
            [-1, -48],
            [-25, -59],
            [0, -61]
        ],
        [
            [8997, 7667],
            [19, -12],
            [20, 25],
            [6, -67],
            [-41, -16],
            [-25, -59],
            [-43, 41],
            [-15, -65],
            [-31, -1],
            [-4, 59],
            [14, 46],
            [29, 3],
            [8, 82],
            [9, 46],
            [32, -62],
            [22, -20]
        ],
        [
            [6970, 7554],
            [-15, -10],
            [-37, -42],
            [-12, -42],
            [-11, 0],
            [-7, 28],
            [-36, 2],
            [-5, 48],
            [-14, 0],
            [2, 60],
            [-33, 43],
            [-48, -5],
            [-32, -8],
            [-27, 53],
            [-22, 22],
            [-43, 43],
            [-6, 5],
            [-71, -35],
            [1, -218]
        ],
        [
            [6554, 7498],
            [-14, -3],
            [-20, 46],
            [-18, 17],
            [-32, -12],
            [-12, -20]
        ],
        [
            [6458, 7526],
            [-2, 14],
            [7, 25],
            [-5, 21],
            [-32, 20],
            [-13, 53],
            [-15, 15],
            [-1, 19],
            [27, -6],
            [1, 44],
            [23, 9],
            [25, -9],
            [5, 58],
            [-5, 36],
            [-28, -2],
            [-24, 14],
            [-32, -26],
            [-26, -12]
        ],
        [
            [6363, 7799],
            [-14, 9],
            [3, 31],
            [-18, 39],
            [-20, -2],
            [-24, 40],
            [16, 45],
            [-8, 12],
            [22, 65],
            [29, -34],
            [3, 43],
            [58, 64],
            [43, 2],
            [61, -41],
            [33, -24],
            [30, 25],
            [44, 1],
            [35, -30],
            [8, 17],
            [39, -2],
            [7, 28],
            [-45, 40],
            [27, 29],
            [-5, 16],
            [26, 15],
            [-20, 41],
            [13, 20],
            [104, 21],
            [13, 14],
            [70, 22],
            [25, 24],
            [50, -12],
            [9, -61],
            [29, 14],
            [35, -20],
            [-2, -32],
            [27, 3],
            [69, 56],
            [-10, -19],
            [35, -46],
            [62, -150],
            [15, 31],
            [39, -34],
            [39, 16],
            [16, -11],
            [13, -34],
            [20, -12],
            [11, -25],
            [36, 8],
            [15, -36]
        ],
        [
            [7229, 7559],
            [-17, 9],
            [-14, 21],
            [-42, 6],
            [-46, 2],
            [-10, -6],
            [-39, 24],
            [-16, -12],
            [-4, -35],
            [-46, 21],
            [-18, -9],
            [-7, -26]
        ],
        [
            [6155, 4958],
            [-20, -24],
            [-7, -24],
            [-10, -4],
            [-4, -42],
            [-9, -24],
            [-5, -39],
            [-12, -20]
        ],
        [
            [6088, 4781],
            [-40, 59],
            [-1, 35],
            [-101, 120],
            [-5, 6]
        ],
        [
            [5941, 5001],
            [0, 63],
            [8, 24],
            [14, 39],
            [10, 43],
            [-13, 68],
            [-3, 30],
            [-13, 41]
        ],
        [
            [5944, 5309],
            [17, 35],
            [19, 39]
        ],
        [
            [6162, 5289],
            [-24, -67],
            [0, -215],
            [17, -49]
        ],
        [
            [7046, 7387],
            [-53, -9],
            [-34, 19],
            [-30, -4],
            [3, 34],
            [30, -10],
            [10, 18]
        ],
        [
            [6972, 7435],
            [21, -6],
            [36, 43],
            [-33, 31],
            [-20, -15],
            [-21, 22],
            [24, 39],
            [-9, 5]
        ],
        [
            [7849, 5777],
            [-7, 72],
            [18, 49],
            [36, 11],
            [26, -8]
        ],
        [
            [7922, 5901],
            [23, -23],
            [12, 40],
            [25, -21]
        ],
        [
            [7982, 5897],
            [6, -40],
            [-3, -71],
            [-47, -45],
            [13, -36],
            [-30, -4],
            [-24, -24]
        ],
        [
            [7897, 5677],
            [-23, 9],
            [-11, 30],
            [-14, 61]
        ],
        [
            [8564, 7339],
            [24, -70],
            [7, -38],
            [0, -68],
            [-10, -33],
            [-25, -11],
            [-22, -25],
            [-25, -5],
            [-3, 32],
            [5, 45],
            [-13, 61],
            [21, 10],
            [-19, 51]
        ],
        [
            [8504, 7288],
            [2, 5],
            [12, -2],
            [11, 27],
            [20, 2],
            [11, 4],
            [4, 15]
        ],
        [
            [5557, 7574],
            [5, 13]
        ],
        [
            [5562, 7587],
            [7, 4],
            [4, 20],
            [5, 3],
            [4, -8],
            [5, -4],
            [3, -10],
            [5, -2],
            [5, -11],
            [4, 0],
            [-3, -14],
            [-3, -7],
            [1, -5]
        ],
        [
            [5599, 7553],
            [-6, -2],
            [-17, -9],
            [-1, -12],
            [-4, 0]
        ],
        [
            [6332, 6828],
            [6, -26],
            [-3, -13],
            [9, -45]
        ],
        [
            [6344, 6744],
            [-19, -1],
            [-7, 28],
            [-25, 6]
        ],
        [
            [7922, 5901],
            [9, 26],
            [1, 50],
            [-22, 52],
            [-2, 58],
            [-21, 48],
            [-21, 4],
            [-6, -20],
            [-16, -2],
            [-8, 10],
            [-30, -35],
            [0, 53],
            [7, 62],
            [-19, 3],
            [-2, 36],
            [-12, 18]
        ],
        [
            [7780, 6264],
            [6, 21],
            [24, 39]
        ],
        [
            [7837, 6385],
            [17, -47],
            [12, -54],
            [34, 0],
            [11, -52],
            [-18, -15],
            [-8, -21],
            [34, -36],
            [23, -70],
            [17, -52],
            [21, -41],
            [7, -41],
            [-5, -59]
        ],
        [
            [5975, 7012],
            [10, 49],
            [14, 41],
            [0, 2]
        ],
        [
            [5999, 7104],
            [13, -3],
            [4, -23],
            [-15, -22],
            [-7, -33]
        ],
        [
            [4785, 5315],
            [-7, 0],
            [-29, 28],
            [-25, 45],
            [-24, 32],
            [-18, 38]
        ],
        [
            [4682, 5458],
            [6, 19],
            [2, 17],
            [12, 33],
            [13, 27]
        ],
        [
            [5412, 6408],
            [-20, -22],
            [-15, 33],
            [-44, 25]
        ],
        [
            [5263, 6848],
            [13, 14],
            [3, 25],
            [-3, 24],
            [19, 23],
            [8, 19],
            [14, 17],
            [2, 45]
        ],
        [
            [5319, 7015],
            [32, -20],
            [12, 5],
            [23, -10],
            [37, -26],
            [13, -53],
            [25, -11],
            [39, -25],
            [30, -29],
            [13, 15],
            [13, 27],
            [-6, 45],
            [9, 29],
            [20, 28],
            [19, 8],
            [37, -12],
            [10, -27],
            [10, 0],
            [9, -10],
            [28, -7],
            [6, -19]
        ],
        [
            [5694, 6357],
            [0, -118],
            [-32, 0],
            [0, -25]
        ],
        [
            [5662, 6214],
            [-111, 113],
            [-111, 113],
            [-28, -32]
        ],
        [
            [7271, 5502],
            [-4, -62],
            [-12, -16],
            [-24, -14],
            [-13, 47],
            [-5, 85],
            [13, 96],
            [19, -33],
            [13, -42],
            [13, -61]
        ],
        [
            [5804, 3347],
            [10, -18],
            [-9, -29],
            [-4, -19],
            [-16, -9],
            [-5, -19],
            [-10, -6],
            [-21, 46],
            [15, 37],
            [15, 23],
            [13, 12],
            [12, -18]
        ],
        [
            [5631, 8267],
            [-2, 15],
            [3, 16],
            [-13, 10],
            [-29, 10]
        ],
        [
            [5590, 8318],
            [-6, 50]
        ],
        [
            [5584, 8368],
            [32, 18],
            [47, -4],
            [27, 6],
            [4, -12],
            [15, -4],
            [26, -29]
        ],
        [
            [5652, 8242],
            [-7, 19],
            [-14, 6]
        ],
        [
            [5584, 8368],
            [1, 44],
            [14, 37],
            [26, 20],
            [22, -44],
            [22, 1],
            [6, 46]
        ],
        [
            [5757, 8453],
            [14, -14],
            [2, -28],
            [9, -35]
        ],
        [
            [4759, 6691],
            [-4, 0],
            [0, -31],
            [-17, -2],
            [-9, -14],
            [-13, 0],
            [-10, 8],
            [-23, -6],
            [-9, -46],
            [-9, -5],
            [-13, -74],
            [-38, -64],
            [-9, -81],
            [-12, -27],
            [-3, -21],
            [-63, -5]
        ],
        [
            [4527, 6323],
            [1, 27],
            [11, 17],
            [9, 30],
            [-2, 20],
            [10, 42],
            [15, 38],
            [9, 9],
            [8, 35],
            [0, 31],
            [10, 37],
            [19, 21],
            [18, 60],
            [0, 1],
            [14, 23],
            [26, 6],
            [22, 41],
            [14, 16],
            [23, 49],
            [-7, 73],
            [10, 51],
            [4, 31],
            [18, 40],
            [28, 27],
            [21, 25],
            [18, 61],
            [9, 36],
            [20, 0],
            [17, -25],
            [26, 4],
            [29, -13],
            [12, -1]
        ],
        [
            [5739, 7906],
            [6, 9],
            [19, 6],
            [20, -19],
            [12, -2],
            [12, -16],
            [-2, -20],
            [11, -9],
            [4, -25],
            [9, -15],
            [-2, -9],
            [5, -6],
            [-7, -4],
            [-16, 1],
            [-3, 9],
            [-6, -5],
            [2, -11],
            [-7, -19],
            [-5, -20],
            [-7, -6]
        ],
        [
            [5784, 7745],
            [-5, 27],
            [3, 25],
            [-1, 26],
            [-16, 35],
            [-9, 25],
            [-9, 17],
            [-8, 6]
        ],
        [
            [6376, 4321],
            [7, -25],
            [7, -39],
            [4, -71],
            [7, -28],
            [-2, -28],
            [-5, -18],
            [-10, 35],
            [-5, -18],
            [5, -43],
            [-2, -25],
            [-8, -14],
            [-1, -50],
            [-11, -69],
            [-14, -81],
            [-17, -112],
            [-11, -82],
            [-12, -69],
            [-23, -14],
            [-24, -25],
            [-16, 15],
            [-22, 21],
            [-8, 31],
            [-2, 53],
            [-10, 47],
            [-2, 42],
            [5, 43],
            [13, 10],
            [0, 20],
            [13, 45],
            [2, 37],
            [-6, 28],
            [-5, 38],
            [-2, 54],
            [9, 33],
            [4, 38],
            [14, 2],
            [15, 12],
            [11, 10],
            [12, 1],
            [16, 34],
            [23, 36],
            [8, 30],
            [-4, 25],
            [12, -7],
            [15, 41],
            [1, 36],
            [9, 26],
            [10, -25]
        ],
        [
            [2301, 6586],
            [-10, -52],
            [-5, -43],
            [-2, -79],
            [-3, -29],
            [5, -32],
            [9, -29],
            [5, -45],
            [19, -44],
            [6, -34],
            [11, -29],
            [29, -16],
            [12, -25],
            [24, 17],
            [21, 6],
            [21, 11],
            [18, 10],
            [17, 24],
            [7, 34],
            [2, 50],
            [5, 17],
            [19, 16],
            [29, 13],
            [25, -2],
            [17, 5],
            [6, -12],
            [-1, -29],
            [-15, -35],
            [-6, -36],
            [5, -10],
            [-4, -26],
            [-7, -46],
            [-7, 15],
            [-6, -1]
        ],
        [
            [2438, 5916],
            [-32, 64],
            [-14, 19],
            [-23, 16],
            [-15, -5],
            [-22, -22],
            [-14, -6],
            [-20, 16],
            [-21, 11],
            [-26, 27],
            [-21, 8],
            [-31, 28],
            [-23, 28],
            [-7, 16],
            [-16, 3],
            [-28, 19],
            [-12, 27],
            [-30, 34],
            [-14, 37],
            [-6, 29],
            [9, 5],
            [-3, 17],
            [7, 16],
            [0, 20],
            [-10, 27],
            [-2, 23],
            [-9, 30],
            [-25, 59],
            [-28, 46],
            [-13, 37],
            [-24, 24],
            [-5, 14],
            [4, 37],
            [-14, 13],
            [-17, 29],
            [-7, 41],
            [-14, 5],
            [-17, 31],
            [-13, 29],
            [-1, 19],
            [-15, 44],
            [-10, 45],
            [1, 23],
            [-20, 23],
            [-10, -2],
            [-15, 16],
            [-5, -24],
            [5, -28],
            [2, -45],
            [10, -24],
            [21, -41],
            [4, -14],
            [4, -4],
            [4, -20],
            [5, 1],
            [6, -38],
            [8, -15],
            [6, -21],
            [17, -30],
            [10, -55],
            [8, -26],
            [8, -28],
            [1, -31],
            [13, -2],
            [12, -27],
            [10, -26],
            [-1, -11],
            [-12, -21],
            [-5, 0],
            [-7, 36],
            [-18, 33],
            [-20, 29],
            [-14, 15],
            [1, 43],
            [-5, 32],
            [-13, 19],
            [-19, 26],
            [-4, -8],
            [-7, 16],
            [-17, 14],
            [-16, 34],
            [2, 5],
            [11, -4],
            [11, 22],
            [1, 27],
            [-22, 42],
            [-16, 17],
            [-10, 36],
            [-11, 39],
            [-12, 47],
            [-12, 54]
        ],
        [
            [1746, 6980],
            [32, 4],
            [35, 7],
            [-2, -12],
            [41, -29],
            [64, -41],
            [55, 0],
            [22, 0],
            [0, 24],
            [48, 0],
            [10, -20],
            [15, -19],
            [16, -26],
            [9, -31],
            [7, -32],
            [15, -18],
            [23, -18],
            [17, 47],
            [23, 1],
            [19, -24],
            [14, -40],
            [10, -35],
            [16, -34],
            [6, -41],
            [8, -28],
            [22, -18],
            [20, -13],
            [10, 2]
        ],
        [
            [5599, 7553],
            [9, 4],
            [13, 1]
        ],
        [
            [4661, 5921],
            [10, 11],
            [4, 35],
            [9, 1],
            [20, -16],
            [15, 11],
            [11, -4],
            [4, 13],
            [112, 1],
            [6, 42],
            [-5, 7],
            [-13, 255],
            [-14, 255],
            [43, 1]
        ],
        [
            [5118, 6189],
            [0, -136],
            [-15, -39],
            [-2, -37],
            [-25, -9],
            [-38, -5],
            [-10, -21],
            [-18, -3]
        ],
        [
            [4680, 5793],
            [1, 18],
            [-2, 23],
            [-11, 16],
            [-5, 34],
            [-2, 37]
        ],
        [
            [7737, 5644],
            [-3, 44],
            [9, 45],
            [-10, 35],
            [3, 65],
            [-12, 30],
            [-9, 71],
            [-5, 75],
            [-12, 49],
            [-18, -30],
            [-32, -42],
            [-15, 5],
            [-17, 14],
            [9, 73],
            [-6, 56],
            [-21, 68],
            [3, 21],
            [-16, 7],
            [-20, 49]
        ],
        [
            [7780, 6264],
            [-16, -14],
            [-16, -26],
            [-20, -2],
            [-12, -64],
            [-12, -11],
            [14, -52],
            [17, -43],
            [12, -39],
            [-11, -51],
            [-9, -11],
            [6, -30],
            [19, -47],
            [3, -33],
            [0, -27],
            [11, -54],
            [-16, -55],
            [-13, -61]
        ],
        [
            [5538, 7532],
            [-6, 4],
            [-8, 19],
            [-12, 12]
        ],
        [
            [5533, 7629],
            [8, -10],
            [4, -9],
            [9, -6],
            [10, -12],
            [-2, -5]
        ],
        [
            [7437, 7970],
            [29, 10],
            [53, 51],
            [42, 28],
            [24, -18],
            [29, -1],
            [19, -28],
            [28, -2],
            [40, -15],
            [27, 41],
            [-11, 35],
            [28, 61],
            [31, -24],
            [26, -7],
            [32, -15],
            [6, -44],
            [39, -25],
            [26, 11],
            [36, 7],
            [27, -7],
            [28, -29],
            [16, -30],
            [26, 1],
            [35, -10],
            [26, 15],
            [36, 9],
            [41, 42],
            [17, -6],
            [14, -20],
            [33, 5]
        ],
        [
            [5959, 4377],
            [21, 5],
            [34, -17],
            [7, 8],
            [19, 1],
            [10, 18],
            [17, -1],
            [30, 23],
            [22, 34]
        ],
        [
            [6119, 4448],
            [5, -26],
            [-1, -59],
            [3, -52],
            [1, -92],
            [5, -29],
            [-8, -43],
            [-11, -41],
            [-18, -36],
            [-25, -23],
            [-31, -28],
            [-32, -64],
            [-10, -11],
            [-20, -42],
            [-11, -13],
            [-3, -42],
            [14, -45],
            [5, -35],
            [0, -17],
            [5, 3],
            [-1, -58],
            [-4, -28],
            [6, -10],
            [-4, -25],
            [-11, -21],
            [-23, -20],
            [-34, -32],
            [-12, -21],
            [3, -25],
            [7, -4],
            [-3, -31]
        ],
        [
            [5911, 3478],
            [-21, 0]
        ],
        [
            [5890, 3478],
            [-2, 26],
            [-4, 27]
        ],
        [
            [5884, 3531],
            [-3, 21],
            [5, 66],
            [-7, 42],
            [-13, 83]
        ],
        [
            [5866, 3743],
            [29, 67],
            [7, 43],
            [5, 5],
            [3, 35],
            [-5, 17],
            [1, 44],
            [6, 41],
            [0, 75],
            [-15, 19],
            [-13, 4],
            [-6, 15],
            [-13, 12],
            [-23, -1],
            [-2, 22]
        ],
        [
            [5840, 4141],
            [-2, 42],
            [84, 49]
        ],
        [
            [5922, 4232],
            [16, -28],
            [8, 5],
            [11, -15],
            [1, -23],
            [-6, -28],
            [2, -42],
            [19, -36],
            [8, 41],
            [12, 12],
            [-2, 76],
            [-12, 43],
            [-10, 19],
            [-10, -1],
            [-7, 77],
            [7, 45]
        ],
        [
            [4661, 5921],
            [-18, 41],
            [-17, 43],
            [-18, 16],
            [-13, 17],
            [-16, -1],
            [-13, -12],
            [-14, 5],
            [-10, -19]
        ],
        [
            [4542, 6011],
            [-2, 32],
            [8, 29],
            [3, 55],
            [-3, 59],
            [-3, 29],
            [2, 30],
            [-7, 28],
            [-14, 25]
        ],
        [
            [4526, 6298],
            [6, 20],
            [108, -1],
            [-5, 86],
            [7, 30],
            [26, 5],
            [-1, 152],
            [91, -4],
            [0, 90]
        ],
        [
            [5922, 4232],
            [-15, 15],
            [9, 55],
            [9, 21],
            [-6, 49],
            [6, 48],
            [5, 16],
            [-7, 50],
            [-14, 26]
        ],
        [
            [5909, 4512],
            [28, -11],
            [5, -16],
            [10, -28],
            [7, -80]
        ],
        [
            [7836, 5425],
            [7, -5],
            [16, -36],
            [12, -40],
            [2, -39],
            [-3, -27],
            [2, -21],
            [2, -35],
            [10, -16],
            [11, -52],
            [-1, -20],
            [-19, -4],
            [-27, 44],
            [-32, 47],
            [-4, 30],
            [-16, 39],
            [-4, 49],
            [-10, 32],
            [4, 43],
            [-7, 25]
        ],
        [
            [7779, 5439],
            [5, 11],
            [23, -26],
            [2, -30],
            [18, 7],
            [9, 24]
        ],
        [
            [8045, 5176],
            [21, -20],
            [21, 11],
            [6, 50],
            [12, 11],
            [33, 13],
            [20, 47],
            [14, 37]
        ],
        [
            [8206, 5379],
            [22, 41],
            [14, 47],
            [11, 0],
            [14, -30],
            [1, -26],
            [19, -16],
            [23, -18],
            [-2, -23],
            [-19, -3],
            [5, -29],
            [-20, -20]
        ],
        [
            [5453, 3369],
            [-20, 45],
            [-11, 43],
            [-6, 58],
            [-7, 42],
            [-9, 91],
            [-1, 71],
            [-3, 32],
            [-11, 25],
            [-15, 48],
            [-14, 71],
            [-6, 37],
            [-23, 58],
            [-2, 45]
        ],
        [
            [5644, 4022],
            [23, 14],
            [18, -4],
            [11, -13],
            [0, -5]
        ],
        [
            [5552, 3594],
            [0, -218],
            [-25, -30],
            [-15, -4],
            [-17, 11],
            [-13, 4],
            [-4, 25],
            [-11, 17],
            [-14, -30]
        ],
        [
            [9604, 3812],
            [23, -36],
            [14, -28],
            [-10, -14],
            [-16, 16],
            [-19, 27],
            [-18, 31],
            [-19, 42],
            [-4, 20],
            [12, -1],
            [16, -20],
            [12, -20],
            [9, -17]
        ],
        [
            [5412, 6408],
            [7, -92],
            [10, -15],
            [1, -19],
            [11, -20],
            [-6, -25],
            [-11, -120],
            [-1, -77],
            [-35, -56],
            [-12, -78],
            [11, -22],
            [0, -38],
            [18, -1],
            [-3, -28]
        ],
        [
            [5393, 5795],
            [-5, -1],
            [-19, 64],
            [-6, 3],
            [-22, -33],
            [-21, 17],
            [-15, 3],
            [-8, -8],
            [-17, 2],
            [-16, -25],
            [-14, -2],
            [-34, 31],
            [-13, -15],
            [-14, 1],
            [-10, 23],
            [-28, 22],
            [-30, -7],
            [-7, -13],
            [-4, -34],
            [-8, -24],
            [-2, -53]
        ],
        [
            [5236, 5339],
            [-29, -21],
            [-11, 3],
            [-10, -13],
            [-23, 1],
            [-15, 37],
            [-9, 43],
            [-19, 39],
            [-21, -1],
            [-25, 0]
        ],
        [
            [2619, 5713],
            [-10, 18],
            [-13, 24],
            [-6, 20],
            [-12, 19],
            [-13, 26],
            [3, 9],
            [4, -9],
            [2, 5]
        ],
        [
            [2690, 5943],
            [-2, -5],
            [-2, -13],
            [3, -22],
            [-6, -20],
            [-3, -24],
            [-1, -26],
            [1, -15],
            [1, -27],
            [-4, -6],
            [-3, -25],
            [2, -15],
            [-6, -16],
            [2, -16],
            [4, -9]
        ],
        [
            [5092, 8091],
            [14, 16],
            [24, 87],
            [38, 25],
            [23, -2]
        ],
        [
            [5863, 9167],
            [-47, -24],
            [-22, -5]
        ],
        [
            [5573, 9140],
            [-17, -2],
            [-4, -39],
            [-53, 9],
            [-7, -33],
            [-27, 1],
            [-18, -42],
            [-28, -66],
            [-43, -83],
            [10, -20],
            [-10, -24],
            [-27, 1],
            [-18, -55],
            [2, -79],
            [17, -29],
            [-9, -70],
            [-23, -40],
            [-12, -34]
        ],
        [
            [5306, 8535],
            [-19, 36],
            [-55, -69],
            [-37, -13],
            [-38, 30],
            [-10, 63],
            [-9, 137],
            [26, 38],
            [73, 49],
            [55, 61],
            [51, 82],
            [66, 115],
            [47, 44],
            [76, 74],
            [61, 26],
            [46, -3],
            [42, 49],
            [51, -3],
            [50, 12],
            [87, -43],
            [-36, -16],
            [30, -37]
        ],
        [
            [5686, 9657],
            [-62, -24],
            [-49, 13],
            [19, 16],
            [-16, 19],
            [57, 11],
            [11, -22],
            [40, -13]
        ],
        [
            [5506, 9766],
            [92, -44],
            [-70, -23],
            [-15, -44],
            [-25, -11],
            [-13, -49],
            [-34, -2],
            [-59, 36],
            [25, 21],
            [-42, 17],
            [-54, 50],
            [-21, 46],
            [75, 21],
            [16, -20],
            [39, 0],
            [11, 21],
            [40, 2],
            [35, -21]
        ],
        [
            [5706, 9808],
            [55, -21],
            [-41, -32],
            [-81, -7],
            [-82, 10],
            [-5, 16],
            [-40, 1],
            [-30, 27],
            [86, 17],
            [40, -14],
            [28, 17],
            [70, -14]
        ],
        [
            [9805, 2640],
            [6, -24],
            [20, 24],
            [8, -25],
            [0, -25],
            [-10, -27],
            [-18, -44],
            [-14, -24],
            [10, -28],
            [-22, -1],
            [-23, -22],
            [-8, -39],
            [-16, -60],
            [-21, -26],
            [-14, -17],
            [-26, 1],
            [-18, 20],
            [-30, 4],
            [-5, 22],
            [15, 43],
            [35, 59],
            [18, 11],
            [20, 22],
            [24, 31],
            [16, 31],
            [13, 44],
            [10, 15],
            [5, 33],
            [19, 27],
            [6, -25]
        ],
        [
            [9849, 2922],
            [20, -63],
            [1, 41],
            [13, -16],
            [4, -45],
            [22, -19],
            [19, -5],
            [16, 22],
            [14, -6],
            [-7, -53],
            [-8, -34],
            [-22, 1],
            [-7, -18],
            [3, -25],
            [-4, -11],
            [-11, -32],
            [-14, -41],
            [-21, -23],
            [-5, 15],
            [-12, 9],
            [16, 48],
            [-9, 33],
            [-30, 23],
            [1, 22],
            [20, 20],
            [5, 46],
            [-1, 38],
            [-12, 40],
            [1, 10],
            [-13, 25],
            [-22, 52],
            [-12, 42],
            [11, 4],
            [15, -33],
            [21, -15],
            [8, -52]
        ],
        [
            [6475, 6041],
            [-9, 41],
            [-22, 98]
        ],
        [
            [6444, 6180],
            [83, 59],
            [19, 118],
            [-13, 42]
        ],
        [
            [6566, 6530],
            [12, -40],
            [16, -22],
            [20, -8],
            [17, -10],
            [12, -34],
            [8, -20],
            [10, -7],
            [0, -13],
            [-10, -36],
            [-5, -16],
            [-12, -19],
            [-10, -41],
            [-13, 3],
            [-5, -14],
            [-5, -30],
            [4, -39],
            [-3, -7],
            [-13, 0],
            [-17, -22],
            [-3, -29],
            [-6, -12],
            [-18, 0],
            [-10, -15],
            [0, -24],
            [-14, -16],
            [-15, 5],
            [-19, -19],
            [-12, -4]
        ],
        [
            [6557, 6597],
            [8, 20],
            [3, -5],
            [-2, -25],
            [-4, -10]
        ],
        [
            [6893, 6457],
            [-20, 15],
            [-9, 43],
            [-21, 45],
            [-51, -12],
            [-45, -1],
            [-39, -8]
        ],
        [
            [2836, 5484],
            [-9, 17],
            [-6, 32],
            [7, 16],
            [-7, 4],
            [-5, 20],
            [-14, 16],
            [-12, -4],
            [-6, -20],
            [-11, -15],
            [-6, -2],
            [-3, -13],
            [13, -32],
            [-7, -7],
            [-4, -9],
            [-13, -3],
            [-5, 35],
            [-4, -10],
            [-9, 4],
            [-5, 24],
            [-12, 3],
            [-7, 7],
            [-12, 0],
            [-1, -13],
            [-3, 9]
        ],
        [
            [2707, 5623],
            [10, -22],
            [-1, -12],
            [11, -3],
            [3, 5],
            [8, -14],
            [13, 4],
            [12, 15],
            [17, 12],
            [9, 17],
            [16, -3],
            [-1, -6],
            [15, -2],
            [12, -10],
            [10, -18],
            [10, -16]
        ],
        [
            [3045, 3974],
            [-28, 33],
            [-2, 25],
            [-55, 59],
            [-50, 65],
            [-22, 36],
            [-11, 49],
            [4, 17],
            [-23, 77],
            [-28, 109],
            [-26, 118],
            [-11, 27],
            [-9, 43],
            [-21, 39],
            [-20, 24],
            [9, 26],
            [-14, 57],
            [9, 41],
            [22, 37]
        ],
        [
            [8510, 5555],
            [2, -40],
            [2, -33],
            [-9, -54],
            [-11, 60],
            [-13, -30],
            [9, -43],
            [-8, -28],
            [-32, 35],
            [-8, 42],
            [8, 28],
            [-17, 28],
            [-9, -24],
            [-13, 2],
            [-21, -33],
            [-4, 17],
            [11, 50],
            [17, 17],
            [15, 22],
            [10, -27],
            [21, 17],
            [5, 26],
            [19, 1],
            [-1, 46],
            [22, -28],
            [3, -30],
            [2, -21]
        ],
        [
            [8443, 5665],
            [-10, -20],
            [-9, -37],
            [-8, -17],
            [-17, 40],
            [5, 16],
            [7, 17],
            [3, 36],
            [16, 4],
            [-5, -40],
            [21, 57],
            [-3, -56]
        ],
        [
            [8291, 5608],
            [-37, -56],
            [14, 41],
            [20, 37],
            [16, 41],
            [15, 58],
            [5, -48],
            [-18, -33],
            [-15, -40]
        ],
        [
            [8385, 5760],
            [16, -18],
            [18, 0],
            [0, -25],
            [-13, -25],
            [-18, -18],
            [-1, 28],
            [2, 30],
            [-4, 28]
        ],
        [
            [8485, 5776],
            [8, -66],
            [-21, 16],
            [0, -20],
            [7, -37],
            [-13, -13],
            [-1, 42],
            [-9, 3],
            [-4, 36],
            [16, -5],
            [0, 22],
            [-17, 45],
            [27, -1],
            [7, -22]
        ],
        [
            [8375, 5830],
            [-7, -51],
            [-12, 29],
            [-15, 45],
            [24, -2],
            [10, -21]
        ],
        [
            [8369, 6151],
            [17, -17],
            [9, 15],
            [2, -15],
            [-4, -24],
            [9, -43],
            [-7, -49],
            [-16, -19],
            [-5, -48],
            [7, -47],
            [14, -7],
            [13, 7],
            [34, -32],
            [-2, -32],
            [9, -15],
            [-3, -27],
            [-22, 29],
            [-10, 31],
            [-7, -22],
            [-18, 36],
            [-25, -9],
            [-14, 13],
            [1, 25],
            [9, 15],
            [-8, 13],
            [-4, -21],
            [-14, 34],
            [-4, 26],
            [-1, 56],
            [11, -19],
            [3, 92],
            [9, 54],
            [17, 0]
        ],
        [
            [9329, 4655],
            [-8, -6],
            [-12, 22],
            [-12, 38],
            [-6, 45],
            [4, 6],
            [3, -18],
            [8, -13],
            [14, -38],
            [13, -20],
            [-4, -16]
        ],
        [
            [9221, 4734],
            [-15, -5],
            [-4, -17],
            [-15, -14],
            [-15, -14],
            [-14, 0],
            [-23, 18],
            [-16, 16],
            [2, 18],
            [25, -8],
            [15, 4],
            [5, 29],
            [4, 1],
            [2, -31],
            [16, 4],
            [8, 20],
            [16, 21],
            [-4, 35],
            [17, 1],
            [6, -9],
            [-1, -33],
            [-9, -36]
        ],
        [
            [8916, 4904],
            [48, -41],
            [51, -34],
            [19, -30],
            [16, -30],
            [4, -34],
            [46, -37],
            [7, -31],
            [-25, -7],
            [6, -39],
            [25, -39],
            [18, -62],
            [15, 2],
            [-1, -27],
            [22, -10],
            [-9, -11],
            [30, -25],
            [-3, -17],
            [-18, -4],
            [-7, 16],
            [-24, 6],
            [-28, 9],
            [-22, 38],
            [-16, 32],
            [-14, 52],
            [-36, 26],
            [-24, -17],
            [-17, -20],
            [4, -43],
            [-22, -20],
            [-16, 9],
            [-28, 3]
        ],
        [
            [9253, 4792],
            [-9, -16],
            [-5, 35],
            [-6, 23],
            [-13, 19],
            [-16, 25],
            [-20, 18],
            [8, 14],
            [15, -17],
            [9, -13],
            [12, -14],
            [11, -25],
            [11, -19],
            [3, -30]
        ],
        [
            [5392, 8233],
            [19, 18],
            [43, 27],
            [35, 20],
            [28, -10],
            [2, -14],
            [27, -1]
        ],
        [
            [5546, 8273],
            [34, -7],
            [51, 1]
        ],
        [
            [5653, 8105],
            [14, -52],
            [-3, -17],
            [-14, -6],
            [-25, -50],
            [7, -26],
            [-6, 3]
        ],
        [
            [5626, 7957],
            [-26, 23],
            [-20, -8],
            [-13, 6],
            [-17, -13],
            [-14, 21],
            [-11, -8],
            [-2, 4]
        ],
        [
            [3159, 6151],
            [14, -5],
            [5, -12],
            [-7, -15],
            [-21, 1],
            [-17, -2],
            [-1, 25],
            [4, 9],
            [23, -1]
        ],
        [
            [8628, 7562],
            [4, -10]
        ],
        [
            [8632, 7552],
            [-11, 3],
            [-12, -20],
            [-8, -20],
            [1, -42],
            [-14, -13],
            [-5, -11],
            [-11, -17],
            [-18, -10],
            [-12, -16],
            [-1, -25],
            [-3, -7],
            [11, -9],
            [15, -26]
        ],
        [
            [8504, 7288],
            [-13, 11],
            [-4, -11],
            [-8, -5],
            [-1, 11],
            [-7, 5],
            [-8, 10],
            [8, 26],
            [7, 7],
            [-3, 11],
            [7, 31],
            [-2, 10],
            [-16, 7],
            [-13, 15]
        ],
        [
            [4792, 7249],
            [-11, -15],
            [-14, 8],
            [-15, -6],
            [5, 46],
            [-3, 36],
            [-12, 6],
            [-7, 22],
            [2, 39],
            [11, 21],
            [2, 24],
            [6, 36],
            [-1, 25],
            [-5, 21],
            [-1, 20]
        ],
        [
            [6411, 6520],
            [-2, 43],
            [7, 31],
            [8, 6],
            [8, -18],
            [1, -35],
            [-6, -35]
        ],
        [
            [6427, 6512],
            [-8, -4],
            [-8, 12]
        ],
        [
            [5630, 7886],
            [12, 13],
            [17, -7],
            [18, 0],
            [13, -14],
            [10, 9],
            [20, 5],
            [7, 14],
            [12, 0]
        ],
        [
            [5784, 7745],
            [12, -11],
            [13, 9],
            [13, -10]
        ],
        [
            [5822, 7733],
            [0, -15],
            [-13, -13],
            [-9, 6],
            [-7, -71]
        ],
        [
            [5629, 7671],
            [-5, 10],
            [6, 10],
            [-7, 7],
            [-8, -13],
            [-17, 17],
            [-2, 25],
            [-17, 14],
            [-3, 18],
            [-15, 24]
        ],
        [
            [8989, 8056],
            [28, -105],
            [-41, 19],
            [-17, -85],
            [27, -61],
            [-1, -41],
            [-21, 36],
            [-18, -46],
            [-5, 50],
            [3, 57],
            [-3, 64],
            [6, 45],
            [2, 79],
            [-17, 58],
            [3, 80],
            [25, 28],
            [-11, 27],
            [13, 8],
            [7, -39],
            [10, -57],
            [-1, -58],
            [11, -59]
        ],
        [
            [5546, 8273],
            [6, 26],
            [38, 19]
        ],
        [
            [0, 9132],
            [68, -45],
            [73, -59],
            [-3, -37],
            [19, -15],
            [-6, 43],
            [75, -8],
            [55, -56],
            [-28, -26],
            [-46, -6],
            [0, -57],
            [-11, -13],
            [-26, 2],
            [-22, 21],
            [-36, 17],
            [-7, 26],
            [-28, 9],
            [-31, -7],
            [-16, 20],
            [6, 22],
            [-33, -14],
            [13, -28],
            [-16, -25]
        ],
        [
            [0, 8896],
            [0, 236]
        ],
        [
            [0, 9282],
            [9999, -40],
            [-30, -3],
            [-5, 19],
            [-9964, 24]
        ],
        [
            [0, 9282],
            [4, 3],
            [23, 0],
            [40, -17],
            [-2, -8],
            [-29, -14],
            [-36, -4],
            [0, 40]
        ],
        [
            [8988, 9383],
            [-42, -1],
            [-57, 7],
            [-5, 3],
            [27, 23],
            [34, 6],
            [40, -23],
            [3, -15]
        ],
        [
            [9186, 9493],
            [-32, -23],
            [-44, 5],
            [-52, 23],
            [7, 20],
            [51, -9],
            [70, -16]
        ],
        [
            [9029, 9522],
            [-22, -44],
            [-102, 1],
            [-46, -14],
            [-55, 39],
            [15, 40],
            [37, 11],
            [73, -2],
            [100, -31]
        ],
        [
            [6598, 9235],
            [-17, -5],
            [-91, 8],
            [-7, 26],
            [-50, 16],
            [-4, 32],
            [28, 13],
            [-1, 32],
            [55, 50],
            [-25, 7],
            [66, 52],
            [-7, 27],
            [62, 31],
            [91, 38],
            [93, 11],
            [48, 22],
            [54, 8],
            [19, -23],
            [-19, -19],
            [-98, -29],
            [-85, -28],
            [-86, -57],
            [-42, -57],
            [-43, -57],
            [5, -49],
            [54, -49]
        ],
        [
            [0, 8896],
            [9963, -26],
            [-36, 4],
            [25, -31],
            [17, -49],
            [13, -16],
            [3, -24],
            [-7, -16],
            [-52, 13],
            [-78, -44],
            [-25, -7],
            [-42, -42],
            [-40, -36],
            [-11, -27],
            [-39, 41],
            [-73, -46],
            [-12, 22],
            [-27, -26],
            [-37, 8],
            [-9, -38],
            [-33, -58],
            [1, -24],
            [31, -13],
            [-4, -86],
            [-25, -2],
            [-12, -49],
            [11, -26],
            [-48, -30],
            [-10, -67],
            [-41, -15],
            [-9, -60],
            [-40, -55],
            [-10, 41],
            [-12, 86],
            [-15, 131],
            [13, 82],
            [23, 35],
            [2, 28],
            [43, 13],
            [50, 75],
            [47, 60],
            [50, 48],
            [23, 83],
            [-34, -5],
            [-17, -49],
            [-70, -65],
            [-23, 73],
            [-72, -20],
            [-69, -99],
            [23, -36],
            [-62, -16],
            [-43, -6],
            [2, 43],
            [-43, 9],
            [-35, -29],
            [-85, 10],
            [-91, -18],
            [-90, -115],
            [-106, -139],
            [43, -8],
            [14, -37],
            [27, -13],
            [18, 30],
            [30, -4],
            [40, -65],
            [1, -50],
            [-21, -59],
            [-3, -71],
            [-12, -94],
            [-42, -86],
            [-9, -41],
            [-38, -69],
            [-38, -68],
            [-18, -35],
            [-37, -34],
            [-17, -1],
            [-17, 29],
            [-38, -44],
            [-4, -19]
        ],
        [
            [6363, 7799],
            [-12, -35],
            [-27, -10],
            [-28, -61],
            [25, -56],
            [-2, -40],
            [30, -70]
        ],
        [
            [6109, 7624],
            [-35, 49],
            [-32, 23],
            [-24, 34],
            [20, 10],
            [23, 49],
            [-15, 24],
            [41, 24],
            [-1, 13],
            [-25, -10]
        ],
        [
            [6061, 7840],
            [1, 26],
            [14, 17],
            [27, 4],
            [5, 20],
            [-7, 33],
            [12, 30],
            [-1, 18],
            [-41, 19],
            [-16, -1],
            [-17, 28],
            [-21, -9],
            [-35, 20],
            [0, 12],
            [-10, 26],
            [-22, 3],
            [-2, 18],
            [7, 12],
            [-18, 33],
            [-29, -5],
            [-8, 3],
            [-7, -14],
            [-11, 3]
        ],
        [
            [5777, 8571],
            [31, 33],
            [-29, 28]
        ],
        [
            [5863, 9167],
            [29, 20],
            [46, -35],
            [76, -14],
            [105, -67],
            [21, -28],
            [2, -40],
            [-31, -31],
            [-45, -15],
            [-124, 44],
            [-21, -7],
            [45, -43],
            [2, -28],
            [2, -60],
            [36, -18],
            [22, -15],
            [3, 28],
            [-17, 26],
            [18, 22],
            [67, -37],
            [24, 15],
            [-19, 43],
            [65, 58],
            [25, -4],
            [26, -20],
            [16, 40],
            [-23, 35],
            [14, 36],
            [-21, 36],
            [78, -18],
            [16, -34],
            [-35, -7],
            [0, -33],
            [22, -20],
            [43, 13],
            [7, 38],
            [58, 28],
            [97, 50],
            [20, -3],
            [-27, -35],
            [35, -7],
            [19, 21],
            [52, 1],
            [42, 25],
            [31, -36],
            [32, 39],
            [-29, 35],
            [14, 19],
            [82, -18],
            [39, -18],
            [100, -68],
            [19, 31],
            [-28, 31],
            [-1, 13],
            [-34, 6],
            [10, 28],
            [-15, 46],
            [-1, 19],
            [51, 53],
            [18, 54],
            [21, 11],
            [74, -15],
            [5, -33],
            [-26, -48],
            [17, -19],
            [9, -41],
            [-6, -81],
            [31, -36],
            [-12, -40],
            [-55, -84],
            [32, -8],
            [11, 21],
            [31, 15],
            [7, 29],
            [24, 29],
            [-16, 33],
            [13, 39],
            [-31, 5],
            [-6, 33],
            [22, 59],
            [-36, 48],
            [50, 40],
            [-7, 42],
            [14, 2],
            [15, -33],
            [-11, -57],
            [29, -11],
            [-12, 43],
            [46, 23],
            [58, 3],
            [51, -34],
            [-25, 49],
            [-2, 63],
            [48, 12],
            [67, -2],
            [60, 7],
            [-23, 31],
            [33, 39],
            [31, 2],
            [54, 29],
            [74, 8],
            [9, 16],
            [73, 6],
            [23, -14],
            [62, 32],
            [51, -1],
            [8, 25],
            [26, 25],
            [66, 25],
            [48, -19],
            [-38, -15],
            [63, -9],
            [7, -29],
            [25, 14],
            [82, -1],
            [62, -29],
            [23, -22],
            [-7, -30],
            [-31, -18],
            [-73, -33],
            [-21, -17],
            [35, -8],
            [41, -15],
            [25, 11],
            [14, -38],
            [12, 15],
            [44, 10],
            [90, -10],
            [6, -28],
            [116, -9],
            [2, 46],
            [59, -11],
            [44, 1],
            [45, -32],
            [13, -37],
            [-17, -25],
            [35, -47],
            [44, -24],
            [27, 62],
            [44, -26],
            [48, 16],
            [53, -18],
            [21, 16],
            [45, -8],
            [-20, 55],
            [37, 25],
            [251, -38],
            [24, -35],
            [72, -45],
            [112, 11],
            [56, -10],
            [23, -24],
            [-4, -44],
            [35, -16],
            [37, 12],
            [49, 1],
            [52, -11],
            [53, 6],
            [49, -52],
            [34, 19],
            [-23, 37],
            [13, 27],
            [88, -17],
            [58, 4],
            [80, -29],
            [-9960, -25]
        ],
        [
            [7918, 9684],
            [-157, -23],
            [51, 77],
            [23, 7],
            [21, -4],
            [70, -33],
            [-8, -24]
        ],
        [
            [6420, 9816],
            [-37, -8],
            [-25, -4],
            [-4, -10],
            [-33, -10],
            [-30, 14],
            [16, 19],
            [-62, 2],
            [54, 10],
            [43, 1],
            [5, -16],
            [16, 14],
            [26, 10],
            [42, -13],
            [-11, -9]
        ],
        [
            [7775, 9718],
            [-60, -8],
            [-78, 17],
            [-46, 23],
            [-21, 42],
            [-38, 12],
            [72, 40],
            [60, 14],
            [54, -30],
            [64, -57],
            [-7, -53]
        ],
        [
            [5844, 4990],
            [11, -33],
            [-1, -35],
            [-8, -7]
        ],
        [
            [5821, 4978],
            [7, -6],
            [16, 18]
        ],
        [
            [4526, 6298],
            [1, 25]
        ],
        [
            [6188, 6023],
            [-4, 26],
            [-8, 17],
            [-2, 24],
            [-15, 21],
            [-15, 50],
            [-7, 48],
            [-20, 40],
            [-12, 10],
            [-18, 56],
            [-4, 41],
            [2, 35],
            [-16, 66],
            [-13, 23],
            [-15, 12],
            [-10, 34],
            [2, 13],
            [-8, 31],
            [-8, 13],
            [-11, 44],
            [-17, 48],
            [-14, 40],
            [-14, 0],
            [5, 33],
            [1, 20],
            [3, 24]
        ],
        [
            [6344, 6744],
            [11, -51],
            [14, -13],
            [5, -21],
            [18, -25],
            [2, -24],
            [-3, -20],
            [4, -20],
            [8, -16],
            [4, -20],
            [4, -14]
        ],
        [
            [6427, 6512],
            [5, -22]
        ],
        [
            [6444, 6180],
            [-80, -23],
            [-26, -26],
            [-20, -62],
            [-13, -10],
            [-7, 20],
            [-11, -3],
            [-27, 6],
            [-5, 5],
            [-32, -1],
            [-7, -5],
            [-12, 15],
            [-7, -29],
            [3, -25],
            [-12, -19]
        ],
        [
            [5943, 5617],
            [-4, 1],
            [0, 29],
            [-3, 20],
            [-14, 24],
            [-4, 42],
            [4, 44],
            [-13, 4],
            [-2, -13],
            [-17, -3],
            [7, -17],
            [2, -36],
            [-15, -32],
            [-14, -43],
            [-14, -6],
            [-23, 34],
            [-11, -12],
            [-3, -17],
            [-14, -11],
            [-1, -12],
            [-28, 0],
            [-3, 12],
            [-20, 2],
            [-10, -10],
            [-8, 5],
            [-14, 34],
            [-5, 17],
            [-20, -9],
            [-8, -27],
            [-7, -53],
            [-10, -11],
            [-8, -6]
        ],
        [
            [5663, 5567],
            [-2, 2]
        ],
        [
            [5635, 5716],
            [0, 14],
            [-10, 17],
            [-1, 35],
            [-5, 23],
            [-10, -4],
            [3, 22],
            [7, 25],
            [-3, 24],
            [9, 18],
            [-6, 14],
            [7, 36],
            [13, 44],
            [24, -4],
            [-1, 234]
        ],
        [
            [6023, 6357],
            [9, -58],
            [-6, -10],
            [4, -61],
            [11, -71],
            [10, -14],
            [15, -22]
        ],
        [
            [5943, 5624],
            [0, -7]
        ],
        [
            [5943, 5617],
            [0, -46]
        ],
        [
            [5944, 5309],
            [-17, -28],
            [-20, 1],
            [-22, -14],
            [-18, 13],
            [-11, -16]
        ],
        [
            [5682, 5544],
            [-19, 23]
        ],
        [
            [4535, 5861],
            [-11, 46],
            [-14, 21],
            [12, 11],
            [14, 41],
            [6, 31]
        ],
        [
            [4536, 5789],
            [-4, 45]
        ],
        [
            [9502, 4438],
            [8, -20],
            [-19, 0],
            [-11, 37],
            [17, -15],
            [5, -2]
        ],
        [
            [9467, 4474],
            [-11, -1],
            [-17, 6],
            [-5, 9],
            [1, 23],
            [19, -9],
            [9, -12],
            [4, -16]
        ],
        [
            [9490, 4490],
            [-4, -11],
            [-21, 52],
            [-5, 35],
            [9, 0],
            [10, -47],
            [11, -29]
        ],
        [
            [9440, 4565],
            [1, -12],
            [-22, 25],
            [-15, 21],
            [-10, 20],
            [4, 6],
            [13, -14],
            [23, -27],
            [6, -19]
        ],
        [
            [9375, 4623],
            [-5, -3],
            [-13, 14],
            [-11, 24],
            [1, 10],
            [17, -25],
            [11, -20]
        ],
        [
            [4682, 5458],
            [-8, 5],
            [-20, 24],
            [-14, 31],
            [-5, 22],
            [-3, 43]
        ],
        [
            [2561, 5848],
            [-3, -14],
            [-16, 1],
            [-10, 6],
            [-12, 12],
            [-15, 3],
            [-8, 13]
        ],
        [
            [6198, 5735],
            [9, -11],
            [5, -25],
            [13, -24],
            [14, -1],
            [26, 16],
            [30, 7],
            [25, 18],
            [13, 4],
            [10, 11],
            [16, 2]
        ],
        [
            [6359, 5732],
            [0, -1],
            [0, -25],
            [0, -59],
            [0, -31],
            [-13, -36],
            [-19, -50]
        ],
        [
            [6359, 5732],
            [9, 1],
            [13, 9],
            [14, 6],
            [14, 20],
            [10, 0],
            [1, -16],
            [-3, -35],
            [0, -31],
            [-6, -21],
            [-7, -64],
            [-14, -66],
            [-17, -75],
            [-24, -87],
            [-23, -66],
            [-33, -81],
            [-28, -48],
            [-42, -58],
            [-25, -45],
            [-31, -72],
            [-6, -31],
            [-6, -14]
        ],
        [
            [3412, 5410],
            [34, -11],
            [2, 10],
            [23, 4],
            [30, -15]
        ],
        [
            [3489, 5306],
            [10, -35],
            [-4, -25]
        ],
        [
            [5626, 7957],
            [-8, -15],
            [-5, -24]
        ],
        [
            [5380, 7746],
            [7, 5]
        ],
        [
            [5663, 8957],
            [-47, -17],
            [-27, -41],
            [4, -36],
            [-44, -48],
            [-54, -50],
            [-20, -84],
            [20, -41],
            [26, -33],
            [-25, -67],
            [-29, -14],
            [-11, -99],
            [-15, -55],
            [-34, 6],
            [-16, -47],
            [-32, -3],
            [-9, 56],
            [-23, 67],
            [-21, 84]
        ],
        [
            [5890, 3478],
            [-5, -26],
            [-17, -6],
            [-16, 32],
            [0, 20],
            [7, 22],
            [3, 17],
            [8, 5],
            [14, -11]
        ],
        [
            [5999, 7104],
            [-2, 45],
            [7, 25]
        ],
        [
            [6004, 7174],
            [7, 13],
            [7, 13],
            [2, 33],
            [9, -12],
            [31, 17],
            [14, -12],
            [23, 1],
            [32, 22],
            [15, -1],
            [32, 9]
        ],
        [
            [5051, 5420],
            [-22, -12]
        ],
        [
            [7849, 5777],
            [-25, 28],
            [-24, -2],
            [4, 47],
            [-24, 0],
            [-2, -65],
            [-15, -87],
            [-10, -52],
            [2, -43],
            [18, -2],
            [12, -53],
            [5, -52],
            [15, -33],
            [17, -7],
            [14, -31]
        ],
        [
            [7779, 5439],
            [-11, 23],
            [-4, 29],
            [-15, 34],
            [-14, 28],
            [-4, -35],
            [-5, 33],
            [3, 37],
            [8, 56]
        ],
        [
            [6883, 7252],
            [16, 60],
            [-6, 44],
            [-20, 14],
            [7, 26],
            [23, -3],
            [13, 33],
            [9, 38],
            [37, 13],
            [-6, -27],
            [4, -17],
            [12, 2]
        ],
        [
            [6497, 7255],
            [-5, 42],
            [4, 62],
            [-22, 20],
            [8, 40],
            [-19, 4],
            [6, 49],
            [26, -14],
            [25, 19],
            [-20, 35],
            [-8, 34],
            [-23, -15],
            [-3, -43],
            [-8, 38]
        ],
        [
            [6554, 7498],
            [31, 1],
            [-4, 29],
            [24, 21],
            [23, 34],
            [37, -31],
            [3, -47],
            [11, -12],
            [30, 2],
            [9, -10],
            [14, -61],
            [32, -41],
            [18, -28],
            [29, -29],
            [37, -25],
            [-1, -36]
        ],
        [
            [8471, 4532],
            [3, 14],
            [24, 13],
            [19, 2],
            [9, 8],
            [10, -8],
            [-10, -16],
            [-29, -25],
            [-23, -17]
        ],
        [
            [3286, 5693],
            [16, 8],
            [6, -2],
            [-1, -44],
            [-23, -7],
            [-5, 6],
            [8, 16],
            [-1, 23]
        ],
        [
            [5233, 7240],
            [31, 24],
            [19, -7],
            [-1, -30],
            [24, 22],
            [2, -12],
            [-14, -29],
            [0, -27],
            [9, -15],
            [-3, -51],
            [-19, -29],
            [6, -33],
            [14, -1],
            [7, -28],
            [11, -9]
        ],
        [
            [6004, 7174],
            [-11, 27],
            [11, 22],
            [-17, -5],
            [-23, 13],
            [-19, -34],
            [-43, -6],
            [-22, 31],
            [-30, 2],
            [-6, -24],
            [-20, -7],
            [-26, 31],
            [-31, -1],
            [-16, 59],
            [-21, 33],
            [14, 46],
            [-18, 28],
            [31, 56],
            [43, 3],
            [12, 45],
            [53, -8],
            [33, 38],
            [32, 17],
            [46, 1],
            [49, -42],
            [40, -22],
            [32, 9],
            [24, -6],
            [33, 31]
        ],
        [
            [5777, 7539],
            [3, -23],
            [25, -19],
            [-5, -14],
            [-33, -3],
            [-12, -19],
            [-23, -31],
            [-9, 27],
            [0, 12]
        ],
        [
            [8382, 6499],
            [-17, -95],
            [-12, -49],
            [-14, 50],
            [-4, 44],
            [17, 58],
            [22, 45],
            [13, -18],
            [-5, -35]
        ],
        [
            [6088, 4781],
            [-12, -73],
            [1, -33],
            [18, -22],
            [1, -15],
            [-8, -36],
            [2, -18],
            [-2, -28],
            [10, -37],
            [11, -58],
            [10, -13]
        ],
        [
            [5909, 4512],
            [-15, 18],
            [-18, 10],
            [-11, 10],
            [-12, 15]
        ],
        [
            [5844, 4990],
            [10, 8],
            [31, -1],
            [56, 4]
        ],
        [
            [6061, 7840],
            [-22, -5],
            [-18, -19],
            [-26, -3],
            [-24, -22],
            [1, -37],
            [14, -14],
            [28, 4],
            [-5, -21],
            [-31, -11],
            [-37, -34],
            [-16, 12],
            [6, 28],
            [-30, 17],
            [5, 12],
            [26, 19],
            [-8, 14],
            [-43, 15],
            [-2, 22],
            [-25, -8],
            [-11, -32],
            [-21, -44]
        ],
        [
            [3517, 3063],
            [-12, -38],
            [-31, -32],
            [-21, 11],
            [-15, -6],
            [-26, 25],
            [-18, -1],
            [-17, 32]
        ],
        [
            [679, 6185],
            [-4, -10],
            [-7, 8],
            [1, 17],
            [-4, 21],
            [1, 7],
            [5, 10],
            [-2, 11],
            [1, 6],
            [3, -1],
            [10, -10],
            [5, -5],
            [5, -8],
            [7, -21],
            [-1, -3],
            [-11, -13],
            [-9, -9]
        ],
        [
            [664, 6277],
            [-9, -4],
            [-5, 12],
            [-3, 5],
            [0, 4],
            [3, 5],
            [9, -6],
            [8, -9],
            [-3, -7]
        ],
        [
            [646, 6309],
            [-1, -7],
            [-15, 2],
            [2, 7],
            [14, -2]
        ],
        [
            [621, 6317],
            [-2, -3],
            [-2, 1],
            [-9, 2],
            [-4, 13],
            [-1, 2],
            [7, 8],
            [3, -3],
            [8, -20]
        ],
        [
            [574, 6356],
            [-4, -6],
            [-9, 11],
            [1, 4],
            [5, 6],
            [6, -1],
            [1, -14]
        ],
        [
            [3135, 7724],
            [5, -19],
            [-30, -29],
            [-29, -20],
            [-29, -18],
            [-15, -35],
            [-4, -13],
            [-1, -31],
            [10, -32],
            [11, -1],
            [-3, 21],
            [8, -13],
            [-2, -17],
            [-19, -9],
            [-13, 1],
            [-20, -10],
            [-12, -3],
            [-17, -3],
            [-23, -17],
            [41, 11],
            [8, -11],
            [-39, -18],
            [-17, 0],
            [0, 7],
            [-8, -16],
            [8, -3],
            [-6, -43],
            [-20, -45],
            [-2, 15],
            [-6, 3],
            [-9, 15],
            [5, -32],
            [7, -10],
            [1, -23],
            [-9, -23],
            [-16, -47],
            [-2, 3],
            [8, 40],
            [-14, 22],
            [-3, 49],
            [-5, -25],
            [5, -38],
            [-18, 10],
            [19, -19],
            [1, -57],
            [8, -4],
            [3, -20],
            [4, -59],
            [-17, -44],
            [-29, -18],
            [-18, -34],
            [-14, -4],
            [-14, -22],
            [-4, -20],
            [-31, -38],
            [-16, -28],
            [-13, -35],
            [-4, -42],
            [5, -41],
            [9, -51],
            [13, -41],
            [0, -26],
            [13, -69],
            [-1, -39],
            [-1, -23],
            [-7, -36],
            [-8, -8],
            [-14, 7],
            [-4, 26],
            [-11, 14],
            [-15, 51],
            [-13, 45],
            [-4, 23],
            [6, 39],
            [-8, 33],
            [-22, 49],
            [-10, 9],
            [-28, -27],
            [-5, 3],
            [-14, 28],
            [-17, 14],
            [-32, -7],
            [-24, 7],
            [-21, -5],
            [-12, -9],
            [5, -15],
            [0, -24],
            [5, -12],
            [-5, -8],
            [-10, 9],
            [-11, -11],
            [-20, 2],
            [-20, 31],
            [-25, -8],
            [-20, 14],
            [-17, -4],
            [-24, -14],
            [-25, -44],
            [-27, -25],
            [-16, -28],
            [-6, -27],
            [0, -41],
            [1, -28],
            [5, -20]
        ],
        [
            [1746, 6980],
            [-4, 30],
            [-18, 34],
            [-13, 7],
            [-3, 17],
            [-16, 3],
            [-10, 16],
            [-26, 6],
            [-7, 9],
            [-3, 32],
            [-27, 60],
            [-23, 82],
            [1, 14],
            [-13, 19],
            [-21, 50],
            [-4, 48],
            [-15, 32],
            [6, 49],
            [-1, 51],
            [-8, 45],
            [10, 56],
            [4, 53],
            [3, 54],
            [-5, 79],
            [-9, 51],
            [-8, 27],
            [4, 12],
            [40, -20],
            [15, -56],
            [7, 15],
            [-5, 49],
            [-9, 48]
        ],
        [
            [750, 8432],
            [-28, -23],
            [-14, 15],
            [-4, 28],
            [25, 21],
            [15, 9],
            [18, -4],
            [12, -18],
            [-24, -28]
        ],
        [
            [401, 8597],
            [-18, -9],
            [-18, 11],
            [-17, 16],
            [28, 10],
            [22, -6],
            [3, -22]
        ],
        [
            [230, 8826],
            [17, -12],
            [17, 6],
            [23, -15],
            [27, -8],
            [-2, -7],
            [-21, -12],
            [-21, 13],
            [-11, 11],
            [-24, -4],
            [-7, 5],
            [2, 23]
        ],
        [
            [1374, 8295],
            [-15, 22],
            [-25, 19],
            [-8, 52],
            [-36, 47],
            [-15, 56],
            [-26, 4],
            [-44, 2],
            [-33, 17],
            [-57, 61],
            [-27, 11],
            [-49, 21],
            [-38, -5],
            [-55, 27],
            [-33, 25],
            [-30, -12],
            [5, -41],
            [-15, -4],
            [-32, -12],
            [-25, -20],
            [-30, -13],
            [-4, 35],
            [12, 58],
            [30, 18],
            [-8, 15],
            [-35, -33],
            [-19, -39],
            [-40, -42],
            [20, -29],
            [-26, -42],
            [-30, -25],
            [-28, -18],
            [-7, -26],
            [-43, -31],
            [-9, -28],
            [-32, -25],
            [-20, 5],
            [-25, -17],
            [-29, -20],
            [-23, -20],
            [-47, -16],
            [-5, 9],
            [31, 28],
            [27, 18],
            [29, 33],
            [35, 6],
            [14, 25],
            [38, 35],
            [6, 12],
            [21, 21],
            [5, 44],
            [14, 35],
            [-32, -18],
            [-9, 11],
            [-15, -22],
            [-18, 30],
            [-8, -21],
            [-10, 29],
            [-28, -23],
            [-17, 0],
            [-3, 35],
            [5, 21],
            [-17, 22],
            [-37, -12],
            [-23, 28],
            [-19, 14],
            [0, 34],
            [-22, 25],
            [11, 34],
            [23, 33],
            [10, 30],
            [22, 4],
            [19, -9],
            [23, 28],
            [20, -5],
            [21, 19],
            [-5, 27],
            [-16, 10],
            [21, 23],
            [-17, -1],
            [-30, -13],
            [-8, -13],
            [-22, 13],
            [-39, -6],
            [-41, 14],
            [-12, 24],
            [-35, 34],
            [39, 25],
            [62, 29],
            [23, 0],
            [-4, -30],
            [59, 2],
            [-23, 37],
            [-34, 23],
            [-20, 29],
            [-26, 25],
            [-38, 19],
            [15, 31],
            [49, 2],
            [35, 27],
            [7, 29],
            [28, 28],
            [28, 6],
            [52, 27],
            [26, -4],
            [42, 31],
            [42, -12],
            [21, -27],
            [12, 11],
            [47, -3],
            [-2, -14],
            [43, -10],
            [28, 6],
            [59, -18],
            [53, -6],
            [21, -8],
            [37, 10],
            [42, -18],
            [31, -8]
        ],
        [
            [3018, 5753],
            [-1, -14],
            [-16, -7],
            [9, -26],
            [0, -31],
            [-12, -35],
            [10, -47],
            [12, 4],
            [6, 43],
            [-8, 21],
            [-2, 45],
            [35, 24],
            [-4, 27],
            [10, 19],
            [10, -41],
            [19, -1],
            [18, -33],
            [1, -20],
            [25, 0],
            [30, 6],
            [16, -27],
            [21, -7],
            [16, 18],
            [0, 15],
            [34, 4],
            [34, 1],
            [-24, -18],
            [10, -28],
            [22, -4],
            [21, -29],
            [4, -48],
            [15, 2],
            [11, -14]
        ],
        [
            [8001, 6331],
            [-37, -51],
            [-24, -56],
            [-6, -41],
            [22, -62],
            [25, -77],
            [26, -37],
            [17, -47],
            [12, -109],
            [-3, -104],
            [-24, -39],
            [-31, -38],
            [-23, -49],
            [-35, -55],
            [-10, 37],
            [8, 40],
            [-21, 34]
        ],
        [
            [9661, 4085],
            [-9, -8],
            [-9, 26],
            [1, 16],
            [17, -34]
        ],
        [
            [9641, 4175],
            [4, -47],
            [-7, 7],
            [-6, -3],
            [-4, 16],
            [0, 45],
            [13, -18]
        ],
        [
            [6475, 6041],
            [-21, -16],
            [-5, -26],
            [-1, -20],
            [-27, -25],
            [-45, -28],
            [-24, -41],
            [-13, -3],
            [-8, 3],
            [-16, -25],
            [-18, -11],
            [-23, -3],
            [-7, -3],
            [-6, -16],
            [-8, -4],
            [-4, -15],
            [-14, 1],
            [-9, -8],
            [-19, 3],
            [-7, 35],
            [1, 32],
            [-5, 17],
            [-5, 44],
            [-8, 24],
            [5, 3],
            [-2, 27],
            [3, 12],
            [-1, 25]
        ],
        [
            [5817, 3752],
            [11, 0],
            [14, -10],
            [9, 7],
            [15, -6]
        ],
        [
            [5911, 3478],
            [-7, -43],
            [-3, -49],
            [-7, -27],
            [-19, -30],
            [-5, -8],
            [-12, -30],
            [-8, -31],
            [-16, -42],
            [-31, -61],
            [-20, -36],
            [-21, -26],
            [-29, -23],
            [-14, -3],
            [-3, -17],
            [-17, 9],
            [-14, -11],
            [-30, 11],
            [-17, -7],
            [-12, 3],
            [-28, -23],
            [-24, -10],
            [-17, -22],
            [-13, -1],
            [-11, 21],
            [-10, 1],
            [-12, 26],
            [-1, -8],
            [-4, 16],
            [0, 34],
            [-9, 40],
            [9, 11],
            [0, 45],
            [-19, 55],
            [-14, 50],
            [0, 1],
            [-20, 76]
        ],
        [
            [5840, 4141],
            [-21, -8],
            [-15, -23],
            [-4, -21],
            [-10, -4],
            [-24, -49],
            [-15, -38],
            [-10, -2],
            [-9, 7],
            [-31, 7]
        ]
    ],
    "transform": {
        "scale": [0.036003600360036005, 0.016927109510951093],
        "translate": [-180, -85.609038]
    }
}
;
  Datamap.prototype.abwTopo = '__ABW__';
  Datamap.prototype.afgTopo = '__AFG__';
  Datamap.prototype.agoTopo = '__AGO__';
  Datamap.prototype.aiaTopo = '__AIA__';
  Datamap.prototype.albTopo = '__ALB__';
  Datamap.prototype.aldTopo = '__ALD__';
  Datamap.prototype.andTopo = '__AND__';
  Datamap.prototype.areTopo = '__ARE__';
  Datamap.prototype.argTopo = '__ARG__';
  Datamap.prototype.armTopo = '__ARM__';
  Datamap.prototype.asmTopo = '__ASM__';
  Datamap.prototype.ataTopo = '__ATA__';
  Datamap.prototype.atcTopo = '__ATC__';
  Datamap.prototype.atfTopo = '__ATF__';
  Datamap.prototype.atgTopo = '__ATG__';
  Datamap.prototype.ausTopo = '__AUS__';
  Datamap.prototype.autTopo = '__AUT__';
  Datamap.prototype.azeTopo = '__AZE__';
  Datamap.prototype.bdiTopo = '__BDI__';
  Datamap.prototype.belTopo = '__BEL__';
  Datamap.prototype.benTopo = '__BEN__';
  Datamap.prototype.bfaTopo = '__BFA__';
  Datamap.prototype.bgdTopo = '__BGD__';
  Datamap.prototype.bgrTopo = '__BGR__';
  Datamap.prototype.bhrTopo = '__BHR__';
  Datamap.prototype.bhsTopo = '__BHS__';
  Datamap.prototype.bihTopo = '__BIH__';
  Datamap.prototype.bjnTopo = '__BJN__';
  Datamap.prototype.blmTopo = '__BLM__';
  Datamap.prototype.blrTopo = '__BLR__';
  Datamap.prototype.blzTopo = '__BLZ__';
  Datamap.prototype.bmuTopo = '__BMU__';
  Datamap.prototype.bolTopo = '__BOL__';
  Datamap.prototype.braTopo = '__BRA__';
  Datamap.prototype.brbTopo = '__BRB__';
  Datamap.prototype.brnTopo = '__BRN__';
  Datamap.prototype.btnTopo = '__BTN__';
  Datamap.prototype.norTopo = '__NOR__';
  Datamap.prototype.bwaTopo = '__BWA__';
  Datamap.prototype.cafTopo = '__CAF__';
  Datamap.prototype.canTopo = {"type":"Topology","objects":{"can":{"type":"GeometryCollection","geometries":[{"type":"Polygon","properties":{"name":"Alberta"},"id":"AB","arcs":[[0,1,2,3,4,5]]},{"type":"Polygon","properties":{"name":"Saskatchewan"},"id":"SK","arcs":[[6,7,8,9,10,11,-5]]},{"type":"MultiPolygon","properties":{"name":"Manitoba"},"id":"MB","arcs":[[[12]],[[-11,13,14,15,16,17]]]},{"type":"MultiPolygon","properties":{"name":"Newfoundland  & Labrador"},"id":"NL","arcs":[[[18]],[[19]],[[20]],[[21]],[[22]],[[23]],[[24]],[[25]],[[26]],[[27]],[[28]],[[29]],[[30]],[[31]],[[32]],[[33]],[[34]],[[35]],[[36]],[[37]],[[38]],[[39]],[[40]],[[41]],[[42]],[[43]],[[44]],[[45]],[[46]],[[47]],[[48]],[[49]],[[50]],[[51]],[[52]],[[53]],[[54]],[[55]],[[56]],[[57]],[[58]],[[59]],[[60]],[[61]],[[62]],[[63]],[[64]],[[65]],[[66]],[[67]],[[68]],[[69]],[[70]],[[71]],[[72]],[[73]],[[74]],[[75]],[[76]],[[77]],[[78]],[[79]],[[80]],[[81]],[[82]],[[83]],[[84]],[[85]],[[86]],[[87]],[[88]],[[89]],[[90]],[[91]],[[92]],[[93,94,95,96,97,98,99,100,101,102]]]},{"type":"Polygon","properties":{"name":"Prince Edward Island"},"id":"PE","arcs":[[103]]},{"type":"MultiPolygon","properties":{"name":"Nova Scotia"},"id":"NS","arcs":[[[104,105]],[[106]],[[107]]]},{"type":"MultiPolygon","properties":{"name":"Northwest Territories"},"id":"NT","arcs":[[[108]],[[109]],[[110]],[[111]],[[112]],[[113]],[[114]],[[115]],[[116]],[[117]],[[118]],[[119]],[[120]],[[121]],[[122,123,-9,124,-7,-4,125,-2,126,127,128,129,130]],[[131,132]],[[133,134]],[[135,136]],[[137,138]],[[139,140]],[[141]],[[142]],[[143]],[[144]],[[145]],[[146]],[[147]],[[148]],[[149]],[[150]],[[151]],[[152]],[[153]],[[154]],[[155]],[[156]],[[157]],[[158]],[[159]],[[160]],[[161]],[[162]],[[163]],[[164]],[[165]],[[166]],[[167]],[[168]],[[169]],[[170]],[[171]],[[172]],[[173,174]],[[175,176]],[[177,178]]]},{"type":"MultiPolygon","properties":{"name":"Nunavut"},"id":"NU","arcs":[[[179]],[[180]],[[181]],[[182]],[[183]],[[184]],[[185]],[[186]],[[187]],[[188]],[[189]],[[190]],[[191]],[[192]],[[193]],[[194]],[[195]],[[196]],[[197]],[[198]],[[199]],[[200]],[[201]],[[202]],[[203]],[[204]],[[205]],[[206]],[[207]],[[208]],[[209]],[[210]],[[211]],[[212]],[[213]],[[214]],[[215]],[[216]],[[217]],[[218]],[[219]],[[220]],[[221]],[[222]],[[223]],[[224]],[[225]],[[226]],[[227]],[[228]],[[229]],[[230]],[[231]],[[232]],[[233]],[[234]],[[235]],[[236]],[[237]],[[238]],[[239]],[[240]],[[241]],[[242]],[[243]],[[244]],[[245]],[[246]],[[247]],[[248]],[[249]],[[250]],[[251]],[[252]],[[253]],[[254]],[[255]],[[256]],[[257]],[[258]],[[259]],[[260]],[[261]],[[262]],[[263]],[[264]],[[265]],[[266]],[[267]],[[268]],[[269]],[[270]],[[271]],[[272]],[[273]],[[274]],[[275]],[[276]],[[277]],[[278]],[[279]],[[280]],[[281]],[[282]],[[283]],[[284]],[[285]],[[286]],[[287]],[[288]],[[289]],[[290]],[[291]],[[292]],[[293]],[[294]],[[295]],[[296]],[[297]],[[298]],[[299,-133]],[[300,-135]],[[301,-137,302,-139,303,-141]],[[304]],[[305]],[[306]],[[307]],[[308]],[[309]],[[310]],[[311]],[[312]],[[313]],[[314]],[[315]],[[316]],[[317]],[[318]],[[319]],[[320]],[[321]],[[322]],[[323]],[[324]],[[325]],[[326]],[[327]],[[328]],[[329]],[[330]],[[331]],[[332]],[[333]],[[334]],[[335]],[[336]],[[337]],[[338]],[[339]],[[340]],[[341]],[[342]],[[343]],[[344]],[[345]],[[346]],[[347]],[[348]],[[349]],[[350]],[[351]],[[352]],[[353]],[[354]],[[355]],[[356]],[[357]],[[358]],[[359]],[[360]],[[361]],[[362]],[[363]],[[364]],[[365]],[[366]],[[367]],[[368]],[[369]],[[370]],[[371]],[[372]],[[373]],[[374]],[[375]],[[376]],[[377]],[[378]],[[379]],[[380]],[[381]],[[382]],[[383]],[[384]],[[385]],[[386]],[[387]],[[388]],[[389]],[[390]],[[391]],[[392]],[[393]],[[394]],[[395]],[[396]],[[397]],[[398]],[[399]],[[400]],[[401]],[[402]],[[403]],[[404]],[[405]],[[406]],[[407]],[[408]],[[409]],[[410]],[[411]],[[412]],[[413]],[[414]],[[415]],[[416]],[[417]],[[418]],[[419]],[[420]],[[421]],[[422]],[[423]],[[424]],[[425]],[[426]],[[427]],[[428]],[[429]],[[430]],[[431]],[[432]],[[433]],[[434]],[[435]],[[436]],[[437]],[[438]],[[439]],[[440]],[[441]],[[442]],[[443]],[[444]],[[445]],[[446]],[[447]],[[448]],[[449]],[[450]],[[451]],[[452]],[[453]],[[454]],[[455]],[[456]],[[457]],[[458]],[[459]],[[460]],[[461]],[[462]],[[463]],[[464]],[[465]],[[466]],[[467]],[[468]],[[469]],[[470]],[[471]],[[472]],[[473]],[[474]],[[475]],[[476]],[[477]],[[478]],[[479]],[[480]],[[481]],[[482]],[[483]],[[484]],[[485]],[[486]],[[487]],[[488]],[[489]],[[490]],[[491]],[[492]],[[493]],[[494]],[[495]],[[496]],[[497]],[[498]],[[499]],[[500]],[[501]],[[502]],[[503]],[[504]],[[505]],[[506]],[[507]],[[508]],[[509]],[[510]],[[511]],[[512]],[[513]],[[514]],[[515]],[[516]],[[517]],[[518]],[[519]],[[520]],[[521]],[[522]],[[523]],[[524]],[[525]],[[526]],[[527]],[[528]],[[529]],[[530]],[[531]],[[532]],[[533]],[[534]],[[535]],[[536]],[[537]],[[538]],[[539]],[[540]],[[541]],[[542]],[[543]],[[544]],[[545]],[[546]],[[547]],[[548]],[[549]],[[550]],[[551]],[[552]],[[553]],[[554]],[[555]],[[556]],[[557]],[[558]],[[559]],[[560]],[[561]],[[562]],[[563]],[[564]],[[565]],[[566]],[[567]],[[568]],[[569]],[[570]],[[571]],[[572]],[[573]],[[574]],[[575]],[[576]],[[577]],[[578]],[[579]],[[580]],[[581]],[[582]],[[583]],[[584]],[[585]],[[586]],[[587]],[[588]],[[589,-14,-123,590]],[[-175,591,-177,592,-179,593]],[[594]],[[595]]]},{"type":"MultiPolygon","properties":{"name":"Ontario"},"id":"ON","arcs":[[[596]],[[597]],[[598]],[[599]],[[600]],[[601]],[[602]],[[603]],[[604]],[[605]],[[606]],[[607]],[[608]],[[609]],[[610]],[[611]],[[612]],[[613]],[[614]],[[615]],[[616,617,618,619,620,621,622,623,624,625,626,627,628,629,630,-17,631]]]},{"type":"Polygon","properties":{"name":"New Brunswick"},"id":"NB","arcs":[[632,633,634,635,636,637,-106,638]]},{"type":"Polygon","properties":{"name":"Yukon Territory"},"id":"YT","arcs":[[639,-130,640,641,642,643]]},{"type":"MultiPolygon","properties":{"name":"British Columbia"},"id":"BC","arcs":[[[644]],[[645]],[[646]],[[647]],[[648]],[[649]],[[650]],[[651]],[[652]],[[653]],[[654]],[[655]],[[656]],[[657]],[[658]],[[659]],[[660]],[[661]],[[662]],[[663]],[[664]],[[665]],[[666]],[[667]],[[668]],[[669]],[[670]],[[671]],[[672]],[[673]],[[674]],[[675]],[[676]],[[677]],[[678]],[[679]],[[680]],[[681]],[[682]],[[683]],[[684]],[[685]],[[686]],[[687]],[[688]],[[689]],[[690]],[[691]],[[692]],[[693]],[[694]],[[695]],[[696]],[[697]],[[698]],[[699]],[[700]],[[701]],[[702]],[[703]],[[704]],[[705]],[[706]],[[707]],[[708]],[[709]],[[710]],[[711]],[[712]],[[713]],[[714]],[[715]],[[716]],[[717]],[[718]],[[719]],[[720]],[[721]],[[722]],[[723]],[[724]],[[725]],[[726]],[[727]],[[728]],[[729]],[[730]],[[731]],[[732]],[[733]],[[734]],[[735]],[[736]],[[737]],[[738]],[[739]],[[740]],[[741]],[[742]],[[743]],[[744]],[[745]],[[746]],[[747]],[[748]],[[749]],[[750]],[[751]],[[752]],[[753]],[[754]],[[755]],[[756]],[[757]],[[758]],[[759]],[[760]],[[761]],[[762]],[[763]],[[764]],[[-641,-129,765]],[[-642,766,-127,-1,767,768,-644,769]],[[770]],[[771]],[[772,773]]]},{"type":"MultiPolygon","properties":{"name":"Quebec"},"id":"QC","arcs":[[[-103,774,-101,775,-99,776,-630,777,-628,778,-626,779,-624,780,-622,781,-620,782,-618,783,784]],[[785]],[[786]],[[787]],[[788]],[[789]],[[790]],[[94,791,96,792]],[[793]],[[794]],[[795]],[[796]],[[797]],[[798]],[[799]],[[800]],[[801]],[[802]],[[803]],[[804]],[[805]],[[806]],[[807]],[[808]],[[809]],[[810]],[[811]],[[812]],[[813]],[[814]],[[815]],[[816]],[[817]],[[818]],[[819]],[[820]],[[821]],[[822]],[[823]],[[824]],[[825]],[[826]],[[827]],[[828]],[[829]],[[830]],[[831]],[[832]],[[833]],[[834]],[[835]],[[836]],[[837]],[[838]],[[839]],[[840]],[[841]],[[842]],[[843]],[[844]],[[845]],[[846]],[[847]],[[848]],[[849,850,-633,851,852,-636]],[[853]]]}]}},"arcs":[[[3040,1706],[1,3],[2,2],[0,3],[-1,3],[-2,3],[-4,5],[-4,13],[0,3],[-1,3],[-3,3],[-5,4],[-4,-1],[-2,0],[-4,5],[-6,1],[-2,2],[0,4],[1,4],[0,1],[-3,3],[-3,3],[-1,4],[-3,5],[-1,2],[-1,7],[-1,1],[-2,1],[-1,2],[0,2],[-4,1],[-1,3],[-2,6],[0,1],[-1,9],[1,7],[3,15],[-1,2],[-1,0],[-5,-2],[-4,0],[-2,1],[-4,4],[-2,5],[0,5],[3,4],[5,4],[0,7],[0,2],[1,7],[2,5],[-1,9],[1,2],[0,10],[0,6],[-3,7],[-2,6],[0,6],[0,4],[4,13],[-1,12],[0,5],[-4,6],[-3,8],[-1,8],[1,7],[0,3],[-4,17],[1,4],[-1,5],[-1,2],[-2,5],[0,3],[3,2],[0,2],[-1,1],[-4,2],[0,4],[-4,2],[-1,1],[-1,1],[-1,7],[0,2],[-4,5],[-5,9],[-1,5],[-4,11],[-2,5],[-3,-1],[-3,2],[-4,-2],[-5,-1],[-3,-3],[0,-2],[-2,-5],[-2,0],[-2,5],[-1,4],[1,4],[-5,4],[-3,7],[-1,2],[3,4],[0,1],[-2,5],[1,2],[-1,5],[-2,3],[-3,2],[-3,-3],[-1,-1],[-3,3],[-1,4],[-3,3],[-1,1],[-4,3],[0,2],[-4,3],[-4,4],[0,2],[-1,5],[-2,1],[-6,0],[-3,3],[-1,2],[0,2],[9,4],[3,3],[-1,3],[-2,2],[-2,9],[-2,7],[-2,4],[-1,0],[-4,5],[-4,0],[-4,5],[0,1],[-5,9],[-10,1],[0,-1],[-2,0],[-8,10],[-2,0],[0,5],[-3,7],[1,2],[2,4],[-3,7],[-1,1],[-3,4],[-2,1],[-4,2],[-1,0],[-2,2],[-1,2],[0,4],[-2,2],[-4,0],[-2,1],[-4,2],[-1,3],[-2,5],[1,2],[-2,7],[0,4],[1,6],[0,2],[-1,6],[-2,2],[-4,2],[-2,3],[-2,3],[-1,4],[0,3],[0,6],[-2,2],[-4,3],[0,-1],[-2,2],[0,6],[-4,6],[-4,5],[-5,6],[-1,6],[0,3],[0,1],[-4,5],[0,3],[-3,4],[0,2],[1,4],[-2,5],[-2,1],[-1,0],[-4,-2],[-3,1],[-2,-5],[-5,-9],[-1,-2],[1,-4],[-2,-4],[-2,0],[-4,0],[-1,1],[-5,3],[0,3],[-4,6],[0,3],[-1,7],[0,3],[-2,6],[-1,1],[-4,8],[0,6],[-6,5],[-4,8],[-1,2],[-4,4],[-1,0],[-5,6],[-1,2],[2,4],[-1,1],[-4,2],[-2,2],[-5,6],[-1,6],[0,2],[1,8],[-4,16],[-1,0],[-1,-1],[0,-5],[0,-1],[-4,-4],[-2,-1],[-6,0],[-9,2],[-4,-6],[-2,0],[-1,1],[-3,8],[-4,8],[-2,1],[-3,-2],[-9,3],[-1,0],[-3,7],[-1,7],[1,6],[1,3],[3,3],[5,2],[1,2],[1,7],[0,1],[-3,7],[-1,1],[-1,-1],[-7,3],[-5,2],[-1,1],[-4,7],[-5,6],[0,4],[-2,2],[-2,-2],[-2,-3],[-2,-4],[0,-3],[-1,-5],[0,-4],[-4,-2],[-1,0],[-3,1],[-2,0],[-3,-3],[-1,0],[-4,0],[-2,1],[-1,6],[0,1],[2,5],[3,5],[0,1],[-4,1],[-1,1],[-2,4],[-3,5],[0,3],[2,5],[-1,2],[-1,1],[-4,1],[-1,2],[0,4],[-2,3],[0,3],[1,3],[5,5],[0,6],[-1,2],[-4,7],[1,3],[0,1],[-4,4],[-5,5],[-1,6],[1,2],[2,8],[0,2],[-1,1],[-4,0],[-2,4],[1,3],[-5,6],[-1,0],[-3,-2],[-3,1],[-1,-3],[-1,-1],[-3,0],[-1,2],[1,2],[-2,4],[-1,6],[-2,2],[-3,5],[1,3],[2,4],[-1,3],[1,2],[-1,4],[-1,0],[-3,-1],[-2,4],[-2,1],[-2,-1],[-2,-3],[-2,3],[-1,-1],[2,6],[1,1],[3,8],[-1,2],[-1,2],[-3,1],[-1,2],[0,3],[-4,5],[-2,2],[-5,6],[-4,4],[-3,3],[-4,1],[-2,0],[0,-4],[0,-8],[-3,-6],[1,-2],[0,-5],[-3,-3],[-1,0],[0,5],[-3,5],[-5,1],[-2,2],[-3,4],[-2,0],[-5,2],[0,-1],[-1,-4],[-2,0],[-1,9],[-7,14],[-3,8],[-1,1],[1,3],[-1,4],[-3,6],[-2,0],[-4,-1],[-5,1],[-3,1],[-6,1],[-3,4],[-2,0],[0,-1],[1,-4],[-1,-1],[-4,1],[-2,0],[-1,2],[-4,2],[-1,1],[-4,8],[-3,9],[0,4],[-1,4],[-3,3],[-4,3],[-2,-2],[-3,4],[0,1],[3,7],[-1,2],[-3,5],[-2,4],[1,5],[2,0],[5,-2],[6,-4],[3,0],[2,-1],[4,4],[0,3],[-1,2],[-1,5],[-1,2],[-5,7],[-2,4],[-1,0],[-1,-1],[-2,0],[-1,3],[-6,-1],[-1,2],[2,6],[0,1],[0,7],[-4,2],[-3,0],[-2,2],[0,4],[-3,0],[0,47],[0,23],[0,60],[0,97],[0,63],[0,84],[0,77],[0,55],[0,27],[0,36],[0,192],[0,14],[0,77],[0,151],[0,15],[0,94],[0,84],[0,65],[0,23],[0,105],[0,13],[0,80],[0,22]],[[2374,4378],[113,0],[113,0],[113,0],[113,0],[113,0],[113,0],[113,0]],[[3165,4378],[113,0]],[[3278,4378],[113,0],[113,0]],[[3504,4378],[0,-243],[0,-243],[0,-243],[0,-242],[0,-243],[0,-243],[0,-243],[0,-243],[0,-243],[0,-242],[2,-243]],[[3506,1707],[-86,-1],[-60,0],[0,-1],[-103,0],[-108,0],[-53,0],[-51,1],[-5,0]],[[3504,4378],[113,0],[113,0]],[[3730,4378],[114,0]],[[3844,4378],[113,0],[113,0],[113,0],[113,0]],[[4296,4378],[113,0]],[[4409,4378],[0,-643],[0,-38],[0,-21],[0,-63],[0,-254],[4,0],[0,-83],[4,0],[0,-2],[0,-16],[0,-26],[-1,-40],[5,-1],[0,-48],[0,-10],[0,-27],[5,0],[0,-2],[0,-83],[4,0],[1,-85],[3,1],[1,-85],[2,0],[0,-1],[1,-83],[4,0],[0,-1],[1,-84],[4,0],[-1,-86],[4,0],[0,-24],[0,-9],[-1,-51],[4,-1],[1,-82],[3,0],[0,-41],[0,-13],[0,-32],[1,-26],[0,-31],[0,-21],[3,0],[0,-2],[0,-14],[0,-4],[0,-5],[0,-60],[4,0],[0,-87],[3,0],[1,-7],[0,-15],[0,-49],[0,-14],[3,0],[0,-87],[2,0],[1,-85],[2,0],[1,-85],[4,0],[0,-45]],[[4482,1707],[-73,0],[-113,0],[-113,0],[-113,0],[-113,0],[-113,0],[-114,0],[-113,0],[-111,0]],[[5231,4155],[-2,-5],[-2,-2],[-3,-1],[-2,1],[-4,3],[0,4],[4,4],[4,1],[5,-5]],[[4409,4378],[113,0],[113,0],[113,0]],[[4748,4378],[94,0],[19,0],[113,0],[113,0],[112,2],[36,-1]],[[5235,4379],[-2,-28],[0,-23],[-2,-3],[1,-18],[2,-13],[4,-26],[3,-15],[1,-20],[-5,-5],[-2,-28],[-4,-21],[-7,-11],[-8,-3],[-8,-1],[-5,-8],[9,-12],[29,-12],[2,-4],[4,0],[7,-11],[4,-9],[4,-24],[5,-5],[3,0],[4,4],[6,18],[4,1],[2,-3],[-3,-10],[3,-20],[-13,-30],[0,-14],[3,-8],[7,-9],[4,5],[-2,32],[10,26],[-1,22],[4,8],[19,0],[7,-3],[14,0],[15,6],[8,0],[8,-12],[7,-5],[4,3],[3,6],[4,4],[6,0],[9,-4],[4,-5],[5,-38],[4,-8],[7,-24],[1,-35],[23,-41],[5,-40],[2,-4],[2,-32],[4,-8],[0,-11],[5,-18],[10,-27],[11,-25],[6,-25],[-1,-23],[-2,-14],[-11,-33],[-2,-17],[-8,-13],[-7,-7],[-6,-5],[-4,-3],[-1,-3],[2,-4],[4,0],[4,2],[2,3],[3,3],[5,6],[32,24],[13,0],[3,-10],[4,-1],[5,1],[33,18],[78,31],[37,8],[10,0],[23,-11],[39,-30],[8,-3],[3,-3],[8,-2],[34,-17],[17,-5],[29,-15],[36,-7],[2,0]],[[5883,3625],[-532,-768],[-169,-219],[0,-189],[0,-98],[0,-127],[0,-11],[0,-199],[0,-145],[0,-68],[1,-5]],[[5183,1796],[-1,-89],[-13,1],[-79,-1],[-49,0],[-93,0],[0,-1],[-81,1],[-52,0],[-67,0],[-60,0],[-29,0],[-45,0],[-63,0],[-29,0],[-40,0]],[[9939,1877],[-2,2],[0,4],[1,3],[2,3],[3,0],[2,-2],[-1,-5],[-2,-3],[-3,-2]],[[9806,1839],[-3,1],[-1,5],[10,29],[12,8],[4,-2],[3,-8],[-1,-7],[-3,-9],[-16,-11],[-5,-6]],[[9653,1838],[-8,3],[-5,3],[1,2],[3,3],[4,1],[4,-4],[2,-5],[-1,-3]],[[9655,1817],[-3,0],[-2,3],[-1,2],[2,3],[4,0],[3,-3],[-3,-5]],[[9883,1658],[-3,-6],[-2,-2],[-2,-3],[-2,-3],[-2,-1],[-3,2],[2,5],[3,6],[4,4],[5,-2]],[[9701,1777],[-3,1],[-1,2],[-1,3],[1,3],[1,2],[3,1],[2,-3],[1,-4],[-3,-5]],[[9631,1830],[-3,-1],[-2,1],[0,4],[2,3],[3,3],[4,0],[0,-3],[-3,-6],[-1,-1]],[[9880,1638],[-1,-4],[-1,-4],[-6,0],[-2,2],[1,4],[2,1],[1,2],[3,1],[3,-2]],[[9888,1595],[0,-3],[-1,-3],[-2,-2],[-3,0],[-2,1],[-1,3],[1,4],[5,2],[3,-2]],[[9978,1479],[-3,-1],[-1,1],[-1,3],[0,4],[3,4],[3,-1],[2,-5],[-3,-5]],[[9872,1478],[-16,13],[-2,6],[1,4],[17,-4],[16,1],[5,-4],[0,-6],[-5,-10],[-9,-2],[-7,2]],[[9965,1366],[-5,-4],[-1,-2],[-2,-3],[-1,-3],[-4,1],[-1,4],[2,2],[1,5],[0,5],[1,4],[1,2],[5,-4],[3,-5],[1,-2]],[[9834,1388],[1,-36],[-3,-5],[-3,8],[-1,27],[2,8],[4,-2]],[[9824,1315],[-2,-3],[-3,-2],[-2,0],[-1,3],[-1,3],[3,4],[2,1],[2,-1],[2,-5]],[[9824,1378],[-3,-9],[-1,-10],[-3,-11],[-4,-10],[-7,-10],[-8,-11],[-4,-1],[0,6],[3,7],[6,8],[5,7],[2,10],[4,11],[2,11],[3,6],[3,-1],[2,-3]],[[9623,1289],[-3,-1],[-4,4],[1,4],[2,2],[4,-1],[2,-4],[-2,-4]],[[9681,1746],[4,1],[5,15],[3,5],[14,10],[2,5],[0,8],[3,4],[3,-1],[3,-12],[11,-5],[3,5],[0,13],[4,7],[2,-3],[3,-21],[3,-2],[4,9],[7,4],[1,2],[13,30],[12,17],[3,-5],[-6,-11],[4,-12],[-3,-7],[-1,-8],[4,-12],[4,2],[4,15],[6,7],[7,2],[14,-6],[3,1],[5,9],[9,6],[6,-9],[17,-1],[11,-6],[8,-18],[11,-4],[9,-7],[1,-3],[-11,-27],[0,-21],[-7,-5],[-12,3],[-4,-8],[-8,-3],[-1,-4],[3,-4],[0,-5],[-1,-3],[-12,-4],[-1,-5],[5,-5],[0,-3],[-2,-5],[-18,-6],[-5,-3],[-2,-6],[0,-3],[7,0],[14,6],[9,1],[5,-3],[1,-5],[-3,-6],[-14,-7],[-1,-5],[1,-5],[15,-3],[7,3],[7,-6],[6,1],[5,-4],[1,-3],[-3,-5],[-24,-13],[-2,-3],[1,-3],[5,0],[7,-5],[0,-3],[-2,-5],[-1,-2],[-17,-5],[-15,-18],[-1,-6],[6,1],[16,16],[3,-2],[2,-8],[4,1],[9,21],[3,2],[2,-2],[1,-5],[-3,-11],[2,-4],[5,1],[2,12],[4,9],[2,1],[3,-2],[0,-11],[5,1],[4,16],[7,16],[3,1],[3,-2],[4,-14],[2,-2],[6,1],[6,15],[-1,3],[4,12],[8,7],[4,2],[2,-2],[1,-7],[-2,-11],[3,-32],[-4,-18],[-9,-11],[-16,-1],[-11,-16],[-19,-18],[-8,-2],[-22,3],[-9,-3],[-4,-11],[1,-9],[2,-7],[7,-5],[10,-1],[5,-4],[-1,-3],[-10,-2],[-7,0],[-4,-2],[-2,-3],[2,-5],[6,-2],[14,4],[11,6],[3,-3],[-2,-7],[-12,-8],[-5,-12],[-2,-15],[-3,-1],[-4,4],[-2,-2],[9,-28],[6,-4],[-1,-9],[5,-6],[3,-15],[5,-5],[3,1],[2,6],[2,15],[4,12],[3,12],[21,57],[8,10],[5,2],[12,-1],[8,16],[9,9],[3,-2],[0,-8],[-10,-25],[-4,-19],[-12,-33],[-1,-8],[-1,-42],[2,-28],[2,-4],[3,1],[10,17],[17,15],[6,18],[2,29],[4,11],[4,0],[0,-14],[2,-5],[10,-7],[3,-9],[1,-15],[-3,-11],[3,-11],[0,-8],[-17,-49],[-4,-20],[0,-17],[-3,-16],[-8,-23],[-3,-22],[-1,-21],[-3,-11],[-5,-4],[-4,-10],[-8,-11],[-6,2],[-7,15],[-4,4],[-11,-4],[-6,1],[-5,-2],[-4,-14],[-5,-2],[-4,4],[-4,6],[-5,19],[2,11],[5,12],[3,3],[2,6],[0,3],[-6,-2],[-4,-10],[-4,-2],[-3,7],[0,6],[3,9],[9,10],[-1,3],[-4,2],[-1,6],[1,14],[3,8],[9,7],[1,4],[0,3],[-9,7],[-7,-15],[-8,-7],[-13,-32],[-19,-29],[-13,-8],[-4,0],[-5,5],[-2,8],[2,12],[-1,24],[17,44],[4,14],[0,10],[5,12],[1,8],[1,4],[11,8],[-1,4],[-6,2],[-3,4],[1,18],[-2,12],[-5,21],[-6,29],[-2,5],[-3,13],[-8,6],[-7,-1],[-3,-5],[-3,-26],[-3,-14],[0,-4],[-15,-33],[-5,-29],[-11,-13],[-4,2],[0,3],[5,22],[8,22],[-2,4],[-4,-5],[-8,-22],[-7,-10],[-8,-7],[-17,-9],[-6,-20],[-10,-9],[-3,-9],[-2,-1],[-2,-6],[1,-12],[-3,-5],[-3,-9],[-1,-5],[-5,-12],[-15,-13],[-8,-3],[-13,2],[-18,-10],[-23,2],[-11,8],[-3,7],[12,27],[8,9],[24,12],[19,14],[11,19],[10,31],[15,18],[10,9],[17,10],[6,11],[9,9],[2,9],[-4,1],[-10,-12],[-8,-6],[-11,-4],[-2,1],[-1,6],[8,23],[-1,4],[-3,3],[-5,-3],[-10,-30],[-4,-1],[-16,12],[-6,2],[-2,5],[-5,3],[-3,-9],[8,-31],[-4,-13],[-16,-11],[-5,0],[-4,3],[-2,8],[-4,3],[-11,-10],[-5,-2],[-9,1],[-5,7],[2,4],[6,4],[1,4],[-3,4],[-8,-2],[-12,-10],[-6,3],[-1,3],[3,7],[14,14],[22,7],[1,5],[-9,4],[-3,7],[10,19],[-2,14],[4,12],[-2,3],[-3,-1],[-10,-29],[-7,-10],[-8,-2],[-4,3],[-3,6],[-5,3],[-2,-1],[-4,-28],[-4,-7],[-5,0],[-2,2],[0,3],[2,18],[-1,5],[-2,2],[-4,-3],[-2,-10],[-5,-16],[-8,-5],[-15,3],[-10,-2],[-3,-8],[0,-6],[-3,-4],[-5,-1],[-11,5],[-12,1],[-5,4],[-5,-2],[-5,2],[-3,8],[0,8],[-3,1],[-3,-2],[-4,-11],[-6,-3],[-18,10],[-19,1],[-13,-5],[-15,2],[-6,6],[-10,6],[-41,-5],[-3,2],[-1,2],[7,17],[-1,3],[-2,2],[-5,-5],[-7,-19],[-7,-6],[-5,2],[-15,-10],[-20,-7],[-21,-2],[-16,2],[-7,5],[-6,10],[-1,28],[-10,29],[3,10],[26,31],[12,19],[13,18],[15,24],[14,16],[11,17],[8,6],[9,-5],[5,9],[4,3],[1,2],[-5,5],[-8,-1],[-17,9],[-9,0],[-25,-9],[-34,-6],[-4,2],[-1,3],[2,5],[11,16],[22,20],[11,15],[2,6],[3,2],[2,-3],[-4,-11],[-15,-17],[-2,-7],[1,-4],[5,-3],[4,3],[4,6],[9,-8],[6,3],[6,20],[1,11],[13,53],[12,33],[3,4],[2,1],[4,-3],[6,-11],[12,0],[20,-17],[4,2],[-1,6],[-11,9],[-1,5],[2,6],[5,3],[1,4],[-4,7],[3,6],[-1,3],[-5,4],[-13,2],[-7,4],[-3,12],[16,43],[9,9],[5,3],[7,-4],[5,-11],[4,-2],[9,4],[0,3],[-7,12],[-10,11],[-4,12],[4,25],[14,38],[0,7],[5,12],[6,10],[24,65],[11,41],[2,20],[6,18],[5,4],[11,1],[1,3],[-1,7],[-10,9],[2,8],[11,4],[23,26],[8,24],[-2,16],[-5,8],[3,5],[8,5],[11,17],[5,11],[6,26],[8,15],[13,13],[48,31],[9,11],[4,10],[5,3],[8,-5],[4,-15],[4,-7],[5,-3],[5,0],[2,5],[-2,10],[1,4],[3,7],[2,1],[12,-9],[10,1],[6,-5],[0,-4],[-7,-12],[-2,-7],[1,-16],[-3,-5],[-4,-3],[-3,-11],[-9,-1],[-11,6],[-15,-2],[-9,5],[-7,-2],[-5,-7],[2,-7],[12,-15],[4,-16],[7,-2],[6,10],[10,5],[9,-5],[3,-9],[0,-4],[-4,-9],[-4,-3],[-7,-11],[-2,-11],[0,-15],[-4,-12],[-8,-7],[-16,-36],[-4,-1],[-3,9],[2,9],[-1,4],[-3,1],[-5,-14],[5,-20],[0,-6],[-20,-47],[-11,-17],[-3,-2],[-3,-8],[1,-9],[-5,-13],[-19,-38],[-9,-25],[-8,-6],[-4,-10],[-2,-21],[-5,-16],[-7,-5],[-2,-6],[7,-13],[-5,-25],[1,-10],[5,-5],[4,10],[2,14],[4,13],[7,15],[18,26],[15,29],[15,18],[8,8],[8,15],[10,8],[4,-3],[2,-4],[-4,-11],[-13,-23],[-5,-13],[2,-6],[6,2],[10,20],[5,5],[6,-4],[2,-9],[12,-6],[4,-5],[4,-1],[4,2],[14,10],[4,-2],[2,-9],[-4,-13],[-14,-18],[-19,-12],[-31,-29],[-4,-9],[2,-5],[4,0],[5,2],[6,6],[8,11],[5,2],[4,-3],[1,-5],[-4,-12],[-17,-19],[-4,-9],[1,-4],[1,-2],[4,0],[9,7],[11,4],[11,-6],[2,-4],[6,-4],[4,1],[6,-4],[6,-1],[6,18],[3,1],[3,-3],[1,-3],[-3,-11],[1,-3],[4,-4],[5,0],[3,7],[-2,18],[4,10],[3,2],[5,-4],[3,-12],[-18,-54],[-2,-12],[3,-11]],[[9493,2845],[-1,-3],[-2,-1],[-2,0],[-1,2],[1,4],[2,2],[3,-1],[0,-3]],[[9335,2946],[-5,-2],[-5,1],[-1,3],[2,4],[5,1],[4,0],[1,-3],[-1,-4]],[[9644,2692],[-2,-1],[-3,0],[-1,2],[-1,3],[0,4],[2,3],[4,-2],[2,-4],[-1,-5]],[[9645,2672],[-2,-2],[-2,1],[-2,2],[-1,4],[2,3],[2,0],[3,-3],[0,-5]],[[8981,3878],[2,1],[2,1],[4,-2],[1,-5],[-3,-3],[-4,3],[-2,2],[0,3]],[[8970,3860],[4,2],[10,-5],[3,-14],[-2,-9],[-9,-2],[-5,3],[-5,9],[1,8],[3,8]],[[8969,3820],[3,-1],[1,-3],[1,-5],[-1,-2],[-4,1],[-3,1],[-1,2],[2,5],[2,2]],[[8950,3789],[8,6],[10,-4],[1,-4],[-7,-17],[-9,-3],[-5,3],[-6,11],[-1,3],[2,5],[7,0]],[[8986,3773],[-3,-2],[-4,-6],[1,-4],[9,-5],[0,-5],[-8,-1],[-14,8],[-1,2],[4,8],[2,1],[8,13],[4,2],[4,-1],[1,-2],[-3,-8]],[[8977,3735],[3,2],[3,1],[3,-3],[-3,-7],[-4,0],[-3,1],[0,4],[1,2]],[[9001,3718],[2,2],[2,0],[3,-2],[1,-4],[-1,-3],[-5,0],[-2,2],[-1,3],[1,2]],[[8961,3714],[1,5],[2,-1],[4,-2],[0,-7],[-3,-3],[-4,4],[0,4]],[[9055,3632],[3,2],[2,-1],[3,-2],[-2,-5],[-5,0],[-1,3],[0,3]],[[9043,3614],[0,2],[1,2],[4,0],[2,-4],[-2,-3],[-3,-2],[-2,2],[0,3]],[[9032,3586],[1,2],[3,0],[2,-2],[1,-2],[-2,-4],[-4,0],[-2,2],[1,4]],[[9049,3557],[-3,-4],[-4,-2],[-3,2],[-1,6],[3,9],[6,5],[4,3],[5,-3],[1,-4],[-3,-4],[-2,-3],[-3,-5]],[[9011,3644],[7,-3],[1,-8],[-7,-19],[7,-14],[-5,-11],[0,-12],[-2,-7],[-6,0],[-5,7],[-9,5],[-3,5],[5,34],[11,18],[6,5]],[[9043,3523],[1,-3],[-2,-2],[-7,-2],[-9,4],[-5,-1],[-10,5],[-9,0],[-6,3],[-3,6],[6,14],[20,-8],[2,-10],[15,-2],[7,-4]],[[9028,3491],[-2,3],[3,7],[3,3],[4,1],[5,1],[4,-2],[-2,-5],[-2,-1],[-6,-4],[-4,-2],[-3,-1]],[[8963,3522],[3,2],[4,0],[4,-1],[3,-3],[1,-4],[-2,-2],[-2,-1],[-2,-1],[-4,2],[-5,2],[-1,3],[1,3]],[[9088,3445],[-1,2],[-1,3],[3,7],[2,0],[2,-1],[0,-7],[-1,-2],[-2,-1],[-2,-1]],[[9042,3471],[1,2],[2,1],[3,1],[1,-2],[1,-3],[-3,-4],[-2,-1],[-3,3],[0,3]],[[8982,3498],[-2,5],[2,5],[6,2],[5,-1],[15,-7],[1,-3],[-3,-6],[-5,-1],[-14,3],[-5,3]],[[8997,3473],[0,3],[2,2],[4,1],[5,0],[6,-1],[7,-3],[-1,-3],[-3,-2],[-5,-1],[-5,0],[-6,2],[-4,2]],[[9139,3382],[4,-2],[1,-3],[-1,-4],[-3,-2],[-2,1],[-2,6],[3,4]],[[9048,3454],[8,-4],[3,-13],[7,-6],[1,-4],[-6,-10],[-5,-2],[-4,1],[-12,8],[-6,3],[-2,3],[2,5],[4,1],[6,15],[4,3]],[[9091,3397],[3,-6],[-4,-4],[-10,3],[-5,4],[-1,4],[1,3],[4,2],[5,-2],[7,-4]],[[9304,3203],[-1,-2],[-4,0],[-1,3],[0,5],[1,1],[4,-1],[2,-3],[-1,-3]],[[9180,3263],[-3,-4],[-3,-3],[-4,-2],[-4,3],[1,4],[3,4],[5,2],[5,-4]],[[9470,3052],[-5,7],[-1,6],[1,3],[4,0],[6,-4],[1,-5],[-2,-5],[-4,-2]],[[9153,3249],[-3,2],[0,3],[4,7],[1,2],[3,1],[3,-2],[-2,-5],[-2,-4],[-2,-2],[-2,-2]],[[9488,3037],[-3,2],[-1,1],[-2,4],[1,5],[2,1],[3,-1],[2,-3],[1,-3],[-3,-6]],[[9175,3246],[0,-3],[-3,-3],[-2,-1],[-3,-1],[-2,2],[0,3],[2,3],[3,1],[3,0],[2,-1]],[[9293,3156],[-3,5],[1,4],[3,7],[2,1],[3,-6],[-6,-11]],[[9136,3274],[0,-3],[-7,-15],[-2,-1],[-3,2],[0,3],[7,16],[2,0],[3,-2]],[[9305,3161],[5,-2],[4,-9],[-2,-6],[-5,0],[-3,7],[-1,6],[2,4]],[[9465,2986],[-4,4],[-2,5],[3,3],[5,-1],[2,-4],[-4,-7]],[[9583,2877],[-2,-4],[-3,-2],[-2,2],[-2,1],[1,4],[2,3],[4,0],[2,-4]],[[9363,2993],[-2,2],[-1,2],[5,7],[2,-1],[2,-1],[0,-6],[-3,-3],[-3,0]],[[9648,2803],[-2,-3],[-3,1],[-2,1],[0,3],[1,2],[2,2],[2,-2],[2,-4]],[[9600,2825],[3,2],[5,-4],[6,1],[4,-3],[0,-5],[-1,-3],[-4,-1],[-9,6],[-4,7]],[[9626,2799],[5,2],[7,-4],[5,-6],[1,-4],[-2,-3],[-3,0],[-7,6],[-4,4],[-2,5]],[[9057,3397],[4,-2],[0,-4],[-5,-1],[-3,3],[2,3],[2,1]],[[9586,1174],[0,4],[2,5],[3,1],[2,-1],[1,-8],[-2,-3],[-4,1],[-2,1]],[[9571,1180],[-4,3],[-2,7],[8,21],[-1,9],[-9,35],[2,12],[3,1],[2,-2],[4,-12],[7,-8],[0,-6],[-5,-14],[2,-8],[7,-18],[-1,-5],[-7,-12],[-6,-3]],[[9637,2618],[-3,-5],[-3,0],[-2,1],[-2,3],[1,3],[4,2],[5,-4]],[[9648,2573],[3,-6],[0,-4],[-3,-2],[-2,0],[-2,3],[-1,2],[-1,3],[-1,3],[2,3],[2,1],[3,-3]],[[9684,2409],[-2,4],[7,15],[8,6],[3,-2],[-8,-19],[-3,-4],[-5,0]],[[9681,2343],[-2,-1],[-3,0],[-1,3],[0,4],[2,3],[2,1],[2,1],[2,-1],[1,-3],[-3,-7]],[[9665,2172],[-5,4],[-1,8],[4,9],[3,1],[3,-2],[1,-12],[-5,-8]],[[9678,2140],[1,-3],[-6,-12],[-6,-3],[-3,1],[-2,8],[3,7],[11,4],[2,-2]],[[9471,2151],[5,2],[2,-2],[1,-3],[-3,-5],[-5,-2],[-2,1],[0,3],[2,6]],[[9660,2005],[0,-4],[-1,-1],[-2,-2],[-2,-1],[-3,2],[-1,3],[0,3],[2,2],[3,1],[4,-3]],[[9642,1992],[0,-3],[-1,-3],[-1,-2],[-2,-1],[-2,2],[-1,3],[1,3],[2,2],[4,-1]],[[9789,1839],[-1,2],[3,9],[4,11],[2,-2],[1,-4],[-1,-7],[-1,-11],[-3,-2],[-4,4]],[[9758,1854],[-3,-1],[-4,3],[-6,0],[-2,4],[2,4],[12,2],[3,-4],[-2,-8]],[[9761,1851],[9,8],[4,-3],[-1,-7],[-6,-14],[-22,-10],[-5,1],[-5,17],[2,4],[3,0],[3,-2],[1,-5],[5,-3],[3,0],[5,4],[4,10]],[[9750,1795],[-3,2],[2,5],[6,13],[4,0],[2,-3],[-3,-2],[-5,-12],[-3,-3]],[[8610,4432],[3,4],[-1,3],[-6,2]],[[8606,4441],[-4,2],[-1,3],[2,4],[12,9],[7,19],[5,-1],[3,-6],[16,-6]],[[8646,4465],[6,-2],[10,-7],[4,-6],[-3,-4],[-16,9]],[[8647,4455],[-3,2],[-4,-1],[-2,-3],[2,-3],[2,-1]],[[8642,4449],[8,-5],[6,-11],[4,0],[7,-4],[-4,-9],[-7,-7],[-3,-7],[1,-3],[4,-2],[5,2],[3,6],[5,-2],[1,-3],[-5,-11],[-4,-4],[-6,-2],[-2,-3],[6,-9],[-2,-12],[2,-6],[4,0],[6,16],[4,3],[9,3],[0,5],[-7,8],[2,5],[10,1],[6,-3],[3,-7],[0,-5],[-6,-14],[-7,-9],[2,-4],[5,-5],[1,-7],[4,-5],[7,2],[0,-8],[9,-20],[-3,-6],[-5,-1],[-10,10],[-6,3],[-3,-4],[6,-14],[10,-1],[7,-5],[-2,-5],[-9,-8],[-3,-9],[0,-7],[4,-4],[4,1],[5,13],[12,9],[5,-3],[7,-21],[7,-11],[-1,-6],[-8,-3],[-15,1],[-7,-1],[-2,-7],[3,-3],[8,-4],[15,-1],[6,-3],[3,-5],[-4,-16],[2,-5],[5,2],[2,10],[5,10],[9,-4],[4,-10],[-7,-16],[3,-5],[5,2],[9,18],[6,-1],[1,-3],[-2,-10],[5,-10],[-7,-13],[-10,-9],[-11,-6],[-13,-2],[-6,0],[-15,7],[-8,0],[-1,-3],[3,-6],[4,-16],[6,1],[8,9],[14,-2],[47,16],[7,-3],[1,-4],[-2,-4],[-9,-1],[-2,-3],[7,-7],[2,-10],[4,-2],[1,-3],[-3,-5],[-6,-4],[-1,-5],[3,-3],[8,1],[14,7],[4,-2],[3,-10],[9,-9],[-2,-6],[-7,-6],[-4,-8],[2,-4],[9,3],[4,-3],[-21,-37],[-9,-6],[-12,-4],[-9,0],[-12,6],[-4,-2],[-3,-9],[1,-3],[9,-3],[1,-3],[-2,-6],[-11,-13],[-3,-7],[2,-5],[7,4],[16,22],[14,8],[6,-2],[1,-3],[-4,-10],[2,-5],[6,5],[9,16],[6,3],[20,2],[16,6],[7,-3],[2,-6],[-9,-14],[3,-15],[-3,-7],[-6,-8],[3,-5],[14,-3],[1,-9],[-17,-4],[-43,-21],[-8,-7],[-3,-9],[-13,-8],[-2,-4],[1,-3],[4,-1],[17,8],[6,8],[10,9],[16,7],[20,6],[18,10],[5,-3],[0,-8],[5,-4],[1,-5],[6,-5],[-1,-6],[-20,-11],[-7,0],[-7,-3],[-3,-4],[2,-5],[4,-2],[13,3],[8,-4],[-1,-15],[2,-5],[3,0],[5,10],[0,13],[2,5],[12,-4],[13,10],[5,-3],[2,-11],[10,-5],[6,-3],[7,5],[4,-3],[-3,-27],[-6,-1],[-14,8],[-2,-3],[3,-7],[9,-5],[5,-20],[8,-8],[-1,-6],[-16,-4],[-7,-6],[-11,-21],[-4,-1],[-7,5],[-12,-8],[-4,1],[-4,2],[-4,-4],[3,-5],[6,-3],[10,-2],[11,3],[24,-2],[12,-5],[4,-5],[1,-7],[-3,-8],[-8,-9],[-6,-11],[3,-10],[25,-9],[7,5],[3,7],[3,3],[4,-4],[-5,-11],[1,-5],[12,3],[6,-1],[10,-5],[9,-10],[4,-12],[-2,-6],[-3,-2],[-16,-2],[-6,-4],[-8,-15],[-1,-13],[-3,-7],[-5,-6],[-6,-3],[-18,1],[-1,-3],[3,-8],[-2,-6],[1,-4],[5,1],[8,8],[7,-4],[2,-6],[-5,-12],[5,-9],[-5,-2],[-10,1],[-31,18],[-23,8],[-4,-1],[-3,-5],[2,-1],[2,-5],[21,-5],[10,-5],[0,-5],[-2,-1],[-11,1],[-7,-1],[-3,-7],[11,-1],[19,-7],[14,6],[15,-6],[7,-6],[2,-5],[-2,-5],[-10,-2],[-22,2],[-8,-7],[-7,-3],[-2,-4],[1,-3],[9,-5],[6,1],[12,-5],[2,-15],[14,-4],[9,-6],[-1,-3],[-8,-4],[-8,2],[-10,0],[-12,3],[-5,-2],[-2,-5],[4,-8],[13,-5],[13,4],[7,-5],[9,-1],[19,5],[5,-1],[8,-4],[-1,-6],[4,-13],[-8,-10],[4,-10],[-2,-4],[-6,-4],[-3,-6],[2,-5],[12,-2],[17,8],[5,-3],[4,-9],[-7,-11],[1,-3],[16,-2],[15,5],[10,-4],[5,-4],[2,-6],[-4,-6],[-11,-3],[0,-4],[3,-4],[17,-2],[2,1],[6,13],[3,-1],[3,-13],[-6,-12],[3,-11],[-3,-10],[3,-7],[7,1],[3,8],[5,26],[1,17],[2,5],[5,-1],[3,-5],[9,-5],[1,-4],[-3,-7],[-10,-7],[-2,-6],[2,-5],[2,-3],[1,-8],[-16,-37],[2,-5],[4,2],[7,17],[10,13],[6,-2],[1,-3],[-3,-7],[-14,-14],[-1,-7],[-4,-6],[-2,-12],[1,-12],[-2,-4],[-10,-10],[-3,-6],[3,-4],[5,1],[5,3],[2,-1],[-1,-5],[-4,-2],[-9,-12],[-15,-28],[3,-4],[5,2],[17,31],[13,13],[1,7],[5,10],[2,2],[5,-2],[2,-5],[-4,-9],[-1,-6],[2,-2],[3,0],[5,5],[5,8],[1,2],[3,0],[3,-3],[-20,-29],[-9,-19],[0,-4],[3,-1],[6,5],[26,43],[4,10],[6,2],[9,1],[4,-3],[1,-7],[-3,-7],[-12,-12],[-2,-7],[2,-2],[8,2],[5,-3],[6,2],[3,5],[4,2],[6,-1],[8,5],[4,-3],[-5,-12],[-25,-38],[-12,-14],[-7,-19],[-5,-8],[1,-8],[18,8],[6,21],[21,32],[21,14],[13,28],[2,4],[8,2],[4,-5],[-5,-10],[-9,-11],[-5,-10],[2,-4],[7,3],[18,21],[3,1],[3,-2],[2,-6],[-4,-16],[2,-6],[6,-6],[2,-14],[5,-14],[38,-19],[11,-4],[9,0],[7,3],[10,16],[29,11],[4,-3],[-2,-8],[5,-11],[-13,-6],[-2,-5],[0,-3],[4,-2],[12,3],[6,-1],[13,-12],[8,-5],[19,0],[9,-4],[2,-18],[-3,-12],[-8,-6],[-11,-19],[-10,-7],[-14,-5],[-20,2],[-21,-5],[-9,-5],[-5,-17],[-7,-3],[-14,-1],[-24,-9],[-40,-22],[-38,-8],[-6,-4],[-2,-4],[2,-5],[9,0],[31,13],[4,0],[62,29],[4,-3],[-3,-6],[-20,-22],[-17,-7],[-18,-2],[-2,-5],[3,-10],[-3,-7],[-4,-4],[-19,-7],[-7,-6],[-22,-7],[-15,-10],[-8,0],[-9,4],[-4,-2],[-7,-15],[-20,-9],[-11,-11],[-3,-9],[0,-10],[-3,-6],[-10,2],[-12,18],[-15,8],[-18,3],[-17,7],[-3,11],[-3,1],[-2,-6],[-4,-5],[-6,-1],[-4,-3],[-2,-2],[2,-4],[5,-5],[8,0],[7,0],[7,1],[5,-3],[9,-3],[6,-4],[7,-6],[8,-9],[7,-7],[5,-3],[4,-3],[6,-4],[6,-3],[4,-1],[5,-2],[2,-2],[3,-3],[0,-3],[-1,-3],[-4,-3],[-7,0],[-5,-1],[-4,-1],[-5,-4],[-3,-2],[-3,-3],[-1,-4],[1,-4],[4,-3],[5,0],[4,1],[6,-1],[5,2],[8,10],[24,19],[2,5],[-1,5],[3,6],[9,-2],[16,5],[21,17],[6,9],[10,10],[7,1],[8,-1],[11,5],[7,8],[-2,8],[17,36],[13,16],[8,7],[20,6],[11,4],[23,12],[9,0],[12,-4],[11,1],[1,3],[-1,4],[-8,3],[-8,0],[-11,4],[-16,-6],[-8,1],[-2,2],[-1,3],[3,7],[11,7],[14,5],[9,4],[46,-3],[13,-3],[8,-5],[19,-33],[5,-18],[7,-9],[2,-9],[-1,-7],[2,-6],[9,-14],[1,-7],[-8,-15],[-7,-7],[-10,-5],[-5,-9],[-7,-4],[-2,-5],[1,-3],[6,-3],[3,-12],[-2,-10],[0,-18],[1,-3],[5,-3],[5,0],[2,6],[-3,12],[2,6],[7,5],[9,27],[6,3],[3,1],[8,18],[5,3],[12,-8],[8,1],[12,6],[9,8],[10,2],[3,-4],[-3,-6],[-11,-9],[-2,-3],[2,-5],[6,1],[7,-5],[12,0],[9,-6],[5,-6],[3,-10],[11,-16],[8,-8],[21,-13],[5,-21],[7,-9],[2,-7],[-6,-22],[-10,-6],[-5,-14],[-18,-6],[-2,-4],[3,-5],[14,1],[8,-5],[2,-17],[-5,-11],[3,-12],[-3,-4],[-12,3],[-13,-4],[-1,-3],[2,-3],[10,-7],[5,-15],[11,-1],[6,-4],[3,-9],[-3,-4],[-10,1],[-4,-9],[-4,0],[-7,5],[-10,-5],[-5,1],[-14,-4],[-1,-4],[0,-3],[5,-2],[23,2],[22,-5],[4,-3],[4,-10],[9,0],[5,-4],[6,-19],[-4,-5],[-8,6],[-7,-5],[-4,2],[-28,16],[-3,-3],[1,-6],[4,-7],[23,-13],[7,-11],[10,-6],[-9,-21],[-2,-23],[-12,-13],[-6,-15],[-6,-7],[-18,-27],[-41,-33],[-14,-14],[-7,-10],[-17,-17],[-2,-5],[-8,-8],[-7,-4],[-18,0],[-1,34]],[[9482,2335],[-1,100],[-99,0],[-113,0],[-113,0],[-22,0],[-5,0],[-86,0],[-72,1],[-3,0],[-38,-1],[-103,0],[-10,0],[-89,0],[-1,0],[0,2],[-1,1],[0,1],[0,1],[0,2],[-1,1],[-1,1],[-1,1],[0,1],[0,1],[-1,1],[0,1],[0,2],[-1,2],[1,1],[0,1],[1,1],[1,0],[1,0],[1,0],[2,-1],[1,0],[2,-1],[1,-1],[1,-2],[1,0],[1,-2],[1,-1],[1,-1],[1,0],[1,0],[0,1],[1,0],[1,-1],[1,-1],[1,0],[1,1],[0,1],[-1,1],[0,1],[-1,1],[0,1],[-1,1],[0,1],[-1,1],[-1,1],[-1,1],[0,1],[0,1],[-1,1],[0,1],[0,1],[0,2],[0,2],[0,1],[1,1],[0,1],[0,1],[0,3],[0,1],[0,1],[0,1],[0,1],[-1,1],[0,1],[0,2],[0,1],[0,1],[0,1],[-1,1],[0,1],[0,1],[-1,2],[0,1],[-1,1],[0,1],[-1,1],[0,1],[0,2],[0,1],[0,1],[0,1],[-1,1],[-1,1],[-1,0],[0,1],[-1,0],[-1,1],[-1,1],[0,1],[1,0],[1,0],[0,-1],[1,0],[0,1],[0,2],[-1,0],[-1,1],[-2,1],[-1,1],[-1,1],[1,1],[1,0],[1,-1],[1,0],[1,0],[0,1],[1,0],[1,-1],[1,0],[1,0],[1,0],[0,1],[-1,1],[-1,1],[-1,1],[-2,1],[-1,1],[-1,0],[-1,0],[-1,1],[-1,-1],[-1,0],[0,-2],[0,-1],[-1,0],[0,-1],[-1,0],[-1,1],[-1,1],[-1,1],[-1,1],[-1,0],[0,1],[-1,0],[-1,0],[-1,1],[-1,1],[-1,1],[-1,1],[-1,0],[-1,1],[-1,0],[-1,0],[-1,0],[-1,0],[-1,1],[-1,0],[0,2],[-1,1],[0,1],[-1,1],[0,1],[1,1],[0,1],[1,1],[0,1],[-1,1],[-1,2],[-1,1],[-1,1],[0,1],[-2,1],[-1,1],[0,1],[-1,2],[0,1],[0,1],[0,1],[0,3],[0,3],[1,3],[1,3],[0,2],[0,1],[1,1],[0,1],[1,1],[1,1],[0,1],[1,2],[0,1],[1,2],[1,1],[0,1],[1,0],[1,1],[1,1],[1,0],[1,0],[0,1],[2,1],[0,1],[1,0],[0,1],[1,1],[0,1],[1,-1],[1,0],[1,1],[0,1],[0,1],[2,1],[0,1],[1,0],[1,0],[1,0],[1,1],[2,0],[1,0],[2,0],[1,1],[2,0],[1,0],[2,0],[1,0],[2,1],[1,0],[3,0],[1,1],[2,0],[2,1],[2,0],[2,1],[1,0],[1,0],[2,0],[1,1],[3,-1],[2,0],[2,0],[1,-1],[3,0],[1,0],[1,0],[2,0],[1,0],[2,1],[1,0],[1,0],[1,0],[1,1],[0,1],[0,1],[0,1],[0,1],[-1,0],[0,1],[-1,0],[-1,1],[0,1],[-1,1],[-1,1],[-1,2],[-1,2],[-1,2],[-1,1],[-1,0],[-1,0],[-2,1],[-2,1],[-1,0],[-2,2],[-1,2],[-1,1],[-1,1],[-1,2],[-1,1],[-1,0],[-1,1],[-1,1],[0,2],[0,2],[1,1],[1,1],[0,2],[0,1],[-1,3],[0,1],[1,0],[1,1],[0,1],[0,2],[0,1],[-1,0],[0,1],[-1,1],[-1,0],[0,1],[0,1],[0,1],[0,1],[-1,0],[-1,-1],[0,-1],[-1,-2],[-1,0],[-2,0],[-1,0],[0,-1],[0,-1],[0,-1],[2,-2],[1,-1],[0,-1],[-1,-1],[-1,-1],[0,-1],[-2,-1],[-1,0],[-1,0],[-1,-1],[-1,-2],[-1,-2],[-2,-1],[-1,-1],[-2,-2],[-1,-1],[-1,-1],[-2,0],[-2,0],[-1,0],[-2,-1],[-1,0],[-1,0],[-1,0],[-1,0],[-1,0],[-1,-1],[-1,-1],[-2,-2],[-1,-1],[-1,-1],[-1,-1],[-2,0],[-1,1],[-2,0],[-2,-1],[-1,0],[-2,-1],[-1,1],[-1,0],[-2,0],[-2,0],[-2,0],[-2,0],[0,-1],[0,-1],[0,-2],[0,-2],[0,-2],[0,-1],[-2,-5],[-2,-1],[-1,-1],[0,-1],[0,-2],[1,-1],[1,-1],[0,-2],[1,-2],[-1,-2],[-1,-3],[-1,-1],[-2,-1],[-1,-2],[-1,-2],[0,-2],[1,-2],[0,-2],[1,-2],[1,-2],[1,-3],[1,-2],[0,-3],[1,-3],[0,-3],[1,-4],[0,-3],[0,-1],[1,0],[0,-2],[1,-1],[1,-5],[0,-2],[1,-2],[0,-2],[-1,-1],[-1,-2],[-1,-1],[-1,-2],[-1,-2],[-1,-3],[-1,-2],[0,-3],[-1,-3],[-1,-1],[-1,0],[-2,0],[-1,-1],[-1,-2],[-1,-2],[0,-2],[0,-3],[0,-3],[0,-2],[1,-3],[1,-1],[1,-2],[0,-2],[0,-1],[0,-1],[0,-1],[1,-2],[0,-1],[0,-2],[1,-3],[1,-3],[1,-2],[0,-3],[1,-4],[-1,-2],[0,-1],[-2,1],[-1,1],[-1,2],[-1,2],[-1,2],[0,1],[-2,0],[0,-1],[0,-1],[-1,-2],[1,-2],[0,-3],[0,-2],[-1,-3],[-1,0],[-2,0],[-1,-1],[0,-2],[1,-2],[0,-3],[0,-1],[1,-2],[1,-2],[0,-2],[1,-2],[0,-2],[1,-3],[-1,-2],[0,-2],[0,-1],[-1,-2],[-1,2],[-1,1],[-1,2],[-2,4],[-1,1],[-1,1],[-1,0],[-1,-1],[-1,0],[0,-2],[0,-2],[-1,-2],[0,-3],[0,-2],[0,-1],[1,-3],[0,-2],[0,-4],[0,-3],[0,-2],[0,-2],[-1,-3],[0,-3],[0,-2],[1,-2],[0,-2],[1,-2],[1,-1],[1,-1],[1,-3],[1,-2],[0,-3],[0,-2],[1,-2],[0,-2],[1,-1],[1,-3],[0,-2],[0,-2],[-1,-3],[-1,-2],[-1,-1],[0,-2],[-1,-1],[0,-2],[-1,-2],[-2,-2],[-2,-2],[-2,1],[-1,0],[-2,1],[-1,0],[-1,0],[-1,-1],[0,-2],[-1,-1],[-1,-4],[0,-3],[-1,-1],[-1,-1],[-2,-1],[-2,-1],[-1,-1],[-1,-1],[-1,-3],[0,-2],[-1,-1],[-1,0],[0,1],[-1,2],[-1,3],[-1,2],[-1,2],[-1,1],[-1,1],[-1,2],[1,2],[0,2],[0,4],[-1,4],[-2,3],[-2,1],[-2,1],[-1,1],[0,1],[-1,1],[-1,5],[0,2],[0,2],[-1,1],[-1,0],[-2,0],[-2,-1],[-1,0],[-2,1],[-2,1],[-1,1],[-1,1],[-1,1],[-2,0],[-1,0],[-1,-1],[-1,-1],[-1,0],[-2,0],[-3,1],[-1,0],[0,-1],[1,-3],[0,-3],[0,-2],[-1,-3],[-1,-1],[-1,-1],[-1,1],[-2,1],[-1,0],[0,1],[-1,2],[0,2],[-1,1],[-1,2],[-1,2],[-1,1],[-2,0],[-1,-1],[-1,-1],[-2,-1],[-1,0],[-2,0],[-2,0],[-1,0],[-2,0],[-1,1],[-1,1],[-1,2],[0,1],[1,1],[1,2],[0,2],[0,2],[0,2],[-2,1],[-1,0],[-2,1],[-1,0],[-1,0],[-1,-1],[-1,0],[-1,1],[0,1],[-1,2],[0,2],[0,1],[0,3],[0,2],[0,2],[-1,1],[-1,0],[-1,0],[-2,0],[-1,0],[-1,-1],[0,-1],[-1,-2],[0,-1],[0,-2],[0,-3],[-1,-2],[-1,1],[-1,1],[-1,2],[0,2],[-1,1],[0,1],[0,1],[-2,2],[-1,1],[-1,2],[1,2],[1,2],[2,3],[1,2],[1,2],[1,3],[0,2],[0,1],[-1,1],[0,1],[0,1],[0,1],[0,2],[0,1],[-1,1],[0,1],[-1,1],[-1,-1],[0,-1],[-1,-1],[0,-1],[-2,-1],[-1,0],[0,1],[0,1],[-1,1],[0,1],[0,1],[-1,1],[-1,1],[-1,1],[-1,1],[0,2],[-1,2],[0,2],[-1,2],[0,1],[0,2],[0,2],[0,2],[0,1],[0,2],[0,1],[-1,2],[0,1],[-1,0],[-1,-1],[0,-1],[-1,-1],[-1,-1],[0,-1],[0,-1],[-1,-1],[0,-1],[0,-2],[0,-1],[-1,-1],[0,-1],[0,-1],[-1,-1],[-1,-1],[-1,-1],[-1,-1],[-2,0],[-1,0],[-1,0],[-1,0],[-1,0],[0,-1],[0,-1],[0,-1],[0,-1],[-1,-2],[0,-1],[0,-1],[0,-1],[-1,-1],[0,-1],[-1,-1],[-1,1],[-1,0],[0,1],[-1,1],[0,2],[0,1],[1,2],[0,2],[1,2],[0,1],[1,2],[0,2],[1,2],[0,1],[0,1],[0,2],[0,1],[0,2],[0,1],[-1,2],[-1,1],[-1,1],[-1,0],[-1,0],[0,-1],[-1,-1],[0,-1],[-1,0],[-1,-1],[-1,0],[-2,1],[-2,0],[-1,0],[-2,1],[-1,0],[-2,1],[-1,0],[-1,1],[-2,1],[-1,0],[-1,0],[-1,-1],[0,-2],[-1,-1],[-1,-1],[-1,-2],[-1,0],[-1,1],[-2,0],[-1,0],[-2,-1],[-1,-2],[0,-1],[0,-2],[0,-2],[-1,-1],[-1,-1],[-1,2],[-1,0],[0,2],[-1,2],[0,3],[-1,1],[-2,0],[-1,1],[-1,1],[-1,-1],[-2,0],[0,1],[-1,0],[0,1],[0,1],[1,3],[0,1],[0,3],[-1,2],[0,3],[0,3],[0,3],[-2,3],[-1,2],[0,3],[-1,1],[0,1],[-1,1],[-1,0],[-1,0],[-1,0],[-1,0],[-1,0],[-1,1],[0,1],[-1,1],[-1,0],[0,1],[-1,2],[-1,2],[-1,3],[0,2],[-1,1],[-1,2],[0,3],[-1,2],[-1,0],[-1,0],[-2,-2],[0,-2],[-1,-1],[0,-2],[-1,-1],[1,-2],[0,-3],[0,-3],[1,-4],[0,-3],[1,-3],[0,-1],[1,-3],[0,-3],[0,-2],[0,-1],[-1,-2],[-1,-1],[-1,-1],[-1,-1],[-1,0],[-1,0],[-1,1],[-1,1],[-1,1],[-1,1],[-1,1],[-1,1],[0,2],[1,1],[0,2],[0,1],[-1,1],[-1,1],[0,2],[-1,3],[-1,1],[-1,2],[-1,0],[-1,1],[-1,0],[-2,2],[-1,1],[0,3],[-1,2],[0,1],[2,0],[1,0],[2,0],[0,1],[-1,2],[-1,2],[-1,1],[-2,2],[-1,1],[-1,1],[0,2],[0,3],[0,2],[1,1],[1,1],[2,0],[1,0],[1,1],[0,1],[0,2],[2,3],[1,0],[1,0],[2,-1],[1,-1],[2,-2],[1,-1],[1,0],[0,1],[0,3],[0,1],[-1,1],[-1,2],[-1,3],[1,3],[0,2],[1,2],[-1,2],[-1,1],[0,2],[-1,1],[0,2],[0,1],[1,0],[1,1],[0,2],[0,2],[0,1],[0,2],[-1,1],[-1,3],[0,2],[0,3],[0,3],[-1,2],[-1,2],[-2,3],[-2,3],[-1,2],[-1,3],[0,4],[2,2],[1,2],[1,2],[1,3],[2,2],[1,0],[1,-3],[0,-2],[1,-2],[1,-1],[1,-2],[0,-1],[0,-2],[1,-3],[1,-2],[1,-1],[2,-1],[1,0],[1,2],[0,2],[0,3],[-1,1],[-1,1],[0,2],[0,1],[0,3],[-1,2],[-1,1],[-1,1],[-1,1],[0,2],[0,2],[0,1],[0,3],[0,2],[0,4],[0,4],[1,4],[0,2],[-1,3],[-1,0],[-1,1],[-2,1],[-2,0],[0,1],[0,3],[0,4],[-2,2],[0,3],[1,3],[0,2],[1,1],[1,0],[1,-1],[1,-1],[1,-2],[2,-1],[1,-2],[2,0],[1,-1],[2,-1],[1,0],[0,1],[0,1],[0,1],[1,2],[-1,3],[0,2],[-1,1],[-1,3],[-1,3],[0,3],[-1,2],[0,2],[-1,2],[-1,1],[0,1],[0,2],[0,3],[-1,2],[-1,2],[-1,1],[-1,0],[0,1],[-1,1],[-1,0],[-2,1],[-1,2],[-1,1],[-1,2],[-2,2],[-1,0],[-1,1],[-2,-1],[0,-1],[0,-1],[0,-1],[0,-2],[0,-1],[-1,-1],[0,-1],[0,-1],[0,-2],[-1,-1],[0,-2],[0,-3],[0,-2],[-1,-3],[-1,0],[0,2],[-1,1],[-1,1],[0,-1],[-1,-1],[0,-2],[-1,-1],[0,-1],[-1,0],[-1,-1],[-2,0],[-1,1],[-1,1],[-2,1],[-1,-1],[0,-1],[-1,-1],[0,-1],[0,-2],[0,-1],[0,-2],[0,-2],[-1,-1],[0,-1],[0,-1],[0,-1],[0,-2],[0,-3],[0,-2],[0,-1],[0,-2],[0,-1],[-1,-3],[0,-2],[0,-2],[0,-1],[1,-3],[0,-2],[-1,-1],[-2,0],[-1,0],[-1,0],[0,-2],[-1,-1],[-1,-2],[-1,1],[-1,2],[-1,3],[-2,1],[-2,2],[-1,-1],[0,-1],[0,-1],[1,-1],[1,-2],[0,-1],[1,-2],[0,-3],[0,-2],[0,-2],[0,-1],[0,-3],[0,-2],[0,-3],[0,-1],[-1,-3],[-2,-1],[-1,0],[0,2],[0,2],[-1,2],[0,2],[-1,3],[-1,3],[0,2],[0,1],[-1,2],[-1,1],[1,-2],[0,-3],[-1,-1],[0,-1],[-1,0],[-1,0],[-1,0],[-1,0],[0,-1],[1,-1],[0,-2],[1,-2],[0,-2],[0,-3],[-1,-2],[-1,0],[-1,1],[-1,0],[-1,1],[0,1],[-1,1],[-1,2],[0,2],[0,1],[-1,2],[0,1],[-1,1],[-1,0],[0,1],[0,1],[0,1],[0,1],[0,1],[0,1],[-1,1],[-1,0],[-1,0],[-2,-1],[-1,0],[-1,0],[-1,0],[-1,-2],[-1,1],[-1,2],[0,2],[-1,2],[-1,2],[0,2],[0,1],[0,2],[0,2],[0,1],[1,2],[0,3],[0,2],[0,2],[0,1],[-1,1],[0,2],[0,1],[-1,1],[-1,-1],[-1,0],[-2,-1],[-1,-1],[-1,-1],[-1,-1],[-1,-1],[0,-1],[0,-1],[0,-1],[-1,-3],[-1,0],[-1,0],[-1,0],[-1,1],[-1,0],[-1,1],[-1,0],[-2,1],[0,1],[-1,3],[-1,2],[-1,2],[-2,1],[-1,0],[-2,1],[-1,1],[-2,0],[0,1],[0,1],[0,1],[0,1],[0,2],[0,1],[-1,4],[0,2],[1,1],[1,2],[1,1],[1,1],[2,-1],[1,0],[2,0],[1,1],[1,0],[1,1],[1,1],[0,2],[-1,1],[-2,1],[-1,1],[-2,0],[-2,0],[-1,-1],[-2,0],[-1,0],[-1,0],[0,1],[-1,1],[0,1],[-1,1],[0,1],[-3,29],[0,1],[1,0],[1,0],[1,-1],[1,-1],[1,-2],[1,0],[0,1],[1,0],[1,2],[1,2],[0,1],[1,4],[1,2],[1,1],[1,-1],[2,0],[1,-1],[1,-1],[0,-1],[2,-1],[1,0],[2,1],[1,0],[1,-1],[1,-1],[0,-1],[1,-2],[1,-1],[1,-1],[2,0],[1,1],[1,0],[1,0],[1,0],[1,-1],[1,-1],[0,-2],[-1,-2],[0,-1],[0,-2],[-1,-2],[1,0],[1,0],[0,-1],[1,0],[1,-1],[1,0],[1,0],[1,0],[4,3],[0,1],[1,4],[-1,1],[0,1],[0,1],[1,1],[0,1],[1,1],[1,1],[0,1],[0,1],[-1,1],[-1,0],[-2,5],[0,1],[1,1],[1,1],[1,5],[0,1],[-1,1],[0,1],[1,1],[0,1],[0,1],[0,1],[0,1],[0,1],[-1,1],[0,2],[0,1],[1,0],[0,1],[0,2],[1,1],[0,2],[1,2],[0,2],[0,1],[-1,1],[0,2],[-1,2],[-1,0],[-1,1],[-2,1],[-1,0],[0,1],[0,1],[1,2],[0,1],[1,2],[0,1],[1,2],[1,0],[1,0],[2,0],[0,1],[1,1],[0,2],[1,1],[2,1],[2,1],[0,2],[1,1],[0,2],[-1,1],[-1,0],[-2,2],[0,1],[0,2],[0,2],[0,2],[-1,2],[-1,1],[-1,0],[0,1],[-1,0],[-1,0],[-1,0],[0,-1],[-1,0],[-1,0],[0,2],[0,1],[0,1],[-1,2],[-1,0],[0,1],[0,1],[0,1],[-1,1],[0,1],[-1,1],[-2,2],[0,2],[-2,1],[-1,0],[-1,0],[-1,-1],[-1,0],[-2,0],[-1,0],[-1,0],[-1,0],[-1,1],[-1,0],[-1,0],[-1,0],[-1,0],[-1,1],[-1,1],[0,-1],[-1,1],[-2,0],[-1,-1],[-1,2],[-1,1],[-1,0],[-1,0],[-1,1],[-1,0],[-1,0],[-2,0],[0,1],[0,2],[-1,1],[0,2],[-1,2],[0,1],[-2,2],[-1,1],[-1,1],[-1,1],[0,1],[0,3],[0,2],[-1,2],[0,1],[-1,2],[0,1],[0,1],[-1,2],[0,3],[0,2],[0,1],[0,2],[0,1],[-1,0],[-1,0],[-1,0],[-2,-1],[-1,0],[-1,0],[-1,1],[-1,1],[0,1],[-1,1],[-1,3],[-1,1],[-1,0],[-1,1],[-1,0],[-1,0],[-1,0],[-2,0],[-1,0],[-1,1],[0,1],[1,0],[0,1],[1,1],[0,2],[0,1],[0,2],[1,1],[1,0],[1,0],[1,0],[1,-1],[1,1],[1,1],[0,1],[1,2],[2,2],[0,2],[0,2],[0,1],[-1,1],[-1,0],[-1,0],[-1,0],[-1,1],[-1,1],[0,1],[-1,0],[-1,1],[-1,2],[-1,1],[-1,1],[-1,2],[0,1],[0,2],[0,2],[0,2],[-1,3],[-1,2],[-2,0],[-2,1],[-1,0],[0,1],[1,2],[0,2],[-1,2],[-1,1],[-2,1],[-1,1],[-1,0],[-1,1],[-1,0],[-2,4],[-1,1],[-2,1],[-1,1],[-1,0],[-2,1],[-1,1],[0,1],[1,1],[0,1],[1,1],[1,0],[0,1],[1,1],[0,2],[0,2],[1,2],[0,2],[1,1],[0,2],[0,1],[-1,1],[-1,0],[-1,1],[-1,2],[-1,0],[0,2],[0,3],[0,2],[1,1],[0,2],[1,0],[2,1],[1,0],[2,0],[1,0],[2,0],[1,0],[2,0],[1,0],[1,1],[1,0],[2,1],[0,1],[1,1],[0,1],[1,3],[0,1],[0,2],[1,2],[0,1],[-1,1],[0,1],[0,1],[0,1],[-1,0],[0,1],[0,1],[-1,1],[0,1],[-1,0],[0,1],[-1,1],[0,1],[-1,0],[0,1],[-1,0],[0,1],[-1,0],[0,1],[-1,0],[-1,0],[0,1],[-1,0],[-1,0],[-1,0],[-1,0],[0,1],[-1,0],[-1,0],[-1,1],[-1,1],[0,1],[0,1],[0,1],[0,1],[0,1],[1,0],[0,1],[0,1],[1,0],[0,1],[1,0],[1,0],[1,0],[1,0],[0,1],[1,0],[0,1],[1,1],[0,1],[0,1],[0,1],[0,1],[0,1],[0,1],[0,1],[0,1],[0,1],[0,1],[-1,0],[0,1],[0,1],[0,1],[-1,0],[0,1],[0,1],[-1,1],[0,1],[-1,1],[0,1],[-1,0],[0,1],[0,1],[-1,1],[0,1],[0,1],[0,1],[0,1],[0,1],[1,0],[0,1],[0,1],[1,0],[1,0],[1,0],[1,-1],[0,-1],[1,-1],[1,0],[1,0],[1,1],[1,0],[0,1],[-1,2],[0,2],[0,2],[0,1],[2,4],[1,1],[1,-1],[0,-1],[1,-1],[1,-2],[1,0],[1,0],[1,0],[1,0],[1,1],[1,0],[2,1],[1,0],[1,0],[2,-1],[1,0],[2,0],[1,0],[2,0],[1,1],[1,0],[1,1],[0,1],[1,3],[0,2],[0,3],[0,2],[1,0],[2,0],[1,-1],[1,-1],[1,-1],[2,-2],[1,-1],[1,-1],[1,-1],[2,-1],[1,-1],[2,0],[2,-1],[1,0],[1,1],[1,1],[1,1],[0,1],[0,2],[0,2],[-1,2],[-1,2],[-1,1],[-1,1],[0,2],[-1,0],[0,2],[0,1],[0,1],[0,2],[1,1],[1,-1],[1,0],[1,1],[1,0],[0,1],[1,1],[0,1],[1,2],[1,1],[0,1],[2,-1],[1,0],[2,0],[1,1],[0,1],[1,1],[1,2],[0,2],[1,2],[1,1],[0,1],[1,0],[1,1],[1,1],[1,0],[0,1],[1,1],[0,2],[1,2],[0,2],[0,2],[0,2],[-1,1],[-1,1],[-1,2],[-1,2],[-1,0],[-1,1],[-1,2],[-2,1],[-1,1],[-2,1],[-1,2],[-2,2],[-1,2],[-1,3],[-1,3],[-1,3],[-2,4],[-3,4],[-2,4],[-2,3],[-2,4],[-2,4],[-2,4],[-2,4],[-1,2],[-1,2],[-1,2],[0,1],[0,1],[-1,1],[-1,1],[0,1],[-1,1],[0,2],[-1,2],[0,2],[0,2],[0,2],[0,1],[0,2],[1,2],[1,1],[0,1],[1,0],[1,1],[2,0],[1,1],[1,0],[1,-1],[1,0],[1,0],[2,-1],[1,0],[1,0],[1,0],[2,-1],[1,-1],[1,-1],[1,-2],[-1,-1],[-1,-1],[0,-1],[-1,-2],[0,-1],[0,-1],[1,-1],[1,0],[1,0],[0,-1],[1,-1],[0,-1],[1,-1],[0,-2],[1,-2],[1,0],[1,-1],[1,-1],[0,-1],[1,-1],[1,-1],[0,-1],[2,-2],[1,-1],[1,-1],[1,-1],[1,-3],[1,-2],[2,-1],[2,-2],[2,-3],[2,-2],[1,-1],[1,-2],[1,-2],[0,-2],[1,-2],[1,-2],[1,0],[1,-1],[1,-2],[0,-1],[1,-2],[2,-2],[1,-1],[2,0],[1,-1],[2,-1],[1,0],[1,0],[2,0],[1,-1],[0,-1],[3,-2],[1,-2],[2,-1],[2,-2],[2,-1],[2,-2],[1,-1],[2,-1],[2,-1],[2,-2],[2,-1],[1,0],[0,1],[0,2],[-1,1],[0,1],[-1,1],[-1,0],[-1,1],[-1,1],[-1,1],[-1,1],[-1,2],[-1,3],[0,2],[-1,3],[1,2],[1,-1],[1,-1],[1,-2],[1,-1],[1,-1],[1,-1],[1,-2],[1,0],[1,1],[0,1],[1,0],[1,0],[1,0],[1,0],[1,0],[1,1],[1,1],[0,1],[0,1],[0,1],[1,2],[-1,1],[0,1],[-1,1],[-1,1],[-1,2],[0,1],[-1,1],[-1,1],[0,2],[-1,3],[-1,2],[0,3],[-1,2],[0,3],[-1,2],[0,2],[-1,2],[-1,1],[0,1],[-2,2],[-1,3],[0,1],[-1,2],[-1,1],[-1,1],[-1,1],[0,1],[0,2],[1,0],[1,0],[1,0],[1,0],[1,-1],[1,0],[1,0],[2,-1],[1,-1],[2,0],[2,-1],[1,0],[1,1],[-1,1],[0,1],[-1,1],[-1,1],[-1,0],[-1,1],[-1,1],[-1,1],[-1,1],[-1,2],[-1,1],[-1,0],[-1,1],[0,1],[-1,1],[0,2],[0,1],[1,1],[1,1],[1,2],[-1,1],[-1,2],[-1,1],[0,1],[-1,1],[-1,1],[-1,2],[0,2],[-1,2],[0,2],[0,1],[1,2],[1,2],[0,1],[0,1],[-1,1],[0,2],[1,3],[0,2],[1,1],[1,0],[1,-1],[1,-1],[1,-1],[1,-1],[1,-1],[1,0],[1,-1],[1,1],[0,1],[0,1],[-1,2],[0,1],[-1,1],[-1,2],[-1,1],[-1,2],[-1,1],[-1,1],[-2,1],[-1,2],[-1,1],[-1,1],[-1,1],[-1,1],[-1,2],[-1,1],[-1,2],[0,2],[0,1],[0,1],[1,1],[1,1],[1,1],[0,2],[1,1],[0,1],[1,1],[1,0],[0,-1],[1,-1],[1,-1],[1,-1],[1,-1],[1,-1],[2,-2],[0,-1],[1,-2],[1,-2],[0,-1],[0,-1],[1,-2],[1,-1],[1,0],[1,0],[1,0],[1,0],[1,1],[1,0],[1,0],[1,-1],[1,-1],[0,-2],[1,-1],[1,-2],[1,-2],[1,-1],[1,-2],[1,-1],[1,-3],[1,-2],[0,-1],[1,-1],[0,-2],[1,-1],[1,-2],[0,-1],[1,-1],[1,-1],[1,-1],[1,-1],[1,-1],[0,-1],[2,-1],[0,-1],[1,-1],[1,-1],[0,-1],[1,-1],[1,-2],[1,-1],[0,-2],[1,-1],[1,-1],[1,-1],[1,-2],[0,-1],[1,-2],[1,-1],[1,-1],[1,-2],[1,-2],[1,-2],[1,-1],[1,-2],[0,-2],[1,-2],[0,-1],[1,-2],[1,-1],[1,0],[1,0],[1,0],[1,0],[1,0],[2,0],[1,0],[1,-1],[2,0],[1,-1],[1,-1],[0,-1],[1,-1],[1,0],[1,0],[1,-2],[0,-1],[1,-1],[1,0],[1,-1],[2,-1],[0,-1],[2,0],[1,0],[0,1],[1,0],[1,1],[1,-1],[1,0],[1,-1],[1,0],[1,0],[2,0],[0,1],[1,0],[2,0],[1,0],[1,0],[1,-1],[1,0],[1,-1],[1,-2],[1,-1],[0,-1],[0,-2],[0,-2],[0,-1],[0,-3],[0,-3],[0,-2],[-1,-2],[1,-1],[0,-2],[1,-1],[1,-1],[1,-2],[1,-1],[1,-1],[1,-2],[2,-2],[1,-2],[2,-2],[1,-2],[1,-1],[0,-1],[0,-1],[1,-1],[1,-3],[0,-2],[0,-1],[0,-1],[1,0],[1,-2],[1,-1],[1,0],[1,0],[1,1],[1,1],[1,1],[0,1],[1,3],[1,2],[1,-1],[0,-1],[1,0],[1,-1],[1,-1],[1,0],[1,0],[1,0],[2,0],[1,-1],[2,1],[1,0],[1,-1],[1,0],[1,0],[1,0],[2,0],[0,1],[1,0],[1,1],[0,2],[1,1],[0,2],[1,2],[-1,2],[0,2],[-2,1],[-1,2],[-1,2],[0,1],[0,3],[1,3],[1,1],[1,1],[0,1],[2,1],[1,-1],[0,-2],[1,-2],[0,-1],[1,-1],[1,0],[1,0],[1,0],[1,0],[1,-1],[1,2],[1,0],[0,1],[1,1],[0,1],[2,2],[1,0],[1,-1],[1,0],[1,1],[2,0],[1,0],[2,1],[1,0],[1,0],[1,1],[1,0],[0,1],[1,0],[0,1],[-1,2],[0,1],[0,1],[0,1],[0,1],[0,1],[1,2],[0,1],[1,2],[1,0],[1,1],[1,1],[1,1],[0,2],[2,2],[1,2],[1,1],[1,1],[1,0],[1,0],[1,0],[1,-1],[1,-1],[1,-1],[1,0],[1,-1],[1,0],[2,-1],[1,0],[1,-1],[1,0],[1,-1],[1,-1],[1,-1],[1,-1],[1,0],[2,-1],[1,-1],[0,-1],[1,0],[1,-1],[1,-2],[1,-2],[1,-1],[0,-2],[1,-2],[0,-1],[1,-2],[0,-2],[1,0],[1,0],[1,0],[2,0],[1,-1],[1,0],[1,-1],[2,-1],[0,-1],[0,-1],[1,-1],[0,-1],[-1,-2],[0,-1],[0,-2],[-1,-1],[0,-2],[-1,-1],[-1,-1],[0,-2],[-1,-1],[0,-2],[0,-1],[0,-1],[1,0],[1,-1],[1,-1],[1,0],[1,0],[1,-1],[1,0],[2,-1],[1,0],[1,1],[2,0],[1,0],[2,0],[1,0],[2,0],[1,0],[1,-1],[1,0],[2,0],[1,-1],[1,1],[2,0],[1,0],[0,1],[0,2],[-1,1],[0,2],[0,1],[1,0],[1,0],[1,0],[1,0],[1,0],[1,0],[1,0],[0,1],[1,1],[0,1],[1,1],[-1,2],[0,1],[0,2],[1,1],[2,0],[1,0],[1,0],[1,0],[1,0],[1,-1],[2,0],[1,-1],[1,0],[2,-1],[1,0],[1,-1],[1,0],[1,-1],[0,-2],[0,-1],[1,-2],[0,-1],[1,-2],[1,-1],[1,-1],[1,0],[1,0],[1,-1],[2,-1],[1,0],[1,0],[1,0],[1,0],[1,0],[1,-1],[0,-1],[0,-2],[0,-1],[0,-1],[1,-1],[1,-1],[1,-2],[1,-1],[0,-1],[1,-1],[1,-1],[1,-1],[1,-2],[0,-1],[0,-2],[0,-1],[0,-1],[0,-2],[0,-1],[0,-1],[1,-1],[1,0],[1,0],[1,0],[1,-1],[1,0],[1,-1],[1,0],[2,-1],[1,0],[1,0],[1,1],[2,1],[1,0],[1,1],[1,0],[1,-1],[1,0],[1,-1],[1,0],[1,0],[1,0],[1,0],[0,1],[1,1],[0,1],[1,1],[1,1],[1,0],[0,1],[1,1],[2,0],[0,1],[1,0],[1,0],[1,1],[1,0],[1,0],[1,0],[1,-1],[1,0],[1,-1],[2,-1],[0,1],[1,0],[0,2],[1,1],[0,1],[-1,1],[0,1],[-1,0],[0,1],[-1,2],[-1,1],[-1,2],[-1,1],[0,2],[-1,1],[0,1],[-1,1],[-1,1],[-1,2],[-1,1],[-1,3],[-2,1],[-1,2],[-2,1],[-2,1],[-1,0],[-1,0],[-1,1],[-1,1],[-1,1],[0,2],[1,1],[0,2],[1,1],[1,2],[2,2],[1,0],[1,1],[1,0],[2,0],[1,0],[0,1],[1,1],[0,2],[0,2],[-1,1],[0,2],[-1,1],[0,2],[0,3],[0,2],[0,2],[1,3],[0,1],[2,1],[0,1],[0,1],[0,1],[-1,2],[-1,1],[1,2],[1,0],[1,1],[1,0],[2,1],[1,-1],[2,-1],[1,-1],[1,-2],[1,-1],[2,-1],[2,-2],[1,-2],[1,0],[2,-1],[1,0],[1,0],[2,1],[1,0],[1,1],[1,2],[0,2],[0,1],[0,2],[0,1],[-1,2],[0,1],[1,1],[0,1],[1,0],[1,2],[0,1],[0,2],[0,1],[0,1],[0,1],[-1,0],[0,1],[0,1],[0,1],[0,1],[-1,0],[0,1],[0,1],[0,1],[1,1],[0,2],[0,2],[0,1],[0,1],[-1,1],[-1,1],[0,1],[-1,1],[-1,1],[0,1],[1,1],[0,2],[0,2],[1,2],[0,2],[1,2],[0,2],[1,1],[1,1],[0,1],[1,1],[1,1],[1,1],[1,2],[1,1],[0,2],[-1,1],[-2,1],[-1,0],[0,1],[1,0],[1,1],[1,0],[1,1],[1,0],[1,1],[2,0],[1,0],[1,0],[2,0],[1,1],[1,1],[1,1],[1,3],[0,1],[1,3],[-1,2],[0,1],[-1,0],[-1,0],[-1,0],[-1,0],[-1,-1],[-1,0],[-1,-1],[-1,0],[-1,-1],[-1,0],[-1,0],[-1,0],[-1,0],[-1,0],[-1,0],[-1,0],[-1,1],[-2,1],[-2,0],[0,1],[-1,0],[-2,0],[-2,0],[-1,0],[0,1],[-1,1],[0,3],[0,1],[1,1],[1,1],[1,1],[1,1],[1,0],[1,0],[1,1],[2,0],[1,0],[2,0],[2,1],[1,0],[0,1],[1,1],[-1,1],[-1,0],[-1,1],[-1,2],[-2,0],[-1,2],[2,1],[2,1],[2,0],[2,0],[1,1],[2,0],[2,0],[2,0],[2,0],[1,0],[1,0],[1,0],[2,1],[1,1],[2,1],[2,1],[1,0],[1,1],[1,1],[0,1],[0,2],[0,1],[0,1],[-1,1],[0,1],[-1,1],[-1,1],[-2,1],[-1,0],[-2,-1],[-1,0],[-2,0],[-1,0],[-1,1],[-1,0],[-1,1],[-2,0],[-1,1],[-2,0],[-2,1],[-1,-1],[-2,0],[-1,0],[-2,0],[-1,1],[-1,0],[-1,1],[-2,0],[-2,0],[-1,0],[-1,-1],[-1,0],[-1,0],[-1,1],[-1,0],[-1,1],[-1,0],[-1,1],[-1,0],[-1,0],[-1,1],[-1,1],[-1,1],[-2,1],[0,1],[-1,1],[-1,1],[0,1],[1,1],[1,0],[1,1],[1,1],[1,1],[1,0],[1,1],[1,0],[1,1],[1,1],[1,2],[1,2],[0,1],[1,2],[1,2],[0,3],[-1,3],[0,2],[0,2],[0,3],[0,2],[0,1],[0,1],[0,2],[0,3],[0,1],[1,0],[1,0],[1,0],[1,1],[1,1],[0,1],[-1,1],[0,1],[-1,1],[-2,0],[-2,0],[-1,0],[-1,1],[-1,0],[-1,0],[-1,0],[-2,-1],[-1,-1],[-1,1],[1,1],[1,1],[0,1],[1,1],[1,1],[1,1],[0,2],[0,1],[1,1],[0,1],[0,1],[0,1],[0,2],[0,2],[0,1],[0,2],[1,1],[0,1],[2,1],[1,0],[1,1],[0,1],[1,2],[0,2],[0,2],[0,1],[-1,1],[-1,-1],[-1,0],[-2,0],[-1,1],[-2,-1],[-1,0],[-1,0],[-1,0],[0,1],[-1,1],[0,2],[-1,1],[0,2],[0,1],[1,2],[0,3],[-1,1],[-1,3],[-1,1],[-1,1],[-2,1],[-1,1],[0,1],[0,2],[0,3],[0,1],[-1,1],[-2,2],[0,1],[0,1],[2,0],[1,0],[1,0],[1,1],[1,0],[1,0],[2,1],[1,0],[2,0],[1,0],[2,1],[1,1],[1,1],[1,2],[1,1],[1,0],[1,1],[1,1],[2,1],[2,0],[1,1],[2,1],[1,1],[1,1],[1,1],[2,1],[1,0],[2,2],[1,0],[1,0],[1,0],[1,-2],[1,-1],[1,0],[1,0],[0,1],[1,2],[0,2],[0,2],[0,1],[0,1],[-1,1],[-2,1],[-1,0],[-2,0],[-1,0],[-1,0],[-1,0],[-1,0],[-2,-1],[-1,-1],[-2,0],[-1,-1],[-1,0],[-1,1],[-1,1],[-1,0],[-2,0],[-1,0],[-1,1],[-1,2],[-1,1],[0,2],[0,1],[-1,1],[-1,1],[-1,1],[-1,-1],[-2,0],[-1,-2],[-2,-1],[-1,-1],[-2,-2],[-2,0],[-1,0],[-1,0],[0,1],[0,1],[1,2],[0,2],[0,2],[-1,2],[-1,2],[-1,2],[0,1],[-1,-1],[-1,0],[0,-1],[-2,-1],[0,2],[1,1],[0,1],[1,2],[0,1],[0,1],[-1,0],[-1,0],[0,-1],[-1,0],[-1,-1],[-1,0],[-1,-1],[-1,0],[0,-1],[-1,-1],[0,-2],[-1,-1],[-1,-2],[-1,-1],[-1,-1],[-1,-1],[-2,0],[-1,0],[-1,0],[-1,1],[-1,1],[0,1],[0,1],[1,2],[0,3],[0,2],[1,1],[0,2],[0,2],[0,3],[0,2],[0,1],[0,1],[1,1],[1,0],[1,1],[1,1],[1,0],[1,1],[1,0],[1,1],[1,1],[2,0],[1,1],[1,0],[1,1],[1,1],[1,1],[0,1],[0,1],[0,1],[0,1],[-1,1],[-2,0],[-1,1],[0,1],[-1,2],[0,2],[0,1],[-1,0],[-1,0],[-1,0],[-1,0],[-1,0],[-1,0],[-2,1],[-1,0],[-1,1],[-1,-1],[-2,0],[-1,-1],[-1,0],[-1,0],[-2,0],[-1,1],[-1,1],[-1,1],[0,1],[0,2],[-1,1],[0,1],[-1,1],[-1,1],[0,1],[0,2],[1,2],[1,1],[0,1],[1,1],[0,1],[0,2],[0,2],[0,2],[0,1],[0,2],[-1,2],[0,1],[-2,2],[-1,2],[-2,1],[-1,1],[-2,1],[-1,2],[0,2],[1,0],[1,0],[1,0],[1,0],[1,0],[1,0],[1,0],[1,0],[1,0],[2,-1],[1,0],[1,0],[1,-1],[1,0],[1,0],[1,-1],[1,0],[1,0],[1,-1],[1,0],[1,1],[1,0],[1,0],[1,0],[1,1],[1,1],[1,0],[1,1],[1,0],[1,0],[1,0],[2,1],[1,1],[0,1],[1,1],[0,1],[-1,1],[0,1],[-1,1],[0,1],[-1,1],[-1,0],[-1,0],[-1,1],[-2,0],[0,1],[0,1],[-1,2],[0,1],[0,1],[0,2],[1,0],[0,1],[0,3],[0,1],[0,2],[-1,2],[-1,0],[0,2],[-1,1],[-1,1],[-1,1],[0,1],[0,1],[-1,2],[0,1],[-1,1],[0,1],[-1,1],[-1,0],[-1,0],[-2,0],[0,1],[0,1],[1,2],[0,2],[1,2],[0,2],[0,2],[0,1],[-1,0],[-1,0],[-1,0],[-1,0],[-1,-2],[-1,0],[-1,1],[0,1],[0,1],[-1,1],[0,1],[-1,1],[0,1],[-1,1],[-1,1],[-1,1],[-1,1],[0,1],[1,1],[0,1],[1,2],[1,2],[1,1],[1,2],[1,0],[1,1],[0,1],[1,2],[0,1],[0,1],[1,2],[0,1],[1,0],[1,0],[1,0],[2,1],[1,0],[0,2],[1,1],[0,1],[0,2],[0,2],[-1,2],[0,3],[0,2],[0,1],[0,2],[0,1],[1,0],[0,2],[2,1],[1,0],[1,0],[1,0],[1,0],[1,0],[1,0],[1,1],[1,0],[1,1],[1,0],[1,0],[1,0],[2,-1],[1,1],[0,1],[1,0],[0,2],[-1,1],[-1,2],[-1,0],[-1,0],[-1,0],[-1,1],[-1,0],[0,1],[0,1],[0,2],[0,2],[0,1],[0,1],[0,2],[0,2],[-1,3],[0,2],[0,2],[1,1],[1,0],[1,1],[1,1],[1,0],[1,1],[-1,1],[0,2],[-1,1],[0,1],[-1,2],[0,1],[0,2],[0,1],[0,1],[0,2],[-1,2],[1,4],[0,1],[0,1],[1,0],[1,-1],[2,0],[2,-1],[1,0],[1,1],[1,0],[1,1],[0,1],[0,1],[0,1],[0,1],[0,2],[1,1],[2,1],[1,1],[0,2],[0,1],[0,1],[-1,2],[-1,0],[0,2],[0,2],[0,1],[1,3],[0,1],[1,1],[0,1],[1,1],[0,1],[1,2],[0,1],[1,2],[0,1],[0,2],[-1,2],[-1,2],[-2,1],[-1,0],[-2,1],[-1,0],[-1,0],[0,-2],[-1,-4],[-1,-3],[-2,-2],[-1,-2],[-1,-2],[-1,0],[-1,1],[0,1],[1,1],[0,2],[0,2],[0,3],[0,2],[-1,2],[1,3],[0,3],[1,2],[0,2],[0,2],[0,1],[1,3],[0,2],[1,1],[2,0],[1,-1],[3,-1],[0,1],[0,2],[1,1],[1,1],[1,1],[1,1],[1,0],[2,1],[1,1],[1,1],[0,1],[1,3],[0,2],[-1,3],[0,1],[-1,2],[-1,1],[-1,2],[0,1],[-1,1],[-1,2],[0,1],[0,3],[0,3],[0,2],[0,2],[0,3],[0,2],[1,2],[1,2],[0,3],[0,2],[-1,2],[-1,2],[-1,2],[0,3],[-1,2],[0,1],[2,1],[1,0],[1,0],[3,0],[2,0],[1,0],[2,0],[1,1],[0,1],[0,1],[2,1],[2,2],[1,2],[1,1],[1,3],[1,1],[-1,3],[0,3],[0,3],[0,2],[0,2],[0,3],[1,2],[0,2],[0,1],[-1,1],[-1,-1],[0,-1],[-1,0],[-1,-1],[-1,0],[-1,0],[-1,0],[-1,0],[0,-1],[0,-1],[0,-1],[0,-2],[0,-1],[0,-1],[0,-2],[-1,-3],[-1,-2],[-1,-1],[-1,-1],[-1,-2],[-2,0],[0,1],[-1,1],[-1,2],[0,2],[-1,3],[0,2],[-1,1],[-1,0],[0,-1],[-1,-2],[-1,-2],[-1,-1],[-1,0],[0,1],[0,1],[0,1],[-1,1],[-1,1],[-1,1],[-1,0],[-1,0],[-1,0],[-1,0],[-1,1],[-1,1],[0,1],[-1,2],[-1,3],[0,1],[0,1],[0,2],[0,3],[0,1],[0,2],[0,3],[-1,1],[-2,0],[-1,-1],[-1,-1],[-1,0],[-1,1],[-1,1],[-1,2],[-1,0],[-1,0],[-1,0],[0,-1],[0,-1],[-1,-3],[0,-2],[-1,-1],[-2,-4],[-1,1],[-1,1],[0,1],[-1,1],[-1,1],[-1,1],[0,1],[-1,2],[0,1],[-1,2],[0,1],[-1,2],[-1,2],[0,1],[0,2],[-1,2],[0,2],[-1,2],[0,2],[0,2],[0,1],[-1,3],[0,2],[0,2],[-1,1],[-1,1],[-1,2],[-1,2],[0,1],[0,3],[-1,1],[-1,2],[-1,2],[0,1],[-1,1],[0,2],[0,2],[0,1],[0,3],[0,2],[-1,1],[0,1],[-2,2],[-1,1],[-1,1],[-2,0],[-1,0],[-1,1],[-2,0],[-1,1],[-1,0],[-2,0],[-1,0],[-1,0],[-1,0],[-2,0],[-1,1],[-1,1],[-1,1],[0,2],[-1,1],[0,3],[0,1],[1,0],[0,2],[0,1],[1,2],[-1,2],[0,1],[0,2],[0,1],[0,2],[0,1],[1,1],[1,2],[1,3],[1,1],[0,1],[1,1],[1,1],[1,1],[1,0],[0,1],[2,0],[1,0],[2,0],[2,1],[2,0],[1,0],[1,1],[1,1],[1,1],[0,2],[1,1],[1,1],[0,1],[0,1],[0,2],[1,2],[1,2],[1,2],[0,1],[0,1],[1,2],[1,1],[0,1],[0,2],[1,1],[0,1],[0,2],[-1,1],[0,1],[0,1],[0,1],[1,1],[1,1],[2,1],[1,0],[1,0],[2,1],[1,0],[1,0],[1,0],[1,0],[1,-1],[1,0],[2,-1],[1,0],[1,0],[1,0],[1,0],[-1,2],[0,1],[0,2],[-1,2],[0,2],[0,2],[0,2],[0,2],[1,2],[1,0],[1,2],[2,1],[2,0],[1,0],[2,0],[1,0],[1,-1],[1,-1],[1,0],[1,-2],[1,0],[1,0],[0,1],[1,1],[1,1],[0,1],[0,1],[0,2],[1,1],[0,2],[2,1],[1,1],[1,1],[0,2],[-1,1],[-2,1],[-1,0],[0,1],[-1,1],[0,2],[0,2],[0,1],[0,2],[0,2],[0,1],[-1,2],[0,2],[-1,1],[0,2],[-1,1],[-1,0],[-2,0],[-1,0],[-1,-1],[-1,-1],[-1,-1],[0,-1],[0,-1],[0,-2],[0,-1],[-1,-1],[0,-1],[-1,-1],[-2,-1],[-1,-2],[-1,0],[-1,0],[-1,1],[-1,0],[-2,0],[-1,1],[-1,2],[-1,1],[-1,2],[-1,1],[-2,2],[-1,1],[0,1],[0,2],[1,2],[0,2],[-1,2],[0,3],[0,2],[0,2],[1,1],[1,2],[1,1],[1,2],[0,1],[1,1],[0,2],[1,1]],[[8697,4056],[1,2],[1,2]],[[8699,4060],[1,1],[1,0],[1,-1],[1,0],[1,0],[1,0],[1,0],[2,0],[1,1],[1,1],[1,0],[1,0]],[[8712,4062],[1,1],[2,1],[1,0],[1,0],[1,0],[1,-1],[1,0],[1,0],[1,0]],[[8722,4063],[1,-1],[2,0],[1,0],[2,1],[1,0],[1,1],[2,0],[1,0],[1,-1],[1,0],[1,0],[0,1],[1,0],[2,1],[2,1],[2,0],[1,0],[2,1],[3,1],[2,1],[2,0],[2,1],[2,1],[2,0],[1,1],[2,1],[1,2],[0,1],[0,1],[1,1],[-1,1],[0,1],[-1,1],[-1,2],[-2,0],[0,1],[-1,1],[-1,1],[-1,1],[0,1],[0,1],[-1,3],[0,2],[-1,1],[0,1],[-1,0],[-2,1],[-1,1],[-1,0],[-1,1],[-2,0],[-2,0],[-1,1],[-1,2],[0,1],[-1,1],[-2,2],[-1,0],[-2,0],[-1,0],[-1,1],[-1,0],[-2,0],[-2,0],[0,-1],[0,-1],[0,-1],[-1,-1],[-1,-2],[0,-1],[-1,-1],[-2,-1],[-1,0],[-1,-1],[-1,-1],[-1,0],[-1,-1],[-2,-1],[-1,0],[-1,-1],[-2,0],[-1,-1],[-2,0],[-1,0],[-1,0],[-1,1],[-1,0],[-1,-1],[-1,0],[0,-1],[-2,-1],[-1,0],[-1,-1],[-1,-1],[0,-1],[-1,-1],[0,-1],[-1,-1],[0,-2],[-1,-1],[0,-1],[-1,-2],[-1,-1],[0,-1],[-1,-1],[-1,-1],[-1,0],[-1,-1],[-1,0],[-1,1],[-1,0],[-2,1],[-1,1],[-1,1],[-1,2],[-1,1],[-1,1],[0,1],[-1,1],[-1,0],[-2,1],[0,1],[-1,1],[1,1],[0,1],[0,2],[0,1],[0,1],[0,1],[1,2],[0,1],[0,2],[0,2],[-1,2],[0,1],[-1,1],[-1,2],[-1,1],[-1,1],[-1,1],[-1,0],[-1,1],[-1,0],[-1,1],[-2,2],[-1,0],[-1,1],[-1,0],[-2,0],[-1,-1],[-2,0],[-1,-1],[-2,0],[-1,-1],[-2,1],[-1,1],[-2,1],[-1,0],[-1,-1],[-1,0],[0,-1],[-1,-1],[-1,-1],[-1,0],[-2,1],[-1,0],[-1,1],[-2,1],[-1,0],[-1,1],[-1,1],[-1,0],[-1,1],[-1,2],[-1,1],[-1,1],[-1,1],[0,1],[-1,1],[-2,1],[-1,0],[-1,0],[-1,0],[-1,0],[-1,-1],[-1,0],[-2,-1],[-1,-1],[-1,-1],[-1,-1],[-1,0],[-1,-1],[-1,0],[-1,-1],[-1,0],[-1,0],[0,1],[0,1],[-1,1],[0,2],[0,1],[0,2],[0,1],[0,2],[0,1],[-1,2],[0,2],[-1,1],[-1,2],[0,1],[-1,2],[1,2],[0,1],[0,2],[1,1],[1,1],[0,1],[1,1],[0,1],[1,1],[1,1],[1,1],[1,0],[1,1],[1,0],[1,0],[1,1],[1,0],[1,1],[1,0],[1,0],[1,0],[1,0],[1,-1],[1,0],[1,-1],[0,-1],[0,-1],[1,-2],[0,-2],[1,-1],[1,-1],[1,0],[1,-1],[1,0],[2,-1],[1,0],[1,-1],[1,0],[1,-1],[1,0],[1,-1],[1,0],[1,-1],[2,0],[1,-1],[1,-1],[1,0],[1,-1],[1,-1],[1,0],[2,0],[1,0],[1,0],[1,0],[2,0],[1,0],[1,0],[1,0],[1,0],[2,0],[2,0],[2,0],[2,1],[1,1],[1,1],[1,1],[0,1],[1,1],[-1,1],[0,2],[0,1],[-1,1],[-1,1],[0,1],[-1,1],[-1,1],[-1,1],[0,1],[-1,0],[-1,1],[-1,2],[-1,1],[0,1],[-1,2],[-1,0],[-1,1],[-1,0],[-1,-1],[-1,0],[-1,0],[-1,0],[-1,1],[-1,0],[-2,0],[-1,0],[-1,1],[-1,1],[0,1],[0,2],[0,1],[1,1],[0,2],[0,2],[0,2],[1,3],[0,1],[0,2],[-1,1],[-1,-1],[-1,0],[0,-1],[-1,-1],[0,-2],[-1,0],[-1,1],[0,2],[0,1],[0,2],[1,2],[0,2],[1,2],[0,1],[1,2],[0,2],[0,1],[0,1],[1,3],[0,2],[0,1],[-1,2],[-1,2],[0,1],[-1,2],[-2,1],[0,2],[-1,1],[1,1],[0,1],[0,1],[1,1],[0,2],[1,1],[0,1],[0,1],[1,1],[0,2],[0,1],[-1,1],[-1,1],[0,1],[-1,1],[0,1],[0,3],[0,1],[1,1],[1,1],[1,1],[2,1],[2,1],[0,1],[0,1],[0,1],[-1,2],[0,1],[0,2],[1,2],[1,1],[1,1],[2,1],[1,0],[1,1],[2,0],[2,1],[1,1],[2,1],[0,1],[1,1],[0,1],[-1,1],[0,2],[-1,1],[0,1],[-1,0],[-1,1],[-2,1],[-1,1],[-2,1],[-1,1],[-2,1],[0,-1],[-1,0],[-1,0],[-1,-1],[-1,0],[0,-1],[-1,-1],[0,-2],[0,-1],[0,-2],[-1,-2],[-1,0],[-1,0],[-1,0],[-1,-1],[-2,0],[-1,-1],[-1,-1],[0,-1],[-1,-1],[-1,-1],[-1,-1],[-1,-1],[-1,0],[-2,-1],[-1,0],[-1,0],[0,-1],[-2,0],[-1,-1],[-1,0],[-1,1],[-1,0],[-1,0],[-1,2],[-1,1],[-1,2],[-1,1],[-1,2],[0,2],[0,2],[-1,2],[0,2],[-2,0],[-1,0],[-2,1],[-1,1],[0,1],[0,1],[-1,1],[0,1],[-1,0],[0,2],[0,1],[0,1],[1,1],[1,2],[1,1],[0,2],[0,1],[0,1],[0,2],[0,3],[0,1],[0,2],[0,2],[0,2],[1,1],[0,2],[1,1],[0,2],[1,1],[0,1],[1,2],[1,2],[0,1],[0,2],[0,3],[-1,0],[-1,0],[0,1],[-1,0],[-1,1],[0,3],[1,2],[0,2],[0,1],[0,1],[0,1],[0,1],[-1,1],[-2,2],[0,1],[1,1],[0,1],[1,0],[0,2],[0,1],[0,1],[0,1],[-1,0],[-1,1],[-1,1],[0,2],[1,1],[1,1],[1,0],[1,1],[1,0],[2,0],[1,0],[1,0],[1,1],[0,1],[0,1],[-1,0],[0,1],[-1,1],[-1,1],[0,1],[0,1],[1,1],[1,0],[1,1],[1,0],[1,1],[1,0],[1,1],[1,0],[1,0],[1,0],[1,0],[1,0],[1,2],[1,1],[0,1],[1,1],[0,1],[1,1],[0,2],[0,1],[0,1],[0,1],[-1,1],[-1,0],[-1,1],[-1,0],[-2,0],[-1,0],[-1,1],[-2,1],[-1,1],[0,1],[-1,1],[-1,2],[-1,0],[-1,0],[-2,-1],[-1,0],[-1,0],[-2,0],[-1,0],[-1,0],[-2,0],[-1,0],[0,1],[0,2],[0,2],[0,2],[0,1],[0,1],[0,1],[0,2],[0,1],[-1,1],[0,2],[0,2],[-1,1],[1,1],[1,0],[1,-1],[1,0],[1,0],[1,-1],[1,0],[2,0],[1,0],[1,-1],[1,0],[2,0],[2,1],[1,0],[1,1],[1,1],[0,1],[1,1],[0,1],[0,2],[0,1],[0,1],[0,1],[-1,1],[-1,1],[0,1],[0,1],[0,1],[2,0],[1,-1],[1,0],[1,0],[2,-1],[1,0],[2,0],[1,-1],[1,0],[2,1],[1,0],[1,1],[1,1],[0,1],[0,1],[0,1],[0,1],[0,1],[0,1],[-1,1],[0,1],[-1,1],[-1,2],[-2,1],[-1,1],[-1,1],[-1,1],[-1,0],[-2,1],[-2,0],[-1,-1],[-2,-1],[-1,0],[-1,0],[0,1],[0,1],[0,1],[0,1],[-1,1],[0,1],[-1,1],[-1,1],[-1,0],[-2,1],[-1,0],[-1,1]],[[8834,972],[-8,2],[-7,14],[-10,8],[-1,6],[9,3],[4,5],[-1,3],[-5,3],[-5,10],[-6,1],[-10,7],[-2,-6],[0,-6],[-5,-4],[-40,15],[-14,8],[-16,16],[-2,5],[1,8],[-12,7],[-7,-3],[-15,10],[-1,8],[4,20],[0,8],[-1,4],[-4,1],[-4,-2],[-9,6],[-4,1],[-5,-2],[-4,1],[-2,15],[1,4],[8,13],[5,17],[8,19],[8,14],[3,10],[11,12],[2,-5],[-1,-10],[3,-17],[-11,-43],[1,-3],[3,-2],[5,1],[4,-5],[6,-21],[2,-12],[-2,-6],[3,-6],[5,-3],[4,-7],[5,-3],[3,1],[2,6],[0,14],[6,4],[16,-8],[12,0],[6,-3],[7,-11],[33,-16],[3,1],[3,7],[6,3],[8,3],[15,-2],[9,7],[27,-1],[29,5],[7,-1],[5,-3],[1,-3],[-3,-6],[-11,-8],[-12,-14],[-18,-13],[-2,-14],[-9,-12],[-2,-7],[1,-4],[6,-5],[-4,-13],[1,-6],[4,-4],[0,-6],[-3,-2],[-5,1],[-17,-9],[-8,2],[-5,-1],[-2,-1]],[[8712,977],[8,-8],[14,-7],[11,-3],[12,0],[6,-3],[3,-10],[8,-5],[8,-1],[4,-3],[1,-5],[0,-3],[2,-7],[2,-1],[5,3],[4,7],[7,4],[16,-5],[20,2],[5,-2],[13,-12],[2,-6],[-1,-4],[-6,-5],[-2,-6],[2,-4],[15,7],[12,-7],[2,1],[6,9],[20,11],[19,22],[9,15],[4,0],[2,-8],[-1,-3],[2,-15],[-4,-18],[1,-8],[11,2],[15,-6],[15,10],[7,0],[8,-7],[20,-27],[1,-4],[-2,-10],[-19,-12],[-4,-6],[0,-7],[21,-6],[11,1],[6,3],[9,2],[8,-4],[1,-5],[-2,-6],[-10,-6],[-10,3],[-2,-1],[-4,-8],[-12,-3],[-5,-12],[-8,-5],[-22,-1],[-3,-5],[2,-7],[-2,-6],[-4,-1],[-6,3],[-16,-13],[-9,-1],[-6,-3],[-11,-11],[-2,-10],[-2,-2],[-31,-23],[-11,-2],[-4,-8],[-10,-12],[-14,-5],[-3,-2],[1,-11],[-3,-4],[-3,-1],[-7,5],[-14,-4],[-3,5],[-5,1],[-4,-3],[-4,-8],[-4,-5],[-15,-3],[-7,-7],[-9,-5],[-14,11],[-5,9],[-4,0],[-1,-4],[2,-5],[10,-13],[2,-10],[-1,-13],[-11,-13],[-4,-1],[-14,9],[-16,4],[-3,11],[1,6],[-4,3],[-4,-19],[-4,0],[-3,6],[-4,2],[-3,-2],[-10,-14],[-2,-10],[4,-10],[0,-17],[-2,-8],[-8,-5],[-8,-14],[-6,-5],[-6,-7],[-3,-6],[-2,-10],[-11,-9],[-5,-18],[-10,-14],[-4,-21],[-14,-11],[-8,-8],[-6,-10],[-7,-5],[-11,10],[-4,-15],[-2,2],[-4,9],[-3,1],[-1,-8],[2,-11],[-1,-15],[-2,-6],[-6,-3],[-5,-18],[-3,0],[-3,9],[-5,3],[-7,0],[-3,-2],[-2,-7],[-8,4],[-11,17],[0,4],[2,8],[-6,15],[-3,21],[-4,3],[-8,-1],[-1,-4],[2,-14],[-1,-6],[-2,-2],[-3,2],[-3,5],[-6,24],[-3,2],[-2,6],[1,3],[-4,30],[1,18],[-5,22],[12,57],[6,13],[12,19],[5,8],[2,9],[-2,3],[-7,-6],[-9,-15],[-8,-18],[-3,-3],[-5,2],[-1,4],[1,4],[6,7],[7,18],[19,20],[11,7],[4,0],[7,-4],[5,5],[3,6],[-4,3],[-2,6],[2,5],[10,9],[17,22],[29,29],[10,15],[10,8],[7,10],[17,17],[18,12],[17,4],[7,4],[6,16],[7,-4],[2,-6],[0,-6],[-4,-16],[2,-7],[10,-4],[13,-17],[4,3],[-4,21],[3,11],[11,7],[13,17],[26,1],[12,8],[1,5],[-4,3],[-9,-3],[-15,3],[-10,-2],[-15,4],[-20,1],[-32,-4],[-17,3],[-6,-4],[-4,-9],[-5,-4],[-3,6],[-6,3],[-9,-2],[-1,6],[4,20],[9,11],[24,19],[10,11],[6,12],[3,12],[10,16],[1,4]],[[8671,936],[19,31],[1,0],[7,-3],[0,-1],[7,-2],[7,16]],[[9056,999],[-20,-16],[-3,-7],[1,-4],[5,2],[8,9],[9,7],[2,4],[9,3],[0,-3],[-1,-8],[6,-3],[12,8],[7,7],[24,35],[-3,4],[-7,-6],[-10,-16],[-5,-4],[-3,3],[3,8],[6,7],[14,24],[6,9],[4,2],[6,-5],[3,-19],[4,-3],[3,2],[7,10],[4,2],[9,-6],[5,-8],[7,-4],[4,1],[6,-4],[0,-5],[-3,-7],[1,-6],[-3,-10],[-2,-1],[-4,-9],[1,-3],[4,-3],[5,2],[6,-4],[1,-4],[-1,-5],[-18,-16],[-14,-5],[-2,-5],[2,-6],[-5,-9],[-40,-36],[-19,-13],[-10,7],[-9,1],[-3,7],[6,8],[2,6],[3,26],[2,1],[2,6],[6,10],[17,21],[2,8],[-4,2],[-6,-10],[-18,-12],[-29,-6],[-3,-3],[1,-3],[5,-3],[-1,-5],[-13,-6],[-3,-6],[-3,-13],[1,-3],[5,-3],[21,12],[4,-2],[1,-6],[-2,-7],[-6,-11],[-7,-7],[-20,-8],[-4,0],[-7,4],[-8,12],[-12,8],[-7,11],[-4,16],[-2,27],[-5,19],[0,8],[4,7],[5,3],[2,7],[-2,12],[2,5],[21,27],[7,15],[14,62],[7,21],[18,35],[7,7],[12,17],[8,19],[8,6],[18,-4],[0,-4],[-5,-12],[-2,-9],[2,-6],[14,-9],[2,-10],[-9,-32],[0,-35],[-9,-28],[-6,-13],[-6,-8],[-2,-8],[3,-4],[3,2],[6,12],[5,4],[2,-4],[-22,-37],[-30,-30]],[[9052,855],[-11,8],[-1,8],[2,7],[19,5],[1,-5],[0,-3],[-5,-3],[-1,-3],[2,-8],[-1,-4],[-5,-2]],[[1153,6702],[-6,0],[-4,4],[1,3],[5,3],[4,-1],[3,-5],[-3,-4]],[[1134,6680],[1,3],[7,0],[5,-6],[-2,-6],[-6,-1],[-5,6],[0,4]],[[1803,6842],[1,-5],[-3,-3],[-5,-1],[-8,-2],[-3,2],[-3,5],[2,3],[9,4],[10,-3]],[[1773,6742],[1,-2],[-1,-2],[-4,-2],[-8,1],[-2,4],[1,3],[5,2],[8,-4]],[[1926,6735],[5,-5],[-2,-2],[-4,-4],[-4,0],[-3,3],[-1,5],[9,3]],[[2716,6949],[-4,-1],[-21,3],[-6,2],[-3,5],[6,3],[12,-3],[11,1],[6,-2],[2,-5],[-3,-3]],[[2777,6945],[-6,-1],[-18,3],[-6,2],[-2,3],[10,4],[11,-2],[10,-4],[1,-5]],[[2800,6947],[-6,2],[-5,1],[-2,4],[0,3],[4,2],[6,-1],[7,-6],[-4,-5]],[[2752,6941],[5,-3],[2,-4],[-3,-4],[-4,0],[-5,2],[-3,4],[0,3],[8,2]],[[2838,6950],[-4,-2],[-5,0],[-8,0],[-5,4],[4,3],[9,2],[7,-2],[2,-5]],[[3171,6878],[-6,-1],[-5,1],[-7,1],[-6,1],[-5,4],[3,2],[5,2],[8,0],[8,-1],[7,-5],[-2,-4]],[[3205,6873],[-11,-1],[-5,4],[3,4],[9,2],[6,-3],[1,-3],[-3,-3]],[[3307,6879],[-12,-1],[-20,1],[-18,7],[-4,5],[2,3],[6,1],[20,-7],[19,-1],[8,-3],[-1,-5]],[[3304,8239],[1,-4],[-3,-2],[-9,-1],[-9,3],[-2,3],[3,3],[10,1],[9,-3]],[[2297,6689],[0,-5],[2,-362],[756,-487],[166,-122],[55,0],[155,0],[149,-156],[260,-37],[97,-16],[71,-18],[130,-28],[157,-35],[40,-7],[74,-8],[0,-59],[0,-243],[0,-242],[0,-243],[0,-243]],[[4409,4378],[-21,0],[-92,0]],[[3844,4378],[-71,0],[0,-3],[-18,3],[-25,0]],[[3278,4378],[-27,0],[-86,0]],[[2374,4378],[-113,0],[-113,0],[-26,0],[-14,0],[-18,0],[-7,0],[-1,0],[-15,0],[-4,0],[-10,0],[-16,0],[-2,0],[-90,0],[-4,0]],[[1941,4378],[-3,0],[-1,0]],[[1937,4378],[-1,2],[-1,2],[0,1],[-2,1],[-1,1]],[[1932,4385],[-1,1],[0,1],[-1,1],[-1,0],[0,1],[-1,1],[-1,2],[-1,2],[-1,2],[-1,1],[0,2],[-1,3],[0,1],[0,2],[0,2],[-1,1],[-1,2],[-1,3],[-1,2],[-1,2],[-2,2],[-2,1],[-2,2],[-1,2],[-1,2],[0,3],[0,2],[0,2],[0,1],[-1,0],[0,2],[-1,1],[-2,3],[0,3],[0,2],[0,1],[-3,4],[-1,2],[-1,2],[-1,2],[0,1],[-1,3],[-1,2],[0,2],[0,2],[0,1],[0,3],[0,2],[0,1],[0,3],[1,2],[0,1],[1,1],[1,4],[0,2],[0,1],[-1,1],[-1,0],[-3,1],[-3,0],[-1,1],[-1,-1],[-2,0],[-4,1],[-2,1],[-1,0],[-2,1],[-2,1],[-2,1],[-1,1],[-1,2],[0,2],[0,1],[0,2],[0,2],[-1,2],[-1,1],[-1,2],[0,3],[-1,1],[-1,2],[0,1],[-1,2],[-1,1],[-2,3],[-2,1],[-1,3],[-1,1],[-2,2],[0,1],[-1,2],[-2,2],[-1,1],[-1,1],[-1,3],[-1,2],[0,1],[0,2],[0,2],[0,2],[0,1],[1,2],[2,0],[1,1],[1,1],[1,1],[2,2],[1,1],[2,3],[0,1],[2,2],[1,2],[2,2],[0,1],[-1,1],[-1,1],[-1,1],[-2,2],[-1,1],[-1,3],[0,1],[0,2],[0,3],[-1,1],[0,2],[0,2],[-1,2],[0,1],[0,2],[-1,3],[0,2],[-1,3],[0,2],[0,1],[0,3],[-1,1],[-1,1],[-1,0],[-1,1],[-2,0],[-1,-1],[-1,-1],[-2,-2],[0,-1],[-2,1],[-2,2],[-2,1],[-1,-1],[-1,-1],[-1,-1],[-1,-1],[-1,2],[-1,0],[-3,2],[-2,1],[-1,-1],[0,-1],[-1,-2],[-1,-1],[-1,-1],[0,-1],[-1,-1],[-1,0],[-1,-2],[-1,-1],[0,-2],[0,-2],[0,-2],[1,-2],[0,-3],[0,-1],[0,-2],[-2,0],[-1,0],[-2,0],[-2,1],[-1,-1],[-2,0],[-3,0],[-3,0],[0,-1],[-2,-1],[-2,-1],[-1,0],[-3,-1],[-2,0],[-3,1],[-2,0],[-2,0],[-1,0],[-1,0],[-1,-1],[-1,-1],[-1,-2],[-1,-3],[-1,-1],[-3,-2],[-1,-2],[-3,-1],[-2,-2],[-2,-1],[-4,-1],[-3,1],[-1,0],[-3,1],[-2,2],[-2,1],[-1,0],[-2,1],[-2,2],[-2,2],[-2,0],[-4,2],[-1,0],[-1,0],[-1,0],[-2,-1],[-2,-1],[-2,0],[-3,0],[-1,0],[-2,0],[-3,1],[-2,0],[-1,1],[-1,2],[0,1],[0,2],[-1,1],[-1,2],[-1,1],[-1,1],[-2,2],[-1,1],[-1,2],[-1,2],[-3,0],[-1,0],[-1,-1],[-1,-1],[0,-1],[-1,-1],[-1,-2],[0,-1],[-1,-1],[0,-1],[-1,-4],[-1,-2],[-1,-2],[0,-1],[-2,-1],[-2,0],[-1,0],[-2,0],[-2,0],[-3,1],[-2,1],[-2,0],[-1,2],[0,1],[0,1],[0,1],[1,2],[0,1],[0,2],[-1,0],[-1,0],[-1,0],[-1,-1],[-2,0],[-3,0],[-1,-1],[-1,0],[-2,-1],[-1,-2],[-1,0],[0,-2],[0,-1],[0,-2],[0,-2],[0,-1],[0,-2],[-2,-3],[-1,-2],[-1,-1],[-1,0],[-3,-1],[-3,0],[-1,0],[-3,0],[-2,1],[-4,1],[-3,1],[-1,0],[-1,1],[-2,1],[0,1],[-2,1],[-1,0],[-1,1],[-1,1],[-1,0],[-1,-1],[-1,-1],[-3,-2],[-2,-2],[-1,-2],[-3,-2],[-2,-2],[-2,-1],[-1,0],[-1,0],[-2,1],[0,2],[-1,2],[0,1],[-2,1],[-1,0],[-2,-1],[-1,0],[-2,0],[-1,0],[-1,-1],[-1,-3],[-1,-1],[-1,-1],[-1,1],[-1,2],[-1,1],[0,1],[-1,2],[0,1],[0,2],[0,3],[-1,3],[-1,1],[-1,3],[-1,2],[0,4],[0,3],[0,3],[0,3],[0,2],[0,3],[0,2],[0,3],[0,3],[0,1],[0,3],[0,2],[-1,1],[-1,2],[-1,3],[-1,2],[0,4],[-1,3],[-1,2],[-3,2],[-2,0],[-3,-1],[-2,-1],[-1,-1],[-1,-2],[-2,-1],[-1,0],[0,1],[0,1],[-1,2],[0,3],[-1,1],[0,1],[1,2],[1,1],[0,1],[0,1],[1,1],[2,1],[1,1],[2,2],[0,1],[0,1],[1,2],[0,1],[0,2],[0,2],[1,3],[1,1],[1,3],[0,2],[0,2],[0,2],[0,2],[0,3],[1,1],[-2,2],[-2,0],[-2,1],[-1,1],[0,1],[0,1],[0,2],[-1,1],[0,2],[0,2],[0,2],[0,1],[-1,3],[0,1],[0,3],[-1,1],[0,1],[0,2],[0,2],[-1,2],[0,2],[0,1],[-1,2],[-1,1],[-1,1],[-1,2],[-1,1],[0,1],[0,2],[-1,1],[0,2],[0,2],[0,2],[0,1],[0,3],[1,2],[0,1],[-1,0],[-1,0],[-3,0],[-2,1],[-2,2],[-1,1],[-2,1],[0,1],[-1,2],[-1,2],[-2,0],[-1,1],[-3,1],[-1,-1],[-3,0],[-2,0],[-1,-1],[-2,0],[-4,0],[-2,-1],[-2,0],[-2,0],[-2,0],[-2,0],[-2,0],[-2,1],[-1,1],[-1,2],[-2,1],[-1,1],[-2,1],[-1,1],[-2,1],[-2,2],[-1,1],[-1,2],[0,1],[0,1],[0,3],[-1,1],[-1,1],[-2,1],[-2,0],[-2,0],[-1,1],[-3,1],[-2,1],[-2,2],[-2,2],[-1,1],[-1,1],[-1,1],[-2,3],[-1,0],[-2,2],[-1,2],[-2,2],[-2,2],[-2,1],[-1,1],[-2,2],[-2,2],[-2,2],[-1,1],[0,1],[-2,1],[-1,1],[-2,1],[-1,2],[-1,1],[0,1],[-1,1],[1,1],[1,1],[2,2],[1,1],[1,1],[0,1],[0,1],[1,2],[0,2],[0,1],[0,2],[-1,1],[-1,3],[-1,1],[-1,1],[-1,1],[-4,1],[-1,0],[-1,1],[-1,0],[-2,0],[-2,0],[-1,1],[-2,0],[-1,0],[-1,1],[-2,1],[-1,2],[0,2],[0,2],[0,1],[0,3],[-1,2],[0,2],[0,1],[-1,1],[-1,3],[-2,1],[-1,2],[-1,0],[-3,1],[0,1],[-1,1],[-1,1],[-1,1],[-1,1],[0,1],[-1,1],[0,1],[0,1],[0,1],[0,1],[0,1],[-1,1],[-1,1],[0,1],[0,1],[-1,0],[-1,2],[-1,2],[-1,2],[-1,1],[-2,1],[-3,4],[-1,1],[-1,2],[-1,1],[-2,3],[-1,1],[-2,1],[0,1],[-3,1],[-2,1],[-1,0],[-1,0],[-2,0],[-1,0],[-2,0],[-2,1],[-2,0],[0,-1],[-1,0],[-1,-2],[-1,0],[0,-2],[-1,0],[0,-1],[-1,-2],[-1,-2],[0,-1],[-1,-1],[0,-1],[0,-3],[-1,-1],[-1,0],[-2,1],[-1,0],[-2,1],[-1,2],[-2,1],[0,1],[-1,2],[-1,2],[0,1],[-1,1],[-2,1],[-1,1],[-1,1],[-1,0],[-2,-1],[-2,0],[-3,2],[-2,1],[-4,0],[-2,0],[-1,-1],[-1,0],[-2,0],[-1,-1],[-2,-1],[-1,-1],[-1,1],[-1,0],[-1,0],[-2,1],[-1,1],[-2,1],[-1,1],[-1,2],[-2,2],[-2,0],[-2,0],[-1,1],[-1,1],[0,1],[2,1],[1,1],[1,1],[2,0],[1,1],[0,2],[1,1],[0,2],[1,1],[-1,2],[0,2],[-1,1],[-1,1],[-1,1],[-1,1],[-2,1],[-1,2],[-1,1],[-1,2],[0,2],[-1,1],[1,2],[0,1],[0,3],[-1,1],[0,1],[0,1],[0,2],[1,2],[0,1],[1,2],[1,0],[1,2],[0,2],[1,1],[0,1],[1,2],[0,1],[-1,1],[-1,1],[-2,1],[-1,0],[-2,2],[0,1],[0,1],[0,2],[1,2],[0,1],[1,2],[1,2],[1,2],[1,0],[2,1],[2,0],[1,1],[2,1],[1,1],[1,1],[0,2],[0,2],[0,1],[-1,1],[-1,1],[-1,1],[-1,2],[-1,1],[-1,1],[-2,1],[-1,0],[-2,1],[-2,0],[0,1],[-2,0],[-1,1],[-1,0],[-2,1],[-1,1],[-1,2],[-1,1],[-1,2],[-2,2],[-1,1],[-1,1],[-2,0],[-1,0],[-1,-1],[-1,0],[-3,-1],[-1,0],[-2,-1],[-1,-1],[-2,0],[-1,1],[1,1],[0,2],[1,1],[1,2],[1,2],[1,2],[0,2],[1,2],[0,1],[-1,1],[-1,1],[-1,1],[-1,1],[-1,1],[0,2],[-1,1],[1,1],[0,1],[1,1],[0,1],[0,2],[-1,0],[-1,0],[-1,1],[-2,0],[-2,0],[-1,1],[-2,2],[0,2],[-1,2],[0,1],[0,1],[0,2],[-1,1],[0,2],[0,1],[0,2],[0,1],[0,1],[0,2],[0,2],[-1,2],[-1,2],[-2,2],[0,1],[-1,1],[-2,2],[0,1],[-2,2],[-1,0],[-2,2],[-1,1],[-1,3],[-1,1],[0,1],[1,3],[0,1],[1,2],[1,0],[1,1],[1,1],[1,0],[1,2],[0,2],[0,1],[1,3],[0,2],[0,1],[1,1],[1,1],[0,2],[1,1],[1,2],[0,2],[1,0],[0,2],[0,1],[0,1],[1,1],[0,1],[1,1],[1,1],[0,2],[1,1],[1,1],[0,2],[0,2],[-1,1],[-1,2],[-1,1],[-1,2],[-1,0],[-1,0],[-2,0],[-1,-1],[-2,0],[-1,0],[-3,0],[-1,-1],[-2,1],[-3,1],[-2,1],[-1,2],[-1,1],[0,2],[0,1],[-1,2],[0,1],[0,1],[-1,2],[0,1],[-2,3],[0,1],[-1,1],[0,2],[0,2],[-1,1],[-1,2],[-1,1],[-1,1],[-2,1],[-1,1],[-1,0],[-2,0],[-2,0],[-2,0],[-1,1],[0,1],[0,1],[-1,2],[0,1],[0,1],[-1,3],[0,2],[-1,1],[0,1],[-1,1],[-1,0],[-1,-1],[-1,0],[-1,0],[-1,-1],[-2,0],[-1,0],[-2,0],[-1,0],[-1,0],[-1,1],[0,1],[0,2],[0,1],[0,1],[0,1],[0,2],[0,1],[0,2],[0,1],[0,1],[1,1],[1,1],[1,-1],[1,0],[1,0],[1,0],[2,0],[1,1],[0,1],[0,1],[0,1],[0,1],[1,1],[1,1],[1,0],[1,0],[1,1],[1,0],[2,0],[1,0],[1,1],[2,0],[1,0],[2,1],[1,1],[2,1],[0,1],[1,2],[1,3],[-1,1],[0,2],[0,2],[-1,2],[0,1],[0,2],[0,2],[0,1],[1,2],[1,1],[0,1],[1,0],[1,1],[1,0],[1,0],[1,0],[2,-1],[1,0],[1,1],[1,0],[-1,2],[0,1],[-1,1],[-1,1],[-1,1],[0,2],[-1,1],[-1,2],[-1,1],[-1,2],[-1,2],[-1,3],[-1,1],[0,1],[-1,1],[-1,1],[-1,0],[-2,0],[-1,0],[-2,0],[-1,1],[0,1],[2,2],[1,1],[1,1],[1,1],[0,1],[0,1],[0,2],[-1,1],[-1,2],[-2,0],[-3,1],[0,-1],[-3,-1],[-1,0],[-2,0],[-1,0],[-1,1],[-1,1],[-1,0],[-1,1],[-1,2],[0,1],[0,1],[0,1],[0,2],[0,2],[0,2],[1,1],[1,1],[0,1],[0,1],[1,1],[-1,0],[0,1],[-1,0],[-2,0],[-1,-1],[-1,0],[-2,-2],[-1,-1],[-1,-1],[-2,-1],[0,-1],[-3,-1],[-1,-1],[-1,0],[-2,0],[-1,0],[-1,0],[-2,1],[-1,0],[0,1],[-1,1],[-1,1],[-1,2],[-1,2],[0,1],[-1,2],[0,3],[0,1],[1,0],[1,1],[1,0],[1,0],[1,1],[2,1],[1,0],[1,0],[2,1],[3,1],[1,0],[2,1],[1,1],[2,0],[2,2],[1,1],[2,1],[0,2],[0,2],[0,1],[-1,1],[-1,1],[-1,2],[0,2],[0,1],[0,2],[1,2],[1,2],[0,1],[0,1],[1,2],[0,3],[-1,1],[-1,0],[-1,0],[-2,0],[-2,0],[-3,0],[-2,0],[-2,-1],[-1,0],[-1,-1],[-1,-1],[0,-1],[0,-2],[-1,-2],[-1,-1],[-1,-2],[-1,0],[-1,-1],[-1,0],[-2,0],[-2,0],[0,1],[-1,1],[0,1],[0,1],[0,1],[-1,2],[-1,1],[-2,3],[-2,2],[-2,3],[-1,2],[-1,1],[-1,1],[-1,1],[-2,2],[-1,0],[-1,2],[-2,1],[-2,0],[-1,0],[-1,0],[-3,0],[-1,1],[-3,1],[-1,1],[-2,1],[-1,0],[-2,2],[-1,0],[-2,1],[-2,1],[-2,1],[-1,1],[-1,1],[-1,0],[-1,1],[-1,2],[-1,1],[0,1],[1,1],[0,1],[1,1],[1,0],[1,1],[1,1],[1,1],[2,1],[2,1],[0,1],[-1,1],[-1,0],[-1,0],[-3,0],[-1,0],[-2,0],[-1,0],[-2,0],[-3,1],[-1,0],[-1,0],[-2,1],[-1,1],[-1,1],[0,2],[0,2],[0,2],[1,2],[-2,1],[-3,2],[-1,1],[-1,1],[-2,2],[-1,1],[0,1],[0,2],[1,0],[1,1],[2,1],[2,1],[1,1],[2,2],[2,1],[2,1],[0,1],[-1,1],[-1,1],[-1,2],[-2,1],[-2,0],[-2,0],[-2,2],[0,2],[1,1],[1,2],[0,1],[-1,1],[-1,1],[0,2],[-1,1],[-1,1],[-2,2],[-1,0],[-2,0],[-1,0],[-2,1],[-2,1],[-1,1],[0,1],[0,1],[-1,1],[0,2],[0,2],[0,1],[1,1],[1,1],[1,1],[1,2],[0,1],[-1,2],[-1,1],[-1,2],[-1,1],[-1,2],[0,1],[-1,1],[-1,2],[0,1],[-1,2],[-1,2],[-1,1],[-1,0],[-1,1],[-2,1],[-1,0],[-2,2],[-2,1],[-1,1],[-2,1],[-2,1],[-2,1],[-3,1],[-3,0],[-1,2],[-2,-1],[-3,1],[-2,1],[-2,0],[-1,0],[-2,-1],[0,-2],[0,-1],[1,-2],[1,-1],[0,-1],[-1,-1],[0,-2],[0,-1],[0,-1],[-1,-1],[0,-1],[-1,-1],[-2,0],[-2,0],[-2,0],[-2,0],[-1,0],[-2,-1],[-2,-1],[-1,-1],[-1,-1],[0,-1],[-2,-1],[-1,-1],[-1,0],[-2,0],[-1,0],[0,2],[-1,2],[-1,1],[-1,1],[-1,0],[-1,0],[-2,-1],[-2,0],[-2,-1],[-2,0],[-3,-1],[-2,1],[-3,0],[-3,0],[-2,1],[-2,0],[-1,2],[0,1],[0,1],[1,0],[0,3],[2,1],[1,2],[0,1],[2,2],[2,1],[1,1],[3,1],[1,1],[2,1],[2,1],[1,1],[1,1],[2,2],[1,1],[1,2],[1,1],[0,1],[0,2],[0,1],[0,1],[0,2],[0,2],[-2,1],[-1,0],[-1,0],[-2,0],[-1,1],[-3,0],[-1,0],[-2,1],[-2,0],[-3,1],[-2,2],[-1,0],[-1,1],[-1,1],[-1,2],[-2,1],[-1,1],[-1,1],[-1,2],[-1,2],[-2,2],[-1,2],[-1,1],[-1,2],[0,1],[0,1],[0,3],[-1,1],[0,3],[-1,2],[0,3],[-1,0],[-1,1],[-1,0],[-1,1],[-3,1],[-2,1],[-3,1],[-1,0],[-1,1],[-2,1],[-2,2],[-2,1],[-1,1],[-1,1],[-1,2],[-2,1],[-2,2],[-2,2],[-1,1],[-2,1],[-2,2],[-1,1],[-3,1],[-3,0],[-3,0],[-2,-1],[-2,1],[-2,0],[-2,1],[-2,0],[-2,0],[-2,-1],[-2,-2],[-1,-1],[-1,2],[0,1],[0,2],[-1,2],[-2,1],[-1,1],[-1,1],[-1,2],[0,2],[2,1],[1,1],[2,1],[1,1],[2,1],[1,1],[2,2],[1,1],[2,1],[2,3],[1,2],[1,2],[0,2],[-1,2],[0,1],[-2,3],[0,1],[-2,1],[0,2],[-1,1],[1,2],[2,1],[1,1],[0,1],[1,1],[1,1],[1,2],[1,1],[2,0],[1,1],[2,1],[2,2],[1,1],[2,1],[2,2],[0,2],[0,1],[0,2],[0,1],[1,1],[0,1],[-1,2],[-1,2],[-2,1],[-1,-1],[-1,0],[-1,0],[-3,-1],[-3,0],[-2,-1],[-1,1],[-2,0],[-2,0],[-2,1],[-1,0],[-1,2],[-2,2],[-1,2],[0,2],[0,3],[1,1],[0,2],[2,1],[1,2],[1,1],[1,1],[0,2],[0,2],[-1,1],[0,1],[-1,1],[-1,0],[-1,0],[-3,0],[-2,0],[-3,-1],[-1,-1],[-1,-1],[-2,-1],[-1,-1],[-2,-1],[-2,0],[-2,0],[-2,0],[-2,1],[-1,1],[0,1],[-1,2],[0,1],[0,3],[1,1],[1,1],[1,1],[2,1],[1,1],[1,0],[2,2],[-2,0],[-2,1],[0,-1],[-2,0],[-1,1],[-1,1],[2,1],[2,0],[1,1],[2,1],[2,1],[3,3],[2,1],[1,1],[1,1],[2,0],[1,1],[3,3],[1,2],[1,1],[0,1],[0,2],[0,1],[0,2],[1,2],[0,2],[1,1],[1,2],[1,0],[2,1],[1,1],[1,2],[2,1],[2,2],[1,2],[2,2],[1,2],[2,1],[2,2],[2,3],[2,2],[1,1],[0,1],[1,1],[0,2],[0,2],[0,1],[0,2],[1,1],[1,2],[1,2],[1,2],[1,1],[2,3],[1,1],[1,3],[1,2],[2,2],[2,3],[1,0],[1,3],[0,3],[-1,2],[-1,1],[-2,3],[-2,4],[-1,3],[-1,2],[-1,3],[-1,3],[-2,4],[-1,2],[-2,2],[-1,2],[-2,2],[-3,3],[-2,3],[-1,1],[-1,1],[-3,2],[-2,2],[-2,2],[-3,2],[-3,3],[-2,2],[-1,1],[-1,1],[-1,3],[-1,2],[-1,2],[1,3],[1,2],[2,1],[2,2],[1,0],[3,1],[2,1],[2,2],[1,1],[1,2],[1,1],[1,2],[1,0],[3,0],[2,1],[2,1],[1,1],[1,1],[0,1],[0,1],[0,2],[0,2],[0,1],[-1,0],[-2,2],[-1,1],[-2,0],[-1,0],[-1,0],[-1,0],[-3,-1],[-1,0],[-3,0],[-3,1],[-1,1],[-2,2],[-1,2],[-1,0],[-1,2],[-2,0],[-2,1],[-1,-1],[-2,0],[-1,-1],[-1,0],[-3,-2],[-1,-1],[-1,-1],[-3,-2],[-2,-1],[-2,-2],[-1,-1],[-1,-1],[-2,-2],[-2,-2],[-1,-3],[-1,-3],[-1,-2],[-1,-2],[-1,-1],[-1,-1],[-2,-1],[-3,0],[-1,0],[-3,0],[-3,1],[-2,1],[-2,1],[0,2],[0,1],[0,2],[1,1],[1,2],[0,1],[1,2],[1,1],[1,1],[1,2],[1,1],[1,2],[0,1],[1,1],[0,1],[-1,1],[-1,1],[-1,0],[-3,1],[-1,0],[-3,1],[-1,-1],[-3,1],[-3,0],[-3,0],[-2,1],[-3,-1],[-3,-1],[-4,-1],[-2,-1],[-3,-1],[-1,-1],[-1,-1],[-3,-2],[-2,-1],[0,-1],[-2,-1],[-3,-2],[-2,-2],[-1,-1],[-2,-1],[-2,-2],[-2,-1],[-1,-1],[-2,1],[0,1],[-2,1],[-1,0],[-4,2],[-2,0],[-1,0],[-3,0],[-2,0],[-1,0],[-1,1],[-1,0],[-2,2],[-2,2],[0,1],[1,2],[0,1],[1,3],[1,1],[1,1],[1,2],[1,1],[0,2],[0,2],[-1,0],[-1,0],[-1,1],[-2,0],[-1,1],[-1,1],[-1,0],[-1,1],[0,1],[-1,3],[0,1],[0,2],[1,1],[0,1],[2,1],[0,1],[1,1],[1,1],[2,2],[1,0],[1,1],[0,1],[1,2],[1,2],[1,3],[0,1],[1,3],[-1,2],[0,2],[-1,2],[0,1],[-1,2],[0,2],[0,1],[-1,3],[0,1],[0,3],[0,1],[1,2],[-1,2],[0,1],[0,1],[-1,1],[-2,3],[-1,0],[-2,1],[-2,0],[-1,0],[-1,0],[-2,0],[-2,0],[-1,0],[-3,0],[-3,0],[-1,0],[-2,0],[-1,0],[-1,1],[-1,1],[-1,2],[0,1],[0,1],[0,2],[1,1],[1,1],[0,1],[1,1],[1,0],[1,2],[1,1],[0,2],[0,1],[0,2],[0,1],[0,1],[1,4],[0,2],[1,1],[0,1],[2,1],[0,1],[2,1],[2,1],[2,0],[2,0],[3,-1],[1,-1],[1,-1],[1,1],[1,1],[0,1],[-1,2],[-1,2],[0,2],[-1,0],[0,1],[-2,1],[-1,1],[0,1],[-1,1],[-1,2],[0,1],[0,1],[0,2],[-1,2],[1,2],[2,0],[2,1],[2,1],[2,1],[0,1],[1,1],[1,2],[0,1],[0,1],[0,1],[-1,0],[-2,0],[-1,2],[-2,1],[-1,2],[-1,1],[-2,2],[-1,0],[-2,2],[-2,1],[-1,2],[-2,2],[-2,2],[-1,1],[-1,2],[1,1],[0,1],[2,1],[1,1],[1,0],[1,1],[0,1],[-1,1],[-1,1],[-1,0],[-2,2],[-2,1],[-1,1],[-2,1],[0,1],[-2,2],[0,1],[0,1],[1,0],[2,1],[2,1],[1,0],[2,3],[0,2],[0,2],[0,2],[0,1],[1,2],[1,3],[0,1],[-1,1],[-1,1],[-1,2],[-1,1],[-1,2],[0,1],[-1,1],[-1,1],[-1,2],[-2,1],[-2,2],[-1,1],[-1,2],[-1,1],[-1,2],[-1,2],[-1,2],[-1,1],[-1,1],[-1,0],[-3,0],[-2,0],[-3,1],[-3,1],[-1,1],[-2,2],[-1,0],[-1,2],[-2,1],[-1,2],[0,1],[0,1],[1,1],[0,1],[1,1],[1,1],[1,0],[1,1],[3,0],[1,0],[3,0],[2,0],[2,0],[2,0],[3,1],[4,0],[4,1],[2,1],[1,1],[1,0],[1,1],[0,1],[-22,0],[-113,0],[-5,0],[-125,0],[0,1],[0,1],[-1,1],[0,1],[0,1],[0,2],[-1,0],[0,2],[0,2],[-1,2],[0,1],[0,1],[0,1],[0,2],[-1,1],[0,3],[0,2],[0,1],[0,1],[0,2],[0,2],[0,2],[1,1],[-1,1],[-1,1],[0,1],[-1,1],[-1,1],[-1,1],[0,2],[-1,2],[1,0],[1,1],[1,1],[2,1],[0,1],[2,2],[1,1],[1,1],[1,1],[0,1],[1,1],[1,1],[-1,1],[0,1],[1,2],[1,3],[1,1],[0,1],[1,3],[0,1],[0,3],[0,1],[-1,1],[0,1],[-1,2],[-1,1],[-1,4],[0,1],[-1,2],[-1,1],[0,2],[0,1],[1,3],[-1,1],[-1,1],[-3,1],[-1,1],[-2,2],[0,1],[1,3],[1,1],[0,2],[1,1],[0,1],[0,1],[1,2],[0,2],[1,3],[0,1],[0,2],[0,2],[0,2],[0,1],[-1,2],[-1,2],[1,1],[-1,2],[1,1],[0,2],[0,1],[0,2],[0,2],[-1,1],[-1,2],[-1,2],[-1,1],[-1,1],[-1,2],[-1,1],[-1,1],[-2,2],[-1,1],[-2,1],[-1,0],[-1,0],[-3,0],[-2,0],[-1,0],[-2,0],[-3,0],[-1,0],[-2,2],[-1,1],[1,1],[0,1],[1,2],[1,1],[0,2],[0,1],[0,2],[0,1],[-1,2],[0,1],[-1,1],[0,1],[0,1],[0,1],[1,56],[1,223],[0,3]],[[517,6533],[8,-3],[15,-13],[4,2],[9,-2],[7,-7],[35,-22],[21,-6],[1,0],[9,2],[8,-1],[1,3],[-10,10],[-2,3],[-9,21],[-5,3],[0,4],[11,6],[38,-4],[26,4],[6,-1],[6,-5],[2,-10],[31,-29],[11,-6],[8,-8],[-1,-5],[4,-6],[-2,-16],[8,-7],[3,2],[-1,3],[5,23],[-4,9],[-9,10],[-14,7],[-20,21],[-19,23],[7,4],[32,-30],[6,-1],[1,8],[-29,31],[3,13],[11,14],[13,8],[11,14],[15,10],[28,27],[10,5],[15,15],[13,6],[30,0],[22,9],[8,12],[-2,16],[2,11],[15,8],[29,12],[11,12],[9,4],[23,-4],[14,4],[40,20],[8,12],[16,8],[10,10],[9,4],[6,-3],[10,-11],[11,2],[0,15],[3,12],[5,6],[34,17],[11,-1],[3,7],[8,3],[6,-1],[7,-5],[15,-3],[8,-9],[30,-5],[8,6],[5,18],[10,13],[9,4],[4,-1],[26,-27],[2,-16],[-4,-9],[-53,-31],[-75,-30],[-7,-6],[-1,-5],[4,-7],[-2,-4],[-25,-10],[-4,-3],[-3,-9],[-5,-3],[-4,1],[-10,9],[-18,2],[-25,-14],[-16,0],[-22,-7],[-21,-3],[-15,-7],[-3,-6],[-2,-19],[-13,-8],[-3,-13],[-18,-2],[-1,-3],[7,-9],[-2,-7],[-3,-2],[0,-4],[-1,-3],[5,-1],[5,4],[2,5],[1,5],[5,2],[4,-1],[10,0],[10,6],[2,4],[7,2],[22,16],[2,5],[-10,9],[1,7],[19,10],[7,-1],[4,-4],[6,-2],[5,-5],[5,-1],[4,2],[2,5],[-4,9],[4,2],[9,-1],[16,-17],[2,9],[-14,15],[1,3],[5,2],[5,-1],[4,-6],[5,-1],[2,3],[-6,11],[3,3],[4,-4],[5,-5],[8,-4],[5,-8],[-1,-8],[3,-10],[1,-17],[-12,-29],[2,-13],[6,-7],[4,-1],[4,6],[3,27],[7,17],[31,42],[8,26],[6,8],[9,5],[22,6],[20,3],[36,20],[45,12],[6,0],[10,4],[10,15],[8,8],[7,-6],[-3,-9],[-27,-28],[-3,-12],[0,-5],[7,-8],[13,-2],[7,1],[0,18],[28,13],[7,7],[6,13],[16,8],[7,7],[4,10],[-3,7],[2,14],[7,11],[19,8],[24,3],[27,-1],[4,3],[1,3],[-4,5],[-40,16],[-6,7],[-2,11],[-15,2],[-6,5],[1,11],[7,16],[4,4],[12,5],[4,-1],[7,-8],[24,-15],[17,-9],[13,-13],[30,-21],[12,-18],[28,-33],[8,-14],[-1,-8],[24,-50],[60,-80],[14,-10],[27,-5],[7,-10],[4,-1],[11,5],[6,-1],[8,-6],[7,-1],[4,8],[-2,9],[5,2],[11,-2],[5,4],[-6,8],[-13,3],[-18,0],[-4,1],[-3,5],[7,4],[14,0],[8,3],[6,7],[-3,6],[-16,8],[-3,5],[1,12],[30,11],[3,5],[-19,20],[1,5],[9,4],[12,-7],[6,0],[4,8],[0,9],[18,8],[3,5],[-5,6],[-13,4],[-21,-7],[-5,1],[0,14],[18,12],[18,-8],[10,4],[24,-5],[7,2],[3,5],[-4,5],[-18,2],[-3,4],[1,7],[-7,8],[7,4],[15,0],[4,-2],[-3,-6],[2,-3],[12,-2],[2,-15],[4,-5],[0,-4],[-11,-8],[-3,-6],[8,-15],[1,-8],[-10,-25],[5,-6],[5,-2],[28,-4],[5,-2],[5,-7],[-6,-7],[-17,-11],[-5,-17],[-11,-8],[-4,-14],[-8,-8],[9,-8],[12,-4],[15,0],[25,8],[26,-6],[12,0],[15,6],[10,10],[4,17],[23,10],[4,10],[-2,22],[9,13],[-8,11],[3,6],[57,14],[56,-8],[16,0],[37,-4],[41,-11],[25,-19],[30,-14],[7,-13],[16,-13]],[[3505,8743],[-38,-14],[-49,-7],[-13,-3],[-5,-4],[6,-9],[22,-8],[48,1],[10,-3],[4,-7],[-9,-12],[10,-20],[-12,-15],[-42,-26],[-30,-12],[-13,-2],[-21,3],[-32,-4],[-49,-17],[-24,-2],[-26,4],[-21,5],[-14,17],[-14,6],[-25,5],[-5,4],[-31,10],[-4,5],[7,17],[-23,20],[7,7],[3,10],[-1,27],[-4,5],[3,15],[11,2],[21,-4],[20,3],[50,14],[36,5],[30,0],[48,10],[37,5],[39,-2],[39,5],[25,-4],[29,0]],[[3505,8773],[0,-30]],[[3505,8818],[-30,-5],[-43,0],[-23,3],[-20,11],[-23,8],[-9,-1],[-7,-6],[-13,-3],[-8,-9],[-10,-2],[-18,4],[-20,11],[-32,8],[-72,-10],[-12,-12],[-9,-3],[-12,2],[-4,4],[4,5],[-10,16],[18,20],[27,12],[48,12],[97,11],[44,22],[34,3],[17,6],[22,2],[21,0],[36,-6],[7,-4]],[[3505,8917],[0,-99]],[[3504,7434],[-39,13],[-4,5],[1,6],[11,3],[23,-4],[8,0]],[[3504,7457],[0,-23]],[[3504,7467],[-31,9],[-19,20],[-46,23],[-1,11],[6,6],[12,5],[25,3],[44,-10],[10,-4]],[[3504,7530],[0,-63]],[[2758,6694],[0,1],[-3,7],[-22,9],[-7,14],[-37,30],[-13,17],[-8,15],[-4,16],[1,11],[6,10],[11,8],[38,13],[58,10],[29,3],[23,7],[14,-3],[39,2],[67,10],[26,1],[11,3],[10,6],[21,2],[24,-4],[27,-10],[18,-2],[41,3],[33,-11],[13,2],[10,-1],[27,-9],[6,1],[3,8],[37,8],[24,-5],[26,5],[30,-5],[9,2],[-1,4],[-8,5],[-1,8],[-1,4],[-7,3],[-34,2],[-19,8],[-14,21],[-13,10],[-14,5],[-23,3],[-21,7],[-24,1],[-63,30],[-18,-3],[-10,1],[-31,11],[-15,-3],[-17,-1],[-13,-3],[-12,-6],[-55,-12],[-21,-3],[-19,3],[-12,-3],[-23,4],[-11,0],[-31,0],[-6,2],[-6,9],[-8,3],[-39,-4],[-36,-8],[-33,6],[-11,-3],[-23,3],[-16,5],[-16,27],[-23,11],[-40,29],[-10,15],[3,5],[13,8],[10,3],[35,18],[21,4],[18,0],[13,3],[10,9],[18,5],[8,-1],[33,10],[8,10],[29,9],[32,3],[17,-3],[11,0],[28,8],[3,3],[-2,4],[-8,3],[-34,-1],[-4,5],[5,4],[41,11],[26,-11],[7,-1],[17,4],[6,7],[-3,3],[-6,1],[-12,-3],[-7,2],[-6,10],[-4,2],[-6,1],[-24,-3],[-41,-8],[-64,-17],[-25,3],[-9,-1],[-31,-12],[-8,3],[-7,12],[-12,4],[-6,-3],[12,-20],[-10,-4],[-25,7],[-21,-2],[-18,3],[-11,3],[-4,7],[9,15],[9,6],[48,10],[-2,7],[-14,4],[-6,14],[-6,2],[-13,-2],[-11,-17],[-9,-5],[-8,1],[-18,15],[-24,10],[-12,-2],[-7,-9],[-7,-2],[-4,1],[-7,10],[-6,44],[17,33],[21,31],[48,13],[8,7],[3,9],[1,7],[-4,6],[-38,9],[-9,14],[5,22],[10,15],[20,19],[25,12],[34,12],[22,14],[21,29],[76,17],[43,25],[58,14],[63,24],[56,24],[20,4],[14,-5],[32,-23],[25,-45],[-6,-23],[0,-22],[-31,-15],[-6,-6],[3,-15],[-3,-7],[-28,-13],[-7,-8],[5,-6],[12,-2],[25,4],[15,5],[6,5],[22,6],[8,6],[19,8],[7,-5],[-15,-12],[-4,-6],[2,-3],[9,-1],[16,11],[8,10],[1,8],[-6,11],[-8,6],[-2,8],[14,23],[22,20],[18,2],[22,-6],[27,-1],[35,-19],[79,-29],[39,-24],[6,-5],[5,-10],[-18,-22],[-6,-17],[-15,-15],[-16,-11],[-34,-9],[-9,-10],[6,-3],[8,2],[16,7],[9,2],[4,-2],[3,-10],[8,-1],[18,13],[-5,14],[6,7],[19,10],[5,-3],[-10,-11],[-2,-5],[4,-9],[25,-7],[4,5],[-5,19],[6,10],[4,3],[17,4],[12,19],[10,2],[8,-4],[3,-5],[-3,-10],[4,-9],[6,-1],[11,3],[-6,12],[7,4],[10,-3],[11,-9],[13,-5],[7,-1],[4,2],[0,4],[-21,12],[0,5],[12,1],[18,-10],[0,-1]],[[3504,7417],[0,-44],[0,-203],[0,-163],[0,-201],[-226,0],[-15,-23],[-1,0],[-1,-1],[-1,0],[-2,-1],[-1,0],[-1,0],[-9,0],[-1,0],[-1,0],[-1,0],[0,-1],[-1,0],[0,-1],[-2,-10],[-1,-1],[-1,0],[-1,-1],[-1,0],[-1,0],[-51,2],[-1,0],[-1,1],[-1,0],[-1,1],[-1,1],[0,1],[-1,33],[-14,0],[-339,0],[-85,0],[0,-68],[42,-22],[3,-1],[2,-1],[2,-1],[2,-1],[1,-2],[1,-2],[0,-2],[0,-2],[0,-2],[-1,-1],[-1,-2],[-2,-2],[-2,-1],[-12,-2],[-5,0],[-13,0]],[[3049,8683],[-17,-2],[-16,1],[-35,13],[-43,27],[-10,12],[4,7],[11,6],[28,5],[21,12],[11,2],[7,-2],[23,-22],[38,-17],[17,-19],[-11,-13],[-28,-10]],[[3071,8537],[-6,-1],[-9,2],[-4,5],[3,3],[10,2],[9,-2],[3,-5],[-6,-4]],[[3114,8527],[-6,-1],[-9,2],[-4,5],[3,3],[11,2],[8,-2],[3,-5],[-6,-4]],[[2052,8277],[-12,1],[-4,8],[19,5],[10,-1],[0,-7],[-13,-6]],[[3080,8437],[-40,4],[-22,0],[-27,5],[-21,1],[-14,3],[-9,12],[-1,7],[2,3],[21,4],[25,0],[59,9],[21,-8],[8,-7],[22,-5],[5,-8],[-7,-9],[-22,-11]],[[2106,8236],[-9,-1],[-6,2],[-9,11],[9,0],[14,-5],[4,-4],[-3,-3]],[[2240,8200],[-12,1],[-6,6],[3,6],[29,14],[4,16],[7,2],[6,-1],[7,-12],[-6,-9],[-16,-14],[-16,-9]],[[2395,8527],[38,21],[4,16],[23,22],[13,7],[30,4],[81,-4],[26,-4],[27,-1],[10,-2],[8,-7],[23,-3],[11,3],[2,7],[8,1],[18,-3],[12,6],[2,6],[-5,6],[-34,8],[-5,5],[3,3],[20,5],[13,7],[6,8],[19,3],[16,-4],[11,-7],[32,-11],[9,-17],[28,-7],[10,-6],[2,-6],[-6,-7],[-31,-24],[-13,-5],[-37,-7],[-8,-10],[6,-10],[8,-4],[58,-18],[6,-5],[-14,-3],[-33,11],[-13,-2],[-2,-3],[6,-10],[10,-3],[15,-13],[-2,-15],[4,-11],[-3,-10],[-10,-11],[-20,-10],[-58,-6],[-25,-11],[-5,-8],[6,-24],[-6,-9],[-7,-13],[-17,-3],[-9,-2],[-18,2],[-28,12],[-23,5],[-7,9],[24,68],[9,15],[-4,5],[-9,2],[-25,-10],[-11,0],[-13,4],[-8,-2],[-2,-11],[-6,-6],[16,-26],[-4,-8],[-14,-8],[-23,6],[-15,-3],[-3,-4],[15,-12],[16,-21],[-4,-14],[-8,-12],[-19,-12],[-2,-6],[7,-15],[-5,-7],[-6,-4],[-14,1],[-19,5],[-8,12],[-1,19],[-20,20],[-4,9],[-8,-1],[-6,-16],[12,-19],[-10,-6],[3,-12],[-11,-5],[7,-7],[12,-4],[9,-10],[-4,-8],[-18,-11],[-16,-27],[-12,-2],[-14,3],[-6,5],[-13,-3],[-7,-5],[-14,0],[-10,12],[7,17],[-27,26],[0,15],[-13,14],[-11,5],[-7,-3],[-3,-13],[2,-10],[11,-14],[-2,-10],[-6,-3],[-17,6],[-16,-10],[-12,-2],[-9,2],[-6,6],[-20,9],[-9,7],[-12,3],[-11,-2],[-30,-15],[-20,-5],[-18,2],[-12,7],[15,24],[-10,13],[2,7],[-4,6],[-16,-3],[-10,-8],[-14,-5],[-8,6],[2,4],[61,51],[65,20],[54,32],[26,26],[38,13],[46,10],[31,30],[22,14],[11,14],[11,7]],[[2542,8149],[-20,-2],[-12,3],[-14,12],[-42,6],[-6,12],[23,20],[16,25],[13,12],[31,15],[10,10],[19,4],[13,8],[16,3],[24,16],[12,3],[15,-6],[3,-12],[-16,-25],[-7,-19],[-26,-31],[-19,-28],[-33,-26]],[[3438,7446],[10,1],[4,-2],[2,-5],[-2,-3],[-3,-3],[-8,0],[-4,4],[0,5],[1,3]],[[1877,7744],[-13,0],[-4,5],[-3,10],[5,4],[7,-2],[11,-9],[-3,-8]],[[1856,7698],[-6,-2],[-7,1],[-4,4],[1,3],[6,2],[8,-1],[2,-7]],[[1883,7687],[18,-12],[-3,-3],[-17,-4],[-5,1],[-3,7],[5,9],[5,2]],[[2416,7779],[5,4],[-11,17],[19,24],[11,3],[27,-6],[12,-15],[-13,-25],[6,-6],[8,0],[6,2],[6,11],[15,12],[1,6],[-6,14],[14,11],[28,7],[37,-3],[32,2],[19,-2],[20,-5],[18,-9],[52,-44],[19,-11],[31,-23],[49,-28],[21,-15],[26,-23],[7,-12],[-13,-21],[-32,-21],[-74,-16],[-18,-7],[-50,-29],[-19,-16],[-37,-12],[-34,-24],[-44,-13],[-29,-18],[-42,-19],[-8,-7],[-12,-20],[-3,-12],[-19,-39],[-12,-13],[-17,-9],[-26,-25],[-5,-1],[-15,3],[-10,7],[-16,5],[-9,-3],[-2,-9],[11,-17],[-7,-16],[-6,-5],[-12,-27],[-2,-26],[7,-26],[-2,-26],[-5,-9],[-11,-11],[-24,-16],[-34,-18],[-36,-12],[-10,0],[-12,4],[-9,15],[-4,1],[-13,-4],[-9,-5],[-13,-18],[-19,-17],[-45,-19],[-8,-6],[-13,-14],[-36,0],[-16,5],[-30,35],[-10,17],[-2,10],[-30,39],[-35,32],[-31,14],[-27,20],[-37,13],[-8,5],[-12,17],[-36,5],[-37,-2],[-7,1],[-3,3],[4,9],[8,3],[8,7],[0,6],[-6,9],[3,5],[9,3],[8,8],[0,17],[18,7],[5,4],[22,37],[7,4],[9,11],[13,6],[3,5],[-9,18],[6,15],[-3,18],[-16,18],[1,8],[4,2],[20,-4],[11,0],[31,11],[11,10],[-5,7],[-14,3],[-11,6],[-7,10],[25,41],[6,4],[13,43],[14,11],[20,7],[13,12],[-7,21],[4,9],[21,12],[3,9],[-3,9],[-10,9],[-19,7],[-21,23],[-21,65],[-5,5],[-9,3],[-6,6],[-2,8],[-14,2],[-5,5],[41,13],[34,-5],[54,10],[44,-1],[44,8],[70,3],[20,6],[25,3],[27,-1],[46,5],[19,-5],[12,-7],[9,-9],[49,-32],[24,-9],[25,-6],[27,-1],[10,-3],[4,-10],[-9,-7],[-5,-13],[5,-9],[13,-12],[5,-1]],[[605,6697],[-7,-2],[-4,3],[1,8],[8,6],[6,-2],[-4,-13]],[[687,6727],[-4,-2],[-8,2],[-3,2],[0,5],[4,2],[7,-2],[4,-4],[0,-3]],[[589,6679],[3,-5],[-2,-3],[-4,0],[-7,1],[-6,3],[-1,3],[5,3],[12,-2]],[[626,6683],[5,-1],[2,-3],[-2,-4],[-8,-2],[-2,2],[0,6],[5,2]],[[606,6669],[4,2],[4,-1],[2,-3],[1,-3],[-1,-4],[-4,0],[-6,3],[-1,3],[1,3]],[[658,6676],[1,5],[8,4],[8,-1],[3,-3],[12,-1],[5,-3],[21,-5],[12,3],[1,8],[-12,8],[2,7],[10,10],[-2,10],[-9,9],[7,6],[6,-1],[20,-16],[1,-13],[8,-8],[15,-2],[7,-5],[6,-1],[14,7],[5,-1],[3,-5],[-14,-27],[-28,-29],[-13,-21],[-8,-6],[-11,-14],[-25,-14],[-7,-12],[-6,-1],[-13,7],[-6,1],[-6,-3],[8,-15],[-5,-11],[-7,-4],[-19,1],[-9,1],[-13,5],[-9,1],[-13,14],[-28,6],[-21,21],[-8,18],[-3,3],[-1,4],[5,1],[5,0],[10,-10],[7,0],[0,7],[-8,12],[1,6],[6,5],[12,-2],[4,-7],[13,9],[8,-1],[15,-7],[15,-1],[4,5],[-3,8],[-8,10],[-2,13],[23,16],[6,-1]],[[521,6600],[5,2],[3,-1],[5,-7],[-7,-2],[-6,8]],[[622,6637],[-6,3],[-7,6],[5,4],[12,-8],[-1,-4],[-3,-1]],[[525,6579],[-5,1],[-2,2],[-3,3],[0,3],[3,2],[4,1],[7,-6],[0,-4],[-4,-2]],[[797,6708],[-9,-5],[-9,1],[-2,3],[0,3],[5,3],[12,-1],[3,-4]],[[538,6575],[4,-6],[0,-2],[-4,-2],[-5,0],[-2,3],[-1,5],[8,2]],[[1412,6942],[-4,3],[5,7],[2,12],[4,2],[6,-2],[6,-6],[-2,-8],[-11,-7],[-6,-1]],[[547,6555],[-1,-3],[-5,-3],[-3,0],[-4,4],[1,6],[3,1],[4,1],[5,-6]],[[565,6560],[-4,-3],[-6,1],[-5,4],[0,4],[1,2],[5,0],[5,-2],[4,-6]],[[839,6679],[-11,2],[1,6],[5,2],[6,-1],[3,-2],[-4,-7]],[[543,6543],[6,3],[4,-1],[3,-1],[4,-2],[3,-3],[0,-5],[-3,-1],[-7,0],[-10,10]],[[583,6541],[-1,11],[6,2],[11,-2],[3,-3],[-4,-8],[-3,-2],[-12,2]],[[558,6548],[6,3],[6,-1],[5,-5],[5,-4],[5,-5],[-3,-4],[-3,0],[-4,2],[-5,4],[-5,5],[-4,3],[-3,2]],[[3504,7992],[-10,-1],[-13,-8],[-11,-1],[-14,2],[-21,-4],[-11,-5],[-7,-7],[1,-6],[-11,-8],[-39,-13],[-43,-22],[-49,-15],[-25,-11],[-92,-14],[-54,6],[-28,8],[-35,14],[-17,12],[-31,14],[-3,9],[9,11],[33,18],[32,6],[27,0],[27,4],[7,8],[0,10],[5,5],[16,7],[68,13],[32,10],[10,0],[32,-6],[9,1],[15,14],[24,3],[5,3],[-2,7],[28,22],[-5,6],[-14,3],[-15,-2],[-19,-14],[-61,-7],[-20,-7],[-9,4],[4,12],[-6,9],[-6,0],[-4,-7],[-11,-3],[-5,2],[-4,7],[1,5],[-9,7],[-4,-2],[1,-19],[-14,-18],[-9,-3],[-11,3],[-10,-1],[-7,-9],[-48,-8],[-24,-1],[-7,2],[-4,7],[26,23],[-3,4],[-9,2],[-5,15],[14,19],[26,12],[14,11],[-7,4],[-9,-2],[-19,-10],[-16,-3],[-17,3],[-8,12],[-5,1],[-6,-1],[-3,-4],[7,-36],[-6,-7],[-8,-1],[-13,4],[-8,6],[-21,7],[-11,-3],[4,-6],[23,-7],[11,-10],[9,-16],[-8,-14],[-10,-6],[-37,-6],[-16,-11],[-20,-4],[-7,2],[-6,9],[8,19],[-10,14],[-5,1],[-9,-1],[-4,-6],[-9,-3],[-10,6],[-11,-2],[16,-27],[-6,-5],[-17,0],[-14,6],[-30,6],[-10,14],[-8,3],[-6,8],[6,12],[-5,2],[-13,-3],[-22,-12],[-86,17],[-8,4],[-10,13],[2,14],[0,11],[17,16],[14,8],[18,4],[91,-2],[35,6],[17,6],[15,11],[31,7],[8,8],[22,8],[-1,5],[-5,1],[-18,-6],[-21,-4],[-25,-1],[-17,-3],[-16,-7],[-50,-9],[-70,7],[-5,8],[0,5],[14,24],[14,10],[11,3],[42,2],[34,-1],[20,2],[28,9],[51,-1],[32,4],[0,5],[-8,3],[-18,-3],[-23,2],[-51,-2],[-29,-5],[-35,-2],[-34,3],[-9,9],[4,6],[21,4],[14,8],[-15,20],[7,10],[7,3],[54,8],[8,4],[20,3],[82,-12],[21,2],[1,5],[-24,3],[-23,7],[-60,5],[-28,8],[-4,5],[15,12],[6,16],[17,8],[42,10],[18,-1],[14,3],[13,7],[16,3],[52,-12],[12,-8],[6,-13],[-4,-14],[25,-29],[12,-2],[16,5],[58,6],[37,-8],[26,-10],[12,-2],[7,-4],[12,-22],[29,-19],[31,-13],[4,-6],[-5,-5],[-43,-4],[3,-8],[18,-1],[21,-7],[19,4],[11,-1],[12,-5],[7,-21],[2,-21],[5,-9],[17,-11],[13,-1],[20,2],[19,7],[21,3],[51,-12],[31,-4]],[[3505,8154],[-1,-162]],[[3505,8239],[-2,0],[-4,3],[3,3],[3,0]],[[3505,8245],[0,-6]],[[3505,8330],[-12,3],[-11,7],[-20,6],[-12,17],[-3,12],[3,6],[12,7],[27,3],[12,6],[4,3]],[[3505,8400],[0,-70]],[[5524,4941],[-2,-8],[-4,1],[-2,5],[2,3],[6,-1]],[[5500,4904],[-5,-5],[-3,1],[-2,1],[-2,4],[0,3],[3,3],[3,0],[3,-1],[3,-6]],[[5479,4877],[-2,-5],[-2,-2],[-3,1],[-2,0],[-3,2],[0,4],[-1,6],[3,1],[3,1],[3,-2],[4,-6]],[[5425,4828],[-4,1],[-3,6],[-10,5],[1,7],[12,6],[7,0],[4,-7],[0,-11],[-7,-7]],[[6731,5403],[-5,3],[1,7],[5,5],[4,-1],[2,-4],[-1,-6],[-6,-4]],[[3740,6068],[-2,-4],[-6,-1],[-4,2],[-5,13],[2,3],[7,-2],[8,-11]],[[3752,6048],[-6,-1],[-5,1],[-2,2],[1,3],[2,3],[3,2],[2,2],[-3,14],[5,2],[4,-2],[-1,-3],[0,-5],[2,-4],[2,-5],[0,-6],[-4,-3]],[[7526,6441],[-4,-3],[-3,-2],[-4,-1],[-4,2],[-1,3],[2,5],[4,2],[7,-1],[3,-5]],[[7529,6421],[4,8],[6,-1],[11,-10],[13,-6],[2,-2],[-8,-22],[-1,-4],[-6,-6],[-3,-1],[-5,1],[-2,3],[1,6],[1,3],[1,9],[-10,8],[-7,10],[3,4]],[[7566,6355],[-4,1],[-2,2],[-5,5],[0,4],[1,4],[4,0],[3,-1],[3,-4],[3,-5],[-3,-6]],[[8844,5738],[5,0],[9,-4],[-1,-4],[-6,-1],[-9,2],[-1,3],[3,4]],[[8818,5731],[-5,-5],[-3,-1],[-4,3],[-1,3],[0,3],[2,4],[3,-1],[5,-1],[3,-5]],[[8827,6103],[-4,-3],[-4,2],[0,5],[2,3],[3,2],[3,1],[3,-1],[2,-2],[-5,-7]],[[8839,6097],[3,-11],[-6,-2],[-5,1],[-3,7],[5,6],[6,-1]],[[7505,7340],[-8,-2],[-5,0],[-2,2],[-1,2],[1,4],[3,4],[5,1],[5,-1],[3,-2],[2,-2],[-3,-6]],[[7488,7356],[-1,-4],[-2,-2],[-4,-3],[-5,-2],[-7,-4],[-7,-2],[-6,2],[1,4],[4,3],[7,4],[8,3],[6,3],[6,-2]],[[7693,7185],[-8,2],[-6,6],[6,15],[5,2],[10,-2],[12,3],[6,-1],[3,-5],[-7,-10],[-8,-6],[-13,-4]],[[7644,7188],[-6,6],[4,8],[14,15],[8,-1],[2,-6],[-9,-15],[-6,-6],[-7,-1]],[[7509,7222],[2,2],[4,2],[9,-2],[3,-2],[-4,-7],[-7,-2],[-7,1],[-3,4],[3,4]],[[7671,7131],[-11,4],[-8,12],[-1,25],[4,8],[8,4],[7,-1],[2,-3],[-2,-10],[3,-4],[14,5],[6,-8],[-2,-8],[-9,-4],[-4,-8],[1,-10],[-8,-2]],[[7906,7075],[-5,-5],[-7,-3],[-5,-2],[-3,1],[-3,4],[3,3],[2,2],[6,3],[12,4],[3,-1],[-3,-6]],[[7793,7006],[-9,8],[6,12],[9,8],[9,17],[5,4],[10,1],[29,-5],[20,2],[2,-7],[-6,-12],[-5,-3],[-30,-10],[-32,-15],[-8,0]],[[7558,8914],[-15,4],[-17,12],[9,8],[32,-4],[10,-7],[-7,-11],[-12,-2]],[[7159,8698],[-21,9],[5,9],[6,2],[21,-1],[5,-4],[-5,-12],[-11,-3]],[[6737,8605],[-6,0],[-5,0],[-6,4],[-4,3],[-1,3],[4,4],[9,1],[5,-4],[3,-2],[2,-4],[-1,-5]],[[7049,8493],[-7,0],[-6,2],[0,3],[1,7],[2,4],[3,3],[6,0],[7,-4],[1,-4],[-3,-8],[-4,-3]],[[6884,7428],[6,-8],[1,-7],[-8,-4],[-8,3],[-4,7],[2,8],[4,1],[7,0]],[[7017,7378],[-14,9],[2,5],[8,5],[21,-3],[4,-4],[-2,-5],[-10,-6],[-9,-1]],[[6958,7385],[-13,2],[-5,6],[2,5],[10,0],[8,-3],[3,-6],[-5,-4]],[[8614,9661],[-8,-1],[-8,-1],[-11,1],[-8,4],[-1,3],[15,3],[15,-2],[5,-4],[1,-3]],[[8442,9631],[-5,-3],[-12,-4],[-13,-2],[-13,0],[-11,2],[0,4],[12,3],[11,2],[23,0],[8,-2]],[[8371,9452],[2,-4],[-7,-4],[-10,-2],[-6,1],[-2,4],[7,5],[8,2],[8,-2]],[[7515,9983],[-8,1],[-4,3],[-6,4],[5,3],[10,1],[13,-2],[8,-2],[5,-4],[-7,-4],[-16,0]],[[7165,9953],[-7,-3],[-10,-1],[-14,2],[-4,2],[-8,3],[-3,3],[2,4],[5,4],[10,1],[15,-2],[7,-3],[7,-10]],[[8631,4543],[2,4],[4,2],[4,0],[2,-2],[-1,-3],[-2,-3],[-3,-2],[-3,-1],[-4,1],[1,4]],[[8642,4527],[-5,2],[0,3],[2,2],[2,1],[4,3],[6,-1],[-1,-3],[-2,-3],[-2,-2],[-2,-1],[-2,-1]],[[8619,4494],[1,9],[5,2],[25,-10],[17,-17],[6,-15],[-1,-2],[-28,12],[-3,8],[-5,3],[-14,5],[-3,5]],[[7588,5433],[-6,-12],[-4,1],[-3,2],[0,3],[3,5],[4,2],[6,-1]],[[7600,5434],[2,-10],[0,-8],[-4,-1],[-4,1],[-3,5],[1,4],[0,7],[3,3],[5,2],[0,-3]],[[7633,5409],[-2,-4],[-3,-2],[-3,0],[-2,1],[-3,3],[-2,3],[1,4],[3,1],[3,1],[4,-2],[4,-5]],[[8262,5187],[-3,1],[-5,5],[0,4],[3,5],[6,-3],[4,-7],[-1,-3],[-4,-2]],[[7653,5382],[-7,2],[-3,6],[1,3],[7,4],[5,-1],[2,-4],[-1,-8],[-4,-2]],[[8279,5153],[-5,3],[-4,5],[2,5],[3,2],[4,-2],[2,-7],[0,-4],[-2,-2]],[[8680,4987],[-4,2],[-1,4],[2,5],[5,3],[3,-4],[0,-3],[-2,-5],[-3,-2]],[[8355,5129],[-3,6],[4,3],[10,-2],[9,-3],[5,-3],[4,-6],[0,-6],[-3,-7],[-3,-1],[-3,2],[-6,4],[-8,6],[-6,7]],[[8241,5173],[1,9],[5,1],[9,-16],[5,-5],[1,-3],[-2,-4],[-4,1],[-15,17]],[[8234,5163],[-8,5],[-1,6],[4,7],[5,-3],[1,-3],[3,-5],[-1,-6],[-3,-1]],[[7386,5423],[-5,1],[-1,2],[1,5],[8,4],[8,-2],[0,-6],[-11,-4]],[[8417,5084],[-5,8],[1,3],[3,1],[5,-2],[6,-4],[2,-4],[-2,-5],[-4,-2],[-3,1],[-3,4]],[[8589,4990],[-4,4],[5,10],[3,1],[6,10],[6,0],[2,-5],[-7,-16],[-11,-4]],[[7831,5263],[-3,1],[-2,4],[1,4],[1,2],[3,0],[6,-3],[-2,-6],[-4,-2]],[[7845,5250],[-3,-1],[-4,2],[-3,1],[0,3],[2,3],[2,1],[4,-1],[2,-1],[2,-4],[-2,-3]],[[8663,4994],[2,-4],[-7,-10],[2,-9],[-5,-8],[-8,-2],[-28,-1],[-8,1],[-11,5],[-1,4],[2,5],[9,5],[5,16],[6,3],[17,0],[14,0],[11,-5]],[[7714,5289],[-4,-1],[-2,2],[-1,2],[0,3],[1,2],[4,2],[4,0],[1,-2],[-3,-8]],[[7759,5281],[-3,-1],[-4,-3],[-2,-2],[-3,-1],[-5,0],[-3,-2],[-2,-2],[-3,0],[-4,2],[-2,3],[1,3],[3,2],[5,1],[4,1],[4,3],[7,3],[6,-1],[1,-6]],[[7851,5231],[-4,1],[-2,3],[0,3],[4,4],[6,-2],[1,-2],[-2,-6],[-3,-1]],[[7714,5272],[-3,-2],[-2,0],[-3,1],[-1,5],[1,2],[3,1],[4,-1],[3,-2],[-2,-4]],[[7774,5256],[-3,-3],[-3,0],[-3,0],[-3,2],[1,3],[1,3],[4,1],[5,0],[3,-2],[-2,-4]],[[8494,4900],[3,4],[4,-4],[-4,-4],[-3,4]],[[7127,5328],[-6,2],[-1,6],[4,7],[8,6],[11,-1],[7,5],[15,-3],[8,-12],[-3,-9],[-7,-4],[-25,5],[-11,-2]],[[8497,4874],[-4,2],[-1,3],[3,4],[6,-2],[1,-2],[-5,-5]],[[7870,5108],[-3,1],[-5,1],[-4,3],[-3,3],[2,4],[3,0],[11,-3],[2,-4],[-3,-5]],[[7912,5095],[-4,-1],[-3,0],[-5,1],[-5,3],[1,2],[1,3],[5,0],[6,-1],[3,-2],[1,-5]],[[8590,4817],[-17,12],[-7,12],[6,15],[5,5],[5,-2],[16,-15],[15,-11],[6,-15],[-3,-6],[-3,-2],[-14,6],[-9,1]],[[7910,5051],[-4,-1],[-5,1],[-4,2],[-2,5],[3,1],[3,1],[7,-2],[3,-4],[-1,-3]],[[8523,4813],[-5,2],[-1,3],[7,10],[3,-9],[-4,-6]],[[8561,4798],[-5,-2],[-6,3],[-3,7],[3,1],[9,-4],[2,-5]],[[8027,4997],[-4,5],[1,3],[5,2],[4,-4],[-1,-4],[-5,-2]],[[8497,4813],[-6,3],[-3,7],[2,3],[3,1],[4,-4],[2,-6],[-2,-4]],[[7962,4997],[-12,7],[-10,19],[-2,10],[4,14],[-5,7],[-14,8],[-30,9],[-2,4],[2,6],[11,0],[61,-21],[18,-13],[14,-14],[8,-13],[-2,-13],[-28,-9],[-13,-1]],[[7275,5189],[-10,2],[-10,7],[-4,5],[-33,24],[-9,6],[-10,2],[-3,4],[3,10],[-9,8],[2,8],[8,3],[13,-3],[11,7],[5,0],[19,-19],[21,-8],[11,-16],[0,-6],[-2,-6],[5,-10],[-8,-18]],[[8610,4712],[-11,7],[-27,32],[-23,17],[-4,10],[2,4],[10,3],[25,14],[5,0],[33,-6],[3,-6],[1,-7],[4,-2],[7,3],[6,-4],[2,-4],[-3,-8],[-4,-2],[-11,-17],[-10,-32],[-5,-2]],[[7070,5213],[-7,5],[2,5],[6,2],[8,-3],[0,-6],[-9,-3]],[[7137,5126],[-12,4],[-25,27],[-26,22],[-6,9],[3,11],[5,4],[14,1],[16,10],[7,1],[26,-5],[11,-16],[5,-1],[9,3],[9,-2],[3,-4],[-2,-16],[3,-7],[-5,-21],[-25,-19],[-10,-1]],[[6682,5348],[32,20],[30,9],[10,-2],[19,-19],[8,-2],[5,4],[2,8],[-5,13],[1,4],[5,4],[7,-1],[10,-8],[16,-21],[8,-5],[13,-3],[4,-7],[-13,-7],[-1,-5],[2,-2],[15,-3],[13,2],[6,-3],[9,-8],[7,-9],[-1,-6],[-12,-6],[-23,1],[-14,-8],[-15,-21],[-22,-13],[-5,-7],[-2,-18],[-6,-5],[-7,1],[-16,16],[-16,9],[-18,6],[-14,3],[-30,18],[-20,2],[-23,-5],[-14,4],[-10,10],[0,13],[7,11],[12,11],[3,10],[-6,9],[-23,8],[-16,3],[-32,-9],[-10,3],[-7,12],[4,13],[10,11],[2,9],[-2,3],[-5,0],[-22,-12],[-15,3],[-10,-3],[-8,-6],[-6,-11],[-2,-12],[8,-28],[1,-9],[-3,-9],[-9,-8],[-18,-5],[-21,-21],[-12,-8],[-20,-4],[-6,-9],[-11,-39],[-9,-15],[-41,-35],[-27,-13],[-16,-11],[-10,-3],[-12,1],[-13,7],[-8,14],[-3,44],[3,22],[5,13],[2,30],[-7,10],[-11,3],[-2,2],[-47,-16],[-49,-4],[-37,-22],[-13,-1],[-11,6],[-4,6],[-2,12],[6,20],[7,16],[9,13],[20,19],[29,20],[21,17],[7,8],[1,10],[-9,37],[-4,45],[3,26],[22,59],[2,21],[-7,14],[1,9],[8,11],[0,4],[-3,6],[5,37],[0,21],[11,72],[25,43],[22,26],[5,-1],[7,-7],[9,-18],[17,1],[4,-6],[4,-9],[1,-10],[14,-30],[-3,-6],[-13,-8],[-2,-5],[6,-9],[8,-3],[13,-15],[8,-24],[-1,-15],[5,-6],[5,-3],[6,4],[23,52],[10,9],[6,0],[5,-11],[12,-14],[9,-3],[7,-7],[1,-22],[12,-15],[18,-3],[8,-6],[33,0],[11,-3],[8,-13],[2,-10],[11,-14],[74,-50],[30,0],[40,-34],[19,-26],[3,-12],[-2,-29],[2,-15],[14,-13],[2,-9],[-1,-6],[-5,-6],[-31,-23],[-2,-10],[6,-7]],[[5597,5274],[-5,2],[-2,3],[0,3],[2,3],[6,-1],[3,-4],[0,-5],[-4,-1]],[[5620,5250],[-6,1],[-4,2],[-5,1],[-5,2],[-3,4],[1,4],[3,3],[12,-2],[7,-8],[0,-7]],[[5698,5246],[-4,-1],[-5,0],[-8,0],[-5,1],[-3,-2],[-5,0],[-4,2],[-1,3],[-2,3],[1,3],[3,1],[5,0],[2,-1],[3,-1],[5,0],[5,1],[4,1],[8,0],[2,-3],[-1,-7]],[[5637,5243],[-3,-1],[-3,1],[-2,2],[-2,3],[4,5],[2,-1],[4,-3],[0,-6]],[[5713,5234],[-2,-1],[-3,1],[-2,2],[-2,2],[0,2],[1,4],[1,2],[3,0],[2,-2],[3,-3],[-1,-7]],[[5660,5231],[-4,-1],[-3,1],[-1,3],[-3,3],[1,3],[2,2],[3,0],[5,-4],[0,-7]],[[5690,5225],[-2,-2],[-3,0],[-3,3],[-2,4],[3,5],[4,-1],[4,-3],[-1,-6]],[[6600,5129],[2,-2],[-1,-7],[-4,-3],[-8,1],[-1,6],[8,6],[4,-1]],[[5554,5061],[-3,-4],[-3,1],[-3,2],[-1,7],[1,3],[4,0],[3,-2],[2,-4],[0,-3]],[[6482,4903],[-4,2],[-6,7],[3,22],[0,10],[-3,10],[-18,19],[2,13],[23,27],[8,14],[13,42],[23,32],[6,4],[7,-1],[5,-18],[6,-5],[7,-2],[13,4],[14,19],[5,3],[12,-2],[12,-5],[10,0],[5,3],[4,6],[14,8],[40,-5],[6,-11],[-2,-7],[-9,-15],[-1,-7],[2,-10],[-2,-9],[-5,-9],[-13,-15],[-34,-32],[-33,-45],[-15,-10],[-23,-24],[-8,-4],[-4,1],[-4,4],[-1,9],[-4,7],[-5,3],[-16,1],[-14,-11],[-10,-19],[-6,-4]],[[6940,3856],[-3,-6],[-2,1],[-2,3],[-2,3],[3,4],[3,-2],[3,-3]],[[6927,3783],[1,-3],[0,-3],[-1,-3],[0,-6],[1,-3],[-1,-3],[-1,-3],[-3,0],[-2,2],[-2,3],[-2,2],[-2,6],[1,2],[2,3],[1,4],[2,2],[6,0]],[[6914,3752],[2,-2],[1,-3],[0,-3],[-1,-3],[-2,-1],[-2,0],[-1,3],[-2,3],[1,4],[4,2]],[[6943,3613],[-3,-5],[-3,1],[-2,3],[-2,7],[0,6],[1,3],[3,1],[2,-2],[4,-14]],[[7090,3567],[-2,-3],[-2,-3],[-3,-2],[-3,0],[-1,1],[0,3],[3,4],[3,2],[3,-1],[2,-1]],[[6910,3628],[1,4],[2,2],[4,-1],[8,-10],[2,-5],[3,-10],[0,-9],[-2,-2],[-2,-1],[-2,2],[-2,3],[0,2],[0,10],[-2,3],[-8,5],[-2,3],[0,4]],[[7122,3540],[-3,-3],[-3,1],[-1,3],[-1,3],[2,3],[2,2],[3,-2],[2,-3],[-1,-4]],[[7044,3559],[-2,-3],[-3,-2],[-3,-2],[-4,1],[-4,3],[2,5],[7,4],[7,-2],[0,-4]],[[6909,3580],[-4,4],[0,4],[3,15],[4,-1],[3,-9],[-2,-9],[-4,-4]],[[6997,3564],[1,-6],[-2,-2],[-2,-2],[-4,1],[-3,1],[-2,3],[-1,3],[1,5],[4,0],[8,-3]],[[6947,3551],[-3,3],[3,16],[-3,16],[3,5],[3,-1],[4,-9],[1,-16],[-1,-8],[-7,-6]],[[7124,3467],[-4,-3],[-2,0],[-2,2],[-1,1],[0,3],[4,3],[2,0],[3,-6]],[[6944,3462],[-2,-2],[-3,1],[0,6],[0,6],[2,9],[2,9],[3,3],[3,0],[2,-3],[-1,-5],[-2,-4],[-4,-20]],[[7028,3431],[-6,5],[1,8],[9,17],[4,31],[5,16],[4,5],[3,-1],[4,-7],[-6,-32],[2,-24],[-2,-9],[-13,-5],[-5,-4]],[[6892,3456],[3,11],[6,6],[3,0],[3,1],[3,2],[2,3],[7,9],[6,0],[5,3],[13,35],[2,2],[4,-3],[-2,-8],[-2,-2],[-5,-17],[0,-2],[-2,-4],[-2,-10],[-8,-13],[-23,-24],[-4,-6],[-8,-1],[-2,1],[-3,5],[4,12]],[[7003,3375],[4,15],[1,8],[3,5],[2,11],[3,1],[2,-4],[-5,-24],[-3,-8],[-1,-7],[-1,-7],[-1,-9],[-2,-3],[-2,-1],[-2,2],[-1,3],[0,3],[1,4],[2,11]],[[7003,3435],[-6,-19],[-2,-3],[-3,-15],[-5,-13],[-5,-5],[-3,3],[1,11],[9,20],[4,18],[1,6],[0,4],[-3,3],[-3,-2],[-3,-9],[-2,-15],[-4,-13],[-3,-9],[-3,-6],[-3,-7],[-2,-9],[-4,-5],[-5,-4],[-5,-1],[-7,2],[-6,0],[-9,-10],[-5,-5],[-4,-2],[-1,3],[2,8],[14,24],[11,24],[1,9],[-3,3],[-9,-9],[-17,-26],[-9,-22],[-4,-2],[-4,10],[-7,6],[2,8],[9,11],[15,35],[4,4],[3,8],[17,11],[8,15],[3,31],[-1,15],[3,14],[4,-1],[3,-9],[-7,-56],[-1,-4],[-3,-6],[-3,-3],[-4,-5],[-2,-3],[-1,-5],[2,-3],[4,1],[4,5],[2,7],[1,1],[5,3],[2,6],[3,13],[2,6],[2,5],[2,13],[5,29],[0,19],[3,4],[4,0],[2,-13],[10,-8],[5,-14],[16,-8],[4,-5],[2,-8],[-5,-34],[-2,-5],[-1,-3],[-3,-7],[-1,-8],[-3,-14],[-3,-10],[-3,-8],[-2,-8],[-2,-9],[-3,-14],[-3,-2],[-2,0],[-2,5],[3,12],[4,14],[2,12],[6,14],[3,14],[3,13],[5,31],[-2,4],[-4,0],[-6,-48],[-2,-5]],[[6993,3340],[4,-3],[-1,-7],[-3,-4],[-2,-2],[-3,0],[-1,3],[2,7],[1,3],[3,3]],[[6977,3356],[1,2],[5,-2],[1,-5],[-1,-3],[-3,-4],[0,-5],[1,-4],[1,-6],[-1,-5],[-2,-1],[-4,2],[0,6],[-1,6],[-2,7],[1,7],[4,5]],[[8306,5910],[0,-5],[-2,-2],[-1,-2],[-4,1],[-3,3],[1,4],[2,3],[5,-1],[2,-1]],[[8729,6206],[-4,1],[-4,15],[4,11],[6,3],[13,-6],[2,-18],[-2,-4],[-15,-2]],[[8740,6197],[1,-3],[0,-4],[-2,-2],[-4,-1],[-3,1],[-2,3],[-1,4],[3,3],[3,0],[5,-1]],[[8740,6160],[-4,-3],[-4,2],[-2,3],[0,4],[3,4],[1,3],[3,4],[3,0],[2,-4],[-1,-4],[2,-3],[-3,-6]],[[8751,6148],[-5,6],[6,9],[6,3],[9,-6],[12,5],[9,-2],[2,-3],[-3,-5],[-9,-3],[-27,-4]],[[7443,9983],[38,-3],[51,-14],[39,-22],[7,-14],[16,-10],[101,-20],[62,-27],[17,-2],[15,8],[-6,4],[-122,38],[-34,15],[-19,18],[10,7],[30,7],[33,20],[21,3],[23,-2],[54,2],[27,-3],[0,-15],[13,-8],[56,-12],[27,-10],[15,-1],[16,2],[3,5],[-65,33],[15,10],[58,6],[41,1],[40,-3],[23,-5],[18,-20],[15,-2],[33,2],[26,-3],[21,-9],[22,0],[33,12],[40,-9],[13,-1],[32,6],[33,-4],[14,-4],[49,2],[25,-3],[10,-9],[-16,-11],[-34,-12],[-72,-15],[-22,-8],[-76,-13],[-2,-6],[19,-1],[112,14],[90,18],[76,22],[23,-4],[19,-13],[18,0],[-12,24],[15,7],[34,4],[28,-7],[7,-20],[14,-9],[28,3],[34,17],[17,1],[19,-4],[4,-8],[-25,-16],[15,-10],[46,-15],[17,-17],[-9,-17],[-14,-7],[3,-5],[23,1],[40,23],[16,2],[66,-10],[46,-3],[47,-9],[10,-5],[5,-15],[-19,-26],[-21,-10],[-31,-9],[-59,-11],[-12,-10],[7,-13],[-20,-10],[-109,-36],[-84,-22],[-21,-13],[-15,-1],[-18,2],[-15,17],[-9,1],[-28,-7],[-60,-6],[-2,-6],[23,-5],[2,-3],[-7,-4],[-71,-4],[-93,-6],[-106,-11],[-31,-1],[-48,5],[-50,9],[-9,-2],[-5,-3],[7,-6],[7,-2],[24,-4],[6,-6],[-12,-9],[3,-3],[30,-2],[143,10],[40,-3],[7,-8],[-27,-15],[-104,-19],[-45,-12],[-50,-13],[-127,-28],[-14,-5],[25,-16],[15,4],[56,27],[103,24],[172,30],[191,36],[46,5],[16,-4],[5,-6],[-31,-18],[-166,-59],[-25,-12],[-52,-36],[-79,-24],[-29,-24],[-78,-34],[-49,-28],[-27,-31],[-1,-11],[-10,-8],[-10,-4],[-26,0],[-22,5],[-3,12],[-27,26],[-11,8],[-21,1],[-6,-5],[39,-30],[-1,-21],[8,-4],[40,-6],[4,-5],[1,-5],[-9,-7],[-19,-9],[-25,-5],[-53,2],[-28,-3],[-53,-15],[-25,6],[-31,21],[-16,2],[-8,-1],[-3,-6],[23,-17],[-19,-13],[11,-4],[38,5],[22,-3],[17,2],[91,12],[25,-2],[6,-6],[-7,-6],[-18,-5],[-16,-9],[-45,-3],[-15,-8],[-33,-11],[-7,-7],[8,-4],[29,-1],[27,9],[11,-4],[-6,-6],[-54,-12],[-30,-17],[-34,-14],[-35,-5],[-30,-1],[-32,3],[-14,4],[-14,10],[1,7],[-9,9],[-16,2],[-47,-3],[-29,3],[-18,7],[-19,2],[-19,-1],[-28,4],[-7,-5],[13,-5],[53,-6],[13,-5],[77,-9],[13,-12],[3,-22],[-6,-7],[-27,-10],[-20,-4],[-20,8],[-21,1],[-10,-11],[10,-8],[-4,-5],[-7,-1],[-27,-2],[-15,2],[-42,11],[-18,2],[-7,-2],[-6,-7],[21,-15],[-3,-5],[-19,-2],[-63,13],[-38,16],[-21,2],[-26,-1],[-50,5],[-6,-4],[8,-4],[76,-8],[7,-13],[19,-4],[10,-6],[-9,-8],[-67,4],[-32,4],[-21,14],[-13,2],[-10,-10],[6,-4],[-5,-7],[-7,-2],[-16,1],[-35,5],[-14,-1],[-6,-5],[8,-4],[43,-5],[4,-2],[-4,-7],[5,-4],[19,-1],[32,8],[44,2],[66,-7],[50,4],[21,-2],[21,-8],[15,-2],[36,4],[13,-1],[3,-3],[-22,-22],[17,-19],[-21,-2],[-85,10],[-50,23],[-54,6],[-93,-5],[-56,2],[-12,-2],[-6,-4],[4,-3],[30,-3],[99,1],[53,-6],[11,-3],[4,-6],[-3,-4],[-13,-2],[-43,-1],[-86,-7],[-61,9],[-66,2],[-9,-2],[-3,-4],[11,-5],[42,0],[45,-5],[12,-7],[2,-10],[-28,-42],[4,-3],[14,2],[10,7],[21,28],[15,11],[31,6],[41,2],[55,6],[56,-5],[11,-4],[-11,-7],[-49,-13],[-6,-8],[15,-1],[42,10],[52,5],[24,-3],[18,-8],[14,-3],[10,-9],[-6,-35],[9,-16],[-6,-8],[-21,-3],[-27,2],[-25,-2],[-18,-7],[-15,-2],[-68,6],[-20,-3],[-4,-6],[12,-5],[71,-6],[25,-4],[30,-8],[15,-9],[-2,-10],[-29,-12],[-15,-14],[-16,-4],[-12,1],[-43,7],[-36,3],[-21,-6],[-12,-14],[13,-6],[28,-4],[30,0],[36,5],[23,-3],[3,-3],[-5,-8],[-21,-8],[-10,-12],[-6,-2],[-17,1],[-6,3],[-23,3],[-10,-1],[-19,-6],[-10,-15],[-21,-3],[-67,0],[-76,8],[-23,-6],[-6,-11],[8,-7],[24,-5],[9,-6],[6,-16],[-6,-18],[23,-18],[-25,-33],[-31,-12],[-23,-22],[-20,-7],[-22,-1],[-6,5],[2,5],[-7,3],[-12,-5],[-9,-8],[-11,-4],[-10,-1],[-31,3],[-23,-4],[-13,1],[-5,3],[-59,3],[-62,11],[-19,11],[-5,9],[3,6],[-6,8],[-14,7],[-17,3],[-14,11],[2,3],[-13,15],[-14,1],[-2,-5],[20,-25],[-4,-16],[3,-15],[19,-11],[30,-3],[9,-6],[-5,-12],[-11,-5],[-19,-2],[-60,6],[-5,-3],[-2,-5],[21,-10],[5,-5],[-3,-12],[-10,-9],[-1,-9],[3,-2],[15,4],[41,28],[31,14],[18,4],[36,-2],[46,-13],[7,-6],[-17,-18],[7,-3],[19,5],[20,15],[6,8],[9,4],[20,-2],[21,6],[19,-2],[12,-5],[25,-24],[-5,-9],[-18,-15],[-4,-6],[7,-5],[30,-3],[7,-10],[-3,-4],[7,-6],[10,-2],[16,5],[23,24],[24,14],[8,3],[26,-3],[12,-6],[9,-51],[-16,-30],[-22,-9],[-7,-18],[-16,-6],[-10,-10],[-10,-3],[-14,4],[-4,9],[3,6],[-4,4],[-11,1],[-9,-6],[-10,-25],[-31,-14],[-7,-16],[-6,-4],[-22,-4],[-19,0],[-21,-9],[-19,0],[-19,-7],[-7,3],[-17,0],[-19,-11],[-15,-5],[-13,0],[-30,-13],[-6,2],[7,14],[-14,7],[26,32],[6,14],[-2,7],[-21,12],[-16,15],[-13,0],[-8,-15],[-11,-6],[-47,6],[-4,2],[6,16],[-10,8],[-34,15],[-29,22],[-7,17],[-9,5],[-5,-8],[4,-19],[27,-22],[30,-13],[-3,-16],[5,-20],[-1,-5],[-5,-2],[-24,0],[-25,-9],[-14,3],[-16,8],[-17,41],[-25,22],[-6,13],[2,7],[-8,2],[-5,-2],[-6,-18],[25,-18],[4,-17],[13,-13],[1,-12],[-10,-5],[-10,-2],[-14,2],[-22,5],[-11,12],[-20,12],[-8,17],[-16,11],[-8,1],[-9,-23],[11,-18],[-1,-5],[-10,-6],[-20,-7],[-20,4],[-14,10],[1,10],[-9,9],[-11,0],[-5,-21],[5,-13],[10,-8],[43,-13],[6,-4],[-2,-4],[-11,-3],[-100,4],[-30,10],[-55,6],[-27,6],[-5,4],[1,7],[18,9],[1,8],[-14,22],[-7,5],[-13,1],[-7,-4],[-1,-4],[20,-14],[-2,-10],[-25,-16],[-1,-25],[-9,-2],[-34,19],[-1,6],[-19,11],[-4,23],[-12,14],[-11,-1],[-1,-4],[10,-13],[-5,-18],[5,-7],[15,-10],[-1,-4],[-27,-8],[-10,2],[-4,4],[-10,0],[-14,-6],[-20,8],[-20,3],[-4,3],[5,20],[-1,16],[-22,26],[5,27],[-9,0],[-10,-8],[-5,-19],[24,-24],[2,-12],[-3,-20],[-5,-6],[-11,-3],[-14,4],[3,22],[-3,8],[-8,2],[-5,-2],[-1,-10],[1,-21],[-7,-3],[-8,0],[-22,9],[-14,9],[-3,7],[-22,11],[3,13],[13,15],[1,22],[-11,17],[7,15],[16,8],[46,11],[55,27],[40,11],[58,0],[18,2],[18,9],[15,-1],[19,-5],[14,2],[1,5],[-6,4],[-15,1],[-13,5],[2,7],[14,4],[1,3],[-6,3],[-13,0],[-9,4],[2,6],[26,8],[-3,4],[-21,1],[-38,-9],[-22,3],[-8,6],[8,36],[-25,13],[1,5],[-21,12],[3,15],[-19,25],[3,12],[5,2],[23,-1],[17,3],[43,14],[57,-2],[20,-5],[71,-29],[16,-10],[-3,-26],[11,-38],[6,-4],[18,1],[16,-10],[43,-2],[42,-11],[7,0],[8,3],[9,7],[35,-4],[20,3],[45,-3],[15,-3],[10,3],[1,3],[-32,14],[2,7],[33,13],[24,27],[42,31],[33,46],[7,17],[18,7],[1,8],[-19,1],[-16,-2],[-7,-24],[-19,-23],[-17,-13],[-26,-31],[-63,-45],[-15,-4],[-40,5],[-45,-1],[-6,3],[-4,3],[6,10],[23,14],[4,6],[6,23],[-4,3],[-12,0],[0,-16],[-18,-3],[-8,-11],[-8,-3],[-14,-1],[-25,4],[-14,7],[4,14],[37,15],[2,3],[-4,3],[-14,0],[-13,-3],[-14,0],[-7,3],[3,8],[8,4],[82,4],[8,2],[1,3],[-13,4],[-44,3],[-28,-6],[-22,2],[-10,6],[2,6],[12,8],[25,11],[22,0],[13,-3],[13,2],[24,0],[18,4],[5,6],[-4,3],[-55,3],[-8,3],[2,8],[17,6],[13,2],[52,-3],[6,2],[1,4],[-10,4],[-41,4],[-25,-2],[-4,2],[2,6],[13,10],[5,14],[-7,9],[5,14],[13,16],[8,23],[-4,2],[-10,1],[-13,-8],[-12,-21],[-26,-71],[-36,-13],[-11,-13],[-16,-4],[-40,-3],[-14,0],[-16,4],[4,15],[42,28],[14,12],[3,11],[-9,3],[-8,-3],[-15,-18],[-31,-23],[-75,-28],[-44,-1],[-9,4],[3,12],[11,6],[23,4],[1,5],[-12,1],[-17,-1],[-9,3],[-3,17],[3,16],[17,30],[32,17],[7,7],[18,41],[4,3],[28,10],[62,11],[71,19],[28,-2],[55,-12],[116,-8],[37,-17],[60,-16],[18,-17],[20,-7],[12,-1],[5,5],[-16,16],[3,7],[24,1],[5,6],[-4,2],[-20,2],[-23,-4],[-50,14],[-14,9],[3,7],[14,2],[28,0],[28,5],[66,-5],[9,2],[8,7],[-14,14],[14,29],[-11,-1],[-28,-15],[-15,-15],[-32,-6],[-12,1],[-19,6],[-45,3],[-53,-13],[-33,1],[-48,12],[-39,15],[7,17],[15,5],[27,-3],[56,-25],[36,-2],[8,5],[-58,19],[-17,18],[-14,-1],[-17,9],[-13,23],[-36,34],[-11,6],[-23,5],[-16,9],[-27,25],[-27,15],[-63,13],[-25,10],[-12,25],[7,12],[13,4],[40,1],[41,-4],[8,-3],[25,-1],[8,6],[-13,5],[-68,9],[-42,10],[-19,13],[-16,40],[4,13],[22,11],[35,-1],[73,-17],[53,-7],[38,-2],[52,4],[23,-1],[56,-36],[35,-12],[40,-20],[46,-16],[16,-10],[6,-15],[-4,-13],[40,-16],[-6,-18],[11,-5],[19,4],[9,6],[12,3],[27,-2],[28,-10],[26,-5],[15,3],[25,9],[32,2],[23,10],[-7,3],[-28,1],[-76,-6],[-27,3],[-16,6],[-35,19],[-12,15],[3,17],[15,5],[2,5],[-6,4],[-44,5],[-9,4],[-50,28],[-16,14],[-21,6],[-32,18],[3,6],[48,13],[77,9],[105,20],[49,6],[77,5],[102,-3],[102,13],[16,5],[4,4],[-17,3],[-61,-7],[-98,-3],[-19,4],[4,5],[171,45],[98,16],[75,4],[19,3],[8,8],[-113,0],[-32,0],[-54,-4],[-62,-10],[-31,2],[-10,4],[25,29],[91,60],[68,25],[61,15],[18,12],[-4,4],[-12,1],[-137,-35],[-44,-21],[-33,-26],[-25,-2],[-14,3],[-12,11],[-17,-2],[-5,-5],[17,-13],[0,-9],[1,-4],[-5,-6],[-14,-6],[-15,-25],[-36,-20],[-185,-44],[-78,-19],[-82,-10],[-18,0],[-24,6],[5,10],[9,5],[92,29],[25,11],[21,15],[-15,2],[-53,-23],[-37,-11],[-37,-6],[-25,6],[5,11],[18,10],[5,11],[-4,4],[-12,0],[-7,-2],[-33,-22],[-6,-12],[8,-15],[-8,-16],[-33,-14],[-33,-4],[-118,-3],[-48,1],[-14,4],[4,19],[-21,1],[-34,-12],[-33,1],[-31,8],[9,27],[43,28],[28,24],[31,17],[18,5],[44,7],[55,2],[84,8],[55,1],[68,7],[47,15],[3,5],[-11,3],[-33,-11],[-39,-7],[-251,-15],[-61,-8],[-14,-5],[-24,-14],[-49,-42],[-31,-20],[-29,-15],[-33,-9],[-18,1],[-17,4],[-49,21],[-67,15],[-48,23],[9,14],[34,12],[43,6],[57,3],[110,-3],[43,7],[63,14],[49,29],[67,18],[-1,7],[-20,0],[-68,-16],[-33,-18],[-22,-7],[-17,-3],[-32,-1],[-81,-13],[-20,-2],[-40,3],[-35,0],[-50,-12],[-65,-6],[-25,0],[-43,8],[-26,11],[4,24],[14,12],[71,-4],[36,3],[20,5],[1,4],[-9,4],[-32,1],[-28,7],[-1,11],[64,20],[46,18],[26,5],[20,1],[43,-2],[39,-2],[26,2],[7,4],[-5,5],[-35,2],[-35,2],[-24,1],[-20,1],[-26,0],[-25,-2],[-37,-7],[-76,-26],[-27,-6],[-27,-2],[-20,1],[-19,5],[2,10],[32,13],[45,8],[32,10],[2,10],[-6,2],[-47,0],[-20,6],[-5,6],[-21,0],[-8,-6],[0,-26],[-18,-6],[-27,0],[-23,3],[-16,6],[-5,11],[-20,2],[-10,2],[-2,14],[61,23],[91,28],[25,5],[43,2],[16,-5],[12,-10],[17,-1],[8,3],[9,22],[18,2],[15,-9],[19,3],[-8,25],[13,9],[32,10],[88,4],[28,-2],[12,-7],[-2,-16],[35,-21],[14,2],[2,4],[-20,13],[5,13],[5,3],[19,3],[28,-2],[33,-7],[46,-25],[21,-8],[22,1],[3,7],[-17,10],[4,7],[11,2],[31,-3],[45,-25],[18,0],[-2,18],[-35,16],[-61,8],[-34,13],[-97,10],[-36,10],[2,5],[13,5],[105,5],[29,6],[13,18],[-29,27],[7,7],[21,4],[53,-2],[42,-14],[-3,-12],[24,-12],[69,-16],[41,-6],[9,-4],[-1,-20],[16,-21],[1,-11],[16,-10],[24,-1],[23,2],[49,-2],[16,2],[6,8],[-6,3],[-56,3],[-20,9],[-27,27],[4,7],[9,1],[25,-1],[53,-15],[66,-31],[85,-14],[106,-26],[31,-2],[9,6],[-12,8],[-64,15],[-82,12],[-68,33],[-44,11],[-61,26],[-5,10],[17,19],[25,4],[35,-1],[18,4],[5,7],[-16,6],[-24,3],[-15,7],[-5,4],[7,9],[22,4],[27,-2],[23,-5],[41,-18],[24,-4],[14,3],[6,22],[-69,28],[-13,14],[6,8],[14,2],[16,0],[22,-7],[47,-3],[8,-4],[17,-27],[35,-6],[20,-8],[24,-1],[4,5],[-8,5],[9,6],[28,-4],[24,-9],[33,-3],[48,5],[4,3],[-8,4],[-73,8],[-38,7],[-29,12],[-8,9],[-17,4],[-17,8],[4,4],[29,6],[84,6],[30,-3],[17,-12],[38,-3],[12,-4],[23,-2],[29,4],[9,1],[19,-1],[37,-11],[22,-3],[15,-8],[11,-17],[17,-10],[33,-6],[15,-8],[0,-15],[5,-3],[21,-2],[21,5],[18,19],[-7,4],[-45,10],[-13,11],[8,10],[-10,6],[-30,6],[-19,16],[-50,18],[-15,9],[12,11],[59,8],[33,-2],[58,-8],[45,2]],[[7670,4948],[-1,3],[1,4],[3,0],[4,-1],[1,-5],[-2,-2],[-3,0],[-3,1]],[[7681,4939],[3,1],[3,0],[2,-2],[1,-3],[1,-2],[-5,-2],[-4,2],[-2,3],[1,3]],[[7059,3757],[0,5],[1,3],[5,-1],[2,-7],[-3,-3],[-3,1],[-2,2]],[[7062,3720],[0,3],[1,3],[0,3],[2,3],[5,-2],[1,-2],[-1,-3],[-1,-2],[-3,-3],[-4,0]],[[7071,3712],[3,2],[4,2],[3,2],[4,0],[2,-1],[0,-6],[-4,-3],[-6,-3],[-4,-1],[-2,1],[-2,2],[2,5]],[[7078,3685],[4,2],[3,1],[4,-1],[1,-1],[0,-5],[-12,-6],[-3,0],[0,3],[0,4],[3,3]],[[7031,3651],[4,0],[2,-3],[-1,-6],[-4,1],[-2,4],[1,4]],[[7183,3507],[2,-4],[-1,-8],[-5,-4],[-3,3],[4,14],[3,-1]],[[7148,3487],[1,4],[1,3],[5,2],[1,-4],[0,-3],[-2,-4],[-4,-2],[-2,2],[0,2]],[[7137,3469],[-4,0],[-4,2],[-1,3],[2,3],[3,2],[2,1],[4,0],[3,0],[2,-3],[0,-4],[-1,-2],[-2,-2],[-4,0]],[[3505,8773],[13,0],[9,-3],[7,-3],[4,-6],[-7,-8],[-26,-10]],[[3505,8917],[14,-8],[15,-14],[28,-12],[10,-8],[12,-19],[-2,-13],[-7,-13],[-15,-12],[-14,-1],[-21,5],[-20,-4]],[[3504,7417],[7,-3],[7,4],[-4,8],[-8,7],[-2,1]],[[3504,7457],[2,0],[4,3],[-2,6],[-4,1]],[[3504,7530],[14,-6],[16,-1],[4,-22],[19,-11],[10,-16],[11,-1],[4,3],[10,2],[6,-3],[5,-17],[7,-9],[-8,-14],[2,-6],[9,0],[11,7],[14,1],[3,-2],[12,-30],[-4,-5],[3,-29],[13,-30],[11,-11],[3,-8],[0,-23],[5,-15],[16,-12],[4,-8],[-7,-27],[8,-22],[19,-8],[5,-4],[3,-10],[9,-7],[11,-2],[3,4],[-7,11],[0,10],[20,2],[10,10],[19,4],[7,7],[-10,18],[6,12],[-20,12],[-9,10],[-24,72],[2,22],[-6,18],[-7,4],[-2,5],[1,31],[-12,30],[-14,19],[-13,33],[-1,11],[8,13],[1,9],[-4,26],[4,7],[13,2],[8,-2],[10,1],[3,3],[-1,3],[-23,9],[-3,5],[5,5],[11,10],[17,3],[16,-5],[46,-25],[20,-19],[10,-2],[8,3],[-10,8],[-3,16],[11,11],[10,2],[7,-5],[6,-12],[31,-13],[21,-23],[28,-12],[11,-12],[16,-12],[43,-24],[4,-2],[1,-5],[-10,-4],[1,-4],[11,-4],[2,-4],[-10,-13],[-1,-8],[12,-45],[9,-22],[4,-5],[4,-11],[4,-3],[15,-52],[5,-6],[5,-17],[11,-15],[6,-23],[39,-45],[9,-34],[0,-11],[10,-29],[-3,-4],[-17,-2],[-3,-3],[-1,-6],[4,-17],[-1,-9],[-4,-19],[-7,-8],[7,-15],[28,-19],[18,-15],[13,-15],[4,-10],[22,-10],[24,-25],[20,-6],[7,-3],[9,-10],[10,-4],[12,0],[5,4],[-5,10],[-9,5],[-3,19],[9,1],[6,-11],[11,-8],[7,-17],[33,-16],[37,-25],[8,-10],[15,-6],[28,4],[7,-3],[5,-10],[-3,-4],[1,-20],[9,-10],[6,0],[14,18],[13,-1],[9,3],[3,5],[9,1],[7,-7],[5,-24],[8,-18],[7,-59],[-10,-11],[-1,-8],[-5,-4],[-13,7],[-5,-1],[-7,-7],[-8,2],[-12,19],[-3,19],[6,15],[-3,8],[-6,0],[-2,-3],[-11,-44],[-5,-10],[-6,-5],[-8,2],[-1,8],[-4,5],[-22,17],[-3,12],[-13,6],[-1,6],[-5,4],[-6,-2],[1,-8],[-7,-5],[2,-15],[-3,-3],[-16,2],[-6,-7],[-6,-1],[-7,4],[-8,-1],[-4,-4],[1,-4],[18,-12],[3,-13],[3,-2],[2,-10],[-8,-5],[-11,1],[-25,-3],[-9,3],[-42,30],[-13,5],[-7,-1],[4,-14],[6,-8],[20,-12],[6,-20],[6,-2],[5,9],[4,0],[4,-2],[1,-4],[-4,-18],[7,-25],[-20,-30],[-3,-8],[2,-10],[5,-2],[10,10],[11,20],[3,13],[18,28],[13,1],[12,5],[14,16],[16,2],[13,-2],[9,-3],[8,-7],[1,-14],[-6,-16],[3,-14],[-4,-3],[-13,0],[1,-13],[11,-3],[10,8],[9,1],[6,-6],[3,-15],[-3,-16],[5,-19],[-4,-4],[-14,-4],[-12,4],[-7,-1],[-9,-9],[-22,0],[-5,-4],[2,-9],[-3,-5],[-9,-3],[-22,0],[-8,-9],[-12,-5],[-18,-1],[-12,6],[-7,0],[-4,-4],[1,-4],[-4,-6],[-6,0],[-9,4],[-5,7],[-7,4],[-23,-3],[-19,5],[-24,-2],[-20,6],[-12,9],[-5,-1],[-11,-10],[-16,-5],[-11,2],[-18,7],[-14,-1],[-9,3],[-6,3],[-2,8],[3,5],[17,11],[5,13],[-4,5],[-7,-1],[-6,-9],[-7,-2],[-11,9],[-20,2],[-18,12],[-14,6],[-49,-6],[-15,6],[-5,13],[11,30],[-6,15],[-8,5],[-4,8],[-6,5],[-9,0],[-15,-6],[-33,-27],[1,-21],[-4,-7],[-20,-28],[-6,-16],[-15,-14],[-15,-4],[-33,-5],[-44,-2],[-18,4],[-15,-4],[2,-5],[-5,-8],[-13,-5],[-11,-11],[-14,-9],[-48,-17],[-36,-16],[-29,-6],[-12,0],[-17,4],[-35,-6],[-9,0],[-13,6],[-18,-7],[-3,-1],[-11,-5],[-9,-2],[-3,2],[-1,4],[4,2],[7,3],[3,5],[-4,6],[-8,-2],[-7,-5],[-31,-3],[-1,-6],[15,-5],[1,-4],[-7,-4],[-30,6],[-19,2],[-60,-10],[-22,2],[-13,-3],[-13,-7],[-16,-5],[-18,3],[-20,-5],[-16,0],[-3,2],[-1,4],[25,6],[4,5],[-1,3],[-19,5],[-18,10],[-8,20],[-17,14],[-6,16],[7,12],[-1,5],[4,6],[-7,18],[-1,18],[-11,23],[18,4],[-1,5],[-4,3],[-17,8],[-32,3],[-13,6],[-16,3],[-55,-9],[-22,4],[-47,0],[-47,7],[-64,28],[-15,11],[-5,9],[0,11]],[[5299,7487],[2,-3],[13,-7],[27,-3],[15,-5],[11,-9],[1,-16],[16,-10],[3,-6],[0,-15],[-18,-12],[-23,-23],[-3,-10],[-17,-17],[-12,-29],[0,-16],[-11,-4],[-17,-3],[-8,4],[-16,14],[-22,0],[-17,-6],[-34,-7],[-18,-7],[-6,0],[-4,2],[-1,32],[7,8],[-3,11],[-6,21],[8,27],[0,11],[-15,27],[-1,17],[-21,16],[-1,10],[-4,6],[0,17],[-2,54],[1,11],[6,8],[-2,42],[5,28],[-7,51],[6,18],[10,5],[15,0],[12,-4],[35,-19],[29,-6],[9,1],[0,5],[-10,5],[-45,19],[3,13],[-22,11],[-2,3],[-1,17],[7,10],[8,6],[24,7],[19,13],[11,3],[27,8],[22,2],[23,9],[11,0],[10,-5],[7,-10],[9,-6],[8,-1],[7,7],[0,12],[9,8],[36,1],[48,-8],[7,-6],[0,-7],[7,-4],[30,0],[9,-7],[6,-19],[7,-3],[15,1],[50,17],[41,0],[29,-5],[36,-14],[44,-12],[14,-2],[12,-6],[0,-6],[-23,-11],[-33,-60],[-13,-15],[-11,-7],[-16,-4],[-8,-7],[-18,-47],[-11,-8],[-18,-4],[0,-5],[5,-5],[0,-8],[-51,-71],[-18,-12],[-13,-5],[-19,2],[-20,9],[-13,2],[-33,0],[-28,10],[-21,4],[-27,-1],[-27,-11],[-36,-3],[-6,-3]],[[5610,9624],[-3,-2],[-7,-3],[-8,-1],[-10,2],[-5,1],[-1,4],[7,3],[17,2],[4,-2],[6,-4]],[[5594,9609],[-1,-4],[-7,-3],[-10,0],[-13,4],[-1,4],[5,2],[9,1],[11,-1],[7,-3]],[[5160,9395],[-33,-1],[-21,5],[-10,3],[-1,8],[6,3],[55,-2],[51,7],[16,-4],[6,-8],[-5,-5],[-64,-6]],[[4722,9283],[-1,-3],[0,-3],[-5,-2],[-8,-2],[-11,0],[-6,2],[-3,2],[2,3],[8,4],[16,1],[8,-2]],[[4728,9161],[-11,-1],[-6,3],[-5,8],[-33,10],[-3,11],[4,5],[-5,8],[-18,5],[-26,-1],[-15,6],[0,7],[12,7],[-12,23],[11,9],[-1,4],[10,6],[23,0],[36,-6],[32,-11],[7,-7],[3,-10],[-5,-22],[17,-49],[-15,-5]],[[5277,9045],[-5,-2],[-8,0],[-10,0],[-6,4],[2,2],[5,3],[6,1],[11,0],[5,-1],[0,-7]],[[6389,8983],[-10,-3],[-7,0],[-8,2],[-7,4],[0,4],[4,2],[9,0],[10,-1],[9,-8]],[[6437,8975],[0,-3],[-3,-3],[-7,-2],[-10,2],[-9,2],[-1,5],[7,3],[8,0],[10,0],[5,-4]],[[6187,8963],[-15,3],[2,5],[12,5],[3,13],[6,2],[30,4],[38,14],[47,-3],[8,-5],[-2,-8],[-21,-8],[-108,-22]],[[5965,8798],[-16,4],[1,6],[5,2],[8,12],[4,23],[9,6],[10,0],[4,-3],[-11,-43],[-6,-5],[-8,-2]],[[5381,9563],[7,-2],[10,2],[23,9],[26,-1],[22,-10],[7,-7],[38,-9],[28,-11],[18,-17],[8,-17],[72,-41],[16,-20],[40,-19],[-1,-12],[-7,-6],[1,-17],[14,-5],[25,2],[14,-2],[14,-9],[44,-5],[10,-9],[14,-5],[13,2],[0,4],[-13,9],[5,7],[33,0],[16,-8],[10,-8],[-2,-9],[-13,-6],[-2,-10],[13,-9],[-10,-21],[18,-9],[35,-13],[9,-13],[19,-4],[19,5],[5,10],[-9,10],[-26,14],[3,27],[12,11],[3,12],[33,0],[42,-8],[8,-4],[8,-13],[-3,-32],[-8,-10],[-36,-14],[-1,-7],[18,-8],[56,-3],[18,-8],[6,-27],[-11,-11],[-25,-10],[-2,-5],[25,-1],[10,4],[5,10],[12,-1],[6,-8],[-3,-8],[-21,-16],[-9,-24],[-18,-17],[-4,-14],[8,-1],[8,2],[27,16],[32,-3],[9,3],[7,15],[6,2],[14,-1],[30,-9],[16,-10],[0,-9],[-18,-13],[-2,-5],[13,-3],[17,3],[10,4],[18,31],[14,0],[7,-5],[-3,-9],[11,-16],[44,-28],[8,-14],[-6,-10],[-35,-16],[-76,-22],[-44,-9],[-31,-15],[-7,0],[-20,15],[-16,-1],[-2,-8],[10,-12],[-2,-7],[-47,-32],[-18,-35],[-11,-4],[-10,0],[-17,6],[-9,16],[6,26],[21,37],[-3,9],[-8,1],[-8,-4],[-20,-16],[-14,-20],[-15,-48],[33,-13],[3,-6],[-3,-17],[-13,-11],[-18,-3],[-20,8],[-16,22],[-5,2],[-10,1],[-5,-3],[-3,-18],[16,-18],[3,-26],[-8,-31],[-7,-12],[-11,-6],[-16,6],[0,12],[-10,13],[-26,10],[-31,20],[-17,18],[-16,27],[-13,-2],[-4,-8],[17,-23],[0,-5],[40,-45],[0,-14],[-5,-2],[-7,-1],[-18,10],[-29,0],[-5,19],[-36,11],[-14,1],[-20,-1],[-8,-3],[0,-5],[12,-3],[19,-1],[14,-7],[-1,-13],[-19,-11],[-12,-2],[-41,2],[-38,5],[-33,9],[-46,0],[-17,7],[0,10],[-4,6],[-56,22],[-22,15],[-2,8],[5,3],[25,-2],[60,7],[17,0],[13,4],[0,8],[-10,4],[-40,-2],[-17,1],[-32,9],[-13,0],[-20,-8],[-15,-1],[-18,7],[-5,10],[-5,7],[-8,3],[-17,7],[-3,7],[13,5],[53,-4],[0,8],[-22,7],[-57,4],[-18,6],[-21,18],[-3,17],[5,4],[42,5],[57,11],[44,6],[118,0],[50,3],[80,11],[16,5],[1,5],[-5,2],[-19,0],[-43,-7],[-42,-3],[-50,0],[-39,4],[-29,9],[0,5],[6,2],[84,0],[32,2],[22,3],[14,8],[-13,5],[-107,-3],[-18,1],[-3,9],[6,3],[0,9],[-11,2],[-8,-5],[-13,-1],[-27,13],[-11,0],[-5,-3],[0,-7],[24,-15],[0,-4],[-11,-4],[-24,-1],[-11,4],[0,4],[-10,2],[-16,-9],[-16,-4],[-16,-12],[-27,-2],[-10,4],[0,9],[15,7],[6,6],[-6,4],[-16,0],[-39,-19],[-34,-9],[-32,-6],[-16,-1],[-13,4],[-6,3],[-4,19],[-24,6],[-26,13],[5,11],[-3,22],[14,4],[57,2],[51,10],[51,16],[8,9],[0,8],[-8,5],[-14,0],[-35,-17],[-33,-5],[-38,-12],[-60,-2],[-11,2],[-9,3],[-9,14],[-18,11],[-13,14],[-18,9],[-1,6],[30,9],[-1,5],[-32,9],[-1,6],[10,12],[-22,11],[-1,7],[32,1],[49,-9],[65,-15],[48,1],[36,12],[17,0],[24,-7],[8,2],[0,7],[-18,8],[0,7],[23,11],[-1,11],[-12,4],[-17,0],[-25,-14],[-48,-16],[-46,-1],[-15,4],[0,6],[22,8],[2,8],[-23,1],[-34,-5],[-24,1],[-18,6],[-48,11],[-2,14],[11,4],[18,0],[22,5],[27,-1],[27,-4],[15,0],[8,4],[-10,14],[-37,13],[4,18],[19,10],[55,-2],[32,7],[55,2],[39,-2],[42,-8],[18,0],[9,3],[0,5],[-9,4],[-61,9],[-18,7],[0,6],[9,3],[27,2],[15,4],[-3,6],[-22,6],[-55,1],[-28,6],[-28,0],[-21,-4],[-22,1],[-7,6],[15,8],[-1,6],[-19,6],[0,4],[23,17],[25,0],[23,-5],[15,-1],[22,3],[12,6],[19,2],[10,-4],[4,-13],[15,-4],[22,-1],[10,3],[-1,6],[-16,17],[0,9],[22,1],[19,-3],[48,1],[32,9],[3,12],[-3,4],[-25,8],[-74,1],[-20,2],[-9,3],[-1,7],[29,15],[26,1],[13,-2]],[[4269,8769],[-11,2],[-1,3],[9,9],[4,16],[10,5],[19,2],[15,-7],[2,-5],[-24,-9],[-23,-16]],[[4436,8775],[-9,-1],[-6,2],[-3,9],[4,3],[8,0],[13,-5],[2,-4],[-9,-4]],[[5281,8787],[-15,4],[0,4],[-15,9],[0,10],[4,3],[10,-3],[8,-9],[17,-9],[-2,-7],[-7,-2]],[[4112,8822],[-19,10],[-15,33],[4,14],[9,9],[29,2],[48,-17],[28,-6],[37,2],[12,7],[-4,10],[-15,6],[-31,1],[-6,2],[-2,5],[13,5],[25,2],[18,6],[16,11],[-2,4],[-6,2],[-15,-1],[-15,6],[-13,-1],[-17,-8],[-12,-1],[-9,3],[-2,11],[36,23],[-2,6],[-26,12],[-22,-2],[-52,-35],[-20,-9],[-13,0],[-2,12],[22,18],[5,13],[-12,3],[-40,2],[-34,9],[-8,5],[-7,14],[15,24],[-9,17],[9,4],[10,1],[45,2],[20,-2],[46,4],[54,12],[37,1],[25,-8],[64,-32],[14,-13],[6,-16],[-4,-17],[-10,-8],[2,-6],[10,-6],[1,-10],[11,-2],[7,4],[3,19],[20,15],[26,9],[20,3],[21,0],[21,-8],[16,-17],[12,-6],[33,-5],[2,-8],[-14,-20],[4,-11],[14,-4],[15,1],[23,8],[20,1],[14,-5],[7,-8],[16,-4],[7,-26],[8,-8],[31,-14],[1,-16],[-16,-23],[3,-15],[11,-14],[27,-10],[1,-7],[19,-17],[6,-50],[-24,-19],[-20,-8],[-20,-1],[-13,3],[-51,-3],[-18,5],[-17,12],[-33,32],[-13,38],[-8,4],[-25,2],[-42,17],[-34,6],[-24,-1],[-12,-7],[-12,-1],[-16,3],[-14,5],[-2,6],[7,8],[-4,11],[-6,1],[-50,-4],[-41,-8],[-13,-4],[-11,-11],[-11,-4],[-9,-1],[-24,5],[-31,9],[-14,8]],[[4512,8680],[-19,1],[-85,-6],[-7,1],[-11,6],[-17,16],[-8,24],[3,3],[26,1],[51,-2],[32,-11],[39,-20],[3,-11],[-7,-2]],[[5152,8859],[38,-8],[23,-11],[5,-6],[-12,-9],[-41,-7],[-21,-12],[1,-6],[40,-21],[11,-18],[15,-9],[0,-9],[-9,-4],[-29,2],[-14,-5],[-28,-4],[-34,-12],[-39,-9],[-14,0],[-20,5],[-11,0],[-4,-9],[-14,-4],[-19,-12],[-9,-1],[-10,5],[-1,20],[-6,7],[-10,8],[-51,19],[-2,12],[13,7],[36,1],[37,-2],[1,9],[-16,9],[-23,8],[-65,12],[-1,5],[-22,15],[-14,26],[-23,12],[-2,10],[14,8],[27,10],[-16,24],[-4,21],[6,7],[17,6],[40,2],[27,-7],[38,-18],[24,-5],[15,-1],[13,-6],[12,-9],[10,-2],[20,1],[8,-4],[3,-10],[-3,-17],[11,-5],[49,0],[16,-6],[17,-3]],[[6334,8616],[-7,1],[-6,4],[1,9],[-12,7],[-19,6],[1,5],[5,2],[23,-3],[34,-18],[-2,-7],[-18,-6]],[[5341,8609],[-132,10],[-96,1],[-35,2],[-11,5],[-6,7],[-19,10],[-4,11],[6,13],[19,13],[50,16],[42,-1],[14,4],[16,0],[24,-9],[38,0],[58,-7],[24,4],[13,5],[12,0],[14,-6],[24,-5],[18,-9],[0,-11],[-5,-7],[-30,-16],[-2,-18],[-32,-12]],[[3587,8496],[-10,2],[-3,6],[3,3],[12,-2],[3,-6],[-5,-3]],[[5770,8556],[-20,2],[-46,17],[-44,10],[-26,14],[-6,8],[2,29],[-6,8],[1,14],[17,11],[16,4],[26,-3],[87,-26],[13,-7],[8,-12],[4,-19],[18,-17],[-1,-7],[-25,-22],[-18,-4]],[[4078,8526],[-15,8],[-2,6],[-38,9],[-11,10],[-27,40],[-6,13],[3,9],[-8,9],[-7,20],[-24,26],[-1,12],[16,2],[11,-4],[44,-22],[21,-16],[23,-44],[11,-5],[12,0],[8,-3],[30,-18],[9,-11],[7,-24],[-12,-10],[-24,-8],[-20,1]],[[5089,8553],[-3,-2],[-11,1],[-6,3],[-1,2],[3,3],[6,1],[7,0],[5,-2],[0,-6]],[[5668,8539],[-20,5],[-19,13],[-2,11],[7,4],[16,1],[28,-14],[1,-14],[-11,-6]],[[5146,8544],[-18,2],[-5,6],[-14,6],[2,5],[18,0],[18,-6],[5,-4],[1,-7],[-7,-2]],[[5102,8536],[-4,-3],[-4,-1],[-7,0],[-6,3],[0,5],[5,3],[9,-2],[7,-5]],[[4928,8491],[-9,2],[3,10],[4,3],[15,0],[5,-2],[1,-6],[-19,-7]],[[4959,8458],[-3,-2],[-11,0],[-5,3],[-1,3],[3,3],[5,1],[7,0],[5,-3],[0,-5]],[[4693,8435],[-44,5],[-2,7],[17,2],[17,-6],[8,0],[5,-2],[-1,-6]],[[4743,8426],[-11,-1],[-6,1],[-6,2],[0,5],[7,3],[8,0],[6,-3],[2,-7]],[[4495,8405],[-26,-2],[-7,3],[6,11],[74,31],[41,4],[5,-2],[0,-4],[-15,-10],[-8,-11],[-70,-20]],[[6466,8366],[-3,-4],[-2,-2],[-8,0],[-6,2],[-4,3],[0,4],[0,4],[4,6],[5,0],[8,-2],[1,-2],[2,-3],[3,-6]],[[4879,8400],[-9,-2],[-4,0],[-7,1],[-5,2],[0,3],[7,2],[9,1],[9,-3],[0,-4]],[[4967,8408],[-2,-8],[-6,-4],[-4,0],[-4,2],[-1,4],[1,6],[6,3],[6,0],[4,-3]],[[5777,8464],[4,-2],[-1,-10],[12,-7],[7,-10],[-1,-11],[-10,-13],[-2,-20],[3,-11],[-14,-4],[-21,-3],[-16,10],[-3,11],[-23,30],[-1,14],[5,6],[50,21],[11,-1]],[[4133,8429],[10,4],[17,2],[12,-5],[3,-13],[25,2],[5,-2],[18,-13],[50,-21],[5,-10],[-19,-19],[-15,-6],[-17,-3],[-29,-2],[-45,1],[-7,3],[-1,3],[20,3],[3,3],[-6,5],[-13,0],[-12,4],[-1,16],[-18,13],[-7,19],[7,10],[15,6]],[[4958,8372],[-10,0],[-5,3],[0,11],[8,0],[7,-5],[0,-9]],[[5841,8360],[-10,4],[3,7],[9,-1],[7,-6],[-9,-4]],[[6719,8293],[-7,4],[4,6],[17,5],[9,-1],[3,-2],[-6,-9],[-20,-3]],[[6955,8204],[-10,6],[1,3],[-12,11],[4,9],[41,25],[11,16],[14,12],[10,3],[8,0],[4,-7],[-5,-10],[-26,-21],[-5,-10],[24,-16],[-2,-5],[-5,-2],[-32,4],[-7,-3],[-5,-11],[-8,-4]],[[4233,8277],[-18,-2],[-28,7],[-21,2],[-26,9],[-11,12],[8,13],[7,4],[85,6],[63,10],[25,2],[14,-5],[15,-22],[-19,-21],[-17,-6],[-60,-4],[-17,-5]],[[4246,8244],[-29,-1],[-11,4],[1,3],[37,6],[54,16],[45,9],[12,1],[9,-3],[2,-7],[-11,-5],[-32,-5],[-77,-18]],[[5190,8266],[-21,8],[-1,9],[23,0],[4,-3],[1,-10],[-6,-4]],[[4245,8227],[-10,-6],[-10,-1],[-7,2],[-2,6],[22,3],[7,-4]],[[5113,8245],[-7,-2],[-7,1],[-5,2],[1,5],[3,6],[5,4],[4,2],[7,-6],[2,-10],[-3,-2]],[[4299,8205],[-32,-2],[-9,2],[-1,5],[27,10],[19,22],[41,5],[32,12],[19,0],[1,-3],[-7,-5],[-18,-4],[-8,-6],[-11,-21],[-8,-6],[-45,-9]],[[5010,8213],[-6,0],[-1,7],[21,16],[6,0],[5,-2],[0,-5],[-15,-13],[-10,-3]],[[5143,8206],[-3,-2],[-10,0],[-5,3],[-1,3],[3,3],[5,1],[7,0],[5,-3],[-1,-5]],[[5244,8197],[-26,0],[-6,2],[-1,6],[4,2],[-1,17],[-6,9],[-1,11],[6,7],[18,8],[19,-1],[10,-5],[-2,-49],[-14,-7]],[[4606,8172],[-67,-5],[-7,3],[-1,5],[17,3],[56,5],[7,-3],[0,-4],[-5,-4]],[[5000,8193],[3,-5],[-8,-6],[-11,-3],[-11,2],[2,5],[17,6],[8,1]],[[4484,8149],[-9,-3],[-9,1],[-4,1],[0,4],[2,3],[5,3],[7,0],[6,-1],[2,-8]],[[4952,8153],[-2,-1],[-10,0],[-5,3],[-2,2],[3,3],[5,2],[7,-1],[4,-2],[0,-6]],[[5012,8115],[-16,0],[-6,6],[-9,27],[7,8],[52,17],[11,14],[17,-5],[20,0],[6,-6],[1,-8],[-11,-10],[0,-8],[-3,-5],[-12,-2],[-8,4],[-5,9],[-10,3],[-1,-12],[-24,-17],[-1,-12],[-8,-3]],[[4949,8084],[-6,2],[-2,12],[3,11],[6,1],[4,-2],[2,-20],[-7,-4]],[[4175,8045],[-20,-2],[-8,2],[-50,20],[-5,8],[6,13],[24,29],[8,17],[8,7],[11,1],[27,-6],[9,-5],[8,-18],[26,-26],[9,-15],[-4,-7],[-49,-18]],[[4615,8168],[37,5],[6,4],[-2,10],[8,7],[83,0],[14,4],[-1,4],[-8,3],[-61,-1],[-93,-10],[-55,-3],[-35,-12],[-74,-5],[-28,-9],[-25,-3],[-11,-12],[-11,-4],[-16,6],[-6,7],[-14,7],[-2,7],[16,7],[14,16],[16,1],[26,-8],[8,3],[-1,5],[-10,4],[-1,13],[-7,3],[-2,6],[10,9],[19,6],[16,1],[9,-4],[1,-4],[18,-2],[13,-6],[11,-9],[24,-8],[10,1],[14,9],[-3,6],[-22,-4],[-9,4],[-1,5],[-22,14],[-2,8],[15,14],[-2,6],[-12,0],[-14,-3],[-22,6],[-3,26],[10,8],[21,7],[7,6],[-27,-1],[-14,5],[-16,-2],[-5,2],[-6,20],[25,17],[18,23],[10,0],[42,-21],[14,-11],[3,-13],[12,-5],[20,-15],[11,-18],[25,-10],[4,-9],[42,-32],[17,-10],[8,-2],[15,1],[21,6],[1,7],[-5,2],[-26,0],[-12,5],[-27,32],[-2,6],[15,2],[18,-7],[21,-3],[17,8],[-1,5],[-4,2],[-21,-2],[-22,8],[-21,0],[-22,4],[-6,8],[7,6],[14,2],[7,8],[10,0],[12,-5],[8,0],[-2,12],[-24,10],[-38,0],[-24,5],[-17,7],[-13,11],[-2,5],[11,9],[30,9],[24,15],[93,3],[12,-5],[5,-8],[20,-14],[6,-27],[9,-3],[8,10],[19,1],[4,2],[-7,19],[-13,9],[0,11],[4,2],[37,1],[6,2],[-2,7],[-29,9],[5,5],[31,-2],[14,-5],[6,-11],[14,-4],[0,-4],[-8,-5],[1,-4],[16,-8],[27,-6],[20,-8],[2,-8],[-11,-15],[2,-12],[23,-29],[3,-27],[-13,-19],[5,-52],[-22,-6],[-4,-3],[1,-4],[43,-15],[5,-12],[-4,-13],[3,-26],[12,-14],[-6,-3],[-12,6],[-28,27],[-4,-1],[0,-10],[-6,0],[-13,7],[-8,-1],[1,-11],[7,-8],[-7,-4],[0,-14],[-11,-8],[1,-3],[10,-5],[1,-6],[21,-7],[7,-13],[17,-8],[1,-6],[-7,-4],[-18,3],[-25,12],[-4,9],[-9,0],[-1,-12],[8,-9],[15,-10],[0,-5],[-9,-5],[-40,-1],[-28,-10],[-8,0],[-16,6],[-12,-1],[-9,-4],[-13,-1],[-6,3],[-1,4],[6,12],[-2,8],[-8,2],[-6,-10],[1,-5],[-12,-10],[-39,-9],[-26,3],[-15,10],[-23,8],[-1,13],[-10,10],[-4,12],[3,3],[12,0],[26,-1],[2,6],[-21,5],[-3,14],[-4,2],[-14,-1],[-12,3],[-11,5],[-1,3],[12,9],[-7,6],[0,8],[16,2],[34,0],[14,9],[26,1],[3,3],[-1,3],[-12,3],[-30,-3],[-7,5],[7,5]],[[6175,8126],[5,4],[17,5],[41,-1],[7,2],[1,5],[-7,4],[-37,4],[-8,4],[2,5],[17,5],[27,14],[26,-3],[8,2],[30,14],[24,6],[14,-1],[36,-12],[12,1],[3,5],[-7,9],[4,10],[36,10],[35,21],[14,-1],[25,-12],[22,-4],[86,18],[20,-2],[9,-3],[55,-3],[17,-6],[24,-2],[15,2],[18,-2],[5,-5],[-9,-7],[-5,-12],[15,-9],[22,-2],[40,3],[36,-2],[11,-10],[-1,-11],[-6,-6],[-19,-7],[-3,-6],[7,-4],[60,8],[19,-3],[5,-8],[-9,-12],[11,-8],[-11,-15],[11,-10],[-2,-4],[-27,-21],[-55,-24],[-6,-15],[8,-9],[12,-1],[33,9],[19,-2],[20,-17],[-2,-12],[-12,-6],[-15,-1],[-23,-9],[-14,3],[-20,21],[-11,2],[-4,-1],[-3,-8],[22,-25],[-11,-23],[4,-10],[-9,-18],[-19,-5],[-39,2],[-52,-5],[-54,-18],[-26,-5],[-19,5],[-15,12],[-9,1],[-6,-6],[-9,-4],[-11,1],[-15,8],[-21,5],[-8,10],[-1,37],[-28,18],[-12,16],[-12,1],[-3,-12],[28,-23],[2,-7],[-5,-16],[-21,-22],[-14,-9],[-12,-1],[-42,3],[-23,-7],[-20,-3],[-21,6],[-30,2],[-10,6],[5,14],[-6,6],[2,8],[-5,1],[-9,-31],[-16,-9],[-13,1],[-9,7],[-6,9],[1,14],[-7,3],[-4,-3],[-2,-27],[-13,-7],[-39,2],[-8,6],[1,7],[-3,3],[-10,0],[-7,-11],[-2,-10],[-6,-2],[-11,2],[-30,21],[-12,-1],[3,-8],[21,-15],[-4,-4],[-48,4],[-10,-4],[-10,1],[-6,4],[4,6],[0,11],[-11,-1],[-8,-12],[-12,-6],[-29,5],[-55,-3],[-9,1],[-5,6],[-4,9],[14,61],[-3,8],[3,18],[-4,3],[-6,0],[-4,-3],[-2,-14],[-20,-11],[-3,-22],[-9,-6],[-7,0],[-5,4],[5,25],[-3,6],[-4,2],[-12,-1],[0,-17],[-8,-9],[-1,-7],[5,-7],[-2,-12],[-10,-8],[-18,-4],[-29,-13],[-6,0],[-29,11],[-35,1],[-19,5],[-43,25],[-17,3],[-1,5],[16,15],[4,8],[1,7],[-4,2],[-8,0],[-4,-2],[-12,-16],[-14,-9],[-1,-10],[9,-14],[0,-7],[-6,-3],[-9,3],[-7,10],[-18,-2],[-16,2],[-13,15],[-11,0],[-13,6],[-9,13],[-12,35],[-8,10],[0,7],[18,5],[2,13],[-7,6],[-17,1],[-20,9],[-7,18],[3,34],[24,28],[13,24],[3,18],[-7,38],[-26,18],[-3,10],[-12,13],[-39,26],[-16,29],[-10,9],[-9,3],[-19,0],[-18,-6],[-23,0],[-5,-6],[15,-8],[0,-4],[-12,-6],[-21,1],[-40,9],[-35,5],[-23,-3],[-21,-7],[-6,0],[-23,8],[-32,3],[-4,9],[8,5],[29,7],[1,5],[-23,7],[-58,8],[-24,10],[-9,8],[0,4],[12,7],[29,8],[16,7],[0,11],[-20,0],[-22,-11],[-22,-1],[-17,5],[-41,20],[-31,3],[-9,4],[7,16],[9,0],[14,-8],[13,-5],[10,4],[-4,18],[-34,12],[4,21],[6,5],[37,2],[8,10],[11,6],[88,3],[29,-12],[25,-2],[24,-11],[23,-2],[22,-12],[24,3],[13,-1],[4,-4],[-2,-6],[7,-3],[28,5],[18,-2],[24,-25],[30,-18],[-4,-13],[0,-27],[-26,-19],[0,-8],[7,-2],[17,7],[32,32],[15,7],[15,0],[19,-5],[40,-1],[53,24],[28,0],[17,-4],[78,-34],[18,-11],[6,-8],[-9,-3],[-34,-1],[-31,9],[-19,1],[-18,6],[-9,0],[-4,-2],[-1,-5],[7,-3],[47,-14],[65,-4],[27,-6],[71,-7],[16,-4],[8,-4],[-9,-19],[-13,-7],[-15,-2],[-54,2],[-4,-2],[-1,-5],[6,-6],[-11,-4],[-24,11],[-33,3],[-25,14],[-29,6],[-22,12],[-11,-1],[0,-5],[12,-9],[-1,-10],[8,-5],[43,-4],[9,-3],[19,-13],[35,1],[4,-2],[0,-6],[-5,-2],[-25,-5],[-24,5],[-16,-1],[3,-13],[-22,-25],[1,-6],[11,3],[17,16],[17,10],[8,0],[8,-5],[0,-4],[6,-4],[8,0],[9,12],[18,-1],[18,16],[15,-3],[6,2],[-1,15],[11,2],[6,-3],[2,-14],[18,-8],[-1,-11],[-13,-21],[6,-3],[22,11],[14,-1],[19,-9],[5,-7],[-16,-32],[-13,-6],[-24,-4],[-3,-6],[6,-4],[45,-2],[11,-13],[9,-7],[15,-5],[16,1],[7,3],[1,6],[-22,21],[2,11],[9,5],[3,9],[10,2],[6,-3],[4,-13],[7,-5],[24,-4],[7,-5],[-1,-11],[-5,-2],[1,-5],[13,3],[9,8],[31,14],[14,0],[0,-7],[9,-8],[-2,-10],[14,-5],[12,4],[1,5],[-10,9],[4,12],[9,8],[9,0],[10,-11],[10,-6],[27,-9],[29,-5],[14,-8],[-1,-8],[-11,-5],[0,-7],[10,-2],[17,5]],[[5033,7975],[-4,-4],[-5,1],[-4,0],[-2,5],[-1,2],[1,4],[5,1],[4,-1],[6,-2],[0,-6]],[[4821,7964],[-9,-2],[-9,0],[-4,2],[-5,2],[0,4],[6,2],[7,0],[6,-1],[7,-2],[1,-5]],[[5057,7957],[1,-5],[-2,-3],[-4,-1],[-6,0],[-4,2],[0,4],[0,3],[6,1],[9,-1]],[[5305,7931],[-25,2],[-21,5],[-13,1],[-19,7],[-13,0],[-8,2],[-8,4],[-6,14],[-24,14],[-9,-2],[-1,-7],[-6,-4],[-8,6],[-4,11],[-34,12],[-14,8],[-4,4],[-2,22],[-4,2],[-9,-2],[-1,-19],[-7,-3],[-8,0],[-8,4],[-3,13],[-6,3],[-15,-4],[-6,3],[-1,8],[6,17],[30,21],[28,15],[1,14],[24,13],[4,5],[-1,3],[-6,3],[-27,-2],[-3,6],[4,4],[18,2],[21,-1],[-1,14],[16,10],[25,12],[43,10],[57,1],[26,-12],[33,-26],[26,-15],[10,-10],[8,-18],[14,-8],[11,-18],[1,-17],[-8,-9],[0,-13],[8,-7],[0,-7],[-8,-9],[0,-13],[6,-13],[0,-18],[-4,-8],[-9,-10],[-14,-8],[-26,-2],[-26,-10]],[[4916,7935],[3,-5],[-14,-11],[-6,-14],[-10,-6],[-18,-3],[-6,3],[-1,7],[14,9],[12,16],[9,4],[17,0]],[[5149,7897],[-15,0],[-17,3],[-6,3],[-2,7],[-18,6],[0,4],[24,14],[13,-1],[8,-15],[23,-10],[-1,-6],[-9,-5]],[[4780,7850],[-13,0],[-13,2],[-3,8],[29,2],[9,-4],[0,-4],[-9,-4]],[[5768,7769],[-11,5],[3,5],[15,6],[9,0],[5,-4],[-1,-5],[-20,-7]],[[3765,7691],[7,-4],[1,-4],[-3,-4],[-6,-3],[-33,-9],[-10,1],[-5,4],[0,9],[6,5],[7,1],[10,1],[26,3]],[[4763,7738],[-17,0],[-11,7],[-33,0],[-7,2],[-6,3],[-2,8],[5,4],[25,2],[10,4],[8,8],[8,4],[64,14],[19,10],[17,6],[18,0],[4,-2],[4,-10],[-5,-9],[-9,-12],[-21,-17],[-21,-11],[-25,-2],[-25,-9]],[[4731,7735],[-9,-6],[-7,0],[-8,1],[0,5],[2,3],[8,1],[13,-1],[1,-3]],[[6965,7474],[-18,6],[-29,28],[-22,8],[-16,9],[-8,8],[-2,9],[5,30],[-12,9],[-61,26],[-17,18],[0,11],[18,48],[-2,12],[-12,12],[6,12],[14,0],[46,10],[11,-1],[9,-10],[33,-10],[23,-12],[22,-3],[33,1],[88,10],[26,-4],[29,-9],[12,-8],[32,-14],[34,-9],[8,-8],[1,-6],[18,-21],[13,-9],[26,-5],[4,-7],[-4,-14],[6,-14],[13,-12],[17,-2],[2,-3],[-6,-16],[5,-6],[33,-14],[7,-8],[-6,-13],[-14,-5],[-13,0],[-85,11],[-39,-1],[-42,6],[-28,0],[-62,-11],[-68,-29],[-28,0]],[[3573,7501],[10,-1],[3,-4],[1,-5],[-5,-4],[-6,0],[-3,2],[-3,8],[3,4]],[[4953,7588],[-9,2],[0,4],[10,7],[7,0],[3,-2],[1,-6],[-12,-5]],[[4032,7505],[-5,3],[-35,24],[-29,23],[-16,18],[-19,34],[-17,18],[-24,13],[-34,6],[-11,6],[-2,15],[9,10],[20,20],[26,16],[14,4],[120,9],[21,-9],[14,-15],[31,-13],[20,-15],[4,-16],[-8,-42],[-27,-51],[-19,-18],[-4,-6],[-24,-16],[-2,-13],[-3,-5]],[[5110,7562],[-9,-2],[-5,1],[-4,3],[-2,8],[2,5],[5,3],[7,-1],[3,-5],[0,-6],[3,-6]],[[3662,7452],[3,-8],[-5,-5],[-4,-1],[-4,2],[-2,7],[3,5],[6,1],[3,-1]],[[5098,7519],[-4,3],[0,4],[0,8],[-1,9],[7,4],[5,-2],[1,-6],[2,-10],[-1,-9],[-6,0],[-3,-1]],[[4976,7513],[-7,0],[-9,5],[-10,19],[-2,15],[3,11],[9,11],[8,6],[7,1],[23,-30],[2,-20],[-7,-13],[-17,-5]],[[5110,7507],[-1,-11],[-4,-2],[-5,1],[-3,1],[-1,4],[4,5],[2,3],[4,0],[4,-1]],[[4575,7477],[-9,-4],[-9,3],[2,5],[6,2],[5,0],[5,-2],[0,-4]],[[4990,7504],[3,-4],[-3,-12],[8,-6],[0,-8],[-11,-5],[-22,-4],[-2,6],[5,23],[12,9],[10,1]],[[6329,7379],[-2,-6],[-6,-2],[-6,1],[-2,4],[5,4],[11,-1]],[[6230,7348],[-3,-2],[-15,0],[-6,5],[2,10],[8,1],[6,-3],[9,-7],[-1,-4]],[[6247,7346],[5,-5],[-4,-5],[-5,0],[-3,1],[-6,6],[1,3],[12,0]],[[3717,7281],[-8,1],[-5,13],[1,5],[10,-3],[5,-13],[-3,-3]],[[5138,7241],[3,22],[7,3],[6,-20],[-7,-6],[-9,1]],[[4956,7212],[0,5],[15,10],[2,-7],[-4,-6],[-8,-4],[-5,2]],[[4654,7742],[43,-21],[6,-12],[9,-3],[13,11],[61,10],[53,17],[7,2],[17,14],[7,0],[2,-5],[8,-4],[23,1],[22,-3],[14,-11],[9,-19],[2,-19],[-7,-19],[-11,-7],[-23,-3],[-4,-8],[-5,-3],[-20,3],[-3,-4],[1,-12],[8,-4],[13,5],[11,0],[9,-5],[13,-1],[3,-2],[2,-14],[-5,-6],[-15,-5],[-29,-5],[-21,-12],[-29,-34],[-42,-32],[-3,-4],[1,-19],[9,-3],[11,22],[14,8],[46,3],[33,-5],[13,-8],[9,-16],[5,-19],[12,-19],[1,-13],[-9,-12],[2,-12],[7,-3],[10,1],[53,37],[9,-2],[1,-11],[-6,-10],[1,-10],[11,-16],[2,-25],[-3,-5],[-15,-10],[-3,-8],[-6,-3],[-15,3],[-13,-3],[0,-4],[7,-4],[19,-5],[7,-5],[8,-37],[-7,-5],[-22,-3],[-8,-5],[1,-4],[3,-2],[24,1],[5,-4],[1,-8],[-15,-8],[-2,-5],[4,-2],[17,3],[4,-5],[-22,-24],[-5,-2],[-3,2],[0,11],[-8,1],[-11,-15],[-14,-5],[-6,-5],[-10,-15],[-38,-19],[-14,-3],[-12,5],[-4,7],[-10,6],[-30,-1],[-15,5],[-6,9],[-2,17],[7,18],[-1,6],[-11,1],[-11,-14],[-3,-7],[2,-21],[8,-16],[27,-28],[2,-15],[-5,-8],[-8,-3],[-13,-10],[-7,-20],[-8,-7],[-8,-3],[-13,2],[-12,7],[-14,15],[-10,0],[-7,-4],[-8,1],[-9,15],[-8,28],[-4,5],[-13,8],[-33,51],[-31,22],[-29,24],[-16,16],[-26,34],[-7,4],[-24,3],[-11,6],[-10,18],[-9,5],[-7,-1],[-4,-4],[-2,-8],[-6,-9],[-6,-1],[-13,4],[-13,13],[-26,14],[1,11],[-8,5],[-1,6],[-7,8],[-41,25],[-30,25],[-3,15],[16,20],[1,21],[8,13],[27,17],[22,1],[7,1],[10,-6],[5,-7],[9,-25],[24,-16],[8,-14],[17,-7],[15,-16],[28,-6],[12,1],[6,10],[36,0],[10,2],[7,5],[0,14],[-4,3],[-9,20],[-5,24],[3,3],[7,1],[4,-2],[1,-13],[10,-8],[3,-17],[3,-2],[5,2],[9,9],[-2,13],[-10,13],[-4,26],[-13,1],[-13,-4],[-12,8],[-2,19],[5,10],[4,2],[8,1],[23,-11],[18,-5],[5,2],[-1,4],[-27,19],[-15,14],[-7,-1],[-4,-8],[-5,-2],[-22,-2],[-11,-7],[-17,0],[-36,27],[-32,18],[-5,4],[-2,9],[36,22],[25,1],[21,-8],[25,-35],[10,-4],[8,2],[3,5],[-11,10],[-3,25],[-5,6],[-15,11],[-31,11],[-3,9],[2,6],[8,13],[6,5],[7,1],[40,2],[36,-13],[29,2],[12,10],[-3,8],[-4,2],[-28,-3],[-4,2],[-1,5],[19,14],[18,0],[15,-21],[4,-2]],[[4744,7109],[-7,0],[-3,2],[-2,7],[2,5],[3,2],[7,0],[4,-3],[1,-7],[-5,-6]],[[5010,7107],[-7,1],[-5,5],[1,15],[8,-2],[4,-11],[-1,-8]],[[4254,6978],[-3,-1],[-10,4],[-2,9],[10,-3],[5,-9]],[[5553,6944],[-6,3],[0,5],[3,2],[6,0],[3,-7],[-6,-3]],[[4595,6951],[7,-4],[4,-17],[-3,-2],[-7,-1],[-10,5],[-4,7],[-22,18],[-1,10],[-4,4],[0,8],[25,-1],[14,-10],[14,-4],[7,-4],[1,-5],[-6,-1],[-9,2],[-9,1],[-1,-4],[4,-2]],[[7235,6741],[-4,0],[-3,0],[-7,4],[0,3],[3,3],[4,1],[5,-1],[4,-6],[-2,-4]],[[7123,6762],[-5,0],[-4,1],[-1,5],[0,3],[1,7],[4,4],[3,1],[4,-1],[2,-2],[0,-4],[-4,-14]],[[5565,6927],[-6,2],[1,7],[8,-1],[1,-5],[-4,-3]],[[4612,6910],[-5,0],[-5,3],[2,6],[8,-2],[0,-7]],[[6985,6766],[-11,3],[1,4],[4,2],[5,-1],[3,-3],[-2,-5]],[[7203,6724],[-7,-1],[-3,1],[-2,3],[0,3],[3,3],[4,1],[4,0],[3,-3],[-2,-7]],[[7261,6703],[-7,-3],[-3,1],[-2,2],[-1,3],[3,2],[5,1],[4,-1],[1,-5]],[[4551,6876],[-6,0],[-7,4],[-1,9],[2,4],[5,0],[7,-6],[2,-8],[-2,-3]],[[8633,6298],[-2,4],[2,4],[6,2],[4,-1],[1,-3],[-2,-4],[-9,-2]],[[6068,6843],[2,-2],[2,-4],[-1,-3],[-2,-2],[-5,-1],[-4,1],[-1,2],[-1,3],[2,4],[3,2],[5,0]],[[6619,6768],[-7,3],[-11,8],[-2,3],[-1,3],[7,2],[5,-3],[4,-4],[6,-3],[4,-4],[-1,-4],[-4,-1]],[[6610,6753],[-7,-1],[-9,1],[-4,0],[-3,2],[-4,1],[-5,1],[-2,2],[1,2],[5,1],[9,-1],[10,-2],[7,-1],[2,-5]],[[6844,6762],[-5,4],[1,9],[4,2],[7,-1],[10,4],[19,-2],[12,-10],[14,-2],[13,3],[13,8],[13,3],[9,-1],[11,-9],[4,-10],[-2,-5],[-21,-19],[-19,-7],[-20,3],[-5,-1],[-2,-7],[10,-14],[-2,-6],[-6,-2],[-10,1],[-8,5],[-10,13],[-1,10],[-4,7],[-5,-1],[-3,-5],[-7,-3],[-4,4],[1,5],[-5,5],[-36,3],[-3,3],[0,7],[7,10],[3,1],[16,-3],[4,-5],[5,-4],[5,2],[-3,5]],[[6544,6762],[4,-3],[-5,-4],[-11,1],[-7,0],[-4,-1],[-6,1],[-3,4],[2,3],[8,3],[20,-2],[2,-2]],[[6146,6792],[-64,8],[-14,12],[-1,10],[14,4],[10,8],[9,-2],[10,-11],[6,-1],[11,5],[4,4],[9,0],[14,-11],[3,-5],[0,-17],[-11,-4]],[[7099,6730],[3,10],[5,3],[6,-1],[8,-8],[6,-9],[-5,-14],[-4,-4],[-24,-11],[-34,-7],[-19,-14],[-8,-4],[-6,1],[-2,3],[5,11],[34,29],[26,16],[9,-1]],[[6479,6752],[-6,1],[-17,10],[0,7],[8,3],[20,-3],[5,-5],[-1,-5],[-9,-8]],[[6885,6677],[-5,-2],[-4,1],[-5,3],[0,4],[3,2],[4,1],[5,-2],[2,-7]],[[6712,6687],[-7,1],[-5,2],[-3,3],[-3,5],[0,4],[6,1],[4,-2],[3,-2],[2,-3],[4,-4],[-1,-5]],[[6634,6710],[-2,-8],[-6,-3],[-3,-1],[-6,3],[2,6],[4,3],[5,1],[6,-1]],[[4926,6787],[-9,4],[-1,12],[9,0],[3,-2],[4,-9],[-6,-5]],[[5628,6790],[7,-5],[2,-2],[-3,-6],[-6,1],[-5,6],[1,6],[4,0]],[[5578,6779],[-8,0],[-2,2],[3,7],[10,1],[3,-2],[0,-5],[-6,-3]],[[7269,6666],[3,-8],[-4,-12],[-15,-21],[-12,-12],[-3,-6],[10,-10],[-1,-3],[-7,-3],[-11,2],[-27,-2],[-9,9],[9,42],[-4,16],[4,11],[10,4],[17,-3],[6,-4],[11,-2],[13,3],[10,-1]],[[6661,6679],[-15,5],[-4,4],[2,6],[17,-2],[5,-8],[-5,-5]],[[5586,6764],[0,7],[9,5],[11,11],[6,0],[4,-5],[-3,-7],[-17,-11],[-6,-3],[-4,3]],[[4392,6735],[-9,2],[-2,10],[3,8],[8,-2],[4,-8],[1,-6],[-5,-4]],[[6687,6659],[-4,1],[-5,5],[5,17],[30,-4],[12,-7],[0,-4],[-6,-6],[-6,-1],[-21,3],[-5,-4]],[[5607,6757],[3,-2],[0,-4],[-7,-5],[-6,1],[-3,3],[0,3],[7,4],[6,0]],[[7458,6499],[-5,1],[-5,4],[6,7],[6,-2],[4,-7],[-6,-3]],[[5652,6741],[4,-1],[2,-3],[-1,-5],[-3,-1],[-4,-1],[-3,2],[-3,4],[3,5],[5,0]],[[5750,6729],[4,-3],[-1,-5],[-2,-2],[-5,0],[-3,4],[1,5],[6,1]],[[5660,6722],[4,-3],[1,-4],[-2,-3],[-2,-2],[-7,1],[-4,3],[1,6],[5,2],[4,0]],[[5742,6699],[-4,1],[-2,1],[0,8],[2,3],[5,-2],[2,-6],[0,-3],[-3,-2]],[[7495,6450],[-12,5],[-3,9],[7,18],[4,2],[6,-4],[3,-11],[10,-5],[4,-7],[-4,-5],[-15,-2]],[[5153,6707],[-6,3],[2,6],[5,0],[5,-4],[-6,-5]],[[4491,6687],[0,3],[-10,4],[-5,5],[-2,17],[23,-12],[9,-2],[12,-8],[1,-7],[-16,-10],[-4,-13],[-5,-5],[-6,1],[-2,13],[-6,4],[-1,4],[12,6]],[[6978,6521],[-13,3],[-7,8],[8,28],[11,16],[9,12],[9,4],[10,1],[5,3],[17,19],[20,6],[3,9],[-13,11],[2,6],[27,19],[10,-2],[14,-7],[3,-4],[-2,-11],[-3,-2],[-4,-13],[-21,-15],[-5,-18],[-10,-9],[-15,-28],[-15,-13],[-21,-9],[-9,-11],[-10,-3]],[[5066,6666],[-2,-3],[-9,1],[-5,3],[-5,10],[-9,7],[-20,1],[-12,13],[-4,12],[31,2],[11,-7],[4,0],[10,8],[4,0],[5,-3],[1,-16],[-4,-9],[4,-19]],[[7474,6434],[12,-11],[-2,-4],[-8,-6],[-3,-9],[-4,-2],[-4,1],[-10,17],[-36,27],[-5,8],[1,17],[9,24],[7,4],[6,-2],[11,-11],[17,-4],[5,-10],[-1,-21],[8,-11],[-3,-7]],[[5123,6648],[-7,2],[-3,6],[2,12],[-2,32],[-3,4],[-7,-2],[1,-17],[-6,-14],[-1,-11],[-7,-3],[-8,5],[1,41],[2,9],[13,10],[10,1],[25,-16],[6,-7],[2,-15],[-9,-15],[-2,-17],[-7,-5]],[[5753,6673],[4,-4],[-6,-13],[-1,-20],[-6,-5],[-9,6],[0,7],[-5,8],[0,9],[15,13],[8,-1]],[[6304,6579],[-5,1],[-3,-1],[-4,1],[-1,3],[0,4],[5,2],[6,-1],[4,-5],[-2,-4]],[[5716,6618],[-7,1],[-7,6],[1,14],[-8,9],[1,8],[4,3],[11,0],[3,-2],[8,-18],[2,-19],[-8,-2]],[[6330,6569],[-5,-3],[-3,0],[-3,1],[-3,2],[-2,3],[-3,3],[0,2],[3,5],[4,1],[5,-2],[3,-2],[4,-5],[0,-5]],[[5754,6623],[4,-1],[3,-5],[-2,-6],[-3,-2],[-3,1],[-3,3],[0,9],[4,1]],[[4447,6585],[-7,1],[-2,3],[7,9],[-6,16],[3,5],[4,1],[4,-2],[5,-20],[-8,-13]],[[6320,6552],[-3,-2],[-7,0],[-3,2],[0,3],[1,3],[4,1],[3,0],[3,-2],[2,-2],[0,-3]],[[5695,6620],[6,-14],[0,-5],[-4,-3],[-4,0],[-6,5],[1,17],[7,0]],[[5777,6594],[4,-5],[-1,-4],[-4,-3],[-6,1],[-2,3],[0,4],[4,4],[5,0]],[[5758,6580],[-7,1],[-8,7],[2,12],[6,0],[10,-13],[-3,-7]],[[7041,6427],[-10,1],[-5,7],[4,14],[15,7],[3,6],[-20,15],[2,6],[7,3],[12,-3],[15,-9],[12,-3],[3,-7],[-2,-5],[-6,-6],[-17,-9],[-7,-15],[-6,-2]],[[4626,6558],[-9,3],[-13,17],[-2,24],[3,2],[6,1],[5,-8],[9,-5],[1,-34]],[[6357,6506],[-6,-2],[-6,0],[-3,2],[-1,2],[3,4],[5,0],[3,-1],[3,-2],[2,-3]],[[5766,6559],[0,-5],[-6,-2],[-4,3],[1,4],[3,2],[6,-2]],[[5774,6562],[3,4],[6,0],[4,-3],[5,-10],[-3,-9],[-5,-2],[-6,4],[2,8],[-6,8]],[[7056,6370],[-5,2],[2,4],[8,6],[6,-1],[1,-5],[-12,-6]],[[7543,6257],[-12,3],[-9,6],[-22,30],[-12,7],[-3,5],[-1,6],[5,15],[7,6],[5,2],[18,-3],[7,7],[5,10],[6,3],[5,-2],[2,-2],[-2,-16],[4,-5],[9,1],[9,3],[26,-6],[14,-1],[19,4],[10,-5],[22,-45],[-1,-8],[-8,-7],[-10,-6],[-8,-1],[-10,2],[-10,6],[-30,5],[-15,-12],[-20,-2]],[[6709,6420],[2,6],[4,2],[6,0],[-1,-8],[-6,-3],[-5,3]],[[4607,6550],[5,-4],[0,-19],[-4,-6],[-6,-3],[-8,-7],[-1,-7],[-8,-4],[-3,2],[-1,4],[3,12],[-5,3],[-10,-8],[-6,0],[-3,2],[0,10],[6,19],[-6,29],[5,4],[14,0],[8,-6],[8,-17],[12,-4]],[[7002,6354],[-8,3],[-3,5],[5,16],[-3,16],[3,10],[6,2],[14,-2],[3,-7],[14,-6],[4,-8],[-14,-9],[-11,-14],[-10,-6]],[[4048,6449],[-6,3],[-1,9],[5,1],[6,-6],[1,-4],[-5,-3]],[[3603,6380],[0,5],[5,1],[5,-3],[-3,-5],[-7,2]],[[4422,6459],[-5,0],[-7,4],[-4,6],[-28,19],[-2,11],[19,12],[9,12],[8,1],[5,-2],[9,-6],[4,-7],[-2,-17],[-7,-12],[5,-17],[-4,-4]],[[3856,6386],[-3,-3],[-4,0],[-7,2],[-3,9],[-1,5],[5,1],[4,0],[0,-4],[9,-10]],[[4123,6414],[-15,-1],[-20,13],[-13,6],[-14,14],[-1,8],[2,2],[6,3],[26,3],[36,-23],[7,-7],[2,-7],[-3,-6],[-13,-5]],[[3802,6370],[-10,1],[-1,3],[3,4],[6,1],[4,-1],[1,-5],[-3,-3]],[[3586,6332],[-10,5],[-7,1],[0,12],[6,2],[4,-2],[7,-10],[2,-6],[-2,-2]],[[3693,6337],[-6,2],[-2,4],[2,3],[6,1],[4,-4],[-4,-6]],[[4540,6435],[11,-9],[0,-7],[-6,0],[-6,5],[-4,8],[5,3]],[[5131,6445],[-2,-7],[-6,-3],[-4,3],[1,4],[5,6],[3,0],[3,-3]],[[4927,6457],[-7,2],[-33,24],[-49,16],[-8,5],[-4,18],[-8,10],[-7,-2],[0,-18],[-3,-4],[-8,2],[-7,5],[-7,9],[-13,3],[-9,5],[-4,22],[-3,2],[-11,-2],[-6,-6],[-5,-16],[-8,-3],[-18,10],[-16,26],[-1,15],[12,18],[15,8],[25,-1],[11,8],[16,5],[11,16],[10,2],[8,10],[7,1],[4,4],[1,3],[-4,8],[-13,11],[1,9],[10,0],[4,3],[-2,7],[-13,8],[-1,6],[6,5],[10,-1],[6,-4],[26,-27],[5,-2],[5,1],[1,7],[-6,12],[-24,25],[-1,9],[13,29],[13,13],[2,14],[4,3],[6,1],[15,-10],[15,0],[5,-3],[10,-17],[14,-4],[8,-6],[0,-7],[-8,-10],[-1,-12],[6,-4],[4,1],[5,5],[4,10],[3,3],[5,0],[7,-6],[10,-18],[24,-15],[25,-23],[38,-26],[7,-18],[1,-51],[6,-3],[6,5],[0,38],[3,4],[5,0],[5,-6],[5,-14],[-1,-29],[11,-15],[6,-16],[7,-5],[7,0],[9,-8],[10,4],[11,13],[9,1],[5,-2],[0,-9],[-8,-12],[-12,-32],[-8,-6],[-5,0],[-2,2],[-1,20],[-10,-1],[-15,-16],[1,-11],[-4,-10],[-5,0],[-6,3],[-8,0],[-10,-15],[-7,-6],[-11,-3],[-14,-18],[-16,0],[-19,12],[-24,10],[-15,13],[-7,-3],[2,-12],[-5,-4],[-7,1],[-10,7],[-8,0]],[[4751,6419],[-6,0],[-9,7],[0,4],[2,3],[7,-2],[6,-5],[0,-7]],[[8446,5874],[-6,-3],[-3,2],[-1,2],[1,2],[3,2],[4,1],[4,-1],[-2,-5]],[[3752,6321],[-6,-1],[-3,2],[-4,9],[5,11],[-1,8],[7,2],[6,-8],[-5,-6],[2,-13],[-1,-4]],[[3636,6299],[-5,-1],[-5,3],[-5,7],[-20,10],[-2,8],[23,1],[7,-3],[7,-25]],[[3684,6301],[-3,1],[-4,0],[-4,2],[-5,2],[-3,3],[0,3],[3,1],[6,0],[12,-5],[1,-5],[-3,-2]],[[6101,6382],[-2,-5],[-5,-3],[-6,1],[-5,4],[-1,3],[2,4],[5,2],[8,-2],[4,-4]],[[3718,6303],[-4,-1],[-3,3],[-5,15],[2,3],[4,0],[7,-5],[2,-11],[-3,-4]],[[4618,6411],[8,-19],[-2,-2],[-8,-1],[-6,4],[-1,7],[9,11]],[[4134,6349],[-5,14],[5,10],[5,2],[5,-3],[1,-14],[-5,-11],[-6,2]],[[3615,6278],[-4,-3],[-4,1],[-4,3],[-1,6],[3,1],[7,1],[3,-9]],[[8528,5794],[-5,4],[3,7],[8,5],[5,-1],[-3,-11],[-8,-4]],[[5050,6378],[-4,-1],[-5,1],[-1,4],[0,4],[2,3],[3,2],[3,0],[3,-2],[1,-8],[-2,-3]],[[6034,6341],[-3,2],[2,9],[3,2],[4,-1],[3,-4],[-1,-8],[-8,0]],[[8789,5679],[-6,-4],[-2,2],[-3,2],[-1,3],[2,2],[3,2],[5,-2],[2,-5]],[[8375,5826],[-5,-2],[-5,2],[-1,3],[-1,3],[1,2],[4,2],[3,-1],[4,-9]],[[8798,5655],[-3,1],[-2,8],[1,6],[4,1],[5,-2],[1,-6],[-2,-7],[-4,-1]],[[3680,6236],[6,2],[4,-2],[1,-5],[-2,-2],[-6,1],[-2,3],[-1,3]],[[8509,5766],[3,-5],[-2,-4],[-3,-1],[-4,0],[-2,1],[-3,3],[1,4],[8,4],[2,-2]],[[7268,6124],[-29,6],[-7,9],[-6,39],[-13,27],[-2,20],[3,62],[8,36],[10,9],[5,11],[15,15],[34,28],[25,11],[36,-6],[7,2],[11,12],[11,-1],[19,-7],[21,-13],[27,-6],[11,-13],[4,-15],[-5,-19],[12,-15],[-1,-17],[6,-41],[-12,-51],[-12,-22],[-16,-19],[-43,-27],[-24,-5],[-29,1],[-36,-9],[-30,-2]],[[4750,6321],[-7,3],[-4,4],[-1,9],[5,10],[5,-1],[2,-25]],[[3696,6201],[-5,-1],[-5,3],[-6,15],[2,2],[11,1],[6,-2],[0,-12],[-3,-6]],[[3723,6210],[4,7],[-8,23],[2,3],[5,1],[17,-13],[3,-11],[-4,-4],[-8,-2],[-4,-8],[-7,4]],[[8331,5782],[-7,-1],[-3,2],[-1,3],[3,4],[3,1],[5,-1],[1,-4],[-1,-4]],[[6146,6261],[-15,3],[-6,5],[-3,10],[2,19],[-4,25],[3,19],[8,10],[4,28],[11,11],[11,-1],[11,-5],[7,-8],[7,-31],[-2,-14],[-3,-3],[-6,-40],[-15,-18],[-1,-4],[-9,-6]],[[8351,5774],[-5,-2],[-5,4],[0,3],[3,2],[5,0],[3,-4],[-1,-3]],[[3711,6192],[-6,3],[-1,8],[1,3],[0,6],[4,7],[3,-3],[5,-22],[-6,-2]],[[4871,6303],[4,-3],[0,-7],[-7,-2],[-5,4],[0,5],[3,4],[5,-1]],[[8296,5783],[-4,-5],[-2,0],[-4,1],[-2,4],[1,2],[3,2],[3,2],[4,-2],[1,-4]],[[8788,5574],[-10,4],[-3,6],[1,7],[3,1],[5,-1],[10,-7],[1,-4],[-2,-4],[-5,-2]],[[8291,5757],[-5,2],[-1,3],[2,5],[5,2],[13,-1],[8,-3],[-4,-5],[-18,-3]],[[5081,6278],[-8,-6],[-8,1],[0,3],[7,4],[1,3],[5,2],[3,-2],[0,-5]],[[3746,6160],[-7,2],[-9,28],[5,6],[5,1],[6,-3],[4,-15],[-5,-6],[2,-10],[-1,-3]],[[8340,5721],[-5,6],[3,6],[5,2],[4,-1],[1,-4],[-4,-8],[-4,-1]],[[4919,6243],[-12,-1],[-3,2],[1,5],[10,4],[11,13],[5,0],[3,-2],[1,-4],[-5,-12],[-3,-4],[-8,-1]],[[3778,6141],[-4,-3],[-3,0],[-3,2],[-3,6],[-2,5],[0,3],[3,1],[5,-2],[7,-12]],[[8395,5685],[-3,-1],[-5,-1],[-1,3],[0,3],[1,2],[5,1],[4,-2],[1,-3],[-2,-2]],[[3800,6105],[-9,-2],[-5,3],[-10,12],[-2,6],[2,2],[6,0],[18,-12],[1,-7],[-1,-2]],[[8366,5658],[-3,1],[-4,9],[3,7],[6,-2],[5,-7],[-2,-6],[-5,-2]],[[3764,6115],[1,-7],[-1,-4],[-1,-3],[1,-3],[-1,-2],[-3,-2],[-5,-2],[-1,3],[-1,6],[2,6],[1,3],[1,2],[1,3],[3,1],[3,-1]],[[5160,6149],[1,-11],[-3,-3],[-6,0],[-3,2],[-1,4],[1,2],[6,6],[5,0]],[[8580,5498],[-4,-5],[-5,0],[-4,-1],[-3,4],[2,4],[5,2],[9,-4]],[[8520,5485],[-3,5],[4,8],[19,16],[9,16],[5,2],[8,-3],[5,-13],[-3,-9],[-8,-4],[-11,-1],[-8,-5],[-2,-4],[-15,-8]],[[8610,5437],[-4,3],[-5,10],[5,4],[4,-1],[4,-11],[-4,-5]],[[8647,5414],[-4,-6],[-5,-1],[-3,0],[-3,2],[3,4],[2,2],[2,1],[8,-2]],[[8624,5411],[-5,-3],[-3,1],[-2,3],[-1,2],[5,4],[4,-1],[3,-2],[-1,-4]],[[8586,5416],[-7,15],[6,13],[5,-2],[1,-6],[9,-5],[1,-3],[-5,-6],[-10,-6]],[[8611,5401],[-3,-4],[-5,2],[-2,4],[-4,7],[1,5],[5,-1],[5,-1],[3,-12]],[[8644,5379],[-5,-2],[-2,1],[-2,2],[-1,4],[1,3],[3,1],[5,-3],[1,-6]],[[8561,5413],[5,4],[6,-2],[4,-9],[-3,-5],[-5,1],[-7,11]],[[8597,5375],[-4,-3],[-3,1],[-4,2],[-2,3],[1,2],[2,3],[7,-1],[3,-7]],[[8699,5317],[1,-3],[-5,-9],[-6,-2],[-10,15],[3,4],[17,-5]],[[8677,5306],[3,-9],[-4,-4],[-3,1],[-6,11],[4,4],[6,-3]],[[6552,5883],[-12,2],[-12,7],[-4,6],[2,12],[7,1],[5,-5],[19,-7],[4,-6],[0,-5],[-9,-5]],[[8696,5279],[-6,3],[1,6],[14,6],[7,-2],[-1,-6],[-7,-2],[-8,-5]],[[8659,5283],[-6,2],[-11,15],[-10,4],[-3,-2],[-9,-1],[-4,3],[-3,6],[5,5],[9,2],[7,16],[6,5],[9,-3],[5,-15],[-2,-10],[13,-20],[-2,-6],[-4,-1]],[[8719,5263],[-2,-5],[-2,-1],[-3,1],[-2,3],[0,3],[1,6],[2,2],[5,-2],[1,-7]],[[6431,5880],[-3,-4],[-3,-2],[-7,2],[-3,2],[0,4],[3,4],[3,1],[4,1],[3,-2],[3,-6]],[[6499,5864],[-4,-8],[-3,-1],[-5,2],[-1,3],[-1,3],[2,3],[2,2],[7,0],[3,-4]],[[8689,5262],[3,4],[8,-3],[3,-11],[-4,-11],[-5,0],[-2,4],[2,8],[-5,9]],[[6389,5864],[-6,-3],[-3,0],[-4,1],[-2,2],[-2,3],[1,7],[4,0],[3,1],[2,-2],[7,-9]],[[6510,5836],[-3,-5],[-2,-1],[-5,2],[-3,3],[-1,5],[3,3],[9,-2],[2,-5]],[[8689,5189],[-5,2],[-5,6],[-15,36],[-1,8],[2,15],[-2,4],[4,8],[4,3],[5,-3],[2,-5],[-2,-15],[11,-26],[-1,-8],[3,-8],[8,-9],[-3,-5],[-5,-3]],[[6528,5799],[-1,-8],[-11,-2],[-5,-3],[-4,-1],[-4,1],[-3,4],[0,2],[3,5],[4,2],[13,3],[6,-1],[2,-2]],[[6517,5744],[-20,10],[-24,0],[-3,2],[3,10],[-3,5],[-11,1],[-13,-2],[-5,2],[-4,5],[4,13],[-6,24],[-13,19],[-11,8],[-9,10],[3,12],[5,3],[16,-3],[22,-17],[33,-16],[6,-11],[-2,-15],[-3,-6],[-2,-11],[5,-8],[10,-5],[24,1],[21,-3],[4,-6],[-2,-3],[-15,-14],[-10,-5]],[[8292,5255],[-1,-5],[-3,-2],[-3,0],[-3,4],[-2,3],[4,5],[4,-1],[4,-4]],[[6340,5846],[11,-19],[8,-24],[22,-42],[4,-15],[-1,-9],[-13,-17],[-7,0],[-6,5],[-7,28],[-17,16],[-18,53],[3,17],[3,3],[8,5],[10,-1]],[[7543,5477],[1,-3],[-1,-3],[-5,-1],[-6,2],[-3,4],[3,4],[11,-3]],[[8173,5257],[-5,3],[-2,4],[1,5],[4,3],[8,-2],[2,-5],[-8,-8]],[[8256,5220],[-3,0],[-4,1],[-4,3],[0,6],[3,1],[6,-2],[2,-5],[0,-4]],[[7532,5450],[-4,3],[2,6],[3,1],[5,-1],[1,-2],[-1,-5],[-6,-2]],[[8211,4428],[-4,3],[-3,7],[0,11],[13,42],[4,6],[7,21],[8,10],[6,2],[12,-4],[10,-16],[12,-8],[2,-4],[-11,-33],[-4,-5],[-19,-7],[-12,-14],[-11,-9],[-10,-2]],[[7876,7154],[21,-27],[-6,-20],[-11,-12],[-9,-10],[-1,-3],[-9,-17],[-11,-1],[-30,8],[-13,-4],[-9,-6],[-15,-30],[-17,-12],[-24,-9],[-2,-4],[3,-5],[8,0],[17,6],[6,-2],[3,-6],[-7,-14],[-31,-26],[5,-5],[13,3],[7,4],[23,27],[30,10],[46,20],[23,-1],[3,0],[7,2],[1,10],[-5,10],[1,1],[9,11],[45,20],[6,-2],[16,-31],[-19,-33],[0,-3],[-1,-6],[-5,-10],[-9,-5],[-12,-6],[-34,-21],[-12,-5],[-14,-1],[-9,-3],[-18,-30],[-9,-4],[-13,-1],[-2,-4],[2,-2],[13,-3],[2,-3],[-4,-10],[6,-5],[4,2],[4,14],[18,33],[17,8],[16,-4],[5,-6],[-4,-21],[-39,-87],[4,-8],[5,2],[7,8],[6,12],[9,27],[21,45],[7,20],[1,15],[6,11],[17,10],[4,3],[55,26],[26,18],[8,3],[14,-2],[6,-8],[-9,-14],[-12,-11],[-17,-11],[-30,-12],[-5,-11],[5,-12],[4,-3],[5,0],[2,4],[-5,8],[6,9],[38,12],[18,15],[19,2],[5,4],[6,9],[10,5],[18,-1],[18,-6],[5,-4],[11,-10],[26,-12],[51,-12],[2,-6],[-15,-20],[1,-12],[-6,-12],[-8,-3],[-6,3],[-3,4],[3,11],[-6,2],[-10,-7],[-13,-18],[-21,-14],[-41,-17],[-33,-7],[-18,-8],[-23,-27],[4,-2],[8,1],[2,-3],[-3,-6],[-19,-8],[-17,-12],[-12,-12],[-4,-10],[11,3],[20,21],[34,9],[10,31],[14,9],[32,9],[46,5],[12,4],[17,-2],[-1,-11],[-5,-10],[-8,-5],[-8,-12],[-17,-8],[-14,-26],[-24,-15],[-13,-4],[-15,-1],[-14,-6],[-19,-29],[3,-2],[5,2],[12,16],[9,5],[12,4],[12,0],[12,2],[36,28],[33,11],[12,22],[8,4],[6,1],[20,2],[9,4],[3,11],[-14,14],[8,13],[-1,2],[5,10],[12,4],[10,-3],[10,-7],[45,-53],[1,0],[9,-16],[27,-30],[6,-10],[0,-11],[-8,-7],[-10,-3],[-21,4],[-19,8],[-18,2],[-20,-7],[-14,-13],[-18,-12],[-12,-5],[-37,-3],[-23,-11],[-39,-14],[-7,-1],[-25,7],[-12,1],[-25,-6],[-2,-4],[1,-3],[22,4],[34,-6],[13,0],[51,15],[8,1],[14,2],[39,-7],[20,-6],[21,-9],[4,-2],[20,2],[31,8],[13,0],[15,-3],[21,-16],[18,-6],[9,-8],[9,-15],[3,-12],[-8,-14],[-3,-4],[-7,-2],[-26,7],[-10,-1],[-18,-7],[-34,5],[-25,7],[-19,14],[-14,4],[-20,4],[-34,-2],[-33,6],[-5,1],[-12,-3],[-22,-10],[-2,-6],[7,0],[28,10],[4,0],[26,-6],[37,0],[21,-7],[0,-6],[-22,-4],[-41,4],[-26,0],[-3,0],[-3,-4],[2,-3],[2,0],[12,-3],[17,3],[6,-3],[-5,-6],[-16,-7],[-15,-2],[2,-13],[-7,-11],[2,-5],[6,1],[21,24],[5,3],[11,3],[1,0],[7,7],[10,5],[25,-6],[29,-17],[14,-4],[3,-3],[1,-2],[-2,-3],[-10,-4],[-22,-2],[-30,5],[-8,-2],[-5,-4],[22,-9],[28,-13],[3,-8],[-3,-4],[-12,1],[-18,6],[-5,-3],[2,-6],[14,-3],[15,-3],[15,-2],[9,0],[7,-2],[3,-4],[-5,-2],[-15,1],[-19,3],[-17,2],[-14,2],[-8,1],[-3,-1],[-5,-7],[-12,-2],[-55,15],[-8,2],[-10,-4],[-4,-8],[2,-2],[9,-3],[7,0],[12,0],[23,-7],[19,-9],[29,1],[39,-9],[2,-8],[-2,-3],[-5,-2],[-12,-1],[-26,2],[-22,-1],[-15,-4],[-2,-4],[2,-2],[17,3],[18,-5],[-1,-4],[-7,-2],[-7,-1],[-9,1],[-2,-3],[1,-3],[8,-3],[8,0],[21,2],[16,3],[18,-5],[13,2],[9,-2],[3,-5],[-10,-18],[4,-4],[8,5],[13,24],[8,3],[13,-3],[3,-6],[-11,-20],[2,-3],[6,2],[18,16],[10,5],[8,-3],[1,-5],[-2,-5],[3,-5],[13,5],[10,9],[14,-5],[15,6],[6,-2],[-1,-6],[-6,-4],[-21,-11],[-21,-6],[-25,4],[-47,-18],[-2,-4],[3,-3],[15,6],[8,-3],[1,-3],[-9,-13],[2,-2],[14,6],[22,16],[9,4],[9,-2],[1,-6],[-3,-5],[-20,-18],[4,-3],[12,5],[11,10],[3,6],[6,2],[9,-3],[2,-2],[6,-7],[-4,-17],[-6,-9],[6,-6],[2,-5],[-11,-8],[-4,-7],[2,-3],[8,2],[9,6],[8,8],[7,-1],[1,-2],[-8,-15],[-2,-9],[4,-5],[5,2],[7,7],[7,13],[0,14],[5,8],[4,3],[14,-4],[1,-12],[11,-2],[2,-4],[-10,-25],[-7,-10],[-28,-7],[-3,-6],[2,-4],[4,-1],[7,0],[8,-3],[13,-5],[5,2],[3,22],[6,9],[12,7],[9,12],[4,0],[-2,-6],[2,-8],[6,-3],[4,-4],[-1,-14],[-14,-39],[1,-11],[6,-7],[7,10],[-1,15],[5,8],[2,15],[12,18],[0,9],[12,20],[3,1],[11,-4],[9,0],[5,-5],[0,-8],[-14,-37],[0,-8],[4,-8],[8,-7],[8,-22],[5,-1],[5,6],[0,9],[-20,30],[1,8],[12,20],[5,5],[11,7],[13,6],[12,17],[8,3],[26,-15],[2,-4],[-2,-3],[-15,-1],[-7,-3],[-4,-3],[-7,-15],[4,-15],[-2,-8],[-6,-10],[-13,-12],[-3,-5],[3,-6],[5,1],[9,14],[19,17],[9,3],[5,-4],[-11,-17],[5,-2],[7,2],[5,4],[14,23],[12,2],[13,-4],[12,-9],[1,-9],[-4,-5],[-19,-7],[-2,-4],[1,-3],[30,11],[6,-3],[1,-5],[-3,-10],[3,-7],[13,-8],[2,-5],[-2,-8],[-10,-13],[2,-5],[17,-4],[4,-12],[-7,-10],[-1,0],[-16,-5],[-45,6],[-15,6],[-6,-2],[-2,-3],[2,-3],[33,-9],[14,-6],[-5,-4],[-22,2],[-7,-2],[-10,-8],[-5,-8],[6,-4],[28,3],[16,5],[30,16],[6,0],[6,-5],[-4,-6],[-58,-22],[-19,-15],[-4,-7],[2,-5],[12,6],[6,9],[13,7],[40,8],[25,11],[12,5],[16,3],[12,0],[7,-3],[2,-4],[-2,-6],[-7,-12],[-20,-13],[-10,-16],[0,-9],[6,-3],[3,6],[-2,2],[8,14],[33,23],[11,23],[0,10],[5,7],[9,-2],[2,-7],[3,-1],[4,1],[3,5],[-1,3],[5,8],[10,-3],[5,-10],[-11,-22],[-19,-8],[-7,-11],[-1,-9],[3,-16],[-4,-10],[-15,-8],[-20,-5],[-14,-19],[-9,-5],[-10,-3],[-2,-3],[1,-3],[7,-1],[15,4],[9,7],[9,12],[7,4],[6,-2],[0,-7],[-12,-30],[5,-4],[5,2],[19,38],[8,7],[4,3],[13,3],[2,3],[7,3],[11,-6],[6,-12],[-7,-14],[4,-8],[-2,-8],[2,-9],[-8,-14],[3,-3],[7,1],[7,12],[6,24],[1,26],[4,9],[4,1],[12,-5],[6,-10],[12,-30],[4,-3],[4,1],[2,4],[-8,29],[0,8],[12,21],[-4,8],[3,4],[27,9],[7,-1],[4,-4],[-3,-4],[-7,-2],[-2,-3],[7,-10],[-7,-11],[2,-4],[9,2],[10,14],[7,1],[5,-2],[0,-8],[7,-11],[-3,-3],[1,-3],[10,-7],[-6,-11],[4,-4],[23,-7],[14,-36],[-4,-4],[-12,-3],[-5,-5],[-8,-4],[-7,5],[-4,5],[-5,13],[0,8],[-5,2],[-9,-8],[-21,-2],[-6,-6],[1,-3],[6,-2],[13,0],[18,-8],[10,-21],[-4,-6],[-13,-2],[-14,1],[-9,-3],[-1,-5],[7,-4],[14,0],[22,8],[10,-1],[3,-3],[1,-8],[-5,-4],[-6,-9],[-15,-1],[-21,-9],[-9,0],[-13,7],[-4,-2],[-4,2],[-8,7],[-4,13],[-4,1],[-14,-3],[-3,-5],[7,-8],[3,-7],[-6,-9],[-12,-9],[-12,-1],[-4,-1],[-15,6],[-4,21],[-5,2],[-4,-5],[1,-17],[5,-11],[7,-6],[10,-4],[21,4],[10,-4],[8,1],[11,-5],[6,1],[10,-3],[1,-3],[-4,-6],[2,-5],[16,-4],[2,-13],[-2,-3],[-8,0],[-15,3],[-17,-6],[-7,0],[-16,7],[-18,3],[-10,4],[-5,5],[-4,10],[-4,1],[-5,1],[-1,-8],[8,-16],[21,-10],[17,-2],[10,-5],[2,-5],[-2,-10],[6,-18],[-4,-11],[-7,-1],[-12,5],[-15,15],[-2,4],[-10,3],[-2,-4],[2,-9],[25,-24],[-5,-4],[-15,3],[-5,-3],[4,-6],[11,-7],[1,-11],[-3,-5],[-17,7],[-3,-1],[-5,-7],[-8,-1],[-10,2],[-6,4],[-1,5],[-19,6],[-18,45],[-3,15],[-3,3],[-4,1],[-1,-16],[11,-42],[-5,-5],[-10,-4],[-12,1],[-5,-2],[-2,-4],[9,-5],[18,2],[12,-2],[4,-9],[-8,-12],[-8,-1],[-4,1],[-3,10],[-5,2],[-5,-9],[5,-12],[25,-7],[0,-5],[-4,-5],[-4,-1],[-29,12],[-4,-5],[4,-8],[20,-11],[7,-26],[12,-11],[-3,-5],[-12,0],[-4,-5],[1,-3],[13,-5],[-9,-12],[0,-7],[-3,-5],[-6,-2],[-2,-4],[-1,-1],[2,-8],[-8,-13],[-8,0],[-3,13],[-13,1],[-2,3],[3,5],[-2,5],[-13,7],[-1,5],[2,4],[5,3],[3,6],[-6,2],[-3,-1],[-5,-6],[-13,-2],[-5,-6],[-1,-10],[-5,-2],[-6,5],[-4,12],[3,5],[11,8],[2,7],[-6,4],[-9,-5],[-6,-8],[-5,-2],[-4,2],[-2,9],[4,18],[20,33],[-3,4],[-7,-4],[-4,-4],[-13,-21],[-6,-18],[1,-13],[-5,-15],[-11,-5],[-8,3],[-1,4],[1,3],[-5,12],[0,11],[-16,7],[-1,3],[2,4],[11,6],[3,5],[-2,5],[2,4],[28,14],[3,7],[-5,1],[-22,-7],[-23,-14],[-12,5],[-8,6],[-5,14],[3,6],[16,4],[3,4],[23,7],[3,5],[-5,6],[-2,5],[5,9],[-1,2],[-9,-4],[-8,-14],[-30,-11],[-15,7],[-2,4],[1,3],[46,23],[2,5],[-5,2],[-6,-2],[-25,-10],[-15,-2],[-6,2],[-3,6],[2,9],[-2,6],[10,25],[11,12],[26,16],[18,8],[8,16],[1,11],[7,14],[12,13],[19,15],[3,5],[-4,3],[-5,-2],[-12,-7],[-16,-12],[-5,-13],[-9,-8],[-8,-18],[-5,-4],[-11,-5],[-22,-4],[-24,-12],[-33,-3],[-13,-5],[-7,2],[-3,3],[1,15],[5,6],[19,12],[21,27],[12,33],[-5,4],[-5,-7],[-7,-19],[-17,-24],[-13,-9],[-14,-1],[-5,1],[-16,6],[-3,10],[3,9],[-3,6],[-13,3],[-5,-2],[-2,-3],[3,-6],[-2,-4],[-11,4],[-2,4],[6,14],[-2,4],[-14,14],[-14,8],[-2,14],[-6,3],[-4,6],[-1,6],[9,17],[-7,1],[-5,-3],[-12,-16],[-15,-6],[-12,3],[-12,11],[-17,5],[-4,0],[-23,-1],[-22,8],[-5,-4],[3,-7],[4,-3],[15,-4],[27,0],[20,-4],[4,-3],[6,-17],[8,-7],[3,-5],[-2,-4],[-6,-2],[-13,4],[-16,9],[-3,-4],[6,-8],[22,-11],[4,-7],[-2,-4],[-13,0],[-3,0],[-21,8],[1,5],[-3,5],[-17,26],[-7,0],[1,-4],[-3,-3],[-1,-2],[-6,2],[-4,6],[-6,1],[0,-3],[-1,-3],[20,-24],[6,-12],[1,-18],[33,-26],[8,-4],[4,-2],[16,-4],[4,-3],[3,-6],[-9,-15],[2,-5],[-3,-5],[-8,-3],[-13,4],[-13,-10],[-17,5],[-9,17],[-5,2],[-3,-2],[-4,-6],[3,-14],[-3,-5],[-3,-1],[-9,3],[-6,5],[-8,22],[4,27],[-2,3],[-15,4],[-3,14],[-5,1],[-3,0],[-11,-7],[-6,2],[-3,8],[-7,2],[-17,-8],[-22,2],[-8,-1],[-1,-3],[2,-5],[7,-2],[13,1],[17,-5],[9,1],[13,-4],[1,-3],[23,-6],[4,-6],[0,-7],[-5,-8],[-15,2],[-2,-3],[7,-12],[-10,-9],[2,-2],[13,-5],[6,-5],[5,-2],[8,3],[3,-3],[1,-2],[-7,-11],[-5,-10],[2,-2],[6,0],[16,8],[7,-2],[2,-3],[-3,-5],[-7,-4],[-4,-5],[9,-17],[-7,-7],[-5,-19],[-17,-16],[-1,-6],[4,-1],[7,4],[19,25],[22,18],[20,5],[14,-2],[4,-2],[2,-3],[-7,-15],[1,-8],[-5,-11],[2,-4],[13,-5],[16,5],[9,-3],[1,-4],[-4,-12],[-7,0],[-15,-6],[-9,-10],[6,-3],[4,1],[12,-3],[4,-6],[-1,-6],[4,-8],[8,-3],[10,0],[-3,-9],[-11,-14],[-5,-10],[2,-3],[11,3],[14,19],[10,2],[1,-3],[-3,-8],[-10,-9],[-3,-6],[2,-5],[6,-3],[9,-18],[2,-12],[-1,-17],[0,-4],[0,-4],[1,-4],[0,-4],[1,-4],[3,-1],[2,3],[1,3],[0,7],[-1,9],[0,7],[8,28],[7,15],[5,0],[5,-3],[10,-19],[4,-1],[7,2],[10,7],[9,-4],[3,-6],[-13,-17],[-22,-19],[-5,-6],[-5,-12],[3,-10],[2,-3],[3,-4],[4,-3],[3,1],[1,3],[-2,5],[-5,11],[4,8],[3,2],[7,-1],[7,-9],[7,1],[-4,17],[6,15],[4,2],[4,-2],[2,-4],[0,-8],[-2,-5],[1,-5],[3,-2],[8,0],[1,-2],[3,-11],[5,-2],[3,7],[-3,8],[-10,26],[6,11],[10,-1],[10,-6],[3,-9],[-4,-9],[4,-3],[8,4],[5,-2],[1,-5],[-5,-20],[-14,-30],[5,-9],[9,-5],[10,3],[4,2],[3,4],[3,5],[5,3],[3,-3],[-2,-4],[-4,-7],[-3,-6],[3,-5],[3,2],[5,10],[5,4],[7,3],[10,-5],[5,-17],[-1,-3],[-11,-5],[-3,-6],[4,-11],[-1,-5],[-8,-1],[-27,7],[-11,-2],[-3,-2],[-2,-5],[2,-2],[7,1],[8,-3],[3,-11],[8,1],[6,-2],[1,-3],[-6,-10],[1,-4],[5,-3],[6,1],[9,-3],[8,-21],[3,-4],[30,-11],[8,2],[13,7],[8,-4],[2,-6],[-3,-7],[-19,-15],[-12,-28],[10,-11],[24,-8],[7,-8],[7,-14],[-4,-22],[2,-17],[-10,-16],[3,-8],[1,-18],[-4,-7],[-6,-1],[-5,2],[-5,8],[-8,45],[-14,26],[-7,16],[2,5],[-4,10],[-15,19],[-7,3],[-3,-4],[1,-5],[17,-19],[2,-6],[0,-16],[8,-17],[-2,-12],[-8,-11],[9,-17],[-2,-12],[6,-17],[-5,-12],[3,-5],[4,-2],[7,4],[7,-4],[3,-11],[-4,-9],[-1,-9],[9,-23],[6,-4],[3,-7],[-5,-7],[-7,-3],[-13,3],[-12,11],[-7,3],[-6,-3],[-3,-6],[1,-9],[7,-17],[16,-16],[2,-5],[-5,-12],[-20,-12],[-5,3],[-5,13],[-15,15],[-3,9],[-1,5],[11,23],[-2,6],[-4,2],[-5,-2],[-8,-10],[-6,-3],[-14,7],[-6,7],[-2,6],[8,17],[-2,3],[-4,1],[-3,-1],[-5,-5],[-7,-18],[-3,-2],[-4,2],[-3,7],[2,13],[-13,6],[-6,12],[-6,3],[-4,-4],[9,-24],[-2,-4],[-4,-2],[-16,6],[-15,12],[-9,19],[-6,25],[-7,3],[-4,-7],[6,-24],[-5,-11],[5,-10],[-2,-6],[-5,1],[-3,3],[-15,39],[-13,4],[-6,9],[-4,9],[0,9],[-16,2],[-8,4],[-14,22],[-16,13],[-6,12],[-2,13],[-5,13],[-4,2],[-13,5],[-4,5],[-7,2],[-4,-6],[4,-17],[19,-40],[-3,-11],[-4,-2],[-7,5],[-11,28],[-6,6],[-40,21],[-28,27],[-12,4],[-14,-6],[-21,6],[-1,-8],[7,-16],[7,-15],[14,-19],[12,-10],[17,-6],[3,-4],[5,-10],[2,-21],[10,-18],[4,-3],[10,-7],[6,-9],[12,-2],[2,-6],[-3,-13],[2,-6],[3,-1],[5,2],[8,13],[7,2],[8,-4],[-2,-5],[-3,-2],[-2,-4],[1,-3],[7,-1],[10,5],[5,-3],[-2,-5],[-7,-6],[-2,-4],[1,-3],[4,-1],[10,5],[9,7],[12,-4],[25,-39],[21,-18],[5,-13],[29,-10],[11,-9],[9,-19],[-3,-8],[1,-9],[3,-4],[10,-2],[3,-4],[-2,-9],[-7,-10],[-1,-5],[5,-10],[4,0],[2,5],[0,10],[3,5],[4,1],[10,-5],[5,-17],[8,-2],[8,4],[6,-3],[8,-12],[-2,-5],[-6,-2],[-4,-6],[4,-14],[-9,-21],[7,-16],[3,-11],[-3,-7],[-7,-2],[-6,0],[-26,9],[-9,0],[-31,11],[-21,13],[-17,6],[-15,-5],[-14,5],[-14,17],[-12,7],[-23,5],[-61,3],[-21,7],[-49,29],[-29,8],[-20,19],[-10,18],[-5,2],[-5,-2],[-8,3],[-6,17],[4,7],[7,4],[1,4],[-3,8],[3,6],[-3,6],[-8,0],[-10,-6],[-16,11],[-6,2],[-4,-5],[9,-14],[-4,-4],[-5,2],[-12,13],[-26,10],[-13,19],[-38,11],[-10,6],[-3,9],[-11,4],[-6,8],[-7,2],[-2,3],[5,7],[19,9],[4,4],[1,5],[-9,1],[-17,-12],[-15,-2],[-4,-11],[-3,-1],[-9,3],[-12,17],[-20,11],[-8,15],[-5,17],[-9,15],[-5,4],[-24,6],[-6,5],[3,7],[4,3],[29,-7],[16,0],[11,3],[12,8],[7,19],[14,6],[3,9],[-7,1],[-20,-8],[-7,2],[-2,4],[9,19],[-3,4],[-3,1],[-8,-6],[-4,1],[-4,12],[-13,6],[-6,12],[-5,1],[-5,-9],[6,-12],[-1,-7],[-10,2],[-6,9],[-5,1],[-4,-2],[-6,-11],[-4,4],[10,29],[0,9],[-4,7],[-1,10],[-4,-1],[-6,-7],[-8,-23],[-5,-4],[-5,1],[-8,17],[-8,2],[-4,4],[9,20],[-2,5],[-7,4],[-8,-11],[-6,2],[-5,6],[-22,4],[-7,9],[-1,5],[3,8],[-1,3],[-6,1],[-9,-8],[-3,4],[3,12],[6,3],[2,4],[-3,3],[-7,2],[-8,22],[-5,1],[-5,-6],[-6,-2],[-7,2],[-13,19],[-3,4],[5,15],[11,16],[11,10],[2,9],[0,11],[-5,1],[-8,-22],[-20,-19],[-8,-36],[-6,2],[-1,22],[8,30],[12,6],[3,6],[-2,3],[-6,2],[-23,-13],[-16,3],[-3,-8],[4,-13],[-1,-5],[-13,-9],[-10,-21],[-10,-5],[-2,4],[11,26],[-3,6],[2,6],[4,3],[2,4],[-8,12],[10,39],[-2,4],[-3,1],[-8,-4],[-4,-12],[-1,-19],[-3,-5],[-6,-1],[-5,7],[-6,2],[-4,-10],[-4,-1],[-8,16],[-17,11],[-6,8],[5,20],[11,11],[-1,6],[-7,2],[-4,-3],[-9,-10],[-2,-7],[-13,-4],[-3,-8],[6,-11],[28,-25],[9,-13],[-2,-5],[-13,-6],[-2,-7],[3,-6],[8,-8],[-1,-4],[-9,-4],[-13,2],[-16,5],[-12,9],[-9,3],[-7,-5],[-9,3],[-9,5],[-23,24],[-20,8],[-6,-3],[-2,-8],[10,-16],[11,-8],[3,-4],[-1,-3],[-18,-2],[-1,-12],[-3,-2],[-21,3],[-18,-3],[-13,-9],[-1,-3],[6,-8],[-1,-4],[-4,-2],[-23,-1],[-10,4],[-12,2],[-7,-7],[10,-10],[-2,-5],[-7,-1],[-11,3],[-22,14],[-12,2],[-12,-2],[-13,-7],[-7,1],[-6,15],[-8,8],[-10,2],[-8,-9],[-16,4],[-4,6],[1,5],[-3,6],[-16,3],[-3,4],[1,4],[5,4],[1,7],[-14,15],[-11,31],[9,25],[5,4],[2,7],[-4,12],[3,15],[13,22],[16,18],[32,9],[19,9],[2,10],[-6,17],[-3,17],[1,4],[3,2],[13,-4],[3,6],[-13,10],[3,8],[4,2],[10,-2],[7,-6],[9,-1],[12,1],[9,4],[8,-2],[78,-31],[22,-1],[21,9],[59,-13],[7,3],[27,24],[4,-1],[2,-3],[0,-7],[4,-5],[14,-3],[8,1],[7,5],[25,30],[6,4],[13,1],[4,3],[11,-2],[5,-5],[2,1],[21,-5],[15,4],[2,10],[-1,8],[-28,54],[-30,26],[-16,22],[-6,15],[-12,7],[-5,8],[17,31],[20,13],[34,37],[29,17],[9,22],[7,7],[22,14],[18,5],[16,-2],[6,5],[-9,10],[-1,7],[4,10],[9,11],[6,10],[-1,20],[4,11],[8,3],[13,-3],[11,2],[8,4],[8,14],[14,15],[6,14],[-1,8],[-11,13],[-8,15],[0,10],[5,19],[-5,16],[-10,7],[-1,14],[-12,16],[3,11],[0,9],[-5,7],[-28,18],[-11,14],[-6,41],[-13,31],[-25,6],[-5,5],[1,6],[-5,1],[-8,-9],[-11,-1],[-10,13],[-10,6],[-5,7],[2,6],[27,9],[3,5],[-11,4],[-17,-9],[-9,0],[12,34],[-9,23],[-17,10],[-16,2],[-5,-7],[22,-19],[7,-16],[-2,-5],[-28,-4],[-9,2],[-8,6],[-36,41],[3,8],[11,7],[2,8],[-8,-2],[-11,-9],[-6,-1],[-10,5],[-4,5],[2,3],[19,8],[2,6],[-8,2],[-21,-5],[-6,3],[1,8],[12,1],[3,4],[-10,3],[-2,3],[2,4],[22,10],[2,4],[-12,10],[-13,-3],[-11,-13],[-9,-20],[-3,-1],[1,-18],[-8,15],[-5,3],[-12,19],[-14,5],[-5,-8],[1,-5],[-3,-9],[-11,-9],[-35,-18],[-42,-30],[-9,-4],[-15,-1],[-8,9],[0,5],[4,11],[9,13],[1,9],[-4,8],[-10,6],[-9,13],[0,7],[6,11],[27,2],[38,-6],[10,10],[7,4],[12,0],[8,3],[2,5],[1,1],[0,11],[-8,26],[-29,28],[-19,2],[-8,1],[-15,7],[-12,10],[-13,17],[-2,4],[11,22],[12,-3],[14,-17],[7,-1],[1,6],[-10,21],[-14,0],[-5,1],[-13,4],[-7,-15],[-4,-1],[-10,1],[-15,2],[-16,-3],[-4,2],[-2,3],[1,4],[23,6],[5,8],[-3,4],[1,3],[15,6],[4,5],[-9,3],[-11,-3],[-9,7],[-10,3],[-8,1],[-12,-1],[-4,4],[2,4],[5,2],[8,5],[6,6],[0,2],[-4,2],[-6,-2],[-4,-3],[-6,-5],[-7,-2],[-6,-4],[-5,-4],[-6,0],[-6,0],[-6,-1],[-2,-4],[1,-2],[11,-2],[2,-2],[-2,-4],[-4,-2],[-1,-5],[-6,-3],[-3,-1],[-5,3],[-7,14],[1,27],[11,32],[-3,13],[-4,16],[-4,5],[-25,4],[-10,-6],[-6,0],[-8,3],[-9,-4],[-6,0],[-11,8],[-4,21],[-3,4],[-16,0],[-5,4],[-2,7],[-13,8],[-20,5],[-4,4],[14,21],[23,5],[1,3],[-14,13],[-6,15],[-9,1],[-3,-5],[9,-10],[0,-5],[-7,-2],[-6,5],[-9,1],[-10,-6],[1,-6],[12,-4],[3,-5],[-4,-10],[-8,-5],[-7,-11],[-1,-2],[-8,-1],[-6,10],[-17,-4],[-6,6],[1,7],[-6,1],[-13,-6],[-7,-4],[-2,-12],[14,-4],[30,-21],[11,-1],[7,2],[14,3],[15,-3],[9,-13],[12,-25],[2,-4],[5,-18],[-2,-15],[-6,-5],[-15,-6],[-59,7],[-30,-6],[-13,1],[-7,5],[-8,12],[-5,2],[-9,14],[-11,-2],[-16,2],[-15,-1],[-16,9],[-14,3],[-108,13],[-4,-2],[-1,-4],[3,-4],[32,-12],[10,-7],[46,-48],[0,-7],[-15,-9],[-5,1],[-9,6],[-27,29],[-23,16],[-48,6],[-42,26],[-28,7],[-39,22],[-10,0],[-2,-5],[12,-11],[25,-14],[68,-29],[11,-6],[7,-8],[0,-9],[-16,-7],[-5,-9],[-12,-4],[-7,5],[0,7],[-4,4],[-37,9],[-26,16],[-15,6],[-16,2],[-29,-11],[-9,-1],[-36,2],[-27,6],[-16,-1],[-31,-6],[-20,4],[-19,-5],[-9,3],[5,11],[0,7],[-9,0],[-13,-5],[-67,5],[-7,-4],[-1,-5],[3,-2],[9,-3],[8,-2],[9,0],[6,-1],[3,-6],[-8,-2],[-14,-1],[-11,-1],[-6,0],[-6,-1],[-7,0],[-4,0],[-11,5],[-20,16],[-26,12],[-19,15],[-6,16],[0,20],[29,34],[-1,7],[-7,1],[-4,-2],[-10,-11],[-12,-15],[0,-5],[-20,-15],[-5,2],[2,14],[-4,4],[-6,0],[-8,12],[-5,1],[-5,-3],[-6,-13],[20,-17],[1,-8],[-7,-3],[-9,1],[-10,4],[-22,1],[-12,-2],[-25,3],[-3,-7],[11,-7],[0,-4],[-11,-4],[-20,4],[-25,11],[-15,11],[1,4],[4,3],[8,-1],[17,-5],[2,4],[-4,4],[-42,25],[-27,3],[-16,6],[-13,12],[-2,4],[1,8],[-6,8],[-16,17],[-28,35],[1,13],[18,11],[-2,10],[-4,5],[-24,10],[-1,8],[3,2],[16,-1],[53,-12],[22,-1],[11,3],[12,-1],[8,-2],[16,-15],[15,-5],[46,3],[35,-3],[13,9],[16,0],[5,4],[-3,3],[-32,4],[-31,12],[-15,12],[-5,14],[-7,5],[-6,0],[-15,-7],[-11,0],[-20,9],[-46,2],[-57,14],[-34,3],[-26,7],[-12,8],[-5,19],[2,21],[4,14],[3,2],[5,25],[0,13],[-7,16],[-8,20],[1,29],[14,14],[22,11],[1,6],[-10,4],[-15,-1],[-7,5],[2,35],[-4,23],[16,38],[8,6],[12,5],[-1,34],[11,8],[9,-1],[8,-3],[3,2],[1,5],[-7,13],[4,22],[26,53],[61,61],[63,51],[62,31],[55,18],[71,4],[50,8],[59,-6],[37,-10],[14,-11],[2,-6],[-6,-11],[-11,-9],[-48,-27],[-54,-40],[-20,-28],[-17,-37],[-21,-25],[-18,-14],[-10,-16],[-5,-33],[2,-9],[5,-10],[8,-9],[6,-15],[28,-34],[-3,-16],[-15,-33],[-3,-17],[2,-15],[18,-43],[39,-46],[32,-38],[35,-27],[28,-12],[8,-7],[2,-7],[8,-7],[0,-3],[-7,-3],[-18,0],[-11,-10],[-10,-4],[-30,-1],[-79,-44],[-12,-4],[-19,-1],[-3,-2],[-1,-6],[6,-4],[13,-1],[17,5],[85,43],[37,-2],[12,5],[12,-1],[9,-10],[2,-10],[-7,-3],[-8,1],[-4,-5],[14,-9],[3,-20],[12,-8],[7,3],[5,9],[-6,16],[-1,4],[5,30],[-3,37],[3,18],[23,0],[6,4],[5,7],[-9,25],[4,10],[-2,8],[-6,8],[-11,2],[-10,-2],[-28,-10],[-17,10],[-18,3],[-13,5],[-8,9],[-4,16],[-8,10],[-13,13],[-23,13],[-9,9],[1,6],[7,4],[30,4],[6,4],[2,11],[24,8],[-2,6],[-11,4],[2,11],[-5,6],[3,8],[12,-1],[12,-4],[35,-1],[68,-59],[10,-15],[8,-8],[5,2],[3,10],[-13,17],[-62,51],[-4,12],[2,9],[5,3],[33,3],[7,4],[1,5],[-2,2],[-9,1],[-5,-2],[-13,1],[-9,7],[1,4],[-4,4],[-12,1],[-17,-13],[-11,-1],[-25,5],[-14,7],[-10,10],[-2,23],[-14,16],[4,49],[7,8],[17,10],[32,-5],[113,-44],[5,5],[-11,11],[-34,16],[-33,8],[-19,9],[-23,19],[-11,0],[-13,-9],[-24,3],[-2,6],[13,8],[2,10],[6,4],[7,0],[8,-12],[12,-1],[6,2],[-1,14],[14,0],[8,-4],[26,-1],[17,-8],[41,-9],[73,-7],[5,4],[-7,6],[-13,5],[-57,3],[-48,17],[-45,8],[-11,6],[-3,6],[3,13],[7,7],[27,12],[11,0],[9,-12],[21,-11],[7,0],[4,2],[1,4],[-14,15],[-3,5],[2,8],[18,9],[21,5],[38,-3],[13,-11],[6,-13],[9,-7],[7,1],[4,2],[1,5],[-11,20],[-8,7],[-23,10],[2,7],[32,13],[17,12],[16,6],[20,0],[12,4],[12,12],[9,3],[49,-4],[39,2],[23,6],[25,-3],[27,-24],[5,-11],[4,-48],[8,-31],[15,-11],[21,-4],[20,-11],[12,-11],[4,-20],[-8,-23],[12,-23],[13,-11],[-5,-21],[-19,-22],[-3,-10],[-32,-21],[-36,-40],[-8,-17],[7,-3],[7,5],[1,5],[22,27],[27,23],[9,5],[6,-1],[4,-5],[-11,-34],[-17,-12],[-12,-33],[7,-9],[16,-4],[4,-4],[-2,-4],[-10,-1],[-9,4],[-8,1],[-17,-8],[5,-5],[19,-4],[-3,-15],[-15,-11],[-1,-3],[7,-4],[9,3],[20,21],[32,20],[3,7],[-2,5],[-13,12],[2,6],[4,2],[17,1],[2,6],[-4,8],[4,8],[11,-3],[21,-16],[36,-20],[8,-1],[4,2],[1,5],[-7,9],[-24,13],[-8,9],[-15,7],[-11,9],[8,12],[18,11],[10,19],[9,0],[5,-5],[-1,-18],[19,-23],[-7,-17],[5,-6],[7,-2],[8,3],[22,28],[6,3],[8,-1],[14,-17],[7,-37],[-5,-21],[-5,-5],[-5,-13],[6,-7],[6,-3],[20,-4],[24,-21],[11,-2],[5,1],[2,5],[-4,4],[-16,9],[-7,8],[-10,17],[-4,6],[-3,11],[3,8],[4,3],[25,-2],[17,-12],[3,-10],[-4,-22],[29,-33],[3,-2],[1,-3],[6,-4],[7,-2],[6,2],[1,4],[0,5],[-3,5],[-4,5],[-6,2],[-7,4],[-5,4],[-2,4],[3,3],[5,0],[6,-1],[5,-4],[9,-6],[7,-7],[1,-5],[1,-7],[5,-9],[8,-6],[5,0],[4,2],[1,3],[-6,16],[-27,31],[-27,7],[-7,12],[-2,18],[-8,9],[-9,5],[-25,3],[-8,4],[-5,7],[7,29],[10,5],[11,-4],[-3,-17],[8,-9],[17,1],[0,7],[-8,7],[5,8],[28,-11],[26,-2],[23,-16],[11,-2],[29,4],[1,3],[-4,3],[-24,3],[-25,14],[-32,7],[-27,10],[-14,8],[-6,6],[-5,14],[10,19],[15,12],[30,14],[5,-1],[5,5],[30,9],[32,15],[26,-4],[24,2],[15,-2],[11,-15],[13,-7],[53,-10],[3,-4],[-8,-20],[3,-4],[11,4],[3,9],[14,11],[15,-3],[17,-8],[16,-3],[21,1],[10,-1],[7,-9],[5,-30],[20,-23],[-4,-12],[-27,-15],[-62,-9],[-25,-10],[-20,-16],[-31,-42],[2,-3],[5,0],[11,7],[41,48],[12,5],[47,7],[12,-4],[4,-4],[-4,-7],[-14,-10],[-9,-6],[-9,-9],[-7,-5],[-7,-13],[-5,-13],[-5,-6],[-5,-5],[-5,-6],[-6,-6],[-7,-5],[-4,-5],[0,-5],[6,-2],[7,3],[6,5],[7,10],[3,4],[3,3],[2,5],[6,5],[9,19],[7,10],[4,4],[3,4],[10,8],[21,10],[6,4],[4,10],[12,7],[24,1],[15,-3],[30,-4],[16,-6],[10,-6],[7,-8],[2,-9],[-5,-22],[-12,-22],[-12,-8],[-12,0],[-8,-3],[-9,-9],[-19,-9],[-18,-2],[-20,3],[-8,-2],[-2,-4],[3,-3],[20,-4],[3,-4],[-4,-8],[-36,-21],[-2,-7],[5,-2],[12,4],[42,29],[11,4],[5,-3],[-3,-7],[-16,-14],[-5,-9],[14,-15],[0,-6],[-6,-19],[-19,-17],[-4,-8],[6,-5],[34,28],[8,19],[-3,19],[7,16],[22,23],[4,2],[12,9],[5,9],[5,2],[6,-2],[-6,-15],[3,-1],[6,1],[26,20],[12,4],[7,-2],[3,-4],[-6,-14],[-17,-14],[-21,-37],[-5,-4],[-15,-4],[1,-6],[9,-2],[2,-2],[0,-8],[-16,-31],[6,-5],[10,4],[25,61],[19,23],[9,1],[4,-8],[-3,-34],[5,-4],[13,2],[2,-5],[-2,-5],[-16,-13],[-19,-48],[3,-3],[8,3],[6,6],[3,13],[11,24],[6,5],[6,2],[16,-3],[4,-6],[-13,-22],[-1,-10],[-6,-17],[-9,-6],[-3,-7],[3,-3],[8,2],[9,9],[17,33],[15,15],[9,21],[-1,7],[15,21],[-3,9],[4,7],[18,9],[6,7],[8,15],[5,2],[4,2],[11,-2],[7,-6],[21,-4],[15,-5],[1,-2],[15,-9],[37,-12],[3,-1],[10,-8],[7,-8]],[[8212,6509],[6,4],[28,-5],[10,0],[18,-4],[6,-5],[-11,-4],[-15,5],[-28,2],[-13,4],[-1,3]],[[8257,6467],[-4,3],[4,5],[12,3],[6,-3],[-2,-6],[-16,-2]],[[8512,6350],[-3,1],[-2,4],[1,10],[5,6],[5,-1],[3,-9],[-5,-10],[-4,-1]],[[8535,6340],[-9,4],[1,5],[14,1],[1,-3],[-3,-6],[-4,-1]],[[8554,6324],[-4,5],[3,5],[5,1],[5,-7],[-2,-3],[-7,-1]],[[8455,6392],[-11,-21],[-3,-1],[-5,-1],[-14,5],[-10,-1],[-6,4],[5,7],[6,-2],[12,4],[12,-1],[4,2],[4,6],[6,-1]],[[8457,6354],[-5,0],[-4,1],[-2,2],[0,4],[6,4],[3,-2],[3,-4],[-1,-5]],[[8490,6344],[-6,-5],[-3,4],[-1,3],[0,4],[1,5],[0,7],[3,2],[4,0],[2,-3],[0,-17]],[[8383,5948],[-4,-2],[-4,2],[-1,4],[2,5],[3,2],[5,-2],[2,-4],[-3,-5]],[[8381,5932],[5,5],[5,-2],[24,-20],[1,-3],[-2,-4],[-9,2],[-22,18],[-2,4]],[[8377,5918],[-6,-4],[-4,2],[-2,2],[-2,5],[3,4],[8,-1],[3,-8]],[[8826,5658],[-4,2],[-1,3],[4,6],[6,-3],[1,-3],[-2,-4],[-4,-1]],[[8198,6851],[-8,-4],[-3,1],[-2,3],[0,2],[4,3],[2,4],[5,1],[3,-3],[2,-4],[-3,-3]],[[8280,6701],[7,7],[19,6],[15,-1],[3,-6],[-7,-4],[-14,0],[-16,-5],[-6,0],[-1,3]],[[8247,6698],[-22,12],[-2,5],[2,3],[26,12],[15,16],[13,-2],[5,-9],[-6,-12],[-5,-4],[-12,-17],[-6,-3],[-8,-1]],[[8261,6599],[-3,1],[-3,4],[3,3],[6,-2],[1,-3],[-4,-3]],[[8299,6545],[-6,-1],[-5,-1],[-4,1],[-2,3],[0,3],[4,3],[5,0],[9,-1],[2,-1],[-3,-6]],[[8316,6534],[-5,0],[-4,0],[-4,-1],[-4,0],[-4,2],[3,4],[5,3],[5,0],[6,-1],[4,-5],[-2,-2]],[[8264,6540],[-4,2],[-3,6],[3,6],[5,3],[6,-2],[2,-3],[-3,-11],[-6,-1]],[[8311,6524],[-14,-6],[-4,-1],[0,5],[3,4],[7,1],[8,-3]],[[8383,6466],[-10,0],[-2,5],[4,3],[3,0],[5,-2],[2,-2],[-2,-4]],[[8365,6453],[-7,-2],[-4,0],[-3,2],[-1,4],[2,3],[4,1],[4,-1],[3,-2],[2,-5]],[[8324,6453],[-3,4],[4,3],[5,1],[8,-3],[1,-6],[-6,-1],[-9,2]],[[8394,6405],[-7,2],[-3,0],[-4,1],[-1,2],[2,3],[2,4],[3,2],[5,-1],[3,-3],[3,-4],[-3,-6]],[[8936,6108],[-6,-1],[-3,-1],[-3,1],[-4,1],[-3,3],[1,2],[3,2],[3,3],[4,1],[5,0],[4,-1],[2,-3],[1,-3],[-4,-4]],[[8907,6071],[-6,-1],[-4,2],[0,4],[5,5],[3,1],[3,-1],[3,-4],[-4,-6]],[[8861,6084],[-3,9],[6,10],[29,26],[8,2],[6,-2],[1,-3],[-4,-6],[-11,-8],[-15,-20],[-7,-6],[-10,-2]],[[8930,5904],[-3,-8],[-4,-2],[-15,-1],[-2,4],[8,7],[10,2],[6,-2]],[[8927,5809],[-6,3],[-5,10],[14,9],[6,-2],[1,-3],[-7,-16],[-3,-1]],[[8922,5779],[2,-13],[4,-2],[3,-5],[-6,-11],[-7,-1],[-6,3],[-4,6],[-7,4],[-2,6],[2,8],[3,4],[12,3],[6,-2]],[[8889,5741],[-1,4],[0,2],[1,3],[6,-1],[3,-4],[-4,-6],[-5,2]],[[8900,5725],[-7,-2],[-4,4],[-2,3],[3,3],[3,0],[4,-1],[3,-3],[0,-4]],[[3038,6470],[-10,2],[-6,7],[-2,7],[4,1],[8,-4],[7,-10],[-1,-3]],[[3064,6462],[-8,2],[-1,4],[0,3],[7,3],[5,-2],[7,-4],[-2,-4],[-8,-2]],[[3441,6446],[-3,-2],[-4,1],[-5,1],[-1,3],[-4,2],[-2,2],[-2,4],[3,3],[4,1],[3,-2],[2,-2],[8,-5],[1,-6]],[[3416,6438],[-21,2],[-5,2],[-1,3],[6,4],[15,2],[8,-4],[2,-6],[-4,-3]],[[3119,6377],[-1,5],[2,1],[6,2],[6,-3],[2,-5],[-1,-2],[-6,-1],[-5,1],[-3,2]],[[3320,6385],[-8,1],[-1,3],[7,13],[16,5],[7,-2],[-1,-6],[-13,-4],[-7,-10]],[[3191,6358],[-13,0],[-5,4],[6,5],[8,1],[6,-5],[-2,-5]],[[3041,6314],[-3,-1],[-3,-1],[-6,0],[-4,1],[0,4],[4,3],[5,1],[4,-1],[3,-6]],[[3078,6313],[-10,2],[-7,-1],[-5,3],[-1,4],[4,2],[4,0],[19,1],[4,-4],[-8,-7]],[[3060,6291],[-6,-1],[-15,2],[-7,3],[-2,4],[10,4],[14,-1],[6,-4],[2,-4],[-2,-3]],[[3106,6303],[6,3],[10,-2],[15,4],[5,-5],[-3,-3],[-12,-3],[-15,2],[-6,4]],[[3528,6363],[-5,-1],[-2,3],[1,3],[5,7],[6,7],[8,8],[8,2],[4,-1],[1,-5],[-13,-7],[-10,-15],[-3,-1]],[[3512,6350],[-9,1],[-2,4],[5,5],[7,1],[3,-3],[0,-3],[-4,-5]],[[3489,6351],[3,-4],[0,-3],[-3,-4],[-7,-1],[-5,4],[1,2],[4,5],[7,1]],[[3471,6335],[-10,-7],[-4,-1],[-3,5],[6,5],[5,1],[5,0],[1,-3]],[[3397,6295],[-5,-1],[-3,1],[-1,4],[3,5],[13,7],[6,9],[7,-2],[0,-7],[-8,-5],[-12,-11]],[[5235,4379],[-448,-1],[-39,0]],[[2297,6689],[3,-2],[13,-10],[29,-14],[19,-6],[13,-3],[19,-1],[27,-3],[31,-10],[38,-10],[22,-9],[5,-10],[14,-13],[45,-26],[44,-14],[54,-12],[19,-7],[18,4],[21,-7],[21,6],[59,-23],[9,-1],[4,2],[-3,7],[-12,6],[-6,13],[-17,7],[-2,7],[18,2],[25,-6],[6,1],[3,11],[6,1],[20,-5],[13,-6],[6,-6],[24,-7],[14,-12],[12,-2],[11,-5],[18,-17],[16,-7],[29,-37],[15,-9],[6,-6],[12,-31],[13,0],[1,-4],[-5,-17],[2,-11],[-7,-5],[-6,-2],[-16,2],[-13,-5],[-18,8],[-23,-6],[-8,0],[-6,4],[-7,-1],[2,-7],[8,-7],[-3,-4],[-20,-4],[-18,-1],[-8,-3],[7,-12],[-5,-10],[5,-9],[-1,-4],[-4,-2],[-8,-4],[-25,-7],[-1,-2],[7,-14],[21,-10],[15,-13],[58,3],[19,-5],[28,-12],[33,-2],[21,-7],[64,2],[24,-5],[43,3],[25,5],[10,8],[28,6],[8,-3],[10,-23],[6,6],[-1,18],[12,2],[12,-4],[15,3],[5,-3],[7,0],[5,5],[1,6],[5,8],[11,4],[4,-1],[2,-12],[4,-2],[6,-1],[17,4],[26,15],[13,10],[46,22],[11,8],[7,1],[3,-2],[4,-12],[-2,-14],[2,-6],[6,-2],[5,10],[5,1],[4,-1],[20,-46],[8,-2],[14,15],[4,1],[15,-9],[13,0],[8,-4],[5,-9],[9,-28],[-2,-22],[3,-8],[7,-5],[2,-5],[9,0],[4,5],[5,46],[5,6],[4,1],[7,-19],[2,-26],[5,-18],[8,-2],[5,12],[9,1],[23,-21],[16,-19],[6,-10],[5,-19],[0,-10],[-4,-5],[-12,0],[-15,-4],[-4,2],[-13,-4],[-21,18],[-6,4],[-6,-3],[11,-15],[10,-6],[5,-11],[15,-5],[10,-17],[4,-18],[22,-9],[4,-14],[-2,-8],[2,-7],[13,2],[8,-11],[4,-15],[10,-9],[25,-40],[8,-7],[8,1],[0,6],[-5,8],[-18,21],[-6,12],[-3,2],[-6,20],[-17,18],[-2,5],[4,15],[-1,19],[-7,21],[2,6],[7,5],[-3,12],[8,5],[6,-8],[4,-23],[-9,-11],[9,-15],[4,-3],[8,2],[-5,12],[3,14],[5,3],[4,-3],[3,-9],[18,-18],[3,-1],[5,1],[4,5],[-3,9],[-14,24],[-19,12],[2,6],[10,9],[-3,11],[-21,18],[-9,25],[-10,10],[-3,10],[3,19],[-2,9],[-9,16],[-28,31],[-4,14],[3,9],[10,13],[18,10],[8,9],[-5,16],[3,4],[38,11],[12,12],[5,1],[3,-2],[2,-4],[5,-3],[5,-1],[10,1],[16,5],[6,5],[-5,14],[2,3],[11,-5],[2,-4],[4,1],[2,3],[0,13],[7,-2],[11,-19],[9,-2],[2,2],[-2,7],[-7,6],[-3,11],[2,4],[-3,9],[4,8],[13,9],[3,5],[7,-2],[1,-4],[4,-2],[10,7],[15,3],[7,5],[12,-1],[3,2],[2,4],[-2,25],[6,15],[-1,5],[-5,3],[-15,-4],[-6,2],[-10,-1],[-39,-21],[-19,-3],[2,-14],[-9,-7],[1,-6],[5,-2],[3,-7],[-2,-11],[-5,-5],[-5,-1],[-6,4],[-10,13],[-5,3],[-10,-3],[-16,0],[-7,-19],[-9,-8],[-40,20],[-12,1],[-19,-3],[-5,-6],[2,-11],[17,-6],[2,-5],[7,-7],[0,-5],[-8,0],[-5,2],[-12,-2],[-6,-4],[-5,-1],[-18,8],[-22,-7],[-5,3],[-1,10],[-7,3],[-2,6],[9,9],[-3,8],[-8,5],[-11,-2],[-11,-11],[-7,-2],[-3,5],[1,5],[6,12],[30,38],[2,9],[11,10],[20,5],[38,2],[54,10],[43,20],[14,9],[18,4],[24,15],[17,6],[11,9],[9,1],[14,-14],[9,-4],[11,-1],[9,-6],[24,-30],[5,-26],[7,-8],[3,-20],[12,-8],[1,-4],[-9,-4],[-14,2],[-2,-10],[35,-17],[5,-11],[8,-5],[7,0],[4,8],[9,1],[8,-2],[1,-4],[-7,-6],[0,-6],[5,-3],[14,2],[8,-2],[6,-22],[25,-26],[7,1],[12,7],[22,-5],[7,3],[8,-5],[8,1],[17,13],[16,1],[5,4],[-3,11],[7,6],[6,-3],[3,-4],[6,-27],[25,-13],[2,-13],[6,-1],[4,6],[7,2],[15,-14],[8,-16],[6,-4],[16,-1],[12,-6],[6,-7],[12,-6],[11,10],[14,0],[4,11],[3,2],[3,-1],[3,-1],[4,-8],[6,-3],[1,-6],[7,-5],[12,0],[14,-7],[9,2],[2,3],[-1,6],[4,2],[15,-1],[11,16],[6,0],[3,-9],[9,1],[8,10],[9,3],[10,9],[5,0],[3,-2],[3,-8],[4,-3],[8,1],[11,10],[8,1],[5,-1],[15,-8],[57,5],[23,-7],[24,-15],[26,-4],[10,1],[5,7],[14,2],[10,7],[9,0],[7,-4],[13,1],[5,6],[-3,14],[-26,19],[-8,11],[1,18],[4,4],[6,0],[12,-7],[16,-22],[12,-24],[19,-29],[13,-9],[12,-2],[27,-22],[11,-1],[16,2],[36,13],[8,5],[-1,3],[-7,6],[-5,-1],[-7,5],[-1,28],[-4,22],[-7,-1],[-1,-6],[-4,-3],[-8,-1],[-11,6],[-18,19],[-8,0],[-33,-14],[-6,-6],[1,-17],[-8,5],[-13,25],[-28,35],[0,11],[9,-1],[10,-10],[5,3],[-1,9],[-43,46],[0,6],[8,1],[12,-10],[7,0],[0,10],[2,3],[7,0],[16,-10],[7,-9],[6,-3],[9,3],[9,11],[14,3],[16,-1],[2,3],[0,6],[-21,14],[-5,7],[-1,9],[5,6],[10,0],[22,-12],[44,-16],[18,-14],[3,-8],[1,-18],[6,-5],[10,0],[12,4],[16,0],[10,14],[6,0],[2,-2],[0,-27],[-14,-22],[-14,-14],[-1,-8],[3,-2],[13,7],[12,-1],[5,5],[0,14],[2,8],[9,9],[8,3],[3,-1],[17,6],[15,16],[5,-1],[0,-11],[-12,-18],[-8,-34],[-10,-20],[-7,-22],[-3,-25],[7,-38],[-5,-2],[-6,4],[-2,3],[-4,17],[-4,1],[-3,-5],[1,-23],[-7,-17],[0,-5],[6,-3],[9,-1],[4,-10],[5,-3],[10,0],[3,-2],[0,-9],[-10,-28],[8,-7],[7,-1],[7,-6],[5,4],[1,11],[2,4],[14,12],[0,6],[2,3],[4,0],[6,-7],[7,1],[4,2],[10,-1],[0,-15],[-23,-16],[-4,-8],[6,-1],[8,5],[15,0],[4,-3],[4,-29],[3,-8],[5,-13],[1,-3],[-5,-4],[-1,-1],[-5,0],[-3,1],[-20,5],[-10,-6],[-6,0],[-7,6],[-7,13],[-5,-2],[-1,-10],[-6,-1],[-14,8],[-15,14],[-8,0],[-3,-7],[8,-12],[51,-53],[4,-9],[13,-10],[4,5],[0,2],[-1,4],[-29,30],[-2,12],[3,3],[9,0],[21,-7],[46,-2],[9,6],[1,3],[-2,16],[-4,8],[2,8],[-5,6],[-1,24],[7,20],[0,12],[-19,36],[5,10],[0,10],[-31,24],[-8,15],[-1,8],[10,20],[0,22],[6,15],[1,16],[6,6],[14,1],[10,-9],[6,4],[7,0],[22,-14],[25,-1],[9,6],[14,24],[13,13],[33,12],[6,6],[6,11],[3,24],[6,10],[34,29],[20,14],[0,10],[-7,9],[0,10],[4,7],[-1,16],[-3,5],[2,37],[-17,11],[0,15],[-3,2],[-5,0],[-3,-2],[-19,-32],[0,-10],[5,-2],[9,5],[10,0],[1,-7],[-27,-31],[-10,-5],[-7,0],[-18,6],[-10,1],[-2,2],[-8,4],[2,34],[-3,13],[17,1],[5,11],[15,4],[14,14],[-3,6],[-10,0],[-5,-2],[-6,3],[5,32],[4,8],[9,8],[27,7],[21,19],[12,0],[0,-6],[-23,-27],[-6,-15],[1,-15],[8,-4],[9,4],[7,17],[12,15],[13,6],[5,6],[-8,2],[-5,2],[5,15],[0,7],[0,6],[-8,10],[-12,0],[-54,-21],[-16,-2],[-15,3],[-12,13],[-11,31],[-11,12],[-9,-5],[0,-5],[6,-9],[0,-7],[-7,-6],[-11,-2],[-56,31],[-43,31],[-13,0],[-4,-2],[-18,1],[-14,13],[-7,20],[-18,14],[-16,17],[-11,19],[-8,9],[-5,15],[-1,23],[27,31],[2,6],[-1,15],[3,5],[22,3],[6,15],[18,14],[-1,5],[-8,-1],[-20,-15],[-9,-3],[-7,4],[-5,13],[-16,12],[-9,11],[-3,18],[8,23],[-1,13],[11,15],[0,3],[-8,3],[-5,6],[1,7],[9,15],[-3,23],[22,6],[16,16],[14,1],[11,-2],[13,-7],[3,-14],[6,-5],[21,-5],[5,2],[1,10],[12,6],[0,5],[-12,10],[1,10],[12,7],[19,4],[9,5],[-3,5],[-13,-1],[-26,-10],[-18,0],[-21,12],[-4,9],[40,30],[29,3],[6,4],[4,18],[9,8],[0,3],[-10,7],[0,4],[11,11],[14,7],[45,9],[23,0],[11,-13],[6,-15],[-11,-15],[-6,-3],[0,-8],[5,-3],[14,12],[6,0],[4,-2],[-2,-18],[5,-5],[13,13],[14,0],[7,3],[8,1],[22,-14],[-4,-22],[27,-13],[18,-13],[9,-16],[3,-11],[27,-27],[10,-49],[13,-15],[0,-7],[-10,-8],[0,-5],[12,-9],[0,-3],[-6,-5],[-14,-4],[2,-7],[10,-6],[11,0],[8,-4],[6,-21],[6,-6],[19,-2],[8,-7],[0,-6],[4,-2],[17,0],[3,-6],[-2,-6],[-11,-14],[0,-5],[12,-5],[6,-11],[16,-9],[1,-9],[-6,-15],[4,-3],[5,0],[6,2],[11,10],[7,0],[2,-19],[8,-6],[11,-5],[6,-6],[0,-4],[-5,-3],[-17,-2],[-20,-8],[-12,-1],[-9,3],[-21,21],[-18,1],[-5,-6],[3,-10],[-2,-14],[38,-6],[6,-5],[-1,-6],[-37,-35],[-10,-3],[-22,-18],[-22,-9],[3,-6],[10,0],[3,-6],[-9,-4],[-17,0],[-3,-5],[3,-2],[26,-2],[7,2],[7,7],[31,-1],[2,-2],[5,-4],[-2,-14],[17,-9],[14,-12],[6,-1],[13,6],[12,15],[17,14],[12,6],[10,1],[8,-8],[1,-12],[-15,-8],[-14,-1],[-3,-6],[3,-2],[10,0],[12,5],[13,1],[11,-2],[21,-10],[18,-1],[8,2],[11,9],[6,0],[20,-16],[0,-7],[-9,-5],[-18,5],[-15,-2],[-2,-15],[-8,-7],[2,-24],[-3,-3],[-13,0],[-7,3],[-2,4],[2,14],[-3,4],[-6,0],[-16,-15],[0,-6],[16,-6],[9,-7],[10,-23],[8,-7],[13,-4],[8,-7],[4,-18],[14,-15],[-1,-9],[7,-24],[-14,-51],[-1,-17],[3,-9],[6,-6],[14,-2],[4,-3],[0,-16],[5,-9],[7,-6],[7,-2],[5,4],[1,7],[14,9],[1,9],[12,19],[-2,14],[-8,12],[1,53],[5,4],[5,0],[3,-3],[1,-28],[4,-23],[8,-2],[6,3],[2,40],[-4,31],[3,30],[7,12],[30,19],[21,22],[5,3],[9,-1],[15,-16],[6,-15],[10,-10],[18,-6],[35,-30],[25,-24],[14,-24],[1,-21],[16,-65],[0,-17],[-7,-25],[-8,-7],[-8,-1],[-9,3],[-6,6],[1,33],[-5,4],[-6,1],[-9,-7],[-3,-30],[7,-29],[-1,-10],[-10,-27],[-1,-16],[10,-31],[10,-14],[37,-36],[17,-36],[9,-14],[25,-26],[2,-6],[-4,-20],[7,-7],[5,-2],[25,32],[0,9],[-5,5],[-1,4],[18,10],[35,3],[6,5],[5,43],[19,63],[28,40],[19,6],[8,9],[1,18],[7,6],[1,11],[-5,9],[0,5],[20,47],[4,27],[-4,22],[4,10],[13,8],[2,9],[5,3],[10,-1],[11,-6],[8,5],[13,-2],[8,-7],[11,-2],[20,6],[4,10],[-9,11],[-35,4],[-5,4],[1,5],[5,2],[4,1],[1,3],[-1,3],[1,5],[6,2],[4,0],[5,0],[2,3],[-1,4],[-3,2],[-2,3],[0,4],[2,2],[4,0],[5,-2],[3,-3],[2,-2],[5,-2],[4,0],[8,3],[3,9],[-22,12],[-18,5],[-14,10],[-9,1],[-32,34],[3,14],[-3,8],[9,11],[-15,14],[6,26],[-7,11],[5,15],[-3,8],[2,7],[9,5],[1,3],[-15,9],[-4,3],[1,6],[28,-2],[11,-10],[10,-3],[17,6],[23,13],[19,3],[23,0],[13,-3],[16,-9],[27,-18],[20,-10],[22,-2],[37,9],[40,-6],[19,3],[38,-8],[2,-8],[-8,-6],[-9,1],[-4,3],[-13,0],[-6,-12],[10,-9],[-3,-8],[-8,-1],[-18,2],[-24,11],[-17,2],[-3,-5],[7,-8],[18,-8],[21,-2],[33,-10],[17,-9],[6,-9],[12,-7],[-5,-19],[3,-3],[7,1],[9,6],[14,-3],[9,4],[10,0],[12,-6],[8,-8],[14,-2],[9,-6],[-3,-16],[3,-8],[-7,-6],[-21,-7],[-15,-22],[-10,-7],[-3,-7],[2,-2],[8,-1],[11,2],[11,-1],[14,-9],[7,-1],[8,4],[10,-3],[6,-11],[0,-46],[-3,-6],[-38,-20],[-18,0],[-2,-9],[2,-3],[-3,-6],[-18,-4],[-7,6],[-3,10],[-7,8],[-8,1],[-3,-2],[-10,-14],[-24,5],[-6,-3],[-1,-4],[3,-5],[-2,-7],[3,-2],[16,-2],[8,-6],[24,-3],[12,-6],[5,-5],[-1,-3],[-9,-4],[-12,3],[-13,6],[-9,1],[-5,-3],[-3,-7],[4,-8],[9,-2],[8,-8],[-4,-21],[4,-6],[6,-1],[6,3],[11,14],[8,0],[3,-3],[-2,-15],[-14,-18],[-2,-14],[12,-19],[11,-13],[10,-6],[12,-13],[47,-60],[4,-10],[-1,-5],[-9,-24],[-4,-2],[-5,-20],[1,-25],[-3,-10],[-8,-10],[-15,-13],[-10,-6],[-22,-4],[-6,-5],[-9,-24],[-18,-36],[-9,-7],[-14,-4],[-7,-5],[-6,-8],[-15,-10],[-14,-5],[-28,-23],[-40,-26],[-5,0],[-9,7],[-1,23],[-9,11],[-31,8],[-15,13],[0,12],[12,28],[1,15],[-2,7],[-6,0],[-3,-2],[-8,-17],[-8,-9],[-9,-4],[-5,5],[0,11],[-13,9],[-2,20],[-16,19],[-7,3],[-14,-1],[-16,-8],[-19,-1],[-7,-5],[-12,-22],[-1,-7],[4,-5],[9,4],[7,12],[8,-11],[7,-1],[3,2],[0,16],[5,4],[13,4],[12,-2],[5,-6],[-2,-12],[3,-7],[16,-13],[0,-13],[5,-4],[16,-2],[3,-5],[2,-20],[12,-12],[12,-5],[13,-11],[4,-10],[2,-15],[14,-23],[0,-12],[-6,-8],[-5,-3],[-3,0],[-7,7],[1,4],[-4,5],[-18,8],[-10,12],[-7,1],[-5,-4],[-8,-2],[-10,15],[-11,3],[-3,-8],[2,-6],[14,-19],[2,-8],[0,-4],[-5,-2],[-24,11],[-27,2],[-16,9],[-9,1],[-5,-3],[-8,2],[-7,10],[2,22],[-11,37],[-3,3],[-12,-1],[-22,-12],[-9,-2],[-36,3],[-9,5],[-8,1],[-7,-8],[-5,1],[-10,7],[-11,1],[-7,-3],[-17,5],[-2,-6],[5,-11],[-3,-6],[-10,-6],[1,-15],[19,-11],[51,-13],[17,-10],[8,-12],[-4,-15],[-5,-15],[-15,-18],[-10,-7],[-17,-6],[-9,-9],[-3,-12],[5,-12],[-1,-10],[-6,-7],[-43,-45],[-30,-39],[-10,-8],[-11,-3],[-32,-4],[-40,3],[-21,8],[-12,7],[-8,8],[-12,21],[-12,15],[-8,3],[-22,4],[-3,2],[1,5],[4,3],[30,-3],[3,2],[0,5],[-2,2],[-21,5],[-26,1],[-15,5],[-25,23],[-26,15],[-26,26],[-5,-1],[-3,-7],[-9,0],[-2,-2],[0,-5],[23,-19],[0,-4],[-2,-2],[-20,3],[-30,13],[-23,2],[-1,3],[3,2],[15,3],[0,6],[-2,2],[-38,-1],[-16,4],[-4,0],[-7,1],[-4,1],[-8,1],[-4,0],[-2,-3],[1,-4],[3,-1],[2,-2],[4,-1],[5,-1],[10,0],[3,0],[13,-3],[11,-10],[11,-6],[41,-14],[28,-14],[22,-20],[6,-13],[5,-6],[14,-7],[12,-13],[6,-16],[22,-25],[7,-4],[36,-9],[52,-3],[20,-6],[108,-3],[14,-8],[-3,-19],[-9,-18],[-4,-18],[-13,-26],[-7,-21],[-6,-6],[-11,0],[-3,-3],[-1,-14],[-6,-18],[-18,-17],[-9,-12],[-6,-22],[-18,-26],[-4,-19],[-4,-6],[-9,-8],[-43,-29],[-16,-15],[-24,1],[-18,5],[-2,-10],[-4,-3],[-6,0],[-7,7],[-20,7],[-15,-1],[-2,3],[0,9],[-2,2],[-7,-5],[-4,0],[-15,25],[1,6],[9,13],[-1,7],[-7,1],[-5,-2],[-2,-2],[-2,-10],[-6,-5],[-5,1],[-3,-5],[4,-6],[-1,-13],[13,-15],[4,-15],[-3,-3],[-6,0],[-13,15],[-24,10],[-8,-1],[-1,-7],[4,-8],[19,-18],[4,-6],[0,-10],[-6,-4],[0,-8],[-7,-6],[-3,-11],[-6,-11],[-21,-4],[-9,2],[0,13],[-5,8],[-12,0],[-2,-2],[0,-4],[6,-6],[1,-3],[-3,-3],[-7,1],[-12,0],[-24,-4],[-12,0],[-28,12],[-12,14],[-15,2],[-10,8],[-30,0],[-7,3],[-24,0],[-12,7],[-2,1],[-9,1],[-11,16],[-17,-3],[-10,9],[-20,6],[-8,10],[-17,0],[-13,11],[-19,3],[-11,6],[-4,5],[-2,4],[-4,4],[-3,5],[-4,3],[-5,0],[-2,-1],[-4,-4],[2,-4],[4,-6],[3,-3],[4,-4],[2,-2],[4,-3],[1,-3],[-1,-2],[-5,-1],[-4,1],[-3,1],[-5,1],[-4,0],[-2,-3],[0,-4],[2,-3],[3,-3],[11,-7],[11,-12],[7,-8],[4,-3],[5,-2],[5,2],[0,4],[-2,4],[-5,9],[0,4],[8,10],[6,2],[9,-7],[11,-15],[12,-8],[16,-4],[12,-1],[17,-13],[17,2],[14,-8],[1,0],[10,0],[12,-6],[3,-2],[-2,-8],[-15,-9],[-7,-14],[-12,-7],[0,-5],[3,-2],[12,0],[4,2],[7,12],[6,5],[8,1],[15,18],[8,2],[15,-2],[8,-3],[7,-8],[-5,-15],[6,-4],[13,-5],[11,-12],[22,-3],[10,-6],[23,-4],[10,-11],[12,-8],[-2,-25],[6,-19],[6,-33],[-2,-19],[-10,-14],[-9,-4],[-11,5],[-10,0],[-17,-17],[-13,-5],[-12,-13],[-5,-1],[-14,3],[-17,10],[-27,2],[-8,4],[-8,-1],[-2,-8],[-5,-6],[-3,-2],[-6,1],[-3,1],[-2,1],[-2,2],[-1,2],[-8,2],[-3,-3],[1,-8],[20,-22],[14,-7],[27,-4],[4,-7],[-5,-11],[-14,-10],[-9,1],[-8,6],[-9,0],[-10,-7],[-10,-2],[-12,9],[-6,-1],[0,-4],[12,-23],[3,-2],[14,0],[8,-7],[10,0],[3,-9],[-3,-3],[-9,-1],[-9,2],[-5,4],[-24,0],[-6,5],[2,8],[-1,12],[-2,2],[-8,-1],[-2,-2],[0,-16],[-7,-5],[-1,-5],[6,-7],[18,-3],[5,-3],[-4,-35],[-5,-3],[-5,4],[-3,21],[-8,9],[-18,9],[-14,3],[-2,-8],[5,-5],[21,-4],[9,-9],[3,-4],[-3,-10],[-6,-1],[-8,6],[-10,0],[-13,-8],[-21,-1],[3,-6],[9,-2],[7,-7],[11,0],[4,-3],[0,-4],[-14,-6],[-1,-12],[-3,-3],[-9,1],[-9,10],[-3,-1],[0,-7],[8,-9],[1,-5],[-9,-6],[0,-8],[-2,-2],[-9,2],[-14,15],[-2,0],[-4,0],[-4,-3],[2,-4],[3,-4],[5,-6],[-2,-14],[2,-2],[9,0],[11,-8],[9,-1],[4,-6],[-3,-3],[-15,1],[-3,-2],[0,-4],[8,-5],[0,-5],[-15,-6],[-26,-20],[-8,-9],[-5,-7],[-9,-31],[1,0],[-8,-4],[-25,-1],[-4,-3],[12,-12],[17,-8],[-5,-9],[0,-11],[0,-26],[-7,-9],[-4,-5],[-18,-50],[-11,-17],[-4,-21],[-8,-13],[-11,-25],[-3,-3],[-7,-3],[-24,10],[-13,0],[0,-4],[3,-3],[29,-9],[6,-10],[2,-25],[-3,-9],[0,-17],[4,-10],[-11,-42],[-1,-2]],[[3505,8154],[17,-3],[40,0],[32,-8],[14,2],[6,5],[-2,8],[6,5],[2,17],[-9,17],[-16,8],[-56,18],[-16,14],[-7,3],[-11,-1]],[[3505,8245],[7,2],[30,11],[18,14],[6,21],[-6,17],[-6,7],[-15,7],[-33,5],[-1,1]],[[3505,8400],[5,5],[-1,17],[5,4],[23,7],[15,24],[20,17],[23,4],[21,-2],[24,2],[-1,-15],[15,-4],[7,-12],[-4,-9],[-18,-14],[3,-4],[8,-4],[15,-29],[-3,-7],[4,-7],[18,-7],[7,-5],[17,-21],[-11,-12],[5,-9],[-22,-13],[8,-16],[-23,-6],[-5,-4],[3,-4],[5,-2],[21,0],[50,7],[20,-8],[5,-10],[-11,-13],[-22,-15],[-5,-7],[2,-4],[5,-2],[7,2],[41,21],[20,3],[5,-2],[6,-5],[7,-20],[13,-17],[6,-23],[9,-2],[9,3],[-10,19],[2,6],[12,11],[-14,8],[-4,8],[6,11],[-5,11],[8,15],[13,10],[18,3],[33,-5],[46,-15],[10,-3],[20,-14],[8,-20],[-1,-34],[-3,-13],[-12,-22],[1,-30],[-9,-28],[-13,-14],[-3,-12],[-20,-17],[-2,-9],[-26,-9],[-41,-7],[-11,-2],[-17,-7],[-21,-7],[-32,-2],[-25,6],[-15,11],[-6,15],[-8,5],[-10,-2],[-25,-31],[-7,-4],[-20,-2],[-36,13],[-5,19],[-7,3],[-10,-2],[-45,-31],[-20,-6],[-18,-12],[-14,-4],[-14,0]],[[4164,8519],[-8,-4],[-9,-1],[-12,4],[-2,6],[10,9],[17,1],[6,-9],[-2,-6]],[[4164,8519],[10,2],[7,0],[6,-2],[1,-6],[-3,-2],[-11,0],[-6,3],[-2,2],[-2,3]],[[6663,884],[-4,-3],[-10,3],[-11,11],[-30,23],[-9,3],[-17,4],[-28,16],[-20,8],[-2,3],[0,8],[4,4],[17,-2],[13,10],[6,1],[2,-3],[3,-21],[3,-5],[18,-3],[4,-2],[5,-7],[3,0],[3,2],[1,7],[-5,9],[0,3],[8,6],[3,6],[1,8],[4,5],[7,-3],[6,-13],[8,1],[2,-9],[-1,-7],[2,-4],[5,-1],[4,4],[3,18],[3,6],[16,0],[3,-5],[2,-12],[7,-10],[2,-18],[4,-4],[4,4],[3,24],[3,3],[3,-1],[2,-4],[-3,-18],[1,-3],[6,0],[-1,-10],[-12,-25],[-3,-15],[-4,-4],[-18,-8],[-3,0],[-3,5],[2,9],[15,18],[0,7],[-5,0],[-17,-19],[-3,-2],[-2,2]],[[6816,2598],[-7,2],[-6,8],[-18,15],[-20,10],[-12,9],[-39,10],[-28,14],[-5,4],[-3,8],[2,18],[4,10],[9,10],[21,10],[17,3],[14,-1],[25,-8],[11,-9],[14,-16],[7,-14],[17,-46],[4,-7],[0,-25],[-3,-4],[-4,-1]],[[6455,1002],[-3,1],[-2,2],[-1,7],[-9,23],[0,9],[2,4],[13,-5],[3,-4],[9,-9],[0,-10],[-5,-4],[-2,-7],[-5,-7]],[[5989,1639],[-5,5],[1,9],[-3,7],[0,7],[4,5],[11,-1],[6,-2],[5,1],[6,-1],[-1,-20],[-14,-2],[-10,-8]],[[6231,1398],[-5,1],[-5,4],[1,5],[8,8],[24,1],[4,-4],[-1,-6],[-5,-4],[-21,-5]],[[6519,976],[1,-6],[6,-10],[-1,-7],[-5,-4],[-9,2],[-4,4],[0,3],[3,3],[4,13],[2,2],[3,0]],[[6677,988],[1,3],[4,3],[19,-2],[3,-4],[-2,-8],[-23,4],[-2,4]],[[6881,675],[-4,1],[-4,8],[0,7],[2,3],[6,-2],[5,-10],[0,-3],[-5,-4]],[[6592,956],[-2,1],[-2,3],[2,5],[10,2],[4,-2],[-1,-4],[-7,-1],[-4,-4]],[[5861,1517],[-4,5],[5,8],[4,1],[2,-6],[-7,-8]],[[6867,2283],[-1,-4],[-1,-4],[-5,-2],[-3,1],[-3,1],[0,4],[3,4],[4,1],[6,-1]],[[6107,1625],[-5,-6],[-4,3],[2,4],[3,4],[4,-1],[0,-4]],[[6652,991],[2,-4],[-1,-4],[-4,-2],[-2,4],[0,6],[2,1],[3,-1]],[[6633,994],[-3,1],[-2,2],[3,8],[5,-3],[-1,-5],[-2,-3]],[[6053,1647],[-4,0],[-2,2],[-1,4],[0,2],[2,1],[4,-1],[1,-3],[0,-5]],[[6794,707],[-1,-3],[0,-3],[-1,-2],[-3,1],[-1,2],[0,3],[1,2],[2,4],[2,-2],[1,-2]],[[6884,704],[-1,-4],[-1,-1],[-3,0],[-1,3],[0,3],[1,1],[3,2],[2,-4]],[[6358,1299],[-3,0],[-2,4],[1,5],[4,0],[2,-3],[-1,-4],[-1,-2]],[[6852,860],[-3,1],[-2,2],[2,5],[5,-3],[0,-3],[-2,-2]],[[5981,1682],[-3,2],[1,7],[4,-3],[0,-4],[-2,-2]],[[6951,2295],[-1,-585]],[[6950,1710],[0,-141],[0,-17],[0,-107],[0,-87],[0,-1],[0,-1],[0,-2],[0,-1],[-1,-2],[-1,-1],[-1,-2],[0,-1],[-1,-3],[0,-1],[0,-2],[0,-1],[-1,-2],[-1,-2],[0,-2],[-1,-1],[0,-1],[0,-1],[-1,-2],[0,-1],[0,-1],[0,-3],[0,-2],[1,-1],[1,-3],[0,-1],[1,-2],[1,-2],[1,-4],[3,-3],[1,-5],[1,-3],[2,-5],[2,-3],[1,-2],[1,-2],[0,-3],[0,-2],[0,-2],[0,-3],[0,-5],[0,-4],[0,-6],[0,-4],[-1,-5],[0,-4],[1,-3],[2,-4],[0,-1],[1,-2],[0,-2],[1,-1],[0,-1],[1,-1],[1,-1],[2,-3],[1,-3],[1,-2],[0,-3],[1,-4],[1,-2],[0,-4],[1,-3],[2,-2],[1,-3],[1,-3],[2,-5],[3,-4],[1,-2],[1,-2],[0,-1],[0,-1],[1,-2],[1,-1],[1,-1],[2,0],[1,-1],[0,-1],[1,-1],[1,-3],[0,-2],[1,-3],[1,-2],[0,-2],[1,-1],[0,-3],[1,-2],[0,-2],[0,-2],[1,-3]],[[6995,1153],[1,-3]],[[6996,1150],[1,-2],[0,-1],[0,-2],[1,-1],[0,-1],[1,-2],[0,-1],[1,-1],[0,-1],[1,-1],[0,-1],[1,0],[1,-1],[1,-1],[1,-1],[0,-1],[0,-1],[1,-1],[0,-1],[0,-2],[1,-1],[0,-1],[1,0],[0,-1],[0,-1],[0,-1],[-1,0],[0,-1],[0,-1],[1,-1],[0,-1],[1,-3],[0,-1],[1,-3],[0,-2],[1,-1],[1,-2],[1,-1],[0,-1],[1,-1],[0,-1],[1,-1],[1,-1],[0,-1],[0,-1],[1,-1],[0,-1],[0,-1],[1,-1],[0,-1],[1,-1],[1,-1],[0,-1],[1,-1],[1,-1],[1,-1],[1,-1],[1,-1],[0,-1],[1,-1],[1,-1],[1,-1],[1,-1],[1,-1],[1,-1],[1,-1],[1,-1],[1,0],[1,-1],[1,-1],[0,-1],[1,0],[1,-1],[0,-1],[1,0],[0,-2]],[[7039,1069],[0,-4]],[[7039,1065],[0,-1],[0,-1],[0,-2],[0,-1],[0,-1],[0,-1],[1,-1],[1,-1],[1,0],[1,0],[1,0],[1,0],[1,-1],[2,0],[1,0],[1,-1],[1,1],[1,0],[1,0],[1,0],[1,0],[1,0],[1,-1],[1,-1],[1,-1],[2,-1],[1,-1],[1,0],[1,0],[2,0],[1,0],[1,-1],[1,0],[1,0],[1,0],[1,0],[1,1],[1,-1],[1,0],[2,0],[1,-1],[1,-1],[2,-1],[1,-2],[1,-1],[2,-1],[1,-1],[1,0],[1,1],[2,1],[1,1],[1,1],[1,1],[1,-1],[1,0],[1,0],[1,-1],[1,0],[1,0],[1,0],[1,0],[1,0],[1,1],[1,0],[1,0],[1,0],[0,-1],[1,0],[1,-1],[1,-1],[2,-1],[1,-1],[1,-1],[2,-2],[0,-1],[1,0],[2,2],[1,1],[1,0],[2,0],[1,0],[1,-1],[1,0],[1,-1],[1,-1],[1,-1],[2,-1],[2,-2],[3,-1],[1,-1],[1,0],[1,0],[1,-1],[1,0],[1,0],[1,-1],[1,-1],[1,-1],[1,0],[1,-1],[1,0],[1,1],[1,0],[1,0],[1,0],[2,0],[1,-1]],[[7154,1025],[2,-1]],[[7156,1024],[1,0],[0,1],[1,1],[1,0],[2,-1],[1,-2],[1,-1],[2,-1],[2,-2],[2,-2],[2,-1],[2,-1],[1,-2],[2,-2],[2,-2],[3,-3],[2,-2],[1,-2],[1,-1],[2,-1],[1,-2],[2,-1],[1,-2],[1,-1],[2,-3],[3,-3],[1,0],[0,-1],[1,-1],[2,-3],[1,-1],[0,-1],[1,-1],[-1,-2],[0,-2],[-1,-5],[0,-1],[0,-1],[0,-2],[1,-1],[1,-3],[1,-1],[2,-3],[1,-1],[2,-3],[0,-2],[1,-1],[1,-2],[2,-3],[1,-2],[2,-1],[1,-1],[2,-1],[1,-2],[1,0],[1,-1],[2,0],[3,-2],[1,-2],[1,-1],[1,0],[1,-2],[1,-1],[2,-2],[0,-1],[1,-2],[1,-1],[1,0],[3,1],[2,2],[2,1],[1,2],[0,4],[-1,1],[0,1],[0,1],[0,1],[1,0],[0,1],[0,1],[1,1]],[[7246,942],[-1,1]],[[7245,943],[0,1],[0,1],[0,1],[-1,1],[0,1],[-1,1],[0,1],[0,1],[0,1],[1,1],[2,1],[2,0],[2,-1],[2,-1],[3,-2],[2,-1],[1,-2],[2,-2],[1,-3],[0,-3],[0,-3],[0,-4],[0,-2],[-1,-4],[-1,-4],[0,-1],[0,-2],[0,-1],[1,-1],[2,-1],[1,-1],[1,-1],[0,-1],[1,-2],[2,-1],[1,-1],[0,-1],[1,-2],[0,-1],[0,-2],[0,-1],[0,-2],[-1,-2],[0,-2],[0,-2],[1,-2],[1,-2],[1,-2],[1,-3],[0,-1],[0,-1],[0,-3],[0,-2]],[[7272,878],[0,-4]],[[7272,874],[1,-2],[1,-2],[1,-2],[4,-3],[3,0],[3,-2],[3,-1],[4,-1],[2,-1],[1,0],[2,-1],[1,0],[1,-1],[1,-1],[0,-1],[2,-3],[2,-3],[2,-2],[1,-1],[1,-1],[1,0],[0,-1],[1,1],[1,0],[2,0],[0,1],[1,0],[2,1],[0,1],[2,2],[1,0]],[[7319,851],[1,4]],[[7320,855],[1,1],[0,2],[1,1],[2,2],[1,0],[1,1],[1,0],[1,0],[1,1],[2,0],[1,0],[1,0],[1,0],[1,0],[2,-1],[1,-1],[2,-2],[1,-1],[1,-1],[2,-1],[2,-1],[1,-2],[1,-1],[1,0],[1,-1],[1,-1],[2,-3],[1,-3],[1,-2],[1,-2],[1,-3],[1,-1],[1,-2],[1,-2],[1,-2],[2,-2],[2,-2],[2,0],[1,1],[2,1],[1,2],[2,2],[2,3],[2,2],[2,1],[1,1],[1,1],[0,1],[0,2],[1,1],[0,1],[1,2],[1,2],[2,0],[2,1],[3,0],[1,-1],[1,1],[1,0],[2,2],[1,1],[2,2],[2,2],[2,1],[2,1],[2,1],[3,1],[1,1],[1,1],[2,0],[1,1],[3,1],[2,0],[1,2],[2,1],[1,0],[0,1],[1,2],[1,1],[1,0],[2,1],[1,1],[1,1],[2,2],[1,0],[2,0],[2,0],[2,0],[1,0],[1,-1],[1,0],[1,0],[2,1],[1,0],[2,1],[2,0],[2,1],[1,0],[1,0],[1,0],[0,1],[2,0],[0,1],[1,1],[2,1],[1,2],[1,2],[1,1],[0,2],[0,1],[1,0],[0,1],[1,0],[1,0],[1,0],[2,0],[1,0],[2,0],[2,-1],[2,0],[2,0],[1,0],[2,1],[1,0],[3,0],[1,-1],[2,-1],[2,-1],[2,0],[2,1],[1,0],[1,0],[1,0],[1,0],[1,1],[1,0],[1,-1],[0,-1],[1,-1],[1,-1],[0,-1],[1,-1],[2,-1],[3,-2],[2,-1],[1,0],[1,0],[1,0],[1,0],[1,-1],[1,0],[1,0],[2,-1],[1,-2],[1,-1],[1,0],[1,0],[1,-1],[2,0],[1,-1],[1,-1],[0,-1],[1,0],[0,-1],[-7,-40],[-3,-21],[12,-22]],[[7533,788],[-3,-4],[-9,-7],[-8,-3],[-11,-10],[-31,-16],[-64,-57],[-27,-45],[-20,-46],[-3,-3],[-14,-14],[-36,-24],[-14,-3],[-11,-10],[-14,-7],[-7,-7],[-6,-11],[-18,-20],[-3,-1],[-2,4],[1,6],[4,8],[-1,8],[-14,6],[-5,-6],[-12,1],[-9,-9],[-8,-2],[-1,-4],[1,-2],[4,-2],[12,9],[11,-1],[6,3],[5,-2],[-1,-17],[4,-6],[7,-2],[4,2],[9,12],[4,-1],[0,-7],[-15,-18],[-1,-4],[2,-4],[2,-1],[9,8],[3,-3],[-3,-6],[-8,-10],[-5,-2],[-9,3],[-4,-4],[-9,13],[-14,0],[-17,5],[-3,5],[1,3],[-3,5],[-2,1],[-17,-6],[-14,-1],[-25,-14],[-29,1],[-26,-13],[-17,-3],[-10,1],[-15,-5],[-23,-16],[-25,-33],[-13,-3],[-8,-9],[-25,-54],[-7,-10],[0,-7],[12,-7],[23,-4],[14,-5],[16,2],[7,4],[4,4],[4,0],[0,-1],[-1,-1],[0,-2],[0,-1],[1,-3],[0,-3],[0,-2],[0,-2],[0,-1],[0,-2],[0,-2],[1,-2],[0,-2],[0,-2],[-1,-2],[-1,-2],[-1,-1],[0,-1],[0,-1],[1,-2],[0,-3],[-1,-1],[1,0],[0,-1],[1,-1],[4,-1],[3,-1],[5,-1],[1,0],[0,-3],[-1,1],[-2,1],[-2,0],[-2,-2],[-1,-1],[0,-1],[0,-2],[-1,-2],[-1,-2],[0,-1],[-1,-2],[1,-2],[0,-2],[0,-3],[2,-1],[3,-3],[1,-1],[2,-1],[1,0],[-1,5],[1,2],[1,4],[2,2],[1,-2],[-1,-1],[-1,-1],[-1,-2],[0,-2],[0,-2],[0,-1],[1,-2],[1,-1],[0,-2],[1,-2],[0,-2],[0,-3],[0,-2],[0,-1],[1,-2],[1,-2],[0,-2],[-4,-3],[-11,-1],[-5,1],[-19,-6],[-26,4],[-11,-4],[-3,1],[-9,-2],[-13,1],[-13,-8],[-8,-1],[-11,-4],[-5,-5],[-7,-2],[-5,-9],[-4,-12],[-8,-5],[-3,-6],[0,-4],[2,-3],[9,-1],[6,-8],[13,-3],[8,1],[1,-3],[0,-4],[-5,-4],[-23,2],[-10,6],[-21,4],[-12,11],[-11,3],[-49,5],[-21,-9],[-9,-6],[-12,-14],[-5,-9],[-19,-20],[-4,-11],[-2,-21],[-3,-8],[-6,-2],[-16,5],[-5,-3],[-35,-33],[-8,-14],[-1,-13],[-3,-4],[-4,4],[0,6],[-2,5],[-12,0],[-20,-9],[-8,2],[-8,5],[-9,11],[-2,27],[1,5],[-2,3],[1,14],[5,8],[9,6],[4,5],[4,1],[0,1],[5,4],[11,22],[17,26],[1,1],[7,9],[6,16],[2,11],[4,55],[6,23],[21,6],[19,23],[4,13],[6,5],[17,7],[4,5],[4,12],[1,30],[-1,17],[1,24],[-1,20],[4,51],[-3,37],[2,32],[4,13],[5,14],[9,14],[5,12],[6,11],[9,18],[4,17],[1,12],[-1,15],[0,20],[-3,12],[-9,21],[-11,17],[0,20],[-7,8],[-5,13],[-4,2],[-2,4],[1,5],[3,4],[16,-3],[15,2],[9,-2],[1,-2],[-2,-14],[3,-19],[14,-33],[3,-4],[3,-1],[5,7],[4,-2],[-4,-10],[0,-7],[3,-9],[-1,-5],[-6,-7],[-2,-8],[5,-5],[5,4],[6,-1],[4,-10],[-1,-18],[3,-5],[3,0],[4,2],[10,15],[4,2],[6,-1],[3,-4],[1,-14],[3,-4],[12,-3],[6,-9],[6,-3],[5,-6],[10,-8],[26,-6],[4,4],[-1,10],[3,29],[-5,13],[-6,10],[0,5],[5,6],[0,8],[2,4],[9,-6],[2,-4],[1,-9],[2,-2],[11,0],[0,5],[-1,6],[-3,6],[-1,9],[-6,10],[-1,8],[-11,20],[-1,13],[-7,9],[1,5],[3,4],[2,5],[-4,15],[-2,3],[-9,1],[-2,3],[2,13],[4,5],[1,20],[-1,2],[-3,-1],[-5,-10],[-5,-2],[-4,5],[-9,20],[-2,25],[-4,5],[-9,6],[-5,10],[-8,37],[-6,13],[-16,18],[-19,6],[-14,-5],[-8,0],[-2,3],[1,8],[-5,3],[-6,-5],[-13,2],[-21,-5],[-9,2],[-3,10],[-2,17],[-3,6],[-2,-2],[-8,1],[-21,4],[-12,0],[-10,4],[-4,7],[-13,3],[-19,-4],[-16,1],[-38,8],[-10,-3],[-2,-2],[-19,4],[-25,7],[-21,4],[-23,13],[-10,13],[-15,2],[-5,12],[2,23],[-3,7],[-5,4],[-9,0],[-7,-8],[-15,3],[-6,-6],[-4,1],[-7,13],[-1,8],[2,5],[10,14],[3,7],[1,8],[-2,3],[-3,0],[-7,-11],[-3,0],[-1,5],[3,24],[5,5],[9,2],[2,3],[1,4],[-3,5],[-6,2],[-5,5],[-14,0],[-16,18],[-7,14],[0,6],[8,21],[1,13],[6,12],[4,11],[0,13],[-22,31],[-16,28],[-2,9],[0,6],[-2,7],[0,10],[7,13],[1,21],[4,7],[1,7],[-9,10],[-4,0],[-14,-3],[-14,3],[-10,-7],[-7,-1],[-18,1],[-22,10],[-17,15],[-4,9],[-6,5],[-7,11],[-7,19],[-2,26],[-3,16],[-5,11],[-8,27],[-7,34],[-7,15],[-7,2],[-7,-6],[-9,1],[-6,11],[-3,0],[-8,-7],[-8,-2],[-7,2],[-3,3],[-13,1],[-9,-3],[-11,1],[-7,3],[-5,5],[-13,8],[-10,-1],[-29,21],[-19,5],[-13,11],[-8,2],[-7,-8],[-2,-12],[4,-16],[5,-10],[5,-13],[1,-10],[-1,-7],[-10,-7],[-7,-9],[-8,3],[-1,-9],[1,-2],[0,-6],[-2,-2],[-10,1],[-2,-4],[-5,-20],[-4,-5],[-2,1],[-2,8],[0,10],[3,11],[22,40],[1,12],[-3,6],[-4,6],[-5,2],[-4,-4],[-4,-10],[-1,-23],[-12,-17],[-2,-21],[-6,-10],[-4,-18],[-6,-8],[-8,-6],[-4,-2],[-5,0],[-1,3],[2,11],[16,31],[0,7],[-4,1],[-28,-24],[-11,-20],[0,-17],[-8,-8],[-2,-9],[-15,-35],[-10,-13],[0,1],[0,1],[-1,0],[0,-1],[-1,-1],[0,-1],[0,-1],[0,-1],[-1,0],[-1,-1],[-1,0],[-1,0],[0,-1],[1,-1],[-1,0],[-1,0],[-1,0],[-1,-1],[-1,0],[-1,0],[-1,1],[-1,0],[-2,0],[-2,1],[-3,-1],[-1,0],[-1,0],[-1,1],[-2,1],[-2,1],[-2,0],[-1,0],[-2,0],[-2,-1],[-1,-1],[-1,0],[-1,-1],[-1,-3],[-1,-1],[-2,-1],[-1,0],[-4,0],[0,1],[-1,0],[-1,2],[-1,2],[-1,1],[-1,0],[-2,2],[-2,2],[0,2],[0,1],[-1,3],[-1,2],[-1,0],[0,2],[-2,3],[-1,1],[-1,1],[-1,1],[-3,1],[-2,1],[-3,1],[-2,0],[-3,1],[-2,-1],[-3,0],[-4,-1],[-6,-1],[-3,-1],[-1,0],[-1,0],[-3,0],[-3,0],[-2,1],[-2,0],[-3,0],[-2,-1],[-3,0],[-1,-1],[-5,5],[0,1],[-1,0],[-1,0],[-1,0],[-3,-1],[-2,-1],[-21,21],[-1,0],[-1,0],[0,1],[-1,5],[0,2],[0,2],[-1,1],[0,1],[-1,1],[-1,1],[-1,-1],[-1,0],[-2,0],[-1,-2],[-3,-1],[-3,-3],[-2,-3],[-2,-2],[-2,-1],[-1,-2],[-2,-1],[-2,-1],[-2,-1],[-3,-2],[-2,-3],[-1,-3],[-2,-2],[-1,-2],[-1,0],[-1,-1],[-1,-1],[-1,-1],[0,-1],[-1,-3],[-1,-1],[-1,-2],[-1,-1],[-1,-1],[-2,-1],[-2,-1],[-3,-1],[-4,0],[-2,0],[-1,-1],[-1,0],[-1,-1],[-5,0],[-1,0],[-2,1],[-1,1],[-1,-1],[-9,2],[-2,1],[0,3],[1,1],[-1,1],[0,1],[-1,0],[-1,0],[-1,0],[-2,0],[-1,0],[-8,8],[0,2],[0,2],[-1,2],[0,2],[-1,0],[0,1],[0,1],[0,1],[0,2],[0,2],[-1,0],[-1,1],[-2,0],[-2,0],[-1,0],[-2,1],[-1,1],[-1,0],[-1,0],[-2,0],[-1,0],[-2,0],[-1,3],[-2,2],[-1,1],[-1,0],[-1,0],[-1,1],[-1,0],[-1,0],[-1,1],[-4,14],[-2,2],[0,2],[-1,1],[0,1],[-1,1],[-1,1],[0,2],[0,2],[-1,1],[0,1],[-1,1],[-4,1],[-2,0],[-3,0],[-3,-1],[-3,0],[-2,-2],[-1,-1],[-2,0],[-1,0],[-2,0],[-2,1],[-1,-1],[-1,-1],[-1,-3],[-1,-4],[0,-3],[0,-2],[0,-2],[1,-2],[1,-3],[0,-1],[1,-1],[-1,-4],[0,-1],[-1,0],[-1,0],[-1,0],[-1,-1],[-1,0],[-5,9],[-3,0],[-2,5],[-2,5],[-3,7],[0,8],[-1,3],[1,3],[0,1],[-3,6],[-1,3],[-1,1],[-1,1],[-6,-1],[-4,-1],[-1,0],[-2,-1],[0,5],[-1,8],[0,2],[1,0],[0,1],[1,1],[0,2],[0,1],[-1,1],[0,2],[0,2],[-1,0],[-1,1],[-2,0],[-2,0],[-12,4],[-5,3],[-2,2],[-3,5],[-8,5],[0,2],[-2,-1],[-2,2],[-3,-2],[-2,0],[-7,0],[-2,0],[-3,0],[-2,0],[-2,1],[-1,0],[-1,1],[-2,1],[-2,1],[-1,1],[-2,0],[-3,-1],[-3,-1],[-2,-1],[-1,-1],[-1,0],[-1,-1],[-1,-1],[0,-2],[-2,-1],[-1,0],[-1,0],[-1,0],[-2,-2],[-1,0],[-1,-1],[-2,-1],[-1,0],[0,-1],[-1,-1],[0,-1],[0,-3],[1,-1],[0,-1],[0,-2],[-1,-1],[-1,-1],[-4,-2],[-18,-1],[-2,-3],[-9,11],[-1,11],[-6,7],[-14,1],[-15,4],[-17,12],[-6,0],[-1,0],[-1,0],[-1,0],[-1,-1],[-1,0],[-1,1],[-1,0],[-2,1],[-2,0],[-1,1],[-1,0],[-2,0],[-1,-1],[0,-2],[-10,2],[-7,6],[-4,11],[-3,10],[0,4],[0,4],[-8,30],[0,3],[-1,9],[-1,5],[-1,5],[0,5],[-1,3],[-2,5],[-1,3],[0,2],[-1,2],[0,4],[-2,14],[-1,9],[-1,4],[0,1],[0,3],[0,2],[1,2],[-1,2],[-1,1],[0,1],[-1,1],[-1,0],[-2,1],[-1,1],[-1,1],[-1,1],[-2,1],[-2,1],[-3,0],[-3,-1],[-2,0],[-3,-1],[-1,1],[-4,2],[-1,-1],[-3,1],[-3,1],[-2,1],[0,-1]],[[5883,3625],[4,-3],[46,-41],[4,-4],[6,-5],[18,-26],[19,-7],[8,-7],[3,-3],[3,0],[8,-17],[6,-24],[8,-24],[9,-17],[8,-10],[1,-1],[12,-4],[8,-12],[8,-5],[16,-1],[19,-7],[41,-20],[50,-36],[8,-3],[26,-3],[14,-6],[12,-11],[29,-39],[13,-11],[14,-6],[12,-8],[4,-6],[1,-6],[-23,-33],[-6,-25],[-4,-9],[-1,-9],[4,-2],[7,11],[12,28],[5,17],[6,7],[9,5],[11,0],[20,-11],[26,-3],[20,2],[25,8],[21,-3],[20,-9],[3,2],[13,1],[24,-8],[30,-4],[5,2],[12,11],[8,-1],[6,-11],[2,-9],[3,-5],[5,0],[7,7],[6,-1],[8,-11],[15,-2],[7,-12],[5,-3],[3,1],[2,20],[5,0],[5,-11],[1,-6],[-4,-26],[8,-29],[1,-14],[-4,-20],[-6,-15],[-2,-23],[-3,-9],[-3,-27],[-6,-23],[-2,-17],[-2,-3],[0,-17],[2,-13],[29,-44],[3,-10],[2,-20],[-2,-18],[-5,-16],[-7,-37],[1,-12],[10,-33],[1,-8],[-3,-10],[-12,-14],[-5,-63],[11,-6],[9,-8],[10,-20],[1,-8],[9,-18],[14,-13],[11,-26],[10,-9],[5,-9],[1,-14],[-1,-8],[-4,-9],[-10,-9],[-17,-9],[-13,-14],[-6,-9],[-2,-8],[6,-1],[25,14],[18,7],[11,-1],[2,-2],[8,-17],[7,-8],[16,-10],[22,-5],[6,-5],[17,-28],[16,-14],[6,-14],[7,-24],[14,-31],[5,-27],[-1,-6],[-5,-11],[-15,-16],[-13,-25],[-10,-8],[1,-4],[4,-1],[7,4],[9,17],[11,10],[10,6],[24,4],[13,-4],[8,-15],[9,-7],[11,-3],[11,-16],[4,-2],[2,3],[2,15],[2,8],[-3,12],[0,7],[7,14],[10,11]],[[8134,1287],[0,1],[0,1],[0,2],[0,1],[0,1],[0,2],[3,1],[2,1],[1,0],[1,1],[1,0],[2,1],[2,0],[0,1],[1,0],[1,0],[0,1],[2,0],[1,0],[1,1],[1,0],[1,1],[1,0],[2,1],[1,1],[1,0],[2,1],[1,1],[1,0],[1,1],[1,0],[2,2],[3,1],[1,1],[1,1],[1,1],[1,0],[1,2],[3,2],[1,1],[1,0],[0,1],[1,1],[1,0],[1,1],[1,0],[1,1],[0,1],[1,0],[1,0],[10,16],[11,16],[1,58],[0,19],[0,13],[8,0],[21,0],[0,19]],[[8238,1465],[20,0],[2,0]],[[8260,1465],[37,0]],[[8297,1465],[2,0],[0,-1],[-1,-1],[0,-1],[0,-1],[-1,-2],[0,-1],[1,-1],[0,-1],[0,-1],[0,-1],[0,-1],[-1,-1],[0,-1],[0,-1],[1,-1],[0,-1],[1,-1],[0,-1],[0,-1],[1,-1],[1,1],[1,0],[1,-1],[1,0],[1,0],[1,-1],[1,-1],[0,1],[1,0],[1,0],[0,-1],[1,-1],[1,-1],[1,0],[1,0],[0,-1],[1,-1],[1,-1],[0,-1],[1,0],[1,0],[0,-1],[1,-1],[1,-1],[1,0],[0,-1],[1,-1],[0,-1],[1,-1],[1,-1],[0,1],[1,1],[1,0],[1,0],[0,1],[0,1],[0,1],[0,1],[0,2],[0,1],[1,0],[1,-1],[1,-1],[1,0],[1,0],[0,1],[0,1],[0,1],[1,0],[1,0],[1,-1],[1,-1],[1,-1],[1,-1],[1,0],[1,0],[1,-1],[1,0],[1,0],[1,0],[1,0],[0,1],[1,1],[1,2],[1,0],[1,-1],[1,0],[0,1],[0,1],[0,2],[1,1],[0,1],[0,1],[1,0],[1,0],[1,0],[1,0],[1,0],[1,1],[0,1],[1,0],[1,1],[1,1],[0,1],[1,-1],[0,-1],[1,-1],[0,-1],[1,0],[1,-1],[1,-1],[0,-1],[1,0],[1,-1],[1,-1],[1,-1],[1,-1],[1,0],[1,1],[0,1],[0,1],[-1,1],[-1,1],[0,1],[0,1],[0,1],[0,1],[0,1],[0,1],[0,1],[0,1],[0,1],[1,0],[0,1],[1,1],[1,1],[0,1],[1,1],[0,1],[0,2],[1,0],[1,1],[1,1],[1,0],[1,1],[1,0],[1,1],[1,0]],[[8381,1463],[1,0],[1,0],[0,-1],[1,0],[2,0],[1,1],[2,0],[1,1],[1,0],[1,1],[1,0],[1,0],[1,1],[2,1],[1,0],[1,0],[1,1],[1,0],[2,1],[1,1],[2,1],[1,0],[0,1],[1,0],[1,0]],[[8409,1472],[1,0],[8,-2],[18,6],[17,-10],[5,0],[15,-6],[7,-11],[21,-11],[12,-8],[7,-16],[0,-24],[3,-7],[4,-3],[6,0],[4,3],[6,6],[10,17],[17,12],[19,6],[3,-2],[3,-10],[3,-1],[9,3],[12,-8],[5,-11],[-5,-12],[-11,-24],[-1,-2],[-3,-12],[1,-25],[-3,-14],[-16,-26],[-9,-21],[-11,-12],[-3,-9],[1,-3],[15,-8],[9,8],[20,-8],[1,-8],[-3,-12],[-7,-8],[-2,-9],[5,-33],[3,-7],[13,-6],[2,-17],[6,-19],[5,-8],[3,-9],[-2,-13],[10,-15],[-2,-14],[2,-9],[5,-3],[18,4],[11,-5],[12,-9],[25,-5],[6,-4],[1,-7],[-2,-8],[-5,-6],[-12,-7],[-1,-4],[1,-4],[6,-3],[5,-2]],[[8671,936],[1,2],[-1,3],[-5,3],[-3,-2],[-5,-9],[-4,-14],[-5,-4],[-3,2],[-1,4],[3,20],[-4,3],[-2,-2],[-12,-26],[-6,-20],[-4,-8],[-3,-1],[-6,3],[-8,-8],[-19,-12],[-23,-27],[-22,-17],[-14,-21],[-21,-8],[-13,-8],[-7,1],[-6,4],[-4,7],[-4,17],[5,15],[7,10],[1,8],[-3,1],[-3,-3],[-4,-11],[-7,-8],[-2,-8],[-2,-1],[8,-27],[-1,-7],[-7,-3],[-5,-9],[-9,-5],[-3,-4],[-13,-7],[-2,-5],[-4,-3],[-3,9],[-7,3],[-13,-2],[-14,-16],[-13,4],[-2,13],[-4,1],[-4,-9],[-6,-2],[-4,2],[-10,26],[-3,0],[-6,0],[0,-3],[-2,2],[-1,1],[-1,0],[-1,-2],[0,-3],[0,-2],[0,-1],[-1,-1],[0,-1],[-1,0],[-1,-2],[-1,-2],[-1,0],[-1,-1],[-1,1],[-2,2],[-1,2],[0,1],[-1,1],[-2,1],[-1,2],[0,1],[0,1],[-1,2],[-1,1],[-1,1],[0,2],[0,1],[0,3],[1,1],[-1,3],[-1,1],[-1,2],[-1,1],[0,1],[0,1],[0,1],[-1,1],[0,1],[0,1],[0,1],[0,1],[0,1],[0,1],[1,1],[0,1],[0,1],[1,1],[1,2],[0,2],[0,1],[0,1],[0,1],[1,0],[1,1],[0,1],[1,1],[0,1],[0,1],[0,1],[0,1],[0,1],[1,1],[0,2],[-1,1],[0,1],[0,1],[-1,1],[0,1],[-1,1],[0,1],[0,1],[-1,1],[0,1],[-1,1],[0,1],[-2,0],[0,1],[0,2],[-1,1],[0,2],[0,2],[0,1],[-1,1],[0,1],[0,1],[0,2],[-1,0],[0,1],[1,1],[1,0],[1,1],[1,0],[1,1],[0,1],[-1,0],[1,1],[1,-1],[0,-2],[1,0],[0,1],[0,1],[0,1],[1,0],[1,-1],[1,-1],[0,1],[0,1],[0,1],[-1,1],[0,1],[0,1],[0,1],[0,1],[0,1],[0,1],[0,2],[0,1],[0,1],[0,1],[0,1],[0,2],[0,1],[0,1],[-1,1],[-1,1],[0,1],[-1,1],[0,1],[-1,0],[-1,0],[-1,0],[0,-1],[-1,-1],[-1,0],[0,-1],[-1,-1],[-1,0],[-1,0],[-1,0],[0,1],[-1,1],[-1,0],[-1,0],[-1,0],[-1,0],[-1,1],[-1,0],[-1,1],[-1,0],[-1,0],[0,1],[-1,1],[-1,0],[0,1],[-1,1],[-1,1],[-1,-1],[-1,0],[0,1],[-1,1],[0,2],[-1,1],[0,2],[-1,1],[0,1],[0,1],[-1,2],[0,1],[-1,1],[-1,1],[-1,-1],[0,-1],[0,-1],[-1,-1],[-1,-1],[-1,0],[-1,1],[0,1],[0,1],[-1,1],[-1,-1],[-1,0],[-1,1],[0,1],[0,1],[0,1],[-1,1],[1,2],[0,1],[0,2],[0,1],[0,1],[1,1],[1,0],[0,1],[0,2],[0,1],[-1,0],[0,1],[-1,1],[0,2],[-1,1],[0,1],[1,2],[0,1],[1,1],[-1,1],[0,1],[1,1],[0,1],[1,1],[1,1],[1,1],[1,1],[0,1],[1,1],[-1,1],[-1,1],[0,1],[-1,0],[0,1],[0,1],[-1,1],[0,1],[-1,1],[0,3],[0,2],[0,1],[1,1],[2,0],[0,1],[0,1],[1,2],[1,1],[0,1],[0,1],[0,1],[-1,2],[-1,1],[-1,0],[0,1],[1,2],[-1,105],[-2,166],[0,1],[-1,1],[-1,0],[-1,1],[-1,1],[-1,0],[-1,1],[0,1],[-1,1],[-1,1],[0,1],[-1,1],[-1,1],[0,1],[-1,1],[0,1],[0,2],[-1,1],[0,1],[-1,2],[-1,1],[-1,1],[-1,1],[-1,2],[0,1],[-1,1],[0,1],[0,1],[0,1],[0,2],[-1,1],[-1,1],[-1,1],[-1,3],[-1,1],[-1,0],[-1,1],[-1,1],[0,2],[-1,1],[-1,1],[-1,1],[-1,1],[-1,0],[0,1],[-2,1],[0,1],[-1,0],[-1,1],[0,1],[-1,2],[-1,2],[-1,2],[-1,1],[-1,1],[0,1],[-1,1],[-1,1],[-1,1],[0,1],[-1,0],[-1,1],[-1,0],[0,2],[-1,0],[-1,1],[-1,1],[0,1],[-1,0],[-1,0],[-2,0],[-1,0],[-1,0],[0,1],[-1,0],[-1,0],[-1,0],[-1,0],[-1,0],[-1,0],[-1,-1],[-1,-1],[-1,-1],[-1,-1],[0,-1],[-1,-1],[0,-2],[0,-1],[0,-1],[0,-1],[0,-1],[0,-1],[0,-1],[0,-2],[-1,-2],[-1,0],[-1,1],[-1,0],[0,-1],[-1,0],[-1,0],[-1,0],[-1,0],[-1,1],[0,1],[-1,1],[-1,0],[-1,0],[-1,0],[-1,0],[-1,0],[-1,0],[-1,-1],[0,-1],[-2,-2],[-1,1],[-1,0],[-1,-1],[-1,-1],[-1,-1],[0,-1],[0,-1],[-1,-1],[0,-1],[-1,-1],[-1,0],[0,-1],[-1,0],[-1,0],[-1,0],[-1,-1],[-1,0],[-1,1],[-1,0],[-1,-1],[-1,0],[0,-1],[-1,0],[-1,0],[-1,0],[-1,0],[-1,-1],[0,-1],[-1,-1],[-1,0],[-1,-1],[-1,0],[-1,-1],[-1,0],[-1,0],[-1,0],[-1,-1],[0,-1],[-1,0],[-1,-1],[-1,-1],[-1,-1],[-1,0],[-1,-1],[-2,-2],[0,-1],[-1,1],[-1,1],[-1,1],[-1,1],[-1,1],[-1,0],[-1,1],[-1,1],[-1,1],[0,1],[-1,1],[-1,1],[-1,1],[0,1],[-1,1],[-1,1],[-1,1],[-1,1],[0,1],[0,1],[0,1],[-1,1],[0,1]],[[222,4377],[-18,23],[14,55],[0,9],[-62,-4],[-5,0],[-4,0],[-32,-37],[-54,29],[-8,-20],[-26,9],[-27,11],[0,169],[0,64],[0,179],[0,485],[0,1372],[41,-11],[19,-1],[29,3],[16,-1],[21,-6],[32,-17],[12,-2],[4,-3],[11,-3],[18,-12],[14,-5],[33,-22],[20,-17],[5,-1],[6,8],[6,1],[5,-14],[14,-15],[48,-23],[27,-18],[41,-17],[29,-3],[10,-7],[12,1],[18,-3],[9,4],[12,-2],[5,-2]],[[1932,4385],[-10,-7]],[[1922,4378],[-113,0],[-113,0],[-113,0],[-113,0],[-113,0],[-113,0],[-113,0],[-113,0],[-113,0],[-113,0],[-99,0]],[[693,4378],[-1,0],[-4,0]],[[688,4378],[-9,0],[-114,0],[-113,0],[-25,0],[-88,0],[-113,0],[-4,-1]],[[1796,1687],[-5,-2],[-3,4],[4,5],[4,3],[3,-3],[-3,-7]],[[1937,1751],[0,2],[3,2],[3,-2],[1,-3],[3,-1],[5,-1],[0,-4],[-1,-2],[-4,-1],[-5,2],[-4,5],[-1,3]],[[1965,1717],[-6,1],[-2,10],[2,1],[4,-2],[2,-7],[0,-3]],[[1116,3072],[0,-1],[-2,-2],[-3,0],[-1,3],[6,0]],[[1150,3072],[2,-2],[-2,-7],[-14,-14],[-4,-3],[-4,1],[-1,3],[1,10],[-1,9],[4,3],[2,0],[6,-2],[7,2],[4,0]],[[1169,3323],[1,1],[1,0],[0,-2],[0,-1],[0,-1],[0,-1],[-1,-1],[-1,0],[0,5]],[[1187,3239],[0,1],[1,1],[0,1],[0,1],[0,1],[0,1],[1,0],[1,0],[0,-1],[0,-1],[-1,0],[0,-1],[1,-1],[-1,-1],[0,-1],[-1,0],[0,-1],[0,-1],[-1,0],[0,-1],[0,3]],[[1207,3151],[1,0],[0,1],[1,1],[0,1],[1,0],[0,1],[5,2],[1,-5],[-1,-6],[-15,-26],[-5,-4],[-4,0],[-1,5],[11,15],[6,15]],[[1187,3138],[0,1],[1,0],[0,1],[0,1],[1,0],[0,-1],[1,0],[0,1],[1,0],[0,1],[1,0],[0,1],[0,-1],[0,-1],[-5,-3]],[[2030,1583],[-1,-3],[-4,-1],[-4,6],[-6,16],[-1,6],[2,5],[4,2],[7,-7],[1,-4],[-1,-13],[3,-7]],[[1992,1680],[-4,0],[-8,5],[-10,13],[1,5],[2,0],[11,-12],[8,-4],[1,-5],[-1,-2]],[[1982,1644],[-4,0],[-3,12],[-5,27],[2,2],[3,-6],[6,-4],[5,-18],[3,-4],[0,-3],[-6,-3],[-1,-3]],[[2006,1645],[0,-2],[-3,0],[-3,3],[-2,8],[1,4],[2,0],[4,-8],[1,-5]],[[1768,1963],[9,-11],[21,-41],[16,-22],[2,-7],[-2,-21],[13,-34],[11,-6],[16,-5],[22,-16],[29,-16],[20,-18],[8,-25],[9,-10],[10,-37],[8,-12],[4,-14],[1,-17],[6,-12],[3,-13],[-1,-10],[-3,-12],[1,-3],[4,0],[4,7],[5,26],[4,2],[3,-1],[3,-10],[2,-22],[9,-24],[-2,-10],[-4,-5],[-6,-5],[-4,0],[-9,6],[-6,-4],[-8,-13],[-2,0],[-13,3],[-2,6],[-4,2],[-7,-2],[-7,2],[-27,18],[-32,16],[-6,15],[-10,-5],[-13,4],[-32,30],[-20,14],[-2,7],[-7,2],[-1,7],[14,8],[5,6],[8,15],[16,17],[4,23],[-1,18],[-3,15],[-4,-1],[-1,-4],[0,-11],[3,-9],[0,-6],[-6,-17],[-5,-9],[-3,-2],[-5,2],[-11,-4],[-11,4],[-3,-2],[-1,-4],[-4,-5],[-3,2],[-3,11],[-6,2],[-5,-4],[-5,-14],[-9,-3],[-9,5],[-6,11],[-5,6],[-19,11],[-4,9],[1,4],[3,2],[14,-5],[4,3],[6,12],[1,4],[-3,2],[-4,-5],[-4,-2],[-2,1],[1,9],[-6,12],[0,8],[-2,5],[-4,-6],[-13,-8],[-2,1],[-1,5],[11,23],[-1,5],[-4,-1],[-2,-8],[-6,-3],[-3,5],[1,11],[-2,4],[-10,-6],[-3,0],[-8,5],[-4,-3],[-2,-8],[-3,-2],[-4,3],[-7,19],[-2,1],[-3,-1],[-1,-14],[-3,-2],[-4,1],[-5,14],[0,10],[4,15],[4,7],[9,5],[15,-2],[17,5],[5,4],[0,6],[-5,1],[-20,-8],[-7,0],[-10,4],[-2,2],[-2,6],[1,4],[8,12],[-2,9],[-3,2],[-3,-2],[-4,-12],[-4,-3],[-3,2],[-6,19],[0,4],[0,7],[1,4],[1,4],[0,2],[-2,2],[-2,-2],[-1,-2],[-4,-2],[-2,2],[-9,19],[-4,2],[-3,-2],[4,-10],[-1,-4],[-3,-3],[-3,-2],[-2,1],[0,3],[1,5],[0,4],[-2,3],[-2,2],[-1,-1],[-1,-3],[0,-7],[-1,-4],[-1,-6],[-3,-5],[-3,-2],[-10,0],[-8,6],[-4,10],[1,6],[3,9],[-1,9],[6,21],[1,4],[-4,4],[-5,-6],[-4,1],[-2,4],[-5,0],[-1,-3],[2,-5],[-2,-6],[-3,-6],[-5,-3],[-5,2],[-4,6],[-3,8],[1,11],[-1,3],[-10,-8],[-2,1],[-4,4],[-21,-13],[-9,4],[0,6],[5,6],[5,12],[1,9],[-5,5],[-4,13],[-4,2],[-4,-3],[-3,1],[-2,5],[5,15],[4,8],[10,6],[19,1],[6,-5],[6,-10],[5,-1],[1,4],[-7,20],[0,5],[1,3],[7,5],[3,2],[1,3],[-1,4],[-3,1],[-2,1],[-2,-1],[-3,-2],[-4,1],[-5,2],[-5,2],[-5,2],[-6,0],[-4,-2],[-2,-2],[1,-3],[4,-2],[4,1],[4,0],[3,-2],[4,-3],[1,-2],[-1,-3],[-2,-2],[-2,-1],[-8,-4],[-12,-3],[-9,-6],[-4,0],[-3,7],[1,5],[-3,3],[-4,-4],[-3,-16],[-5,1],[-15,26],[-4,4],[-5,15],[-5,8],[-5,20],[2,7],[3,2],[17,3],[19,10],[10,1],[56,-27],[17,-13],[13,-14],[22,-16],[50,-23],[10,1],[18,-7],[24,-4],[19,-7],[11,-8],[44,-16],[5,-22],[15,-41]],[[2011,1656],[3,3],[5,0],[5,-4],[-1,-3],[-6,-1],[-6,5]],[[897,2972],[-8,1],[-3,7],[4,3],[6,-3],[2,-5],[-1,-3]],[[1210,3120],[2,-3],[-4,-13],[-7,-6],[-3,1],[-1,6],[5,4],[3,8],[5,3]],[[1148,3044],[0,-3],[-3,-4],[-2,-2],[-3,-1],[-2,1],[-1,3],[1,3],[3,3],[3,2],[2,1],[2,-3]],[[1154,3034],[1,-2],[1,-4],[-2,-1],[-3,-1],[-2,0],[-1,2],[1,4],[5,2]],[[1155,3019],[1,-1],[0,-4],[-2,-2],[-4,0],[-2,3],[0,3],[3,1],[4,0]],[[990,2869],[2,-3],[0,-4],[-1,-5],[-2,-3],[-3,-2],[-2,2],[0,6],[1,5],[2,3],[3,1]],[[1189,2982],[-2,2],[-2,1],[-4,6],[-3,6],[-2,3],[3,3],[2,-1],[1,-1],[2,-3],[3,-3],[3,-3],[3,-5],[-4,-5]],[[1158,2957],[-2,-1],[-6,2],[-4,8],[-1,5],[4,2],[2,0],[4,-5],[4,-8],[-1,-3]],[[1168,2953],[1,2],[2,0],[3,0],[1,-4],[0,-2],[-2,-2],[-3,0],[-2,6]],[[1212,2961],[3,-5],[1,-3],[-2,-2],[-2,0],[-5,1],[-3,6],[1,3],[2,2],[5,-2]],[[1218,2930],[1,-4],[-1,-3],[-3,-2],[-3,3],[-2,5],[-1,3],[-1,6],[3,4],[4,-3],[3,-9]],[[1194,2895],[-8,-3],[-15,14],[-5,2],[-4,-3],[0,-3],[2,-7],[-4,-4],[-2,1],[-5,13],[1,6],[10,9],[6,11],[18,11],[10,-3],[2,-5],[-1,-3],[8,-14],[-4,-10],[-9,-12]],[[1178,2882],[-1,-3],[-5,-4],[-6,2],[-1,2],[7,7],[5,-1],[1,-3]],[[1193,2874],[-1,-3],[-4,-3],[-3,2],[-1,4],[2,3],[5,1],[2,-4]],[[956,2714],[2,-3],[-4,-2],[-5,-2],[-3,-1],[-4,0],[-2,3],[2,2],[4,2],[4,1],[4,0],[2,0]],[[965,2857],[-10,-9],[-9,-6],[-2,-2],[1,-3],[3,0],[4,1],[5,1],[1,-1],[0,-4],[-3,-5],[-1,-2],[-1,-6],[1,-3],[3,0],[3,6],[12,8],[1,3],[15,7],[1,2],[3,3],[2,7],[0,5],[2,11],[1,7],[5,29],[-1,6],[-7,15],[3,2],[8,-3],[12,1],[20,17],[8,14],[4,-3],[-6,-39],[-16,-34],[-3,-12],[-1,-21],[-6,-33],[-1,-12],[7,-18],[-9,-36],[-2,-4],[-7,-5],[-13,-2],[-6,-4],[1,-4],[3,-3],[-2,-5],[-26,-3],[-15,5],[-9,14],[-7,3],[-1,4],[3,8],[-2,3],[-4,1],[-3,5],[1,5],[4,3],[11,0],[6,-3],[6,-12],[6,-1],[2,3],[-9,13],[1,7],[-3,4],[-20,5],[-8,7],[-10,0],[-3,11],[-6,5],[-5,10],[2,10],[-7,12],[1,10],[-11,15],[0,15],[-4,10],[-1,18],[2,7],[6,7],[0,4],[-2,19],[3,9],[7,4],[22,-9],[14,2],[6,-3],[4,-8],[-7,-23],[2,-4],[2,-1],[8,14],[25,19],[5,-2],[4,-7],[0,-5],[12,-21],[-2,-12],[1,-10],[-2,-8],[-7,-12],[-15,-13]],[[1009,2731],[-1,-3],[-2,-3],[-2,-1],[-3,2],[0,3],[2,3],[2,1],[4,-2]],[[1170,2801],[-3,-3],[-3,0],[-3,2],[0,3],[1,3],[2,1],[3,0],[3,-6]],[[982,2676],[0,-3],[-3,-2],[-2,-1],[-3,1],[-3,1],[-1,4],[2,2],[3,3],[3,-1],[3,-2],[1,-2]],[[1192,2853],[2,3],[2,2],[1,3],[0,4],[1,3],[1,2],[2,1],[2,-2],[2,-4],[0,-4],[1,-3],[2,-4],[1,-3],[3,-2],[2,-2],[2,-3],[0,-5],[1,-3],[3,-4],[3,-4],[2,-5],[0,-4],[-3,-2],[-2,2],[-3,3],[-6,4],[-2,1],[-18,12],[-3,6],[4,8]],[[1242,2810],[3,-5],[-1,-2],[-1,-2],[-3,-1],[-2,2],[-4,7],[2,4],[3,0],[3,-3]],[[1357,2872],[3,-6],[-2,-4],[-3,-5],[-3,-3],[-4,0],[-3,-1],[-2,1],[-1,2],[2,5],[3,3],[3,2],[1,2],[6,4]],[[1043,2657],[-6,-3],[-6,3],[-9,23],[5,4],[3,-2],[11,-6],[6,-6],[1,-2],[0,-5],[-5,-6]],[[1044,2640],[-3,-1],[-4,-1],[-3,2],[-1,4],[2,3],[3,1],[8,-4],[-2,-4]],[[1048,2626],[3,-2],[0,-3],[-1,-2],[-2,-2],[-4,0],[-2,3],[1,3],[5,3]],[[1339,2842],[4,3],[8,1],[7,3],[5,-3],[-3,-9],[1,-9],[-4,-3],[-10,1],[-7,-5],[-4,-16],[-2,-8],[-2,-6],[-2,-5],[-3,-3],[-1,2],[-1,5],[1,3],[6,26],[-2,9],[1,8],[8,6]],[[1309,2769],[-1,-5],[0,-3],[-3,-1],[-2,2],[-1,3],[-2,6],[0,3],[3,4],[3,0],[3,-9]],[[1327,2773],[-2,-4],[-4,0],[-2,4],[0,2],[1,2],[4,1],[2,-1],[1,-4]],[[1256,2727],[-8,-3],[-5,-4],[-4,1],[-19,42],[-9,8],[-10,4],[-7,11],[-10,22],[-8,3],[-4,8],[-1,12],[6,4],[5,-1],[13,-14],[35,-20],[7,-13],[3,-2],[17,-37],[2,-13],[-3,-8]],[[1248,2806],[1,10],[-2,5],[-5,4],[-9,3],[-5,8],[-24,45],[1,11],[3,4],[4,3],[8,-5],[8,-12],[3,-1],[2,-5],[6,-5],[10,-14],[17,-28],[9,-19],[8,-10],[8,-4],[2,-4],[1,-7],[-5,-15],[3,-17],[-1,-7],[-5,-3],[-12,4],[-10,24],[-8,5],[-6,12],[-2,14],[0,4]],[[1060,2613],[9,5],[2,-5],[-4,-13],[1,-3],[-1,-3],[-1,-3],[-3,0],[-2,2],[-2,0],[-1,-2],[1,-4],[-1,-3],[-1,-1],[-4,1],[-1,3],[-2,10],[-4,7],[1,5],[6,4],[5,-1],[2,1]],[[1344,2765],[-6,-2],[-3,2],[-1,7],[7,9],[1,6],[1,2],[0,6],[-1,4],[0,3],[2,2],[4,-2],[1,-3],[0,-5],[0,-2],[5,-12],[1,-7],[-5,-6],[-6,-2]],[[1313,2750],[-1,-6],[-2,-2],[-2,-2],[-2,0],[-2,2],[0,3],[1,3],[2,1],[1,2],[3,0],[2,-1]],[[1278,2703],[-3,-2],[-7,5],[-3,9],[4,2],[7,-5],[3,-5],[-1,-4]],[[1083,2576],[-2,-4],[-2,-2],[-3,0],[-1,3],[1,4],[3,2],[3,0],[1,-3]],[[1316,2741],[2,8],[0,8],[4,3],[10,-15],[-3,-21],[2,-5],[-2,-4],[-5,-2],[-8,3],[-5,11],[5,14]],[[1293,2689],[-1,-4],[-2,-2],[-2,1],[-2,1],[-1,3],[0,4],[2,2],[2,0],[4,-5]],[[1285,2681],[-1,-4],[-3,-1],[-3,2],[-3,3],[0,4],[2,2],[3,0],[2,-1],[3,-5]],[[1311,2682],[-5,1],[-11,21],[-7,10],[-3,7],[0,4],[3,1],[6,-2],[5,-5],[4,-12],[3,-4],[3,-2],[2,-3],[0,-2],[1,-5],[-1,-9]],[[1092,2529],[-4,-1],[-4,8],[1,9],[5,3],[4,-3],[-2,-5],[0,-11]],[[1312,2631],[-2,-2],[-2,1],[-2,3],[0,3],[0,3],[2,3],[2,2],[2,-3],[1,-4],[-1,-6]],[[1012,2724],[3,8],[7,3],[6,-1],[9,-19],[8,-8],[5,-11],[-1,-8],[-5,-1],[-4,6],[-10,4],[-14,-8],[-3,-9],[5,-15],[4,-18],[6,-13],[8,-2],[2,-4],[-5,-9],[5,-18],[12,-28],[12,-5],[5,-12],[2,-14],[20,-34],[4,-4],[3,2],[1,7],[6,5],[3,-1],[3,-4],[0,-10],[4,-8],[4,0],[3,-1],[2,-3],[-1,-3],[-1,-2],[-3,0],[-2,0],[-3,1],[-2,1],[-3,-3],[-1,-3],[0,-2],[-2,-2],[-2,-1],[-3,3],[-5,10],[-2,-4],[2,-7],[-1,-5],[-2,-2],[-2,0],[-24,44],[-5,6],[-4,8],[2,11],[-11,6],[-7,17],[-9,9],[-14,9],[-13,20],[-3,4],[0,8],[0,3],[2,3],[4,2],[4,1],[3,2],[-2,4],[-3,2],[-4,1],[-4,-2],[-3,-3],[-2,-2],[-4,-3],[-2,0],[-4,3],[-7,16],[-6,13],[0,8],[2,3],[4,2],[3,1],[5,2],[4,4],[1,3],[-4,3],[-6,1],[-6,2],[-4,3],[-2,0],[-4,-2],[-6,0],[-3,1],[-2,2],[-2,4],[-4,1],[-1,4],[4,3],[11,3],[7,5],[11,0],[25,10],[5,5],[1,2]],[[1109,2455],[0,13],[3,2],[6,-2],[2,0],[4,-1],[4,-1],[2,-4],[-1,-3],[-3,0],[-4,0],[-3,-3],[0,-2],[3,-3],[1,-2],[0,-3],[-1,-3],[-2,-1],[0,-3],[0,-3],[-1,-2],[-4,-2],[-5,11],[-1,2],[0,10]],[[1386,2664],[-4,-2],[-8,-38],[1,-18],[-3,-6],[-9,-6],[-5,2],[-20,47],[-2,15],[-5,7],[-5,16],[1,11],[6,9],[1,11],[5,12],[-1,3],[4,14],[-3,6],[1,6],[7,4],[6,1],[11,-23],[25,-25],[8,-20],[3,-15],[0,-20],[-5,-37],[1,-13],[-3,-8],[-4,-3],[-7,1],[-2,9],[0,16],[9,30],[0,8],[-3,6]],[[1407,2637],[4,-4],[0,-3],[0,-3],[0,-3],[0,-4],[0,-3],[-1,-3],[0,-4],[-1,-6],[-2,-2],[-2,1],[-2,3],[-1,3],[1,3],[1,4],[0,5],[0,3],[2,4],[-1,3],[-1,4],[3,2]],[[1352,2548],[-5,1],[-10,30],[-12,14],[-6,15],[-3,14],[4,14],[2,-1],[11,-26],[18,-17],[6,-10],[0,-9],[-5,-25]],[[1433,2589],[-2,5],[1,8],[-4,15],[1,3],[13,8],[2,-1],[1,-5],[-4,-15],[-3,-3],[-2,-14],[-3,-1]],[[1416,2619],[3,1],[2,-4],[3,-27],[3,-13],[0,-4],[-2,-2],[-5,3],[-5,13],[3,17],[-3,9],[1,7]],[[1400,2588],[4,-7],[-1,-8],[3,-12],[-1,-9],[-6,-1],[-7,10],[-5,2],[-9,-3],[-4,1],[-2,5],[1,3],[7,3],[1,5],[19,11]],[[1419,2567],[3,-1],[2,-2],[2,-3],[1,-2],[-1,-3],[-3,-2],[-2,0],[-2,1],[-3,8],[0,3],[3,1]],[[1428,2545],[-1,-4],[-5,-5],[-5,-4],[-3,2],[0,6],[11,7],[3,-2]],[[1388,2512],[-4,0],[-3,16],[-5,12],[1,4],[5,3],[6,-1],[2,-5],[1,-17],[-3,-12]],[[1452,2513],[-4,-2],[-3,1],[-1,2],[1,4],[2,3],[2,1],[1,4],[0,3],[-1,4],[0,3],[3,1],[3,-3],[1,-3],[0,-3],[1,-3],[0,-4],[-1,-3],[-1,-2],[-3,-3]],[[1417,2488],[-3,-8],[-2,-1],[-2,1],[-3,5],[2,5],[5,3],[3,-5]],[[1426,2497],[2,-1],[1,-4],[-1,-2],[-1,-3],[-2,-1],[-2,1],[-2,1],[-1,4],[1,2],[5,3]],[[1460,2505],[-2,-3],[-3,-3],[-5,-3],[-4,1],[1,4],[3,3],[4,2],[3,2],[3,-3]],[[1441,2488],[-4,-6],[-2,-3],[-3,-3],[-3,0],[-2,2],[2,4],[2,7],[3,2],[4,1],[3,-4]],[[1463,2500],[3,6],[3,-1],[4,-12],[0,-6],[-9,0],[-5,4],[4,9]],[[1441,2452],[-3,1],[-4,13],[6,12],[4,3],[2,-4],[-2,-7],[2,-8],[-5,-10]],[[1475,2465],[-12,-5],[-8,1],[-2,4],[1,10],[6,4],[16,-4],[2,-3],[-3,-7]],[[1412,2416],[-2,2],[0,3],[1,3],[2,4],[2,5],[3,1],[1,-4],[0,-4],[-2,-6],[-2,-2],[-3,-2]],[[1491,2432],[-10,-3],[-3,9],[4,11],[-1,8],[2,7],[8,25],[8,6],[4,-1],[4,3],[8,9],[11,7],[9,18],[10,6],[2,-1],[5,-16],[-2,-8],[-4,-4],[-28,-18],[-12,-14],[-6,-9],[-2,-8],[0,-12],[-1,-7],[-6,-8]],[[1459,2395],[-7,-2],[-5,15],[-6,4],[-2,5],[5,10],[1,15],[4,6],[6,2],[6,0],[7,-4],[4,-8],[-2,-13],[-7,-14],[-2,-12],[-2,-4]],[[1461,2358],[1,6],[2,2],[3,-1],[2,-3],[0,-5],[-3,-2],[-5,3]],[[1452,2354],[5,-9],[10,-2],[6,-8],[4,-9],[-1,-8],[2,-10],[-2,-7],[-4,0],[-3,6],[-11,6],[-10,34],[0,4],[4,3]],[[1503,2312],[1,4],[3,5],[3,4],[2,0],[2,-3],[-1,-5],[-3,-8],[-2,-2],[-4,0],[-1,5]],[[1341,2149],[-3,-2],[-3,1],[-1,2],[-1,4],[2,2],[2,1],[1,1],[3,-3],[0,-6]],[[1363,2145],[-3,-2],[-3,1],[-1,1],[0,4],[1,2],[2,2],[2,0],[2,-2],[0,-6]],[[1383,2140],[-1,-3],[-2,-2],[-3,1],[-2,3],[-1,2],[2,3],[1,4],[3,-1],[3,-7]],[[1400,2146],[-2,-3],[-1,-2],[-3,-2],[-3,-2],[-2,0],[-2,2],[-1,4],[2,1],[2,3],[4,2],[2,0],[3,-1],[1,-2]],[[1515,2204],[-3,-2],[-3,1],[-1,2],[0,4],[1,2],[2,1],[2,1],[2,-3],[0,-6]],[[1478,2171],[-3,-2],[-2,0],[-4,0],[-2,-1],[-3,-1],[-3,3],[1,4],[3,1],[4,3],[1,3],[3,1],[3,-1],[2,-10]],[[1498,2158],[-3,-2],[-3,2],[-4,3],[-1,5],[4,2],[6,-3],[1,-4],[0,-3]],[[1604,2163],[-2,-3],[-3,-2],[-3,0],[-3,1],[-1,3],[1,2],[1,2],[4,2],[2,0],[3,-2],[1,-3]],[[1607,2157],[5,3],[11,-8],[1,-3],[-3,-4],[-10,2],[-8,-4],[-10,6],[5,5],[5,0],[4,3]],[[1619,2138],[0,-4],[0,-2],[-3,-2],[-5,2],[0,3],[2,2],[3,2],[3,-1]],[[1590,2106],[-21,-3],[-7,1],[-1,3],[6,5],[19,1],[4,-2],[0,-5]],[[1623,2124],[0,-4],[-1,-2],[-4,-2],[-2,1],[-1,1],[0,3],[1,2],[3,1],[4,0]],[[1612,2096],[1,-2],[-1,-2],[-3,-2],[-3,1],[-1,2],[-1,4],[3,2],[5,-3]],[[1657,2148],[10,-7],[1,-5],[-5,-7],[-3,-11],[-15,1],[-10,-4],[-6,1],[-1,3],[1,4],[4,5],[3,9],[8,6],[13,5]],[[1625,2090],[-3,-1],[-2,1],[-1,2],[0,3],[1,2],[2,2],[3,-1],[2,-1],[0,-2],[-1,-3],[-1,-2]],[[1650,2110],[0,-5],[-3,-3],[-4,-2],[-4,-3],[-4,-1],[-2,2],[0,4],[2,2],[9,6],[4,1],[2,-1]],[[1660,2092],[-1,-5],[-9,-6],[-11,-3],[-8,0],[-2,3],[0,3],[4,2],[25,8],[2,-2]],[[1694,2055],[0,4],[4,3],[9,-1],[5,-4],[-1,-3],[-3,-1],[-14,2]],[[1544,1962],[3,1],[1,-3],[-1,-5],[-1,-4],[-2,-2],[-3,-1],[-1,5],[1,3],[2,3],[1,3]],[[1722,2051],[5,3],[4,1],[6,1],[4,0],[1,-4],[-1,-3],[-4,-2],[-3,-3],[-6,0],[-4,0],[-2,2],[-2,2],[2,3]],[[1783,2038],[-4,-2],[-2,0],[-2,2],[-3,2],[-3,3],[-1,5],[0,4],[2,2],[2,1],[3,0],[2,-1],[2,-3],[3,-4],[2,-5],[-1,-4]],[[1789,2030],[1,-2],[1,-4],[-1,-3],[-1,-3],[-2,0],[-2,1],[-1,4],[1,5],[4,2]],[[1809,2034],[-1,-5],[-2,-2],[-2,-2],[-2,1],[-3,5],[2,3],[4,2],[4,-2]],[[1799,2016],[3,-5],[0,-3],[-1,-3],[-3,-3],[-2,-4],[-2,-5],[-3,-2],[-2,2],[0,3],[1,4],[2,4],[0,7],[1,2],[6,3]],[[1843,2011],[-4,-6],[-5,2],[-4,11],[1,3],[3,2],[5,-2],[4,-10]],[[1826,1988],[-4,0],[-5,14],[-3,3],[-4,16],[4,3],[7,-4],[8,-24],[-3,-8]],[[1778,2007],[3,-10],[-2,-11],[5,-18],[-2,-6],[-2,0],[-8,19],[-7,21],[0,3],[1,3],[0,7],[1,3],[3,2],[3,0],[1,0],[2,-5],[2,-8]],[[1618,1855],[-5,-2],[-5,0],[-4,6],[-10,6],[-9,16],[2,10],[2,6],[-1,3],[-8,1],[-1,5],[15,10],[7,-3],[5,-10],[13,-39],[-1,-9]],[[1813,1966],[-4,-2],[-5,1],[-7,18],[1,5],[6,7],[1,7],[2,1],[2,-1],[7,-24],[-3,-12]],[[1629,1860],[-3,1],[-2,4],[1,4],[2,1],[2,0],[2,-6],[0,-3],[-2,-1]],[[1841,1919],[2,-3],[0,-3],[-1,-4],[-2,0],[-2,1],[-1,5],[0,2],[4,2]],[[1673,1799],[3,-6],[-1,-3],[5,-15],[-3,-2],[-7,4],[-5,0],[-1,5],[0,11],[9,6]],[[1912,1887],[-11,-12],[-3,2],[-2,4],[9,12],[8,5],[2,-3],[-3,-8]],[[1686,1750],[-2,4],[1,4],[2,2],[2,-1],[2,-2],[0,-4],[-2,-3],[-3,0]],[[1838,1831],[-3,0],[-4,2],[-5,17],[4,0],[3,-8],[4,-4],[1,-7]],[[1706,1753],[-5,2],[-4,5],[0,3],[5,3],[4,-2],[2,-4],[-2,-7]],[[1851,1839],[1,-4],[-1,-2],[-6,-1],[-2,6],[5,2],[3,-1]],[[1844,1887],[0,12],[4,1],[3,-4],[5,-8],[8,-6],[10,-3],[13,-21],[11,-14],[2,-7],[-5,-2],[-5,3],[-5,2],[-6,5],[-8,6],[-10,10],[-10,12],[-7,14]],[[1987,1829],[5,-5],[0,-5],[-3,-1],[-5,1],[-1,6],[1,3],[3,1]],[[1991,1794],[-6,-3],[-1,2],[1,3],[3,9],[4,1],[1,-8],[-2,-4]],[[1937,4378],[-15,0]],[[1922,4378],[19,0]],[[3040,1706],[-35,0],[-35,0],[-31,0],[-52,0],[-67,-1],[-110,1],[-46,1],[-86,0],[-73,-1],[-54,0],[-11,0],[-24,0],[-15,0],[-16,0],[-61,0],[-47,0],[-27,0],[-2,0],[-46,0],[-48,0],[-35,-1],[-2,0],[-8,1],[-45,1],[-3,0],[-8,0],[-2,2],[-6,13],[-5,1],[-12,-4],[-1,-3],[2,-8],[-1,-1],[-3,0],[-4,2],[-5,15],[3,13],[-11,6],[-3,14],[1,16],[3,2],[5,-2],[15,3],[12,7],[5,10],[4,24],[-3,4],[-3,-2],[-3,-18],[-6,-8],[-17,-8],[-14,0],[-3,2],[-1,7],[2,20],[-3,11],[5,18],[1,2],[0,6],[1,5],[2,5],[4,7],[1,4],[0,3],[-2,1],[-2,-2],[-3,-2],[-1,-4],[-1,-5],[-2,-6],[-4,-5],[-6,-5],[-5,-3],[-8,-8],[-3,-8],[-2,-14],[-6,-8],[-9,4],[-10,9],[-21,10],[-3,3],[-6,14],[-7,10],[-2,7],[1,10],[4,12],[3,2],[3,-2],[12,-27],[6,-18],[3,-1],[2,15],[6,7],[9,5],[2,3],[-3,3],[-13,-3],[-7,2],[-10,29],[2,9],[1,10],[-7,22],[0,4],[3,6],[11,7],[5,7],[0,6],[-3,10],[-12,15],[-3,2],[-4,-3],[2,-4],[12,-11],[2,-7],[-2,-4],[-16,-12],[-4,-9],[0,-6],[7,-19],[1,-5],[-1,-7],[-5,0],[-4,13],[-2,1],[-2,-2],[1,-5],[-3,-5],[-3,-11],[-9,0],[-18,-11],[-8,8],[-15,9],[-18,29],[-13,14],[-3,6],[0,5],[4,1],[8,-7],[4,0],[1,3],[-5,9],[-1,6],[4,11],[9,13],[2,12],[0,9],[-8,16],[3,7],[2,5],[9,5],[7,-1],[8,5],[9,11],[1,7],[-4,1],[-12,-12],[-6,-4],[-9,0],[-9,-4],[-9,-14],[-5,-6],[-8,3],[-5,13],[-4,3],[-4,-4],[-2,-7],[-3,-3],[-3,7],[3,12],[16,31],[8,26],[-1,18],[-4,14],[3,9],[4,9],[0,7],[-5,-2],[-3,-4],[-7,-19],[4,-28],[-3,-19],[-17,-27],[-7,-13],[-4,-3],[-5,2],[-3,8],[-7,3],[-3,10],[-2,1],[-5,-2],[-1,-12],[-3,-5],[-3,-3],[-5,3],[-2,6],[1,25],[3,9],[7,13],[-2,7],[-2,1],[-4,-3],[-6,-15],[-5,-33],[-6,-8],[-4,-3],[-6,4],[-2,6],[2,8],[-3,3],[-21,-12],[-11,1],[-8,-2],[-6,1],[-4,1],[-1,5],[8,11],[18,12],[1,4],[-5,1],[-16,-7],[-4,1],[-2,6],[23,9],[23,1],[15,11],[10,13],[2,15],[-2,4],[2,6],[7,7],[2,8],[-2,21],[-5,15],[-2,1],[-1,-14],[4,-16],[-2,-8],[-9,-14],[-2,-6],[1,-15],[-7,-10],[-9,-6],[-5,0],[-35,-7],[-1,4],[5,11],[11,7],[2,4],[-4,4],[-11,0],[-5,10],[-6,-4],[-11,5],[-5,-1],[-12,-9],[-4,1],[-2,6],[0,12],[8,4],[24,-2],[6,1],[1,4],[-1,3],[-5,2],[-14,2],[-7,3],[-8,9],[-5,-3],[-2,-14],[-12,-7],[-4,0],[-7,3],[-3,12],[-3,1],[-9,-6],[-6,-18],[-3,-4],[-5,-2],[-13,4],[-9,6],[-20,9],[-6,6],[-7,17],[0,5],[3,2],[13,-3],[21,-1],[32,5],[7,-1],[13,-9],[4,2],[2,5],[-5,16],[6,16],[-1,3],[-5,-2],[-7,-13],[-7,-5],[-50,-7],[-15,3],[-10,8],[-2,5],[-7,4],[-2,-1],[0,-8],[-2,-4],[-8,1],[-9,8],[-7,14],[3,7],[37,8],[25,8],[13,10],[1,3],[-4,4],[-19,-10],[-14,-1],[-3,1],[-2,4],[7,8],[-1,3],[-5,2],[-12,-7],[-15,-12],[-5,0],[-1,3],[1,5],[9,5],[2,9],[18,13],[0,23],[4,12],[14,9],[8,3],[3,6],[-2,2],[-4,1],[-8,-5],[-12,-4],[-9,-7],[-8,-16],[-12,-7],[-3,2],[-3,7],[0,4],[7,5],[5,0],[2,2],[-2,5],[-8,7],[-10,0],[-5,11],[0,19],[7,30],[4,4],[13,8],[4,5],[2,17],[8,19],[6,5],[2,-1],[2,-11],[3,0],[4,8],[-1,8],[2,6],[15,12],[11,13],[6,4],[17,-7],[11,-28],[14,-20],[8,-21],[3,0],[2,7],[-1,7],[-14,28],[-11,16],[-7,22],[2,6],[5,3],[11,1],[0,6],[-5,2],[-9,-1],[-13,-7],[-7,-1],[-7,4],[-5,16],[-2,12],[2,6],[6,10],[14,15],[8,14],[1,12],[-2,24],[-6,9],[-4,1],[-3,-2],[7,-22],[-5,-23],[-9,-16],[-18,-18],[-5,-19],[-5,-2],[-11,7],[-4,-3],[-2,-5],[5,-12],[-3,-10],[-22,-13],[-6,15],[-3,-3],[-5,-22],[-3,-1],[-5,15],[5,16],[-4,11],[1,3],[4,2],[13,-3],[0,3],[-3,6],[-11,4],[-11,-6],[-2,-9],[0,-6],[1,-2],[-1,-6],[-2,-6],[-3,-2],[-2,2],[-1,3],[-2,4],[1,3],[0,3],[-2,14],[3,7],[-2,5],[-4,2],[-7,-5],[-3,-6],[-5,-27],[-6,-12],[-6,-5],[-5,3],[2,11],[9,16],[4,17],[-1,13],[14,48],[6,5],[15,-5],[4,1],[-1,6],[-20,7],[-3,7],[2,8],[8,5],[2,4],[-2,4],[-5,1],[-6,-1],[-11,-7],[-4,-13],[-3,-5],[-6,0],[-13,5],[-1,4],[-2,5],[0,20],[-4,25],[-9,20],[-5,8],[-7,8],[-8,5],[-7,8],[-8,21],[-1,7],[2,10],[-3,5],[3,8],[-2,5],[-8,1],[-4,8],[-1,7],[5,3],[8,-2],[6,0],[5,-8],[9,-4],[10,-14],[9,-4],[14,1],[11,7],[14,-3],[5,-5],[4,-10],[-1,-6],[2,-5],[9,1],[6,-14],[5,-2],[1,9],[-3,9],[-24,36],[-5,2],[-6,-4],[-7,-1],[-9,3],[-5,-3],[-9,-1],[-8,4],[-10,11],[-9,6],[-8,20],[3,13],[0,5],[-3,8],[0,2],[11,7],[5,7],[7,3],[9,-2],[4,1],[0,3],[-3,2],[-6,0],[-4,0],[-3,2],[-4,1],[-3,7],[0,7],[5,14],[-3,4],[-4,-3],[-19,-37],[-6,-4],[-16,-13],[-6,-6],[-10,-19],[-10,-6],[0,-5],[4,-10],[2,-12],[-5,-26],[-6,1],[-4,5],[-4,7],[-10,20],[-7,5],[-7,9],[-11,21],[-17,23],[-23,38],[-1,30],[5,19],[-4,3],[-14,3],[-6,12],[-10,28],[-11,4],[-4,7],[2,13],[9,11],[-4,7],[0,10],[-4,11],[1,3],[3,2],[9,-6],[7,-14],[7,-8],[16,-39],[7,-8],[5,0],[1,9],[-2,4],[-8,14],[-17,25],[-13,26],[0,5],[3,6],[15,10],[9,24],[6,8],[0,6],[-5,2],[-2,3],[4,10],[8,5],[7,-4],[6,0],[4,8],[-3,4],[-8,2],[-2,5],[1,7],[11,19],[13,30],[11,32],[7,6],[5,-1],[5,2],[1,5],[-8,5],[-12,-3],[-8,1],[-5,13],[-1,13],[-2,4],[-5,-1],[0,-9],[4,-12],[3,-19],[0,-13],[-18,-55],[-14,-23],[-5,0],[-1,6],[4,16],[5,13],[9,16],[1,6],[1,0],[0,1],[1,1],[1,1],[0,1],[1,1],[0,1],[0,1],[-1,0],[0,1],[0,1],[-1,0],[-1,9],[-3,6]],[[1239,3252],[0,1],[0,1],[0,1],[0,1],[0,1],[0,1],[-1,1],[0,1],[0,1],[-1,0],[0,1],[1,0],[0,1],[-1,1],[1,0],[0,1],[0,1],[0,1],[0,1],[0,1],[0,1],[0,1],[-1,1],[0,1],[0,1],[-1,0],[0,1],[0,1],[-1,1],[0,1],[-1,1],[-1,1],[0,1],[-1,1],[0,1],[0,1],[0,1],[-1,1],[0,1],[0,1],[0,1],[0,1],[0,1],[0,1],[-1,1],[0,1],[-1,0],[0,1],[0,1],[0,1],[-1,0],[0,1],[0,1],[0,1],[0,1],[0,1],[0,1],[0,1],[0,1],[-1,0],[0,1],[0,1],[0,1],[0,1],[0,1],[1,1],[0,1],[0,1],[0,1],[0,2],[0,1],[1,0],[0,1],[0,1],[1,0],[0,1],[-1,1],[0,1],[1,1],[0,1],[0,1],[0,1],[0,1],[0,1],[0,1],[-1,1],[0,1],[-1,1],[0,1],[-1,1],[0,1],[-1,1],[-1,0],[-1,1],[0,1],[1,0],[0,1],[1,1],[0,1],[0,1],[0,1],[0,1],[-1,1],[0,1],[-1,0],[0,1],[0,1],[0,1],[0,1],[1,2],[6,10],[0,1],[1,0],[0,1],[0,1],[1,0],[1,1],[1,1],[0,1],[0,1],[1,1],[0,1],[0,1],[0,1],[1,0],[0,1],[0,1],[0,1],[1,0],[0,1],[0,1],[1,0],[0,1],[1,1],[0,1],[1,2],[1,3],[-1,0],[0,2],[0,2],[0,8],[1,5],[1,2],[-1,6],[-2,5],[-3,7],[-5,12],[-16,-5],[-11,7],[-2,1],[-7,3],[-3,14],[-2,10],[-8,2],[-6,3],[-4,2],[-2,3],[-11,15],[-5,6],[-1,0],[-2,1],[-2,0],[-6,2],[-15,4],[-6,2],[-1,-2],[-1,0],[-13,14],[-30,22],[-10,11],[-3,4],[-29,-3],[-3,26],[-5,12],[3,12],[-28,17],[1,1],[-1,0],[7,32],[1,8],[-36,12],[1,1],[0,1],[13,27],[0,1],[-12,31],[-2,2],[-21,36],[-10,26],[-13,23],[-12,34],[-16,28],[-7,11],[0,2],[-1,1],[-10,32],[-1,1],[-2,3],[-8,12],[-11,18],[-10,22],[0,1],[0,1],[-1,1],[9,10],[-35,41],[-11,21],[-7,10],[-48,34],[-7,12],[2,9],[0,1],[-5,2],[-5,2],[3,15],[-7,12],[-3,10],[-10,0],[-14,16],[-2,13],[-29,7],[-7,15],[0,1],[-1,2],[3,8],[-10,10],[0,1],[-1,1],[3,6],[3,3],[3,2],[0,15],[-1,7],[-9,14],[-3,1],[-1,0],[-1,0],[-1,1],[0,1],[-6,7],[-2,8],[0,1],[-1,0],[-1,0],[-25,24],[-28,-17],[-15,-9],[-1,0],[-9,-7],[-7,-1],[-21,-5],[-8,-3],[-10,-6],[13,-10],[0,-5],[0,-3],[0,-1],[-5,-8],[-3,-6],[-6,-4],[-1,0],[-12,4],[1,-44],[-3,-3],[0,-3],[0,-1],[0,-1],[-10,-22],[-27,-2],[-14,-12],[-10,-7],[-7,-5],[-12,-9],[-8,-5],[-20,-22],[-8,-1],[-2,0],[0,1],[3,16],[0,6],[-11,57],[-86,101],[-30,31],[-8,32],[-36,20],[-2,2]],[[688,4378],[5,0]],[[1171,3097],[0,1],[0,1],[0,1],[0,1],[-1,1],[1,1],[7,7],[3,-1],[2,-4],[-2,-6],[-6,-4],[-4,1],[0,1]],[[1171,3097],[-1,0],[0,1],[-1,0],[0,1],[1,0],[1,-2]],[[1239,3252],[0,-1],[0,1]],[[1239,3252],[0,0]],[[8722,4063],[-10,-1]],[[8699,4060],[-2,-4]],[[9482,2335],[0,-34],[-9,-2],[-9,8],[-2,3],[-13,-9],[-28,1],[-9,-5],[-9,-13],[-24,-16],[-12,-3],[-18,4],[-13,-5],[-5,-2],[-6,-12],[-3,-11],[-15,-10],[-16,-20],[-10,-5],[-8,-32],[3,-15],[-8,-22],[-4,-1],[-5,3],[-4,-2],[-4,-7],[-8,-5],[-8,-11],[-7,-4],[-2,-6],[-5,-5],[-5,-23],[-12,-2],[-5,-9],[-23,-16],[-2,-7],[0,-7],[-4,-12],[-23,-15],[-4,-1],[-5,6],[-4,3],[-5,-2],[-2,7],[-3,2],[-5,-9],[-2,-1],[-25,-2],[-14,-8],[-46,-1],[-49,-16],[-19,-11],[-7,1],[-3,9],[-7,14],[-11,8],[-46,6],[-13,4],[-55,4],[-17,-3],[-16,-7],[-11,-1],[-11,-3],[-19,8],[-27,0],[-1,3],[-6,-3],[-25,-2],[-10,4],[-12,0],[-11,6],[-3,3],[-39,-9],[-8,1],[-7,3],[-14,-3],[-29,5],[-32,-8],[-12,-1],[-16,3],[-12,-4],[-6,-4],[-4,-6],[-10,-4],[-7,2],[-6,6],[-8,-3],[-7,2],[-5,5],[-6,-2],[-2,-6],[2,-4],[5,-3],[2,-4],[-2,-5],[-8,-3],[-7,-1],[-8,-4],[-8,-9],[-5,-10],[-13,-10],[-8,-10],[-4,-7],[-3,-18],[-10,-12],[-4,-9],[-7,-31],[-1,-32],[-3,-10],[-5,-5],[-5,-10],[-12,-12],[-28,-5],[-8,-4],[-31,-8],[-11,-9],[-7,-11],[-4,-3],[2,-8],[-4,-9],[-13,-5],[-10,-9],[-4,0],[-2,4],[-10,-4],[-6,-5],[-13,-33],[-7,-6],[-28,-29],[-8,-15],[-8,-32],[-2,-4],[-13,-8],[-31,-77],[-7,-7],[-4,-8],[-5,-4],[-11,7],[-22,29],[-22,9],[-10,12],[-21,7],[-14,-2],[-36,15],[-4,-3],[2,-4],[7,-4],[2,-11],[3,-1],[9,3],[16,-5],[15,2],[19,-6],[10,-15],[24,-10],[10,-18],[14,-13],[5,-9],[-9,-41],[-21,-55],[-11,-18],[-13,-28],[-16,-13],[-6,-8],[-10,-17],[-3,-18],[-3,-8],[-19,-28],[-33,-46],[-11,-16],[-20,-19],[-8,-7],[-15,-8],[-44,-14],[-6,-5],[-5,-9],[-8,-7],[-8,-2],[-6,-5],[-3,-6],[-14,-11],[-17,-21],[0,-3],[-5,-5],[-7,-1],[-32,-17],[-19,-20],[-7,-12],[-17,-41],[-13,-23],[-5,-13],[-3,-13],[-6,-10],[-2,-31],[-2,-12],[-6,-16],[-7,-7],[-8,-3],[-17,-11],[-7,-3],[-2,1],[-5,-5],[-6,0],[-13,-8],[-22,-25]],[[7320,855],[0,-1],[0,-1],[-1,-2]],[[7272,874],[0,3],[0,1]],[[7245,943],[1,0],[0,-1]],[[7156,1024],[-1,0],[-1,1]],[[7039,1065],[0,2],[1,1],[-1,1]],[[6996,1150],[0,1],[-1,2]],[[6950,1710],[1,582],[0,3]],[[6951,2295],[5,6],[4,25],[7,5],[4,9],[7,6],[6,-2],[2,-2],[-1,-5],[-2,-4],[-1,-9],[4,-6],[6,1],[11,-3],[7,-10],[6,-29],[2,-28],[2,-13],[4,-7],[6,3],[-3,14],[1,20],[-2,10],[1,4],[-3,5],[2,10],[11,11],[4,10],[-8,13],[-1,12],[-19,32],[1,9],[3,3],[8,-2],[3,3],[5,35],[5,11],[13,17],[7,21],[8,17],[7,7],[4,7],[-1,3],[-9,2],[-2,3],[1,5],[5,7],[2,15],[-3,17],[-6,9],[-15,8],[-2,5],[0,11],[-7,13],[0,10],[-7,12],[0,5],[3,2],[8,3],[1,13],[-2,4],[-11,2],[-2,2],[3,15],[-12,17],[-5,18],[1,7],[10,21],[1,19],[-6,25],[-14,24],[3,12],[12,-4],[3,3],[0,3],[-4,10],[-6,6],[1,12],[-9,11],[5,15],[-2,10],[2,10],[-3,4],[-2,7],[6,22],[-7,7],[-6,13],[1,5],[3,3],[0,5],[-5,12],[-5,1],[-5,-2],[-11,2],[-3,3],[2,14],[-12,24],[-3,13],[1,6],[-3,10],[-6,11],[2,20],[-4,5],[-10,2],[-4,4],[0,7],[10,6],[9,0],[9,5],[22,17],[10,2],[28,15],[20,8],[37,41],[12,19],[23,22],[20,12],[6,1],[2,7],[5,5],[20,32],[-8,-10],[-6,-2],[-2,3],[1,4],[4,6],[5,4],[6,8],[6,4],[2,-5],[6,10],[-1,5],[2,4],[5,5],[5,4],[13,22],[-1,-1],[-3,1],[0,3],[3,2],[2,1],[2,0],[1,-1],[51,83],[-2,1],[-2,1],[0,7],[2,2],[2,1],[3,-4],[-1,-5],[11,18],[-1,7],[0,2],[2,7],[8,125],[-1,16],[0,13],[3,11],[-3,25],[1,15],[-2,9],[-2,36],[-3,20],[-6,19],[-21,39],[-4,17],[0,11],[-2,8],[-24,40],[-15,30],[-12,17],[-11,7],[-6,17],[-25,16],[-14,15],[-11,7],[-12,14],[-5,11],[-13,4],[-7,6],[-6,10],[1,5],[-3,11],[-5,0],[-2,-7],[3,-6],[0,-6],[-5,-1],[-4,11],[-11,17],[4,12],[-2,6],[1,4],[5,0],[7,-10],[4,1],[1,6],[-5,10],[-7,6],[-4,6],[1,12],[-4,10],[2,5],[6,-1],[8,-8],[7,4],[4,14],[-1,12],[2,8],[7,5],[1,4],[2,2],[9,-2],[3,3],[0,8],[-3,6],[2,9],[16,9],[5,12],[6,1],[5,4],[5,18],[10,7],[4,6],[-2,2],[-7,2],[-12,-8],[-6,-1],[-7,8],[1,5],[9,5],[-1,8],[3,9],[12,4],[2,7],[-7,27],[0,11],[5,0],[4,-7],[4,-4],[14,-4],[9,-22],[15,-2],[5,2],[-3,5],[-9,5],[-2,4],[1,7],[-12,16],[3,7],[13,9],[10,2],[1,5],[-7,14],[-1,9],[4,15],[-5,13],[7,9],[18,-2],[5,8],[9,5],[-5,8],[-23,6],[-3,-2],[-1,-5],[1,-4],[-3,-10],[-7,-3],[-18,-10],[-11,9],[10,13],[1,12],[-5,25],[-12,22],[-2,11],[4,10],[11,12],[2,7],[-2,5],[-21,2],[-5,8],[2,18],[15,10],[1,18],[6,5],[1,7],[-4,2],[-12,-11],[-6,-4],[-15,4],[-12,-1],[-6,4],[-10,3],[-3,4],[10,22],[23,22],[11,20],[5,44],[-1,16],[-5,15],[2,11],[12,0],[9,4],[1,3],[-7,9],[1,4],[3,2],[6,0],[8,4],[1,6],[-4,7],[-5,2],[-9,-5],[-6,1],[-4,4],[-2,13],[-23,16],[-11,35],[-6,26],[-3,14],[-2,35],[2,24],[4,14],[9,12],[28,19],[23,23],[4,9],[4,4],[8,-1],[3,-6],[7,-1],[10,2],[54,-9],[21,-15],[24,-4],[11,-5],[26,-19],[9,2],[9,-2],[8,-6],[29,-5],[1,-7],[-5,-7],[-17,-8],[-11,-8],[0,-4],[5,-3],[18,8],[10,9],[10,4],[7,10],[8,5],[6,1],[12,-4],[9,-12],[3,0],[9,3],[19,-6],[21,-22],[10,-6],[3,5],[-4,7],[-15,16],[2,8],[52,5],[10,3],[15,8],[10,9],[11,17],[9,4],[14,-5],[49,-43],[6,-8],[20,-11],[11,-15],[8,-1],[8,4],[5,-1],[8,-19],[1,-12],[-4,-11],[-14,-16],[-2,-9],[3,-4],[9,-1],[9,-9],[3,1],[1,5],[-8,14],[3,9],[4,3],[14,-3],[21,-11],[7,-12],[-2,-15],[5,-4],[12,-3],[2,-3],[-2,-11],[2,-3],[-3,-8],[-6,-3],[-10,-2],[-3,-3],[2,-4],[14,-4],[8,5],[9,1],[1,6],[-4,12],[2,8],[5,4],[10,-3],[5,-5],[9,-4],[6,-4],[4,-12],[-2,-4],[-9,-4],[-8,0],[-4,-4],[-2,-6],[4,-8],[-5,-15],[3,-3],[20,-4],[1,-3],[-1,-3],[-14,-5],[-1,-4],[3,-10],[6,-4],[4,-10],[20,-6],[8,-9],[74,-21],[8,-8],[7,-3],[6,2],[8,9],[11,6],[5,0],[17,-5],[7,-12],[-3,-19],[4,-6],[7,-3],[12,-25],[5,0],[1,8],[4,11],[9,-1],[7,3],[1,5],[-1,15],[6,18],[5,8],[7,-1],[2,-3],[14,-28],[7,-15],[-3,-11],[-24,-24],[-8,-11],[-5,-15],[3,-13],[-3,-8],[-8,-7],[-4,-9],[3,-10],[12,-19],[-5,-15],[5,-4],[5,-20],[0,-12],[-7,-19],[-15,-3],[-2,-6],[2,-4],[-3,-5],[-12,5],[-3,1],[-8,0],[-9,-4],[-4,0],[-6,0],[-6,0],[-7,0],[-7,-3],[-6,-3],[-8,-1],[-12,1],[-8,1],[-6,3],[-10,6],[-12,6],[-10,3],[-10,0],[-5,0],[-3,-3],[1,-5],[4,-3],[6,0],[8,-2],[7,-1],[6,-1],[6,-3],[3,-1],[6,-4],[6,-2],[7,-3],[8,0],[15,1],[9,2],[10,1],[10,1],[10,-2],[14,-5],[8,-7],[14,-6],[5,-12],[17,-14],[3,-9],[-3,-6],[3,-9],[-2,-12],[7,-17],[-2,-6],[-13,-9],[-4,-10],[-1,-4],[3,-7],[4,-2],[5,-13],[-2,-5],[-6,-4],[-1,-3],[4,-6],[5,-2],[9,1],[12,6],[8,-3],[2,-4],[10,0],[7,-2],[1,-8],[-6,-8],[-11,-2],[-2,-7],[-14,-4],[-2,-7],[1,-4],[7,-6],[10,-4],[1,-4],[-2,-6],[-9,-12],[-2,-7],[4,-18],[-1,-3],[-11,-7],[-3,-9],[-3,-4],[-11,4],[-3,7],[2,24],[-4,7],[-6,2],[-6,10],[-3,1],[-4,-9],[10,-30],[-1,-7],[-3,-2],[-10,-2],[-13,-9],[-12,-2],[-13,-4],[-9,-8],[-1,-7],[5,0],[11,9],[14,-4],[13,6],[5,-2],[3,-11],[12,-5],[1,-3],[-6,-15],[3,-3],[5,2],[21,32],[8,8],[25,20],[24,14],[4,1],[21,-7],[16,4],[12,-8],[14,-4],[2,-3],[8,-25],[0,-24],[2,-4],[12,-12],[3,-8],[-2,-6],[-1,-20],[-4,-28],[-15,-52],[-7,-8],[-11,-6],[-26,-9],[-26,-14],[-8,-7],[-2,-6],[2,-2],[5,0],[19,14],[33,12],[15,9],[13,12],[10,31],[-1,4],[7,25],[3,29],[10,25],[3,1],[12,-5],[5,-6],[-6,-22],[4,-15],[0,-7],[-3,-7],[-5,-9],[-5,-8],[-3,-8],[-2,-5],[-1,-6],[4,-3],[3,0],[3,7],[5,10],[6,6],[5,4],[1,3],[3,5],[1,17],[1,5],[-1,11],[3,8],[3,0],[2,-6],[-1,-7],[1,-6],[0,-8],[0,-3],[1,-3],[3,-4],[3,-6],[1,-4],[-2,-7],[-3,-13],[-1,-9],[-2,-11],[1,-8],[0,-9],[2,-7],[0,-5],[1,-3],[2,-2],[3,2],[4,9],[-1,37],[7,20],[22,25],[21,10],[4,5],[10,4],[11,25],[2,2],[6,-2],[3,-6],[3,-2],[5,3],[2,4],[10,4],[7,14],[6,28],[12,7],[-2,10],[4,11],[9,11],[8,-3],[14,-31],[6,-4],[15,-6],[3,-9],[-1,-15],[-17,-50],[5,-16],[3,-4],[8,-4],[3,1],[-1,6],[-9,15],[2,5],[7,4],[2,4],[0,12],[11,32],[-1,10],[-4,10],[-11,10],[-6,24],[3,7],[2,2],[14,-3],[12,5],[-2,4],[-4,2],[-6,-1],[-5,2],[-3,5],[1,4],[12,7],[3,6],[4,3],[8,-3],[3,1],[2,4],[-3,7],[4,7],[5,-2],[16,-21],[4,-2],[3,1],[1,4],[-10,21],[1,3],[4,2],[14,2],[1,4],[-1,3],[-6,2],[-20,-1],[-3,2],[-8,11],[-6,17],[2,5],[2,1],[9,-3],[12,-13],[4,7],[-9,22],[-1,5],[3,8],[3,2],[8,-4],[14,-16],[3,1],[1,3],[-13,18],[-8,20],[3,7],[9,-1],[4,3],[-11,32],[-2,17],[3,20],[5,8],[12,10],[5,-3],[10,-8],[5,-1],[2,4],[-5,8],[8,13],[-4,10],[2,7],[-2,12],[3,6],[6,4],[0,12],[5,12],[9,5]],[[6913,4761],[-4,0],[-5,8],[-2,12],[-8,13],[-14,14],[-13,17],[-8,25],[-1,29],[4,23],[9,21],[23,28],[5,13],[9,7],[7,-2],[5,-5],[6,2],[17,16],[5,-1],[5,-9],[0,-4],[7,-11],[16,-12],[4,-7],[-5,-29],[-1,-27],[-4,-14],[-15,-4],[-3,-3],[-2,-8],[2,-6],[0,-9],[-8,-35],[-13,-25],[-13,-16],[-5,-1]],[[8967,1371],[10,10],[14,6],[6,-3],[2,-1],[1,-3],[-2,-3],[-3,-2],[-1,-3],[-2,-5],[-2,-2],[-3,1],[-2,2],[1,2],[-3,3],[-2,0],[-3,-2],[-8,-10],[-22,-27],[-7,-24],[-2,-1],[-4,-12],[2,-3],[4,2],[3,-1],[3,1],[3,4],[2,-1],[2,-6],[-1,-3],[-21,-12],[-3,1],[-2,3],[-2,10],[6,17],[0,11],[2,9],[9,11],[11,9],[14,22]],[[7011,3145],[0,-5],[-8,-6],[-13,-7],[-15,-1],[-10,-4],[-25,-22],[-6,1],[3,8],[15,16],[29,11],[20,11],[10,-2]],[[7556,5023],[-34,10],[-13,11],[2,8],[6,3],[7,-2],[6,-6],[18,-4],[13,1],[19,-7],[5,-7],[-1,-3],[-6,-4],[-22,0]],[[6947,2410],[-4,2],[-2,4],[1,10],[4,8],[6,9],[21,20],[7,-1],[3,-4],[-6,-20],[2,-12],[-2,-4],[-6,-4],[-13,-3],[-11,-5]],[[8126,4181],[4,-2],[3,-6],[-1,-6],[7,-19],[-5,-8],[-14,-9],[-1,-4],[-7,-6],[-5,2],[-1,3],[9,16],[3,9],[1,13],[-1,9],[2,5],[6,3]],[[8646,4465],[-1,-1],[0,-1],[0,-1],[0,-2],[0,-1],[0,-1],[1,-1],[0,-1],[1,-1]],[[8642,4449],[-1,0],[-2,0],[-1,0],[-1,0],[-2,0],[-2,0],[-1,0],[-1,0],[-1,0],[-2,0],[-1,0],[-1,0],[-1,0],[-1,1],[-2,0],[-1,-1],[-1,-1],[-1,-1],[-2,-1],[-1,0],[-1,0],[-1,0],[-2,0],[-1,0],[-1,-1],[-1,0],[-1,-2],[-1,0],[-1,-2]],[[7052,4546],[-4,1],[-3,4],[2,8],[28,20],[6,0],[1,-2],[-1,-5],[-29,-26]],[[6886,4311],[-10,4],[1,8],[16,16],[7,4],[5,-1],[1,-6],[-15,-21],[-5,-4]],[[8972,1355],[3,-2],[-8,-19],[-6,-7],[-5,-3],[-3,1],[0,6],[7,6],[12,18]],[[6906,2728],[-6,4],[-2,8],[4,20],[7,8],[4,-1],[2,-5],[-4,-28],[-5,-6]],[[8293,3993],[5,1],[5,-1],[4,1],[3,-2],[2,-3],[-2,-5],[-2,-2],[-2,-3],[-1,-6],[-4,-3],[-4,0],[-3,2],[-1,3],[0,4],[1,4],[-3,4],[0,2],[2,4]],[[7266,3724],[-4,3],[-7,11],[-2,5],[2,6],[6,-2],[9,-15],[-1,-7],[-3,-1]],[[7121,5018],[12,-2],[4,-5],[-1,-5],[-3,-2],[-20,4],[-3,3],[1,5],[10,2]],[[7277,3531],[-3,1],[-2,3],[-1,5],[0,4],[-1,8],[2,14],[4,3],[1,-3],[-1,-12],[3,-12],[1,-3],[0,-5],[-3,-3]],[[6872,4300],[0,-4],[-2,-6],[-3,-6],[-3,-5],[-5,-1],[-2,3],[0,4],[3,4],[2,4],[2,5],[4,3],[4,-1]],[[6924,2696],[-5,2],[-2,6],[2,15],[3,-1],[3,-6],[3,-2],[3,-5],[-3,-7],[-4,-2]],[[9241,2097],[1,-5],[0,-3],[0,-3],[1,-6],[1,-3],[-2,-3],[-1,-1],[-2,0],[-2,2],[-2,5],[-2,6],[-1,4],[1,4],[4,5],[4,-2]],[[6839,4244],[0,-3],[-1,-9],[1,-5],[-1,-6],[-3,-2],[-3,1],[-2,3],[0,7],[0,4],[1,8],[2,3],[6,-1]],[[7268,3695],[2,-1],[1,-4],[1,-5],[3,-7],[0,-5],[-2,-4],[-3,1],[-3,3],[-2,8],[1,10],[2,4]],[[7146,5003],[0,3],[2,5],[2,3],[3,1],[3,0],[3,-1],[2,-2],[-4,-3],[-3,-3],[-2,-3],[-1,-2],[-3,0],[-2,2]],[[6843,4291],[2,2],[3,4],[3,2],[2,-1],[2,-3],[-3,-5],[-2,-3],[-3,-4],[-5,0],[-1,3],[2,5]],[[7243,3777],[1,4],[1,2],[3,0],[2,-4],[2,-5],[2,-3],[-3,-6],[-2,0],[-2,2],[-1,2],[0,3],[-3,5]],[[7267,3654],[2,4],[4,-1],[3,-5],[1,-9],[-2,-5],[-2,-1],[-3,2],[0,3],[-1,5],[-2,7]],[[7021,2455],[-12,6],[0,6],[6,-1],[7,-3],[1,-6],[-2,-2]],[[7863,4709],[-1,-3],[-2,-3],[-2,-1],[-3,-1],[-3,-1],[-4,3],[1,2],[1,3],[3,1],[6,2],[4,-2]],[[7025,4097],[-3,-9],[-3,-1],[-4,2],[-1,4],[3,8],[5,0],[3,-4]],[[6803,3982],[-4,3],[-3,5],[2,6],[7,-2],[2,-4],[0,-5],[-4,-3]],[[6820,4208],[2,-3],[2,-2],[1,-3],[-1,-4],[-1,-3],[-2,-1],[-2,0],[-2,2],[0,3],[-1,3],[1,7],[3,1]],[[6886,4060],[-5,4],[2,8],[2,3],[3,-1],[3,-7],[-1,-5],[-4,-2]],[[8996,1423],[-2,-6],[-3,-2],[-3,-1],[-4,2],[0,2],[2,2],[2,4],[4,1],[4,-2]],[[6774,2991],[-3,1],[-1,4],[-1,3],[0,4],[1,3],[4,0],[1,-2],[3,-6],[-1,-6],[-3,-1]],[[7127,3965],[6,-2],[3,-5],[-1,-4],[-3,-2],[-5,2],[-2,4],[2,7]],[[7157,3933],[1,4],[8,-2],[2,-4],[-1,-5],[-4,0],[-4,3],[-2,4]],[[7046,2535],[-9,3],[-1,4],[2,3],[2,0],[4,0],[5,-2],[1,-2],[0,-5],[-4,-1]],[[7265,3473],[0,4],[2,3],[2,3],[2,1],[3,0],[1,-3],[-1,-4],[-1,-3],[-2,-1],[-3,-2],[-2,0],[-1,2]],[[6954,2569],[-2,-4],[-2,1],[-2,2],[-1,3],[2,6],[1,3],[3,-1],[3,-3],[-2,-7]],[[7754,4871],[-2,2],[1,5],[2,3],[3,0],[4,-1],[1,-4],[-1,-2],[-4,-3],[-4,0]],[[7229,3824],[0,4],[1,3],[3,0],[3,-3],[3,-5],[-2,-3],[-3,0],[-3,1],[-2,3]],[[6829,4294],[1,-5],[-1,-3],[-2,-1],[-4,-1],[-3,3],[1,3],[2,3],[2,2],[4,-1]],[[6924,4058],[-1,-2],[-3,-3],[-3,1],[-2,2],[-1,3],[1,6],[3,-1],[2,-2],[4,-4]],[[6859,4216],[2,-3],[-1,-3],[0,-4],[-3,-1],[-2,1],[-2,2],[0,4],[1,4],[2,1],[3,-1]],[[7803,4834],[-7,-1],[-1,3],[0,5],[2,2],[3,1],[3,-1],[1,-3],[1,-3],[-2,-3]],[[6810,4122],[-4,1],[-1,2],[0,5],[2,2],[3,1],[2,-1],[1,-5],[-3,-5]],[[7052,4080],[0,-4],[-1,-4],[-2,-1],[-3,1],[-1,2],[-2,2],[1,5],[1,2],[4,0],[3,-3]],[[7112,4559],[-2,-3],[-3,0],[-3,2],[-1,3],[1,5],[3,0],[3,-1],[2,-6]],[[6972,2500],[-1,-4],[-3,-3],[-2,0],[-3,2],[-1,2],[2,4],[3,2],[5,-3]],[[7110,3971],[-1,3],[1,4],[2,1],[3,0],[3,-4],[-2,-4],[-2,-2],[-3,0],[-1,2]],[[6824,4142],[-3,-4],[-2,-1],[-4,2],[-1,3],[1,3],[2,2],[4,-1],[3,-4]],[[6812,4183],[1,-3],[0,-4],[-1,-2],[-1,-2],[-2,-1],[-2,1],[-2,3],[1,3],[2,4],[4,1]],[[7049,4025],[2,5],[3,0],[2,-2],[2,-5],[-2,-3],[-3,0],[-3,2],[-1,3]],[[6817,4235],[-3,-2],[-3,1],[-2,2],[0,4],[2,2],[3,1],[4,-2],[-1,-6]],[[7273,3512],[1,3],[2,2],[2,-1],[3,-4],[-3,-5],[-3,1],[-2,2],[0,2]],[[7263,3449],[-2,0],[-2,4],[2,6],[3,0],[3,-5],[-1,-3],[-3,-2]],[[9222,2055],[0,3],[0,2],[1,3],[2,1],[3,0],[2,-2],[-2,-4],[-1,-3],[-2,-1],[-3,1]],[[7001,2563],[-4,0],[-1,2],[0,4],[2,4],[3,1],[2,-3],[-2,-8]],[[6919,4354],[-2,3],[1,6],[4,2],[2,-3],[-1,-7],[-4,-1]],[[6987,2412],[-3,4],[-1,2],[1,3],[2,2],[4,-2],[0,-2],[0,-5],[-3,-2]],[[7045,4044],[0,3],[1,3],[4,1],[2,-4],[-1,-4],[-1,-2],[-4,0],[-1,3]],[[6914,3935],[-3,-2],[-2,0],[-2,4],[-1,3],[2,1],[2,1],[3,-1],[1,-3],[0,-3]],[[6941,2787],[-3,1],[-3,5],[2,3],[4,-1],[2,-4],[-2,-4]],[[7273,3586],[2,2],[3,0],[3,-2],[-1,-5],[-2,-1],[-3,1],[-2,2],[0,3]],[[8473,4137],[2,2],[3,1],[3,-1],[0,-5],[-1,-2],[-3,0],[-3,3],[-1,2]],[[8297,1465],[-1,0],[-36,0]],[[8260,1465],[-22,0]],[[8134,1287],[0,1],[-1,3],[0,1],[0,1],[0,1],[0,1],[0,1],[0,1],[1,2],[-1,0],[0,2],[0,2],[0,1],[1,1],[-1,1],[0,2],[0,1],[0,2],[0,2],[1,1],[0,1],[1,1],[0,1],[0,1],[0,3],[-1,0],[0,2],[-1,1],[-1,1],[-1,0],[-1,0],[-1,-1],[0,1],[-1,1],[-1,0],[-1,0],[0,1],[0,2],[-1,0],[-1,0],[0,1],[-1,0],[-1,0],[0,-1],[-1,1],[-1,0],[0,1],[-2,0],[-1,0],[-1,0],[-1,0],[-1,0],[-1,0],[-86,-191],[-3,-23],[-1,-10],[-1,-11],[-1,-9],[0,-2],[0,-2],[0,-1],[-1,-1],[0,-2],[-1,-1],[-1,0],[-1,-1],[-1,0],[0,-1],[-1,-1],[0,-2],[-1,0],[0,-1],[-1,-1],[0,-1],[-1,-1],[0,-1],[-1,-1],[-1,-1],[0,-1],[-1,0],[-1,0],[-1,0],[-2,-3],[-1,-2],[0,-2],[-1,-1],[0,-1],[0,-2],[0,-1],[1,-1],[0,-1],[-1,-2],[-1,-1],[-1,0],[-1,-2],[-1,-1],[0,-1],[-1,-1],[0,-3],[0,-1],[0,-1],[0,-1],[-1,-1],[0,-1],[-1,-1],[0,-1],[0,-1],[0,-1],[0,-1],[-1,-1],[0,-1],[-1,-1],[0,-2],[0,-1],[0,-1],[0,-1],[1,-1],[1,-1],[1,-1],[0,-1],[1,-1],[0,-1],[0,-1],[1,-1],[0,-1],[1,-1],[0,-1],[-1,-1],[0,-1],[-1,0],[0,-1],[-1,0],[0,-1],[0,-1],[0,-1],[0,-1],[0,-1],[0,-1],[-1,-1],[-1,-1],[-1,0],[-1,0],[0,-1],[-1,-1],[0,-2],[-1,-1],[0,-1],[0,-1],[1,-1],[1,0],[0,1],[1,-1],[0,-1],[0,-1],[0,-1],[-1,-1],[0,-1],[-1,-1],[0,-1],[0,-1],[-1,-1],[0,-1],[0,-1],[0,-1],[0,-2],[1,0],[0,-1],[0,-2],[-1,-1],[0,-2],[0,-1],[0,-1],[1,-1],[1,0],[1,-1],[1,0],[1,0],[0,-1],[1,-1],[1,-1],[0,-2],[0,-1],[0,-2],[-1,-1],[0,-1],[0,-2],[0,-2],[0,-2],[-1,-1],[-1,-2],[-1,-1],[-1,-3],[-2,-2],[-1,-1],[-2,-2],[-1,-1],[-1,-1],[-1,-1],[-1,-1],[-1,-1],[-1,-2],[-1,-1],[0,-1],[0,-1],[0,-1],[-1,0],[-1,0],[0,-1],[0,-1],[0,-1],[0,-1],[1,-1],[0,-2],[1,-1],[0,-2],[0,-1],[1,-2],[0,-1],[0,-1],[0,-1],[0,-1],[-1,-1],[-1,-2],[-1,0],[-1,-2],[-2,-1],[-1,0],[-1,0],[0,-1],[-1,-1],[-1,0],[-1,-2],[-3,-2],[-2,-2],[-3,-2],[-1,-1],[0,-1],[-1,-1],[0,-1],[-1,-1],[0,-1],[-1,-1],[-1,-1],[-1,-1],[-1,0],[-1,-1],[0,-1],[0,-1],[-1,-1],[-1,-1],[0,-1],[-1,-1],[0,-1],[-1,-1],[-1,0],[0,-1],[-1,-2],[0,-1],[-1,-1],[0,-1],[-1,-1],[0,-1],[0,-3],[0,-1],[-1,-1],[0,-1],[-1,-2],[0,-1],[-1,-1],[1,-1],[0,-1],[-1,-1],[0,-1],[0,-2],[0,-1],[0,-1],[1,-1],[0,-1],[1,-1],[1,-1],[0,-1],[1,-1],[0,-1],[1,0],[1,-1],[0,-1],[1,-1],[0,-1],[0,-1],[1,-1],[1,-1],[0,-1],[0,-1],[0,-2],[0,-1],[1,-1],[0,-1],[-1,-2],[-1,-1],[-1,0],[-1,0],[-1,0],[-1,1],[-1,1],[-1,0],[-1,0],[0,1],[-1,1],[-1,2],[-1,0],[0,2],[0,1],[-1,0],[0,2],[-1,0],[-1,0],[-1,0],[-1,0],[-1,0],[-1,-2],[-1,-1],[-1,-2],[0,-1],[-1,-1],[0,-2],[0,-1],[1,-4],[1,-1],[0,-1],[0,-1],[0,-1],[-1,-1],[0,-1],[0,-1],[-1,-1],[0,-1],[0,-1],[1,-1],[0,-1],[0,-3],[-1,-1],[0,-1],[-1,-1],[0,-1],[-1,0],[0,-1],[0,-1],[0,-1],[0,-1],[0,-1],[0,-1],[-1,-1],[0,-1],[0,-1],[0,-3],[0,-1],[0,-1],[-1,-1],[0,-1],[-1,0],[-1,0],[-1,1],[0,1],[0,1],[-1,2],[0,1],[0,1],[-1,2],[0,1],[-1,1],[0,1],[0,1],[0,1],[0,1],[0,1],[-1,1],[0,2],[0,1],[-1,1],[0,1],[-1,1],[0,1],[-1,2],[0,1],[-1,1],[-2,0],[-1,-1],[0,1],[-1,1],[-1,0],[-1,-1],[0,-1],[0,-1],[0,-1],[0,-1],[-1,-1],[-1,-1],[-1,0],[-1,-1],[-2,0],[0,-1],[-1,-1],[-1,0],[-1,-2],[-1,-1],[0,-1],[-1,-1],[0,-1],[0,-1],[-1,-1],[0,-1],[-1,-1],[0,-1],[0,-1],[0,-2],[-1,-1],[-2,-1],[0,1],[-1,1],[-1,0],[-1,1],[-1,1],[-1,0],[-1,1],[-1,0],[-1,0],[-1,1],[-1,1],[0,1],[-1,1],[-1,1],[-1,1],[0,1],[-1,1],[-1,1],[-1,0],[-1,-1],[-1,-1],[-1,-1],[-1,-1],[-1,-1],[0,-1],[-1,-1],[-2,-2],[0,-1],[0,-1],[-1,-1],[0,-1],[0,-1],[-1,-1],[-1,0],[0,1],[-1,0],[-1,0],[-1,0],[-1,0],[-1,0],[-1,0],[0,-1],[1,-1],[1,-1],[0,-1],[1,0],[0,-1],[1,-1],[1,-1],[0,-1],[0,-3],[-1,-1],[0,-1],[-1,-2],[0,-1],[0,-2],[-1,-1],[0,-1],[0,-1],[-1,-1],[0,-2],[0,-1],[0,-1],[1,-1],[0,-1],[0,-1],[-1,0],[0,-1],[-1,-1],[0,-1],[0,-1],[-1,-1],[-1,0],[0,-1],[0,-1],[-1,-2],[-3,-5],[0,-1],[0,-1],[0,-1],[0,-1],[1,-1],[0,-1],[0,-1],[0,-1],[-1,-2],[0,-1],[-7,-1],[-1,0],[-22,-1],[-8,1],[-7,-1],[-8,0],[-13,-1],[-19,0],[-1,0],[-17,1],[-15,0],[-73,0],[-17,0],[-77,-4],[-33,-2],[-38,4],[-1,0],[-1,0],[-1,1],[1,3],[0,2],[2,1],[2,1],[1,2],[2,1],[1,0],[1,1],[1,0],[0,1],[1,0],[1,1],[1,0],[2,1],[1,1],[0,1],[0,1],[1,1],[1,0],[0,1],[1,0],[0,-1],[1,0],[1,0],[0,1],[0,1],[1,1],[0,1],[0,1],[1,1],[1,2],[0,1],[1,2],[0,1],[1,2],[1,1],[1,1],[1,0],[2,1],[1,2],[9,7],[12,16],[9,8],[35,17],[25,18],[5,9],[3,10],[3,7],[12,55],[17,44],[7,14],[3,3],[1,6],[3,4],[19,12],[13,6],[17,13],[7,16],[7,9],[15,13],[8,11],[29,29],[11,7],[9,10],[15,8],[25,8],[32,22],[8,6],[3,2],[6,6],[8,6],[10,8],[12,8],[8,8],[6,4],[16,9],[10,9],[5,13],[13,20],[13,29],[14,19],[13,29],[14,17],[18,33],[18,38],[2,10],[0,5],[4,14],[20,34],[6,13],[24,36],[34,36],[65,58],[52,38],[25,20],[14,9],[23,12],[26,17],[38,20],[27,17],[26,4],[16,4],[10,5],[20,3],[75,0],[12,-6],[6,-5],[29,-13],[25,-14],[14,-20],[5,-15],[11,-13],[7,-27],[-1,-9],[-4,-2],[-5,3],[-6,6],[-12,8],[-5,-1],[-1,-3],[4,-7],[8,-6],[9,-15],[9,-8],[3,-9],[-1,-6],[-7,-4],[-1,-7],[4,-9],[-2,-7],[-13,-23],[-8,-7],[-13,-1],[-13,-11],[-12,-22],[-27,-27],[-5,-12],[-25,-19],[-19,1],[-8,4],[-13,15],[-12,6],[-16,4],[-10,6],[-10,-4],[-7,-9],[-7,-5],[-7,-1],[-9,3],[-7,-2],[-16,7],[-16,-8],[-2,-8]],[[8409,1472],[-10,-4],[-18,-5]],[[8840,1752],[-84,51],[-8,13],[-7,22],[-6,13],[-50,35],[-8,10],[-5,3],[-3,-3],[-6,6],[-10,4],[-2,6],[1,3],[10,10],[16,4],[17,-5],[33,-12],[19,-1],[21,-5],[35,-20],[44,-17],[32,-18],[14,-22],[8,-8],[14,-7],[7,-6],[6,-9],[18,-7],[25,-41],[2,-9],[-1,-4],[-3,-1],[-13,-3],[-9,-5],[-16,0],[-11,4],[-8,-1],[-36,7],[-36,13]]],"transform":{"scale":[0.008846796002081558,0.0041180707052657075],"translate":[-141.00285937700158,41.9714969544088]},"bbox":[-141.00285937700158,41.9714969544088,-52.54374615218809,83.1480859363606]};
  Datamap.prototype.cheTopo = '__CHE__';
  Datamap.prototype.chlTopo = '__CHL__';
  Datamap.prototype.chnTopo = '__CHN__';
  Datamap.prototype.civTopo = '__CIV__';
  Datamap.prototype.clpTopo = '__CLP__';
  Datamap.prototype.cmrTopo = '__CMR__';
  Datamap.prototype.codTopo = '__COD__';
  Datamap.prototype.cogTopo = '__COG__';
  Datamap.prototype.cokTopo = '__COK__';
  Datamap.prototype.colTopo = '__COL__';
  Datamap.prototype.comTopo = '__COM__';
  Datamap.prototype.cpvTopo = '__CPV__';
  Datamap.prototype.criTopo = '__CRI__';
  Datamap.prototype.csiTopo = '__CSI__';
  Datamap.prototype.cubTopo = '__CUB__';
  Datamap.prototype.cuwTopo = '__CUW__';
  Datamap.prototype.cymTopo = '__CYM__';
  Datamap.prototype.cynTopo = '__CYN__';
  Datamap.prototype.cypTopo = '__CYP__';
  Datamap.prototype.czeTopo = '__CZE__';
  Datamap.prototype.deuTopo = '__DEU__';
  Datamap.prototype.djiTopo = '__DJI__';
  Datamap.prototype.dmaTopo = '__DMA__';
  Datamap.prototype.dnkTopo = '__DNK__';
  Datamap.prototype.domTopo = '__DOM__';
  Datamap.prototype.dzaTopo = '__DZA__';
  Datamap.prototype.ecuTopo = '__ECU__';
  Datamap.prototype.egyTopo = '__EGY__';
  Datamap.prototype.eriTopo = '__ERI__';
  Datamap.prototype.esbTopo = '__ESB__';
  Datamap.prototype.espTopo = '__ESP__';
  Datamap.prototype.estTopo = '__EST__';
  Datamap.prototype.ethTopo = '__ETH__';
  Datamap.prototype.finTopo = '__FIN__';
  Datamap.prototype.fjiTopo = '__FJI__';
  Datamap.prototype.flkTopo = '__FLK__';
  Datamap.prototype.fraTopo = '__FRA__';
  Datamap.prototype.froTopo = '__FRO__';
  Datamap.prototype.fsmTopo = '__FSM__';
  Datamap.prototype.gabTopo = '__GAB__';
  Datamap.prototype.psxTopo = '__PSX__';
  Datamap.prototype.gbrTopo = '__GBR__';
  Datamap.prototype.geoTopo = '__GEO__';
  Datamap.prototype.ggyTopo = '__GGY__';
  Datamap.prototype.ghaTopo = '__GHA__';
  Datamap.prototype.gibTopo = '__GIB__';
  Datamap.prototype.ginTopo = '__GIN__';
  Datamap.prototype.gmbTopo = '__GMB__';
  Datamap.prototype.gnbTopo = '__GNB__';
  Datamap.prototype.gnqTopo = '__GNQ__';
  Datamap.prototype.grcTopo = '__GRC__';
  Datamap.prototype.grdTopo = '__GRD__';
  Datamap.prototype.grlTopo = '__GRL__';
  Datamap.prototype.gtmTopo = '__GTM__';
  Datamap.prototype.gumTopo = '__GUM__';
  Datamap.prototype.guyTopo = '__GUY__';
  Datamap.prototype.hkgTopo = '__HKG__';
  Datamap.prototype.hmdTopo = '__HMD__';
  Datamap.prototype.hndTopo = '__HND__';
  Datamap.prototype.hrvTopo = '__HRV__';
  Datamap.prototype.htiTopo = '__HTI__';
  Datamap.prototype.hunTopo = '__HUN__';
  Datamap.prototype.idnTopo = '__IDN__';
  Datamap.prototype.imnTopo = '__IMN__';
  Datamap.prototype.indTopo = '__IND__';
  Datamap.prototype.ioaTopo = '__IOA__';
  Datamap.prototype.iotTopo = '__IOT__';
  Datamap.prototype.irlTopo = '__IRL__';
  Datamap.prototype.irnTopo = '__IRN__';
  Datamap.prototype.irqTopo = '__IRQ__';
  Datamap.prototype.islTopo = '__ISL__';
  Datamap.prototype.isrTopo = '__ISR__';
  Datamap.prototype.itaTopo = '__ITA__';
  Datamap.prototype.jamTopo = '__JAM__';
  Datamap.prototype.jeyTopo = '__JEY__';
  Datamap.prototype.jorTopo = '__JOR__';
  Datamap.prototype.jpnTopo = '__JPN__';
  Datamap.prototype.kabTopo = '__KAB__';
  Datamap.prototype.kasTopo = '__KAS__';
  Datamap.prototype.kazTopo = '__KAZ__';
  Datamap.prototype.kenTopo = '__KEN__';
  Datamap.prototype.kgzTopo = '__KGZ__';
  Datamap.prototype.khmTopo = '__KHM__';
  Datamap.prototype.kirTopo = '__KIR__';
  Datamap.prototype.knaTopo = '__KNA__';
  Datamap.prototype.korTopo = '__KOR__';
  Datamap.prototype.kosTopo = '__KOS__';
  Datamap.prototype.kwtTopo = '__KWT__';
  Datamap.prototype.laoTopo = '__LAO__';
  Datamap.prototype.lbnTopo = '__LBN__';
  Datamap.prototype.lbrTopo = '__LBR__';
  Datamap.prototype.lbyTopo = '__LBY__';
  Datamap.prototype.lcaTopo = '__LCA__';
  Datamap.prototype.lieTopo = '__LIE__';
  Datamap.prototype.lkaTopo = '__LKA__';
  Datamap.prototype.lsoTopo = '__LSO__';
  Datamap.prototype.ltuTopo = '__LTU__';
  Datamap.prototype.luxTopo = '__LUX__';
  Datamap.prototype.lvaTopo = '__LVA__';
  Datamap.prototype.macTopo = '__MAC__';
  Datamap.prototype.mafTopo = '__MAF__';
  Datamap.prototype.marTopo = '__MAR__';
  Datamap.prototype.mcoTopo = '__MCO__';
  Datamap.prototype.mdaTopo = '__MDA__';
  Datamap.prototype.mdgTopo = '__MDG__';
  Datamap.prototype.mdvTopo = '__MDV__';
  Datamap.prototype.mexTopo = '__MEX__';
  Datamap.prototype.mhlTopo = '__MHL__';
  Datamap.prototype.mkdTopo = '__MKD__';
  Datamap.prototype.mliTopo = '__MLI__';
  Datamap.prototype.mltTopo = '__MLT__';
  Datamap.prototype.mmrTopo = '__MMR__';
  Datamap.prototype.mneTopo = '__MNE__';
  Datamap.prototype.mngTopo = '__MNG__';
  Datamap.prototype.mnpTopo = '__MNP__';
  Datamap.prototype.mozTopo = '__MOZ__';
  Datamap.prototype.mrtTopo = '__MRT__';
  Datamap.prototype.msrTopo = '__MSR__';
  Datamap.prototype.musTopo = '__MUS__';
  Datamap.prototype.mwiTopo = '__MWI__';
  Datamap.prototype.mysTopo = '__MYS__';
  Datamap.prototype.namTopo = '__NAM__';
  Datamap.prototype.nclTopo = '__NCL__';
  Datamap.prototype.nerTopo = '__NER__';
  Datamap.prototype.nfkTopo = '__NFK__';
  Datamap.prototype.ngaTopo = '__NGA__';
  Datamap.prototype.nicTopo = '__NIC__';
  Datamap.prototype.niuTopo = '__NIU__';
  Datamap.prototype.nldTopo = '__NLD__';
  Datamap.prototype.nplTopo = '__NPL__';
  Datamap.prototype.nruTopo = '__NRU__';
  Datamap.prototype.nulTopo = '__NUL__';
  Datamap.prototype.nzlTopo = '__NZL__';
  Datamap.prototype.omnTopo = '__OMN__';
  Datamap.prototype.pakTopo = '__PAK__';
  Datamap.prototype.panTopo = '__PAN__';
  Datamap.prototype.pcnTopo = '__PCN__';
  Datamap.prototype.perTopo = '__PER__';
  Datamap.prototype.pgaTopo = '__PGA__';
  Datamap.prototype.phlTopo = '__PHL__';
  Datamap.prototype.plwTopo = '__PLW__';
  Datamap.prototype.pngTopo = '__PNG__';
  Datamap.prototype.polTopo = '__POL__';
  Datamap.prototype.priTopo = '__PRI__';
  Datamap.prototype.prkTopo = '__PRK__';
  Datamap.prototype.prtTopo = '__PRT__';
  Datamap.prototype.pryTopo = '__PRY__';
  Datamap.prototype.pyfTopo = '__PYF__';
  Datamap.prototype.qatTopo = '__QAT__';
  Datamap.prototype.rouTopo = '__ROU__';
  Datamap.prototype.rusTopo = '__RUS__';
  Datamap.prototype.rwaTopo = '__RWA__';
  Datamap.prototype.sahTopo = '__SAH__';
  Datamap.prototype.sauTopo = '__SAU__';
  Datamap.prototype.scrTopo = '__SCR__';
  Datamap.prototype.sdnTopo = '__SDN__';
  Datamap.prototype.sdsTopo = '__SDS__';
  Datamap.prototype.senTopo = '__SEN__';
  Datamap.prototype.serTopo = '__SER__';
  Datamap.prototype.sgpTopo = '__SGP__';
  Datamap.prototype.sgsTopo = '__SGS__';
  Datamap.prototype.shnTopo = '__SHN__';
  Datamap.prototype.slbTopo = '__SLB__';
  Datamap.prototype.sleTopo = '__SLE__';
  Datamap.prototype.slvTopo = '__SLV__';
  Datamap.prototype.smrTopo = '__SMR__';
  Datamap.prototype.solTopo = '__SOL__';
  Datamap.prototype.somTopo = '__SOM__';
  Datamap.prototype.spmTopo = '__SPM__';
  Datamap.prototype.srbTopo = '__SRB__';
  Datamap.prototype.stpTopo = '__STP__';
  Datamap.prototype.surTopo = '__SUR__';
  Datamap.prototype.svkTopo = '__SVK__';
  Datamap.prototype.svnTopo = '__SVN__';
  Datamap.prototype.sweTopo = '__SWE__';
  Datamap.prototype.swzTopo = '__SWZ__';
  Datamap.prototype.sxmTopo = '__SXM__';
  Datamap.prototype.sycTopo = '__SYC__';
  Datamap.prototype.syrTopo = '__SYR__';
  Datamap.prototype.tcaTopo = '__TCA__';
  Datamap.prototype.tcdTopo = '__TCD__';
  Datamap.prototype.tgoTopo = '__TGO__';
  Datamap.prototype.thaTopo = '__THA__';
  Datamap.prototype.tjkTopo = '__TJK__';
  Datamap.prototype.tkmTopo = '__TKM__';
  Datamap.prototype.tlsTopo = '__TLS__';
  Datamap.prototype.tonTopo = '__TON__';
  Datamap.prototype.ttoTopo = '__TTO__';
  Datamap.prototype.tunTopo = '__TUN__';
  Datamap.prototype.turTopo = '__TUR__';
  Datamap.prototype.tuvTopo = '__TUV__';
  Datamap.prototype.twnTopo = '__TWN__';
  Datamap.prototype.tzaTopo = '__TZA__';
  Datamap.prototype.ugaTopo = '__UGA__';
  Datamap.prototype.ukrTopo = '__UKR__';
  Datamap.prototype.umiTopo = '__UMI__';
  Datamap.prototype.uryTopo = '__URY__';
  Datamap.prototype.usaTopo = {"type":"Topology","transform":{"scale":[0.03514630243024302,0.005240860686068607],"translate":[-178.123152,18.948267]},"objects":{"usa":{"type":"GeometryCollection","geometries":[{"type":"Polygon","id":"AL","arcs":[[0,1,2,3,4]],"properties":{"name":"Alabama"}},{"type":"MultiPolygon","id":"AK","arcs":[[[5]],[[6]],[[7]],[[8]],[[9]],[[10]],[[11]],[[12]],[[13]],[[14]],[[15]],[[16]],[[17]],[[18]],[[19]],[[20]],[[21]],[[22]],[[23]],[[24]],[[25]],[[26]],[[27]],[[28]],[[29]],[[30]],[[31]],[[32]],[[33]],[[34]],[[35]],[[36]],[[37]],[[38]],[[39]],[[40]],[[41]],[[42]],[[43]]],"properties":{"name":"Alaska"}},{"type":"Polygon","id":"AZ","arcs":[[44,45,46,47,48]],"properties":{"name":"Arizona"}},{"type":"Polygon","id":"AR","arcs":[[49,50,51,52,53,54]],"properties":{"name":"Arkansas"}},{"type":"Polygon","id":"CA","arcs":[[55,-47,56,57]],"properties":{"name":"California"}},{"type":"Polygon","id":"CO","arcs":[[58,59,60,61,62,63]],"properties":{"name":"Colorado"}},{"type":"Polygon","id":"CT","arcs":[[64,65,66,67]],"properties":{"name":"Connecticut"}},{"type":"Polygon","id":"DE","arcs":[[68,69,70,71]],"properties":{"name":"Delaware"}},{"type":"Polygon","id":"DC","arcs":[[72,73]],"properties":{"name":"District of Columbia"}},{"type":"Polygon","id":"FL","arcs":[[74,75,-2]],"properties":{"name":"Florida"}},{"type":"Polygon","id":"GA","arcs":[[76,77,-75,-1,78,79]],"properties":{"name":"Georgia"}},{"type":"MultiPolygon","id":"HI","arcs":[[[80]],[[81]],[[82]],[[83]],[[84]]],"properties":{"name":"Hawaii"}},{"type":"Polygon","id":"ID","arcs":[[85,86,87,88,89,90,91]],"properties":{"name":"Idaho"}},{"type":"Polygon","id":"IL","arcs":[[92,93,94,95,96,97]],"properties":{"name":"Illinois"}},{"type":"Polygon","id":"IN","arcs":[[98,99,-95,100,101]],"properties":{"name":"Indiana"}},{"type":"Polygon","id":"IA","arcs":[[102,-98,103,104,105,106]],"properties":{"name":"Iowa"}},{"type":"Polygon","id":"KS","arcs":[[107,108,-60,109]],"properties":{"name":"Kansas"}},{"type":"Polygon","id":"KY","arcs":[[110,111,112,113,-96,-100,114]],"properties":{"name":"Kentucky"}},{"type":"Polygon","id":"LA","arcs":[[115,116,117,-52]],"properties":{"name":"Louisiana"}},{"type":"Polygon","id":"ME","arcs":[[118,119]],"properties":{"name":"Maine"}},{"type":"MultiPolygon","id":"MD","arcs":[[[120]],[[-71,121,122,123,124,-74,125,126,127]]],"properties":{"name":"Maryland"}},{"type":"Polygon","id":"MA","arcs":[[128,129,130,131,-68,132,133,134]],"properties":{"name":"Massachusetts"}},{"type":"MultiPolygon","id":"MI","arcs":[[[-102,135,136]],[[137]],[[138,139]],[[140]]],"properties":{"name":"Michigan"}},{"type":"Polygon","id":"MN","arcs":[[-107,141,142,143,144]],"properties":{"name":"Minnesota"}},{"type":"Polygon","id":"MS","arcs":[[-4,145,-116,-51,146]],"properties":{"name":"Mississippi"}},{"type":"Polygon","id":"MO","arcs":[[-97,-114,147,-55,148,-108,149,-104]],"properties":{"name":"Missouri"}},{"type":"Polygon","id":"MT","arcs":[[150,151,-92,152,153]],"properties":{"name":"Montana"}},{"type":"Polygon","id":"NE","arcs":[[-105,-150,-110,-59,154,155]],"properties":{"name":"Nebraska"}},{"type":"Polygon","id":"NV","arcs":[[156,-48,-56,157,-88]],"properties":{"name":"Nevada"}},{"type":"Polygon","id":"NH","arcs":[[-135,158,159,-120,160]],"properties":{"name":"New Hampshire"}},{"type":"Polygon","id":"NJ","arcs":[[161,-69,162,163]],"properties":{"name":"New Jersey"}},{"type":"Polygon","id":"NM","arcs":[[164,165,166,-45,-62]],"properties":{"name":"New Mexico"}},{"type":"Polygon","id":"NY","arcs":[[-133,-67,167,-164,168,169,170]],"properties":{"name":"New York"}},{"type":"Polygon","id":"NC","arcs":[[171,172,-80,173,174]],"properties":{"name":"North Carolina"}},{"type":"Polygon","id":"ND","arcs":[[175,-154,176,-143]],"properties":{"name":"North Dakota"}},{"type":"Polygon","id":"OH","arcs":[[177,-115,-99,-137,178,179]],"properties":{"name":"Ohio"}},{"type":"Polygon","id":"OK","arcs":[[-149,-54,180,-165,-61,-109]],"properties":{"name":"Oklahoma"}},{"type":"Polygon","id":"OR","arcs":[[-89,-158,-58,181,182]],"properties":{"name":"Oregon"}},{"type":"Polygon","id":"PA","arcs":[[-163,-72,-128,183,-180,184,-169]],"properties":{"name":"Pennsylvania"}},{"type":"MultiPolygon","id":"RI","arcs":[[[185,-130]],[[186,-65,-132]]],"properties":{"name":"Rhode Island"}},{"type":"Polygon","id":"SC","arcs":[[187,-77,-173]],"properties":{"name":"South Carolina"}},{"type":"Polygon","id":"SD","arcs":[[-142,-106,-156,188,-151,-176]],"properties":{"name":"South Dakota"}},{"type":"Polygon","id":"TN","arcs":[[189,-174,-79,-5,-147,-50,-148,-113]],"properties":{"name":"Tennessee"}},{"type":"Polygon","id":"TX","arcs":[[-53,-118,190,-166,-181]],"properties":{"name":"Texas"}},{"type":"Polygon","id":"UT","arcs":[[191,-63,-49,-157,-87]],"properties":{"name":"Utah"}},{"type":"Polygon","id":"VT","arcs":[[-134,-171,192,-159]],"properties":{"name":"Vermont"}},{"type":"MultiPolygon","id":"VA","arcs":[[[193,-123]],[[120]],[[-126,-73,-125,194,-175,-190,-112,195]]],"properties":{"name":"Virginia"}},{"type":"MultiPolygon","id":"WA","arcs":[[[-183,196,-90]],[[197]],[[198]]],"properties":{"name":"Washington"}},{"type":"Polygon","id":"WV","arcs":[[-184,-127,-196,-111,-178]],"properties":{"name":"West Virginia"}},{"type":"Polygon","id":"WI","arcs":[[199,-93,-103,-145,200,-140]],"properties":{"name":"Wisconsin"}},{"type":"Polygon","id":"WY","arcs":[[-189,-155,-64,-192,-86,-152]],"properties":{"name":"Wyoming"}}]}},"arcs":[[[2632,3060],[5,-164],[7,-242],[4,-53],[3,-30],[-2,-19],[4,-11],[-5,-25],[0,-24],[-2,-32],[2,-57],[-2,-51],[3,-52]],[[2649,2300],[-14,-1],[-59,0],[-1,-25],[6,-37],[-1,-31],[2,-16],[-4,-28]],[[2578,2162],[-4,-6],[-7,31],[-1,47],[-2,6],[-3,-36],[-1,-34],[-7,9]],[[2553,2179],[-2,291],[6,363],[4,209],[-3,20]],[[2558,3062],[24,1],[50,-3]],[[1324,6901],[1,32],[6,-19],[-1,-32],[-8,4],[2,15]],[[1317,6960],[5,-23],[-3,-33],[-2,11],[0,45]],[[1285,7153],[6,5],[3,-8],[-1,-28],[-6,-6],[-5,17],[3,20]],[[1267,7137],[12,-7],[3,-36],[13,-41],[4,-25],[0,-21],[3,-4],[1,-27],[5,-27],[0,-25],[3,8],[2,-19],[1,-74],[-3,-17],[-7,3],[-3,38],[-2,-3],[-6,28],[-2,-10],[-5,10],[1,-28],[5,7],[3,-10],[-2,-39],[-5,4],[-9,49],[-2,25],[1,26],[-7,-2],[0,20],[5,2],[5,18],[-2,31],[-6,7],[-1,50],[-2,25],[-4,-18],[-2,28],[4,14],[-3,32],[2,8]],[[1263,6985],[5,-12],[4,15],[4,-7],[-4,-28],[-6,8],[-3,24]],[[1258,7247],[-4,19],[5,13],[15,-18],[7,1],[5,-36],[9,-29],[-1,-22],[-5,-11],[-6,5],[-5,-14],[-6,9],[-7,-9],[-1,45],[0,30],[-5,1],[-1,16]],[[1252,7162],[-4,14],[-4,32],[0,24],[3,11],[4,-11],[0,20],[12,-35],[1,-33],[-4,-5],[-3,-37],[3,-11],[-3,-43],[-5,9],[0,-27],[-3,13],[-2,54],[5,25]],[[1207,7331],[8,38],[3,-16],[7,-13],[6,-2],[0,-30],[6,-99],[0,-85],[-1,-22],[-4,13],[-10,84],[-7,25],[3,20],[-3,48],[-8,39]],[[1235,7494],[10,-15],[5,2],[0,-14],[8,-52],[-5,8],[-2,-18],[6,-27],[2,-48],[-6,-13],[-2,-16],[-10,-35],[-3,1],[-1,37],[2,22],[-1,32],[-3,40],[0,21],[-2,51],[-4,22],[-1,38],[7,-36]],[[1203,7324],[4,0],[4,-35],[-2,-24],[-6,-5],[0,38],[0,26]],[[1207,7331],[-5,7],[-3,26],[-6,18],[-5,37],[-6,17],[1,30],[4,10],[1,26],[3,-11],[8,-1],[6,17],[8,-23],[-5,-26],[2,-9],[4,28],[10,-9],[5,-21],[-3,-38],[3,-3],[3,-50],[-7,-7],[-14,41],[0,-42],[-4,-17]],[[883,7871],[-12,-48],[-1,-19],[-9,-12],[2,29],[10,30],[7,34],[3,-14]],[[870,7943],[-2,-39],[-4,-41],[-6,14],[5,47],[7,19]],[[863,9788],[3,-8],[15,-9],[8,5],[10,0],[12,-7],[7,4],[7,-15],[12,-18],[16,-4],[5,10],[11,6],[4,14],[12,2],[0,-9],[7,5],[15,-15],[9,-24],[10,-11],[2,-11],[8,-2],[8,-18],[1,-11],[5,9],[6,-7],[0,-1783],[13,-16],[2,17],[14,-24],[8,30],[18,4],[-3,-52],[4,-17],[10,-17],[2,-27],[29,-101],[4,-63],[6,17],[12,31],[7,1],[3,23],[0,34],[5,0],[1,31],[9,7],[13,26],[13,-45],[-1,-27],[3,-27],[7,-7],[10,-40],[-1,-12],[4,-22],[12,-25],[19,-110],[3,-29],[6,-29],[8,-65],[9,-55],[-3,-23],[9,-9],[-2,-33],[7,-14],[1,-38],[7,2],[14,-40],[9,-7],[5,-19],[4,-5],[1,-19],[9,-5],[3,-23],[-4,-43],[1,-36],[4,-58],[-4,-15],[-6,-53],[-10,-39],[-3,20],[-4,-6],[-3,39],[1,17],[-3,20],[7,21],[-2,7],[-7,-26],[-3,17],[-4,-10],[-12,42],[4,46],[-8,-15],[0,-23],[-6,17],[-1,22],[4,24],[-1,24],[-6,-19],[-6,42],[-3,-8],[-2,36],[5,23],[6,0],[-2,28],[3,36],[-5,-1],[-9,32],[-6,37],[-15,27],[0,77],[-4,9],[1,31],[-5,9],[-8,42],[-2,22],[-12,7],[-14,56],[-6,132],[-3,-30],[1,-27],[6,-53],[-1,-8],[3,-43],[0,-28],[-6,6],[-4,31],[-6,6],[-8,-9],[0,45],[-5,38],[-5,-12],[-17,40],[-2,-11],[10,-13],[7,-31],[3,-1],[1,-25],[4,-30],[-10,-16],[-5,10],[0,-26],[-8,20],[-2,14],[-5,0],[-13,38],[-10,33],[-1,20],[-5,30],[-14,21],[-9,21],[-14,26],[-9,24],[1,26],[2,-9],[3,17],[-3,38],[4,21],[-2,9],[-7,-40],[-14,-26],[-18,10],[-14,24],[-1,18],[-7,-4],[-7,14],[-17,12],[-9,1],[-21,-10],[-8,-7],[-10,27],[-12,12],[-3,17],[-2,28],[-8,-2],[-3,-25],[-15,34],[-2,14],[-15,-27],[-7,-32],[-3,30],[3,17],[4,-5],[14,22],[-2,17],[-6,-8],[-3,22],[-6,3],[-6,55],[-3,-13],[-8,-8],[-3,8],[-3,-18],[-11,6],[-1,-20],[-7,-5],[-3,7],[2,36],[-3,-1],[-5,-38],[7,-12],[1,-27],[4,-30],[-3,-31],[-5,10],[-2,-15],[6,-7],[3,-41],[-8,-9],[-4,9],[-7,-12],[-3,10],[-9,-2],[0,16],[-4,-10],[-3,-20],[-3,18],[-5,-25],[2,-12],[-6,-15],[-6,-2],[-3,-20],[-6,-17],[-4,6],[-5,-21],[-4,1],[-8,-43],[-9,-3],[-3,14],[-5,-23],[-11,17],[2,33],[8,11],[4,-2],[2,13],[8,25],[0,21],[-11,-28],[-9,16],[-1,12],[5,48],[8,34],[1,29],[2,5],[1,30],[-4,34],[10,12],[19,48],[4,-19],[6,-5],[9,20],[-10,26],[-4,20],[-7,-2],[-5,9],[-2,-8],[-9,-14],[-4,-26],[-9,-6],[-9,-30],[-1,-20],[-7,-11],[-2,-22],[-5,-13],[-2,-39],[-10,-25],[5,-20],[-4,-29],[-9,-5],[-1,-38],[-8,-13],[-3,15],[-4,-29],[-5,-1],[1,-21],[-11,-13],[-2,-57],[12,-3],[10,-16],[3,-19],[-4,-30],[-7,-19],[-6,-1],[0,-17],[-4,-6],[1,-21],[-4,-31],[-9,-29],[-5,0],[-5,-11],[-5,2],[-4,-11],[2,-16],[-7,-8],[-2,-23],[-5,14],[-5,-45],[-9,4],[1,-24],[-6,6],[-3,-11],[0,-32],[-6,-50],[-10,-6],[-7,-23],[-2,-13],[-5,18],[-8,-48],[-2,13],[-5,-4],[-1,-27],[-5,-10],[-6,4],[-4,-27],[8,-9],[-9,-60],[-25,-20],[-6,-54],[-2,12],[1,33],[-5,6],[-6,-13],[-1,-14],[-10,-22],[-4,-25],[-1,18],[-2,-21],[-6,14],[-10,-33],[-8,2],[1,25],[-4,24],[-3,-20],[1,-21],[-11,-64],[-3,16],[-1,-24],[-8,4],[-1,38],[-4,8],[-2,-14],[4,-16],[-2,-27],[-5,-13],[-5,29],[-5,2],[-1,-11],[5,-17],[-9,-27],[6,-7],[0,-13],[-5,9],[-7,-25],[-15,1],[-7,-16],[0,-13],[-8,-15],[-6,6],[-2,35],[6,12],[4,43],[6,1],[13,28],[10,1],[4,-27],[3,20],[-1,23],[6,10],[7,0],[8,50],[10,45],[12,40],[15,18],[6,-9],[6,12],[1,-17],[-3,-19],[4,-14],[1,23],[7,2],[2,-15],[5,-5],[0,18],[-8,15],[0,11],[5,49],[6,28],[9,27],[15,24],[10,35],[5,-13],[4,5],[-1,22],[1,21],[8,44],[11,28],[8,38],[0,21],[7,148],[11,40],[-1,31],[-27,-45],[-8,6],[-2,18],[-5,9],[-1,21],[-4,-10],[-3,-32],[5,-41],[-6,-18],[-5,7],[-9,64],[-6,33],[-4,0],[-2,-24],[-3,-4],[-4,19],[-5,4],[-2,32],[-16,-37],[-13,-26],[-1,-14],[-11,-22],[-6,20],[5,23],[-1,54],[-4,57],[7,24],[-6,49],[-5,27],[-4,39],[-6,17],[-2,-34],[-7,-8],[-12,-22],[-14,-9],[-7,2],[-7,12],[-1,30],[-5,9],[-9,42],[-8,8],[-8,46],[6,21],[1,39],[-5,-8],[0,24],[2,19],[-6,18],[0,-19],[-7,8],[-1,32],[-6,4],[-3,22],[0,27],[-5,-12],[-1,26],[7,6],[-6,30],[10,2],[0,35],[2,24],[18,77],[4,23],[3,-5],[-2,33],[7,55],[6,22],[11,9],[8,-9],[12,-33],[8,4],[11,32],[11,49],[6,6],[1,-13],[13,0],[12,10],[11,52],[0,12],[-5,48],[-1,28],[-8,31],[-3,26],[8,-7],[8,22],[0,20],[-10,39],[-8,-30],[-7,5],[-6,-17],[-8,-4],[-2,-11],[-9,-17],[-2,-28],[-5,-12],[-2,34],[-5,7],[-4,-26],[-2,12],[-10,19],[-20,-1],[-14,-21],[-6,-3],[-11,13],[-22,14],[-6,12],[-3,19],[2,26],[-8,22],[2,24],[5,12],[-2,31],[-8,0],[-6,8],[-13,6],[-7,16],[-10,16],[-1,19],[16,27],[20,43],[15,27],[8,-15],[8,-3],[2,21],[-5,3],[-1,18],[20,29],[22,22],[12,2],[7,-7],[-4,-32],[2,-22],[-3,-15],[4,-26],[8,5],[10,-5],[11,6],[4,-10],[7,-2],[7,10],[8,-11],[9,42],[5,2],[5,-8],[2,24],[-12,11],[-11,-9],[1,31],[-8,34],[-10,10],[-2,30],[7,8],[9,-31],[-1,-24],[4,-18],[10,-22],[2,23],[-11,30],[5,54],[-4,10],[-11,-12],[-11,3],[-2,10],[-6,-10],[-24,23],[0,24],[-7,54],[-6,19],[-9,17],[-19,46],[-9,18],[-8,4],[-13,31],[-12,18],[-1,6],[9,10],[4,29],[1,59],[25,-4],[31,13],[8,11],[12,29],[12,45],[3,45],[5,38],[10,33],[5,24],[13,38],[2,-10],[11,-3],[16,20],[10,21],[24,64],[9,4],[1,-10],[9,7],[9,-2],[18,9],[17,28],[17,58],[7,13],[2,-10],[26,-24],[2,-17],[-9,-22],[-4,-1],[0,-29],[14,9],[0,16],[6,14],[2,-8],[5,33],[13,-30],[-2,-23],[8,-6],[5,-14],[7,22],[13,1],[7,7],[18,-7],[10,-8],[-5,-45],[17,-12],[2,-11],[16,-20],[1,9],[12,13],[11,-1],[0,-11],[7,-1],[7,15],[11,2],[9,-6],[11,-16],[5,3],[7,-22],[4,9],[7,-7],[5,-13]],[[717,7456],[-1,-8],[-9,13],[7,49],[6,4],[4,45],[5,-40],[4,14],[8,-22],[0,-31],[-11,-4],[-5,-13],[-8,-7]],[[688,7363],[8,25],[-8,6],[0,22],[6,14],[5,-10],[0,-22],[3,15],[0,32],[5,-15],[1,21],[5,-12],[5,0],[5,11],[7,-20],[0,-55],[9,4],[-6,-37],[-11,15],[4,-24],[-3,-20],[-6,10],[0,-38],[-8,-10],[-3,-16],[-5,15],[-6,-40],[-4,-4],[-5,-18],[-2,43],[-6,-23],[-1,13],[-6,14],[0,39],[-6,15],[4,45],[11,28],[7,-2],[1,-21]],[[671,7185],[-6,-39],[-2,6],[8,33]],[[640,7055],[4,-2],[-1,-40],[-8,6],[-1,13],[6,23]],[[519,6933],[-2,-41],[-9,-33],[5,51],[2,-5],[4,28]],[[501,6947],[5,0],[0,-20],[-5,-23],[-5,15],[-3,-14],[-2,35],[2,12],[8,-5]],[[451,6875],[1,-16],[-3,-11],[-3,18],[5,9]],[[447,8527],[-4,-19],[-2,16],[6,3]],[[436,6781],[6,-7],[-1,-16],[-5,1],[0,22]],[[358,6745],[2,-22],[-5,-10],[-1,23],[4,9]],[[352,6718],[-8,-21],[-2,14],[3,19],[7,-12]],[[335,7902],[6,7],[2,-14],[5,3],[6,-12],[1,-54],[-3,-18],[-7,-11],[-2,-18],[-11,20],[-5,-1],[-10,28],[-4,0],[-6,15],[-3,25],[4,7],[10,-7],[5,20],[5,2],[3,14],[4,-6]],[[334,6690],[5,-14],[-10,-36],[1,-6],[12,26],[0,-15],[-5,-17],[-8,-12],[-1,-18],[-8,-18],[-7,-1],[-5,-18],[-9,-16],[-5,17],[9,20],[3,-3],[8,16],[-2,19],[4,20],[6,-9],[1,12],[-7,4],[-4,14],[4,23],[11,13],[2,-26],[5,25]],[[266,6527],[10,37],[1,16],[4,17],[7,9],[3,-10],[1,-25],[-12,-27],[-6,-40],[-6,-13],[-2,36]],[[238,6477],[2,-19],[-8,-1],[-1,13],[7,7]],[[227,7303],[-4,-18],[-1,18],[5,0]],[[212,6440],[2,-18],[-5,-13],[-1,19],[4,12]],[[182,8542],[22,-28],[13,24],[6,-2],[5,-14],[2,-23],[11,-12],[4,-12],[15,-5],[8,-8],[-4,-28],[-7,6],[-8,-5],[-4,-13],[-4,-28],[-5,26],[-6,18],[-6,2],[-3,20],[-15,25],[-6,1],[-11,-22],[-7,11],[-4,23],[4,44]],[[162,6381],[0,-22],[-5,-4],[1,19],[4,7]],[[128,6335],[4,-8],[10,1],[1,-7],[-13,-9],[-2,23]],[[108,6360],[0,19],[4,7],[6,-19],[-2,-17],[-4,1],[1,-20],[-5,-2],[-12,-21],[-6,6],[2,15],[7,-2],[9,33]],[[47,6279],[5,3],[0,-24],[-6,3],[-8,-28],[-4,37],[4,1],[0,29],[5,1],[0,-21],[4,-1]],[[28,6296],[3,-9],[-2,-32],[-5,-10],[0,20],[4,31]],[[0,6291],[5,-1],[4,-23],[-4,-27],[-5,51]],[[9993,6496],[6,-13],[0,-19],[-11,-12],[-8,31],[0,15],[13,-2]],[[1966,3444],[-1,-1081]],[[1965,2363],[-57,0],[-34,71],[-73,150],[3,43]],[[1804,2627],[6,8],[1,16],[-1,36],[-4,1],[-2,71],[6,27],[0,28],[-1,45],[4,34],[4,12],[4,25],[-6,27],[-4,51],[-5,31],[0,24]],[[1806,3063],[2,26],[0,36],[-3,36],[-2,112],[11,7],[3,-23],[3,1],[3,33],[0,153]],[[1823,3444],[101,2],[42,-2]],[[2515,3253],[-1,-35],[-4,-11],[-1,-29],[-5,-31],[0,-46],[-3,-34],[-3,-5]],[[2498,3062],[2,-17],[-4,-14],[-2,-33],[-3,-8],[0,-38],[-5,-10],[0,-13],[-6,-31],[2,-21],[-5,-30],[-5,-59],[5,-25],[-2,-16],[1,-39],[-2,-26]],[[2474,2682],[-69,3],[-13,0]],[[2392,2685],[0,101],[-4,8],[-5,-9],[-3,18]],[[2380,2803],[1,335],[-5,211]],[[2376,3349],[4,0],[123,-1],[2,-36],[-4,-23],[-4,-36],[18,0]],[[1654,4398],[0,-331],[0,-241],[36,-171],[35,-169],[27,-137],[20,-101],[34,-185]],[[1804,2627],[-38,-18],[-30,-16],[-4,25],[0,40],[-2,47],[-4,33],[-9,46],[-12,43],[-2,-12],[-4,8],[1,18],[-5,39],[-7,-8],[-12,28],[-2,23],[-8,28],[-9,-1],[-7,13],[-10,-6],[-5,26],[1,53],[-1,8],[1,38],[-8,28],[0,39],[-3,2],[-4,33],[-4,8],[-1,20],[-11,79],[-5,23],[-1,61],[2,-5],[2,37],[-4,33],[-5,-4],[-7,30],[-2,24],[0,23],[-3,31],[0,50],[5,0],[-2,70],[-2,-7],[-1,-35],[-5,-7],[-7,26],[-1,45],[-4,35],[-6,22],[-3,25],[-9,50],[2,14],[-4,64],[2,35],[-3,54],[-7,52],[-7,29],[-2,35],[7,83],[2,29],[-2,22],[3,57],[-2,52],[-3,13],[1,42]],[[1534,4399],[28,1],[24,1],[38,-3],[30,0]],[[2107,4208],[57,0],[0,-191]],[[2164,4017],[1,-574]],[[2165,3443],[-28,1]],[[2137,3444],[-38,-1],[-72,0],[-15,1],[-46,0]],[[1966,3444],[0,223],[-1,21],[0,162],[0,357]],[[1965,4207],[32,1],[63,-1],[47,1]],[[3025,4400],[0,-113],[-2,-18]],[[3023,4269],[-2,3],[-12,-14],[-15,4],[-7,-26],[-7,-9],[-8,-22]],[[2972,4205],[-2,22],[7,21],[-2,16],[2,144]],[[2977,4408],[12,-2],[36,-3],[0,-3]],[[2922,3980],[-2,-23]],[[2920,3957],[-3,-13],[0,-30],[5,-29],[1,-47],[6,-49],[3,-2],[1,-66]],[[2933,3721],[-19,2],[-2,241]],[[2912,3964],[5,21],[5,-5]],[[2876,3786],[-2,27]],[[2874,3813],[2,12],[4,-19],[-4,-20]],[[2649,2300],[4,-55],[39,-13],[37,-14],[1,-41],[4,1],[1,39],[-1,35],[2,15],[7,-16],[8,-7]],[[2751,2244],[1,-83],[4,-93],[8,-122],[13,-131],[-2,-9],[1,-61],[5,-68],[8,-137],[2,-42],[0,-44],[-3,-158],[-3,-3],[-3,-49],[1,-16],[-5,-36],[-2,9],[-6,-15],[-9,-8],[-2,20],[1,29],[-7,85],[-5,15],[-4,-11],[-3,47],[-1,38],[-6,43],[-2,28],[1,41],[-3,8],[1,-24],[-3,-7],[-9,104],[-4,26],[9,76],[-6,-4],[-4,-24],[-3,38],[5,104],[1,87],[-4,21],[-1,28],[-5,6],[-7,46],[-5,19],[0,28],[-4,11],[-3,31],[-11,42],[-9,-10],[0,-29],[-3,5],[-12,-35],[-12,-9],[0,21],[-3,25],[-15,57],[-10,24],[-10,6],[-8,-4],[-17,-18]],[[2703,3063],[-6,-41],[0,-20],[9,-40],[3,3],[5,-42],[1,-22],[4,-40],[7,-24],[3,-35],[8,-33],[0,-22],[5,-35],[7,-29],[2,-32],[1,-40],[3,-14],[5,-51],[0,-33],[7,-16]],[[2767,2497],[-7,-65],[-2,-34],[-3,-29],[0,-30],[-3,-14],[-1,-81]],[[2632,3060],[37,1]],[[2669,3061],[20,-1],[14,3]],[[640,0],[-7,17],[-1,16],[1,43],[-5,73],[4,24],[2,34],[-2,22],[1,23],[8,-27],[9,-20],[5,-29],[0,-26],[8,-40],[-5,-34],[-8,-15],[-7,-25],[-3,-36]],[[613,397],[3,-26],[4,11],[9,-30],[-1,-27],[-9,-14],[-2,6],[-1,33],[-5,7],[-1,19],[3,21]],[[602,432],[-3,-20],[-7,0],[2,22],[8,-2]],[[574,525],[3,-45],[-2,-26],[-6,-5],[-4,54],[4,1],[5,21]],[[531,626],[3,-2],[2,-20],[-1,-28],[-4,-18],[-9,22],[1,31],[8,15]],[[1908,4871],[0,-472]],[[1908,4399],[-31,-1],[-54,0]],[[1823,4398],[-85,1]],[[1738,4399],[0,349],[4,62],[-2,16],[-6,3],[-2,26],[6,68],[3,6],[3,29],[-1,17],[4,23],[1,34],[6,56],[-2,26],[-7,14],[-4,32]],[[1741,5160],[0,34],[-3,33],[0,16],[0,255],[0,236]],[[1738,5734],[28,0]],[[1766,5734],[0,-195],[9,-54],[1,-52],[5,-23],[6,-8],[0,-14],[11,-51],[1,-21],[8,-20],[0,-12],[8,1],[-4,-71],[-1,-45],[3,-29],[-5,-21],[2,-20],[-1,-21],[6,-20],[7,26],[3,21],[5,-19],[-1,-15],[3,-37],[5,-39],[3,-13],[0,-37],[3,-16],[6,-2],[4,-61],[3,-11],[3,18],[9,-1],[7,17],[3,-10],[7,9],[2,-11],[5,8],[7,39],[4,-33],[5,-20]],[[2489,4496],[53,-3],[28,0]],[[2570,4493],[-1,-37],[4,-43],[5,-70]],[[2578,4343],[0,-450],[-3,-35],[3,-40],[1,-34],[-4,-27],[-1,-25],[-5,-41],[-3,-3],[0,-24],[-2,-9],[-1,-45],[0,-13]],[[2563,3597],[-3,-27],[2,-34],[-11,-17],[-1,-20],[2,-25],[-3,-16],[-11,29],[-3,-2],[-4,-33],[1,-11]],[[2532,3441],[-5,2],[-6,55],[2,12],[-2,37],[0,29],[-9,41],[-3,-4],[-3,25],[-9,38],[0,31],[5,49],[-1,18],[3,23],[-4,13],[-6,9],[-3,-18],[-3,11],[-1,63],[-10,41],[-9,49],[-3,58],[-1,39],[3,27]],[[2467,4089],[0,35],[8,21],[1,29],[4,19],[0,33],[-4,27],[2,34],[11,9],[9,24],[0,29],[4,13],[1,37],[0,24],[-7,18],[-1,20],[-6,35]],[[2655,4340],[0,-228],[0,-266]],[[2655,3846],[-2,-9],[2,-52],[-5,-1],[-5,-18],[-8,9],[1,-38],[-5,-16],[-2,-24],[-5,-9],[-3,-48],[-3,-13],[-6,18],[-1,22],[-7,-24],[1,-21],[-7,-7],[-1,19],[-8,-19],[-2,-20],[-7,28],[-4,-6],[-2,13],[-3,-13],[-7,-2],[-3,-18]],[[2578,4343],[3,-12],[8,0],[9,22]],[[2598,4353],[23,0],[34,0],[0,-13]],[[2473,4685],[0,-28],[4,-19],[-3,-23],[1,-43],[2,-30],[10,-22],[2,-24]],[[2467,4089],[-3,7],[-6,38],[-3,-1],[-40,-5],[-39,-2],[-33,3]],[[2343,4129],[-3,25],[2,49],[-3,43],[0,48],[-5,17],[-1,26],[2,23],[-2,33],[-4,13],[-5,86]],[[2324,4492],[-5,41],[2,29],[1,37],[2,14],[-3,19],[1,33],[-2,16],[4,4]],[[2324,4685],[144,0],[5,0]],[[2356,4017],[3,-18],[9,-14],[-6,-56],[4,-18],[4,-45],[6,-10],[0,-412]],[[2376,3444],[-156,0],[-55,-1]],[[2164,4017],[5,0],[187,0]],[[2718,3716],[-1,-57],[4,-37],[4,-28],[2,-22],[5,-22],[4,-3]],[[2736,3547],[-11,-51],[-11,-29],[0,-14],[-4,-13],[0,-16],[-6,-8],[-1,-21],[-16,-27]],[[2687,3368],[0,-3],[-24,2],[-22,6],[-5,-2],[-32,8],[-36,-5],[-6,9],[1,-35],[-36,2],[-3,-2]],[[2524,3348],[1,24],[5,-8],[2,77]],[[2655,3846],[11,0],[5,-40],[1,-17],[9,-7],[6,-26],[5,13],[10,-14],[4,19],[4,6],[1,-32],[3,-6],[4,-26]],[[2474,2682],[3,-22],[-2,-9],[-1,-38],[5,-24],[0,-57],[-3,-44],[-7,-27],[-2,-43],[-2,4],[-1,-70],[-3,-2],[2,-37],[-2,-14],[54,0],[-3,-63],[4,-41],[1,-32],[4,-20]],[[2521,2143],[-9,-26],[0,-19],[7,-12],[3,30],[6,-30],[-1,-24],[-3,-11],[-7,10],[1,-18],[-2,-27],[5,-24],[9,-7],[3,-29],[3,-4],[-5,-32],[-5,6],[-4,33],[-10,18],[0,33],[-6,-11],[1,-27],[-3,-25],[-3,-4],[-3,28],[-7,1],[-2,-29],[-4,-9],[-5,18],[-4,2],[-3,47],[-7,21],[-2,-3],[-3,40],[-7,-5],[0,24],[-8,-23],[1,-18],[-5,-17],[-9,8],[-10,27],[-7,11],[-16,-9],[-2,-8]],[[2398,2049],[-2,19],[6,68],[-2,37],[2,20],[-1,26],[3,19],[3,50],[0,40],[-8,78],[0,41],[-7,42],[0,196]],[[3046,5029],[12,26],[-2,13],[5,30],[4,13],[-1,12],[5,18],[-1,33],[2,50],[5,17],[1,53],[22,147],[6,-7],[0,-35],[4,-13],[9,21],[6,0],[4,14],[8,-31],[4,-25],[1,-214],[-1,-51],[10,-14],[-2,-22],[3,-21],[-2,-18],[4,-30],[5,7],[5,-68],[-6,-31],[-3,12],[-3,-21],[-4,5],[0,-18],[-6,2],[-8,-40],[-2,28],[-3,2],[1,-30],[-6,-15],[-2,24],[-3,-12],[-7,0],[0,28],[-5,-6],[1,-20],[-4,-42],[1,-12],[-6,-23],[-5,9],[-3,-24],[-4,-3],[-4,-20],[-4,4],[-1,21],[-7,-34],[2,-21],[-5,-7],[0,-18],[-5,-22],[-5,-50]],[[3056,4600],[-3,14],[0,19],[-4,22],[-2,250],[-1,124]],[[2904,3626],[2,0],[-1,0],[-1,0]],[[2933,3721],[-6,-80]],[[2927,3641],[-4,-3],[-8,-12]],[[2915,3626],[-6,-8],[0,31],[-2,13],[3,13],[-4,32],[-2,-14],[-6,3],[-2,35],[2,0],[0,45],[2,18],[-2,60],[3,36],[5,6],[0,37],[-3,-5],[0,-18],[-8,-25],[-2,-21],[0,-56],[-3,-26],[1,-44],[4,-30],[-1,-23],[3,-23],[-2,-16],[-6,30],[-10,15],[-2,29],[-6,-16],[-2,23],[5,29]],[[2874,3756],[2,30]],[[2874,3813],[-4,18],[-6,10],[0,28],[-3,15],[-4,4]],[[2857,3888],[-4,53],[-4,0],[-5,18],[-3,-15],[-5,1],[-1,-21],[-8,14],[-6,-28],[-3,6],[-6,-33],[-6,-17],[1,98]],[[2807,3964],[105,0]],[[3053,4565],[1,-34],[-1,-27],[-5,-25],[0,-29],[6,-4],[4,-31],[0,-24],[3,-6],[0,-22],[8,-19],[9,18],[-2,-26],[-13,-23],[-5,-1],[-3,18],[-5,-6],[0,-13],[-5,-9]],[[3045,4302],[-3,35]],[[3042,4337],[0,6]],[[3042,4343],[-3,14],[-2,45],[-4,0],[-8,-2]],[[2977,4408],[0,7],[6,126]],[[2983,4541],[23,-3]],[[3006,4538],[34,-7],[3,18],[7,19],[3,-3]],[[2598,4353],[5,25],[4,43],[4,26],[3,36],[1,52],[0,57],[-9,111],[3,42],[-2,50],[6,51],[2,43],[-1,23],[5,9],[0,31],[8,9],[5,34],[0,-69],[3,-3],[3,35],[1,58],[2,15],[8,9],[-3,41],[5,35],[7,2],[7,-22],[7,-3],[3,-28],[6,-2],[9,-25],[3,1],[4,-41],[-3,-21],[3,-29],[2,-32],[-2,-71],[-6,-18],[-1,-37],[-7,-12],[-4,-44],[2,-17],[6,-15],[6,24],[6,49],[10,19],[5,-15],[3,-27],[3,-80],[0,-39],[3,-48],[-3,-69],[-4,-11],[-1,25],[-3,-7],[-3,-58],[-6,-21],[-2,-44],[-7,-37],[0,-16]],[[2694,4347],[-39,-7]],[[2635,5110],[1,-23],[-4,-4],[1,33],[2,-6]],[[2496,5270],[11,20],[5,23],[12,9],[8,29],[4,1],[3,20],[9,28],[4,24],[7,15],[6,-13],[-11,-59],[-2,-19],[0,-36],[5,27],[10,-4],[8,-19],[7,-52],[3,-10],[7,9],[2,-12],[7,-6],[16,44],[8,4],[10,-2],[7,15],[6,1],[1,-54],[5,-7],[6,8],[2,-12],[4,16],[8,5],[1,-67],[3,-28],[6,-8],[1,19],[5,0],[3,-20],[-3,-14],[-15,12],[-8,-8],[-8,23],[-2,-21],[1,-18],[-4,4],[-5,27],[-9,15],[-5,1],[-4,-25],[-8,-6],[-8,5],[-3,-10],[-1,-21],[-9,-18],[1,25],[-4,5],[-2,-26],[-6,-1],[-3,-11],[-5,-45],[-8,-58],[1,-5]],[[2576,4989],[-4,20],[2,27],[-7,4],[3,26],[0,34],[-5,23],[-4,24],[-12,19],[-4,-7],[-12,29],[-29,38],[-3,33],[-5,11]],[[2541,5539],[-7,-24],[-4,-3],[1,19],[18,45],[-4,-31],[-4,-6]],[[2324,4685],[0,343],[-7,22],[-5,36],[8,41],[1,22]],[[2321,5149],[-1,76],[-4,20],[-2,42],[0,51],[-1,8],[-1,123],[-5,65],[-3,36],[0,77],[1,27],[-3,60]],[[2302,5734],[59,0],[0,73],[5,-2],[4,-14],[4,-100],[3,-11],[9,-3],[1,-10],[11,-4],[1,-21],[10,5],[0,9],[7,10],[6,-4],[8,-16],[2,-19],[4,2],[4,-43],[2,18],[7,8],[1,-18],[9,-12],[0,-17],[4,-14],[8,8],[5,18],[8,12],[2,-28],[5,6],[6,-6],[6,4],[8,-24],[7,4],[0,-10],[-10,-24],[-13,-19],[-9,-20],[-12,-49],[-5,-31],[-8,-34],[-13,-46],[2,-16]],[[2450,5296],[-2,9],[-6,-16],[0,-113],[-2,-11],[-8,-16],[-6,-41],[-1,-27],[3,-2],[4,-24],[-3,-29],[0,-33],[-2,-70],[8,-34],[6,-3],[3,-21],[8,-21],[2,-25],[8,-33],[5,-7],[5,-42],[-1,-30],[2,-22]],[[2553,2179],[-3,-8],[-7,4],[-3,12],[-7,-8],[-9,-22],[-3,-14]],[[2498,3062],[53,0],[7,0]],[[2524,3348],[-2,0],[-2,0],[1,-47],[-6,-48]],[[2376,3349],[0,95]],[[2356,4017],[-7,50],[-6,62]],[[2108,5151],[0,-181],[-1,0]],[[2107,4970],[-53,1],[-90,0],[-56,0],[0,-100]],[[1766,5734],[130,-1],[58,1],[154,0]],[[2108,5734],[0,-217],[0,-366]],[[2107,4208],[0,382]],[[2107,4590],[21,0],[49,-1],[88,0],[1,-10],[15,-34],[4,19],[4,-4],[13,0],[15,-36],[2,-27],[5,-5]],[[1823,4398],[0,-954]],[[1654,4398],[37,-1],[47,2]],[[3006,4538],[-2,14],[0,28],[3,11],[-1,27],[3,81],[5,37],[2,43],[3,16],[-1,47],[10,17],[5,33],[-3,31],[4,32],[0,18]],[[3034,4973],[4,49],[6,-5],[2,12]],[[3056,4600],[-3,-35]],[[2962,4152],[-5,-13],[-2,-29],[8,-14],[0,-22],[-3,-103],[-9,-76],[-6,-22],[-5,-48],[-3,31],[-8,16],[-10,42],[-1,28],[0,4],[2,11]],[[2922,3980],[8,15],[0,15],[9,31],[2,17],[-9,39],[0,24],[-3,6],[-1,22],[5,33],[-3,20],[7,40],[2,21],[4,13]],[[2943,4276],[13,-41],[9,-28],[-3,-55]],[[2137,3444],[0,-95]],[[2137,3349],[-1,0],[0,-474],[0,-193],[0,-192],[-101,0],[-1,-18],[3,-22]],[[2037,2450],[-48,0],[0,-87],[-24,0]],[[2972,4205],[13,-15],[2,11],[10,0],[6,6],[8,31],[1,-22],[5,-10],[-11,-28],[-22,-42],[-9,-8],[-6,2],[-5,-9],[-2,31]],[[2943,4276],[-2,14],[-4,1],[-5,32],[1,29],[-4,22],[-2,-2],[-3,27],[-125,0],[0,48],[0,3]],[[2799,4450],[17,54],[3,26],[5,18],[-2,32],[-2,7],[-2,52],[17,22],[15,-1],[6,-5],[6,-21],[4,8],[12,-1],[8,14],[8,34],[5,1],[0,52],[3,31],[-7,21],[2,24],[11,32],[4,28],[14,64],[13,32],[19,-5],[23,4]],[[2981,4973],[1,-39],[-2,-36],[3,-34],[-1,-37],[-3,-39],[2,-52],[-1,-16],[4,-31],[-1,-132],[0,-16]],[[2909,3359],[4,-77],[-8,8],[-1,-10],[-10,-11],[-1,-11],[-7,-3],[0,-13],[8,9],[1,-8],[9,9],[3,-18],[5,8],[2,-46],[-2,-22],[-3,-2],[-8,-47],[-9,-2],[-2,-33],[4,-32],[4,-6],[-6,-54],[-6,7],[-9,-6],[-6,-11],[-10,-37],[-7,-48],[-4,-60],[-6,13],[-11,-12]],[[2833,2844],[-32,181],[-32,4],[1,21],[-5,33],[-3,-12],[0,20],[-35,10],[-8,-8],[-6,-17],[-10,-13]],[[2669,3061],[1,45],[5,4],[3,31],[7,29],[7,1],[7,29],[8,10],[6,43],[4,13],[1,-19],[11,37],[5,-8],[4,36],[5,9],[1,45]],[[2744,3366],[20,-5],[19,-3],[23,-1],[103,2]],[[2321,5149],[-213,2]],[[2108,5734],[194,0]],[[2777,4138],[-4,-10],[2,-21],[0,-29],[-4,-46],[-3,-70],[-11,-62],[-3,-8],[-4,12],[-3,-27],[-3,1],[-4,-36],[1,-22],[-3,-18],[-4,29],[-5,-46],[1,-29],[-3,-11],[-1,-25],[-8,-4]],[[2694,4347],[11,-26],[3,-15],[3,14],[6,-30],[4,-9],[14,25],[7,-6],[9,36],[12,34],[14,24]],[[2777,4394],[0,-256]],[[2380,2803],[-11,21],[-3,22],[-7,18],[-2,-16],[-8,1],[-1,10],[-7,-19],[-3,11],[-6,-10],[-5,-29],[-2,17],[-6,14],[-7,0],[-2,21],[-7,-42],[-2,24],[-3,-8],[-3,16],[-7,15],[-5,-25],[-2,26],[-4,3],[-2,21],[-6,8],[-3,-18],[-3,16],[-5,-2],[-6,17],[-6,-2],[-2,36],[-9,2],[-4,-6],[-6,37],[-2,-3],[0,370],[-52,0],[-34,0]],[[1534,4399],[-4,22],[-2,61],[0,43],[-4,33],[3,32],[2,51],[4,54],[2,48],[3,162],[0,22],[3,71],[1,99],[-2,54],[1,32],[12,29]],[[1553,5212],[5,-22],[4,5],[3,2],[6,-20],[3,-23],[1,-57],[15,-21],[12,30],[8,3],[9,-10],[1,-13],[16,27],[3,-9],[9,5],[7,19],[12,17],[12,4],[4,12],[58,-1]],[[2807,3964],[-30,0],[0,174]],[[2777,4394],[5,11],[17,45]],[[3045,4302],[-6,-4],[3,39]],[[3042,4343],[-4,3],[-3,-28],[-1,-40],[-11,-9]],[[2833,2844],[-5,-10],[-6,-31],[-6,-49],[-1,-40],[-5,-31],[-6,0],[-2,-23],[-6,-25],[-4,-28],[-6,-11],[-6,-29],[-1,-14],[-6,-16],[-6,-40]],[[2107,4590],[0,380]],[[2687,3368],[57,-2]],[[2398,2049],[-5,-1],[-14,-26],[-6,15],[-1,31],[-3,-22],[-3,5],[-1,-27],[3,-11],[0,-36],[-5,-37],[-9,-47],[-17,-51],[-2,9],[-5,-13],[0,12],[-7,-9],[-3,24],[-2,-5],[7,-49],[-5,-16],[-5,10],[-1,-35],[-7,-35],[-6,-66],[-4,-69],[-3,5],[-1,-25],[3,6],[-2,-50],[-2,-2],[0,-28],[3,-16],[1,-57],[3,-20],[0,-37],[3,-32],[-9,-20],[-3,25],[-7,10],[-9,-3],[-8,32],[-5,3],[-5,25],[-6,8],[-4,24],[-2,58],[-5,34],[0,30],[-2,31],[1,27],[-4,30],[-3,4],[-5,27],[-1,34],[-5,32],[-6,26],[-3,57],[-2,16],[-4,46],[-1,38],[-4,27],[-6,24],[-1,16],[-6,15],[-4,42],[-13,9],[-7,-2],[-7,15],[-1,-20],[-7,-6],[-5,-40],[-3,-64],[-2,-1],[-4,-37],[-5,-1],[-7,29],[-17,47],[-4,25],[-6,24],[-5,54],[-1,49],[-4,40],[-2,35],[-3,22],[-11,32],[-6,44],[-4,15],[-6,38],[-7,20],[-5,50],[-4,11]],[[1908,4399],[0,-192],[57,0]],[[2981,4973],[30,-2],[23,2]],[[2927,3641],[-4,-32],[-3,-12],[-3,-44],[-6,-71],[-5,-15],[-1,27],[2,58],[8,74]],[[2874,3756],[-4,-8],[-2,-28],[1,-19],[8,6],[1,-31],[10,-12],[3,-24],[8,-26],[-4,-54],[4,-41],[-4,-20],[-1,-24],[4,-15],[-4,-23],[-6,30],[-1,-10],[5,-22],[14,-5],[3,-71]],[[2736,3547],[-1,-16],[4,-32],[5,-16],[4,1],[5,25],[4,-20],[7,11],[13,36],[1,-11],[5,17],[0,34],[4,30],[5,29],[2,34],[6,36],[2,44],[5,-27],[4,-8],[3,16],[6,68],[4,-17],[13,77],[2,57],[15,-64],[3,37]],[[1553,5212],[-5,7],[-4,-12],[-6,17],[1,26],[4,14],[-6,40],[-4,103],[-2,14],[-3,73],[-6,28],[-2,56],[3,38],[6,-18],[11,-24],[8,1],[8,-9],[8,9],[3,-16],[7,1],[5,-42],[3,3],[1,-56],[2,-52],[3,6],[-3,43],[1,43],[4,44],[-3,18],[-1,31],[-3,35],[2,25],[-2,29],[-5,4],[-4,22],[1,21],[163,0]],[[1576,5602],[4,9],[0,-39],[-5,15],[1,15]],[[1568,5655],[3,25],[4,-30],[-1,-27],[-7,8],[1,24]],[[2576,4989],[-1,-23],[-6,-4],[-4,-44],[-2,-30],[3,-6],[5,20],[4,38],[6,15],[5,48],[6,10],[-1,-25],[-4,-23],[-8,-79],[-2,-44],[0,-32],[-3,-10],[-2,-43],[1,-37],[-3,-24],[-3,-59],[0,-47],[4,-42],[-1,-55]],[[2450,5296],[6,-2],[20,33],[8,17],[2,-13],[-4,-25],[9,-33],[5,-3]]]};
  Datamap.prototype.usgTopo = '__USG__';
  Datamap.prototype.uzbTopo = '__UZB__';
  Datamap.prototype.vatTopo = '__VAT__';
  Datamap.prototype.vctTopo = '__VCT__';
  Datamap.prototype.venTopo = '__VEN__';
  Datamap.prototype.vgbTopo = '__VGB__';
  Datamap.prototype.virTopo = '__VIR__';
  Datamap.prototype.vnmTopo = '__VNM__';
  Datamap.prototype.vutTopo = '__VUT__';
  Datamap.prototype.wlfTopo = '__WLF__';
  Datamap.prototype.wsbTopo = '__WSB__';
  Datamap.prototype.wsmTopo = '__WSM__';
  Datamap.prototype.yemTopo = '__YEM__';
  Datamap.prototype.zafTopo = '__ZAF__';
  Datamap.prototype.zmbTopo = '__ZMB__';
  Datamap.prototype.zweTopo = '__ZWE__';

  /**************************************
                Utilities
  ***************************************/

  //convert lat/lng coords to X / Y coords
  Datamap.prototype.latLngToXY = function(lat, lng) {
     return this.projection([lng, lat]);
  };

  //add <g> layer to root SVG
  Datamap.prototype.addLayer = function( className, id, first ) {
    var layer;
    if ( first ) {
      layer = this.svg.insert('g', ':first-child')
    }
    else {
      layer = this.svg.append('g')
    }
    return layer.attr('id', id || '')
      .attr('class', className || '');
  };

  Datamap.prototype.updateChoropleth = function(data) {
    var svg = this.svg;
    for ( var subunit in data ) {
      if ( data.hasOwnProperty(subunit) ) {
        var color;
        var subunitData = data[subunit]
        if ( ! subunit ) {
          continue;
        }
        else if ( typeof subunitData === "string" ) {
          color = subunitData;
        }
        else if ( typeof subunitData.color === "string" ) {
          color = subunitData.color;
        }
        else if ( typeof subunitData.fillColor === "string" ) {
          color = subunitData.fillColor;
        }
        else {
          color = this.options.fills[ subunitData.fillKey ];
        }
        //if it's an object, overriding the previous data
        if ( subunitData === Object(subunitData) ) {
          this.options.data[subunit] = defaults(subunitData, this.options.data[subunit] || {});
          var geo = this.svg.select('.' + subunit).attr('data-info', JSON.stringify(this.options.data[subunit]));
        }
        svg
          .selectAll('.' + subunit)
          .transition()
            .style('fill', color);
      }
    }
  };

  Datamap.prototype.updatePopup = function (element, d, options) {
    var self = this;
    element.on('mousemove', null);
    element.on('mousemove', function() {
      var position = d3.mouse(self.options.element);
      d3.select(self.svg[0][0].parentNode).select('.datamaps-hoverover')
        .style('top', ( (position[1] + 30)) + "px")
        .html(function() {
          var data = JSON.parse(element.attr('data-info'));
          try {
            return options.popupTemplate(d, data);
          } catch (e) {
            return "";
          }
        })
        .style('left', ( position[0]) + "px");
    });

    d3.select(self.svg[0][0].parentNode).select('.datamaps-hoverover').style('display', 'block');
  };

  Datamap.prototype.addPlugin = function( name, pluginFn ) {
    var self = this;
    if ( typeof Datamap.prototype[name] === "undefined" ) {
      Datamap.prototype[name] = function(data, options, callback, createNewLayer) {
        var layer;
        if ( typeof createNewLayer === "undefined" ) {
          createNewLayer = false;
        }

        if ( typeof options === 'function' ) {
          callback = options;
          options = undefined;
        }

        options = defaults(options || {}, self.options[name + 'Config']);

        //add a single layer, reuse the old layer
        if ( !createNewLayer && this.options[name + 'Layer'] ) {
          layer = this.options[name + 'Layer'];
          options = options || this.options[name + 'Options'];
        }
        else {
          layer = this.addLayer(name);
          this.options[name + 'Layer'] = layer;
          this.options[name + 'Options'] = options;
        }
        pluginFn.apply(this, [layer, data, options]);
        if ( callback ) {
          callback(layer);
        }
      };
    }
  };

  // expose library
  if (typeof exports === 'object') {
    d3 = require('d3');
    topojson = require('topojson');
    module.exports = Datamap;
  }
  else if ( typeof define === "function" && define.amd ) {
    define( "datamaps", ["require", "d3", "topojson"], function(require) {
      d3 = require('d3');
      topojson = require('topojson');

      return Datamap;
    });
  }
  else {
    window.Datamap = window.Datamaps = Datamap;
  }

  if ( window.jQuery ) {
    window.jQuery.fn.datamaps = function(options, callback) {
      options = options || {};
      options.element = this[0];
      var datamap = new Datamap(options);
      if ( typeof callback === "function" ) {
        callback(datamap, options);
      }
      return this;
    };
  }
})();
