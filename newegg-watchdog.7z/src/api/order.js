var request = require("request");
var async = require("async");
var TIME_INIT_GAP = 60 * 1000 * 15;
var TIME_RECALL = 1000 * 30 * 60;


const ORDERS_API = "http://10.1.41.115/WebMonitor/blackfriday/getamount.aspx";
const STATE_ORDERS_API = "http://" 