var request = require("request");
var async = require("async");
var fs = require("fs");

var TIME_INIT_GAP = 60 * 1000 * 15;
var TIME_RECALL = 1000 * 60 * 30;


// The bigdata service host address
const REAL_TIME_HOST = "http://172.16.16.112:8087/watchdog/realtime";
const ITEM_AND_KEYWORD_API = "http://172.16.16.112:8087/watchdog/rangetime";
const ORDERS_HOST = "http://10.1.41.115/WebMonitor/blackfriday/getamount.aspx";
const STATE_ORDERS_HOST = "http://10.1.41.115/WebMonitor/blackfriday/getAmountGroupByState.aspx"
// const ITEM_AND_KEYWORD_API = "http://10.16.60.42:8088/watchdog/rangetime";
const ITEM_IMAGE_API = "http://172.16.24.137/api/item/base?InheritBase=true&CompanyCode=1003&CountryCode=USA&LanguageCode=en-US&ItemNumbers=";

const STATE_ORDERS_HOST_CA = "http://10.1.41.115/WebMonitor/blackfriday/CAN/getAmountGroupByState.aspx";
const ORDERS_HOST_CA = "http://10.1.41.115/WebMonitor/blackfriday/CAN/getAmount.aspx";

module.exports = function(app) {
    // get data from bigdata service (middleware)
    // Format: MM/DD/YYYY HH:MM:SS GMT+*
    app.get('/data/:startTime/:endTime', function(req, res, next) {

        // decodeURI Component
        var startTime = decodeURIComponent(req.params.startTime),
            endTime = decodeURIComponent(req.params.endTime);
        // global.YigaTimer  = Date.now(); 
        async.auto({
            get_real_time_api: function(callback) {
                request({
                    method: "POST",
                    url: REAL_TIME_HOST,
                    // Content-Type is required
                    headers: {
                        'Accept': 'application/json',
                        'Content-type': 'application/json'
                    },
                    body: JSON.stringify({
                        "start_time": startTime,
                        "end_time": endTime
                    })
                }, function(err, response, body) {
                    if (!err && response.statusCode < 400) {
                        try {
                            var source = JSON.parse(body).result;
                            callback(null, resultEntity(source || []));
                        }
                        catch (e) {

                        }
                    }
                });
            },
            get_item_and_keyword: function(callback) {
                request({
                    method: "POST",
                    url: ITEM_AND_KEYWORD_API,
                    // Content-Type is required
                    headers: {
                        'Accept': 'application/json',
                        'Content-type': 'application/json'
                    },
                    body: JSON.stringify({
                        // "start_time": "11/16/2016 10:40:14 GMT+8",
                        // "end_time": "11/16/2016 10:49:35 GMT+8"
                        "start_time": decodeURIComponent(timeFormater(Date.now() - TIME_INIT_GAP - TIME_RECALL)),
                        "end_time": decodeURIComponent(timeFormater(Date.now() - TIME_RECALL))
                    })
                }, function(err, response, body) {
                    if (!err && response.statusCode < 400) {
                        try {
                            var source = JSON.parse(body).result;
                            Object.keys(source).map(function(key) {
                                source[key] = source[key].map(function(obj, idx) {
                                    return Object.assign(obj, {
                                        values: obj.values.sort(function(a, b) { return a.x - b.x; }),
                                        // count: obj.
                                    });
                                });
                            });
                            callback(null, source);
                        }
                        catch (e) {
                            callback(null);
                        }
                    }
                });
            },
            get_item_image: ['get_item_and_keyword', function(results, callback) {
                if (results.get_item_and_keyword) {
                    var itemList = results.get_item_and_keyword.itemNumber;
                    var itemNumberList = itemList.map(function(item) { return item.keyword; });
                    request({
                        method: "GET",
                        url: ITEM_IMAGE_API + itemNumberList.join(","),
                        // Content-Type is required
                        headers: {
                            'Accept': 'application/json',
                            'Content-type': 'application/json',
                            'Authorization': 'Bearer Mk41kWzMchA0oSR7KIsFBu01EBLIpFtTzX7EJmNW'
                        },
                    }, function(err, response, body) {
                        if (!err && response.statusCode < 400) {
                            try {
                                var tmp = JSON.parse(body) || [];
                                var tmpItemList = tmp.map(function(item, idx) {
                                    var itemIndex = itemList.findIndex(function(a) { return a.keyword === item.Item; });
                                    var imagePathPattern = item.Image.ImagePathPattern.find(function(pathObj) {
                                        return pathObj.Size === 60;
                                    }), imageName = item.Image.Normal.ImageName;
                                    var imageSrc = imagePathPattern.PathPattern.replace(/\{ImageName\}/, imageName);
                                    return Object.assign({},
                                        itemList[itemIndex], {
                                            imageSrc: imageSrc,
                                            unitCost: item.UnitCost,
                                            instantRebateAmount: item.InstantRebateAmount
                                        });
                                });

                                callback(null, Object.assign({},
                                    results.get_item_and_keyword, {
                                        itemNumber: tmpItemList.sort(function(a, b) { return b.totalCount - a.totalCount; })
                                    }));
                            }
                            catch (e) {
                                callback(null, results.get_item_and_keyword);
                            }
                        } else {
                            callback(null, results.get_item_and_keyword);
                        }
                    });
                } else {
                    callback(null, results.get_item_and_keyword);
                }

            }],
            get_orders_api: function(callback) {
                request({
                    method: "GET",
                    url: ORDERS_HOST,
                    // Content-Type is required
                    headers: {
                        'Accept': 'application/json',
                        'Content-type': 'application/json'
                    },
                }, function(err, response, body) {
                    if (!err && response.statusCode < 400) {
                        try {
                            callback(null, JSON.parse(body) || []);
                        }
                        catch (e) {
                            callback(null);
                        }
                    }
                });
            }
        }, function(err, results) {
            var result = Object.assign({}, results.get_real_time_api, results.get_item_image, { orders: results.get_orders_api });
            res.send(result);
            // console.error((Date.now() - global.YigaTimer)/1000);
        });
    });

    app.get('/header/', function(req, res, next) {
        var fileName = "./dist/logo-info.json";
        fs.readFile(fileName, function(err, data) {
            if (!err) {
                res.send(JSON.parse(data));
            } else {
                res.send({});
            }
        })
    });


    app.get('/USA/ssl/orders', function(req, res, next) {
        var US_TIME_GAP = 1000 * 3600 * 16,
            startTime = decodeURIComponent(req.params.startTime),
            endTime = decodeURIComponent(req.params.endTime);

        async.auto({
            get_orders_api: function(callback) {
                request({
                    method: "GET",
                    url: ORDERS_HOST,
                    // Content-Type is required
                    headers: {
                        'Accept': 'application/json',
                        'Content-type': 'application/json'
                    }
                }, function(err, response, body) {
                    if (!err && response.statusCode < 400) {
                        try {
                            callback(null, { orders: JSON.parse(body) || [] });
                        } catch (e) {
                            callback(null);
                        }
                    }
                });
            },
            get_state_order_api: function(callback) {
                request({
                    method: "GET",
                    url: STATE_ORDERS_HOST,
                    headers: {
                        'Accept': 'application/json',
                        'Content-type': 'application/json'
                    }
                }, function(err, response, body) {
                    if (!err && response.statusCode < 400) {
                        try {
                            callback(null, { map: JSON.parse(body) || [] });
                        } catch (e) {
                            callback(null);
                        }
                    } else {
                        callback(null)
                    }
                });
            }
        }, function(err, results) {
            var result = Object.assign({}, results.get_orders_api, results.get_state_order_api);
            res.send(result);
        });
    });

    app.get('/CAN/ssl/orders', function(req, res, next) {

        async.auto({
            get_orders_api: function(callback) {
                request({
                    method: "GET",
                    url: ORDERS_HOST_CA,
                    // Content-Type is required
                    headers: {
                        'Accept': 'application/json',
                        'Content-type': 'application/json'
                    }
                }, function(err, response, body) {
                    if (!err && response.statusCode < 400) {
                        try {
                            callback(null, { orders: JSON.parse(body) || [] });
                        } catch (e) {
                            callback(null);
                        }
                    }
                });
            },
            get_state_order_api: function(callback) {
                request({
                    method: "GET",
                    url: STATE_ORDERS_HOST_CA,
                    headers: {
                        'Accept': 'application/json',
                        'Content-type': 'application/json'
                    }
                }, function(err, response, body) {
                    if (!err && response.statusCode < 400) {
                        try {
                            callback(null, { map: JSON.parse(body) || [] });
                        } catch (e) {
                            callback(null);
                        }
                    } else {
                        callback(null)
                    }
                });
            }
        }, function(err, results) {
            var result = Object.assign({}, results.get_orders_api, results.get_state_order_api);
            res.send(result);
        });
    });

};





function resultEntity(raw) {
    var result = {}, key;
    // sort by timespan
    raw.map(function(data, idx) {
        var timespan = new Date(data.timespan).valueOf();
        for (key in data) {
            if (key !== "timespan") {
                if (result[key] instanceof Array) {
                    result[key].push({
                        timespan: timespan,
                        data: data[key]
                    });
                } else {
                    result[key] = [
                        {
                            timespan: timespan,
                            data: data[key]
                        }
                    ];
                }
            }
        }
    });
    for (key in result) {
        result[key].sort(function(a, b) {
            return Date(a.timespan) - Date(b.timespan);
        });
    }
    return result;
}




function timeFormater(timespan) {
    var t = new Date(timespan);
    return encodeURIComponent(t.toLocaleTimeString("en-US", { timeZoneName: "short", hour12: false, year: "numeric", month: "numeric", day: "numeric" }).replace(/\,/, ""));
}