import React from 'react';

import Datamap from './datamap';
import Column from './column';

class StateLegend extends React.Component {
    componentWillUpdate() {
        $('.datamaps-legend').transition('jiggle');
    }

    render() {
        let states = this.props.states,
            showStates = states.map(function (state) {
                return (<div className="item" key={state.keyword}>{`${state.keyword} : ${state.totalCount}`}</div>);
            }),
            style = {

            }
        return (
            <div className="datamaps-legend">
                <div className="ui list">
                    {showStates}
                </div>
            </div>
        );
    }
};


export default class StateMap extends React.Component {

    render() {
        let styles = {
            height: '500px',
            width: '100%',
            position: 'relative'
        };
        const rstate = /[A-Z]{2}/;
        let viewModal = {};
        this.props.data.map((obj, idx, ary) => {
            let tmpLevel = 'level'
            if (obj.totalCount > 2000) {
                tmpLevel += '6';
            } else if (obj.totalCount > 1500) {
                tmpLevel += '5';
            } else if (obj.totalCount > 1000) {
                tmpLevel += '4';
            } else if (obj.totalCount > 500) {
                tmpLevel += '3';
            } else if (obj.totalCount > 200) {
                tmpLevel += '2';
            } else {
                tmpLevel += '1';
            }
            if (rstate.test(obj.keyword)) {
                viewModal[obj.keyword] = {
                    fillKey: tmpLevel
                };
            }
        });

        let top3 = this.props.data.slice(0, 3);

        return (
            <Column label="Activeness" titleClass={`${this.props.titleClass}`} extraClass={this.props.size ? `${this.props.size} ` : ""}>
                <div style={styles}>
                    <StateLegend states={top3} />
                    <Datamap
                        scope="usa"
                        projection = "mercator"
                        geographyConfig={{
                            highlightBorderColor: '#000000',
                            highlightBorderWidth: 1,
                            borderColor: '#333333',
                            highlightFillColor: '#b10026',
                            popupOnHover: false
                        }}
                        fills={{
                            'level1': '#ffeda0',
                            'level2': '#fed976',
                            'level3': '#feb24c',
                            'level4': '#fd8d3c',
                            'level5': '#fc4e2a',
                            'level6': '#e31a1c',
                            'defaultFill': '#ffffcc'
                        }}
                        data={viewModal} 
                        labels
                    />
                </div>
            </Column>
        );
    }

}
