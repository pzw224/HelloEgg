import React from 'react';

import Datamap from './datamap';
import Column from './column';
import {transition} from '../utils/';


class StateLegend extends React.Component {
    componentDidUpdate() {
        transition('.datamaps-legend', 'jiggle');
    }

    render() {
        let states = this.props.states,
            showStates = states.map(function (state, idx) {
                let color;
                switch (idx) {
                    case 0: color = 'red'; break;
                    case 1: color = 'orange'; break;
                    case 2: color = 'olive'; break;
                    default: color = 'green'

                }
                return (
                    <div className={`item ui inverted statistic mini ${color}`} style={{ margin: '0 0 0 0' }} key={idx}>
                        <span className="value">{state.keyword}: </span>
                        <span className="label">{state.totalCount}</span>
                    </div>
                );

            }),
            style = {

            }
        return (
            <div className="datamaps-legend">
                <div className="ui list">
                    {showStates}
                </div>
            </div>
        );
    }
};

class Legend extends React.Component {


    render() {

        let styles = {
            borderLeftWidth: '15px',
            borderLeftStyle: 'solid',
            fontSize: '.75em',
            width: '100px',
            paddingLeft: '2px'
        }

        return (

            <div className="datamaps-legend" style={{ top: '0', left: '5px', zIndex: 1 }}>
                <ul className="list-inline" style={{ listStyle: 'none' }}>
                    <li className="key" style={ Object.assign({}, styles, { borderLeftColor: '#ffffcc' }) }>0-200</li>
                    <li className="key" style={ Object.assign({}, styles, { borderLeftColor: '#FFEDA0' }) }>200-500</li>
                    <li className="key" style={ Object.assign({}, styles, { borderLeftColor: '#FED976' }) }>500-1000</li >
                    <li className="key" style={ Object.assign({}, styles, { borderLeftColor: '#FEB24C' }) }>1000-2000</li>
                    <li className="key" style={ Object.assign({}, styles, { borderLeftColor: '#FD8D3C' }) }>2000-5000</li>
                    <li className="key" style={ Object.assign({}, styles, { borderLeftColor: '#FC4E2A' }) }>5000-10000</li>
                    <li className="key" style={ Object.assign({}, styles, { borderLeftColor: '#E31A1C' }) }>10000-20000</li>
                    <li className="key" style={ Object.assign({}, styles, { borderLeftColor: '#BD0026' }) }>20000-40000</li>
                    <li className="key" style={ Object.assign({}, styles, { borderLeftColor: '#800026' }) }>40000+</li>
                </ul >
            </div >
        )

    }
}


export default class StateMap extends React.Component {
    componentWillUpdate() {
        jQuery('.labels text').remove();
    }

    componentDidUpdate() {
        jQuery('.labels line').remove();
    }

    componentDidMount() {
        jQuery('.labels line').remove();
    }

    render() {
        let styles = {
            height: '650px',
            width: '100%',
            position: 'relative'
        };
        const rstate = /[A-Z]{2}/;
        let viewModal = {};
        console.log(this.props.data);
        this.props.data.map((obj, idx, ary) => {
            let tmpLevel = 'level'
            if (obj.totalCount > 40000) {
                tmpLevel += '8';
            }
            if (obj.totalCount > 20000) {
                tmpLevel += '7';
            }
            else if (obj.totalCount > 10000) {
                tmpLevel += '6';
            } else if (obj.totalCount > 5000) {
                tmpLevel += '5';
            } else if (obj.totalCount > 2000) {
                tmpLevel += '4';
            } else if (obj.totalCount > 1000) {
                tmpLevel += '3';
            } else if (obj.totalCount > 500) {
                tmpLevel += '2';
            } else {
                tmpLevel += '1';
            }
            if (rstate.test(obj.keyword)) {
                viewModal[obj.keyword] = {
                    fillKey: tmpLevel
                };
            }
        });

        let top3 = this.props.data.slice(0, 3);

        return (
            <div style={styles}>
                <Legend />
                <Datamap
                    scope="usa"
                    projection = "mercator"
                    geographyConfig={{
                        highlightBorderColor: '#000000',
                        highlightBorderWidth: 1,
                        borderColor: '#333333',
                        highlightFillColor: '#b10026',
                        popupOnHover: false
                    }}
                    fills={{
                        'level1': '#ffeda0',
                        'level2': '#fed976',
                        'level3': '#feb24c',
                        'level4': '#fd8d3c',
                        'level5': '#fc4e2a',
                        'level6': '#e31a1c',
                        'level7': '#bd0026',
                        'level8': '#800026',
                        'defaultFill': '#ffffcc'
                    }}
                    data={viewModal}
                    
                    labels
                    />
            </div>
        );
    }

}
