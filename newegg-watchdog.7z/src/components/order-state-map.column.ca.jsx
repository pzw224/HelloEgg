import React from 'react';

import Datamap from './datamap';
import Column from './column';
import { transition, formatMoney } from '../utils/';
import kMeans from 'kmeans-js';
import Count from 'countup.js';

class Legend extends React.Component {
    render() {

        let styles = {
            borderLeftWidth: '15px',
            borderLeftStyle: 'solid',
            fontSize: '1.25em',
            textAlign: 'left',
            display: 'block',
            paddingLeft: '5px',
            color: '#ccc',
            fontFamily: "Lato,'Helvetica Neue',Arial,Helvetica,sans-serif"
        }

        return (
            <div className="datamaps-legend" style={{ top: '30px', left: '0px', zIndex: 1 }}>
                <ul className="list-inline" style={{ listStyle: 'none' }}>
                    <li className="key" style={Object.assign({}, styles, { borderLeftColor: '#800026' })}>$2,000K+</li>
                    <li className="key" style={Object.assign({}, styles, { borderLeftColor: '#BD0026' })}>$1,000K - $2,000K</li>
                    <li className="key" style={Object.assign({}, styles, { borderLeftColor: '#e31a1c' })}>$700K - $1,000k</li>
                    <li className="key" style={Object.assign({}, styles, { borderLeftColor: '#fc4e2a' })}>$400K - $700K</li>
                    <li className="key" style={Object.assign({}, styles, { borderLeftColor: '#fd8d3c' })}>$400K - $700K</li>
                    <li className="key" style={Object.assign({}, styles, { borderLeftColor: '#feb24c' })}>$200K - $100K</li >
                    <li className="key" style={Object.assign({}, styles, { borderLeftColor: '#fed976' })}>$50K - $100k</li>
                    <li className="key" style={Object.assign({}, styles, { borderLeftColor: '#ffeda0' })}>$20K - $50K</li>
                    <li className="key" style={Object.assign({}, styles, { borderLeftColor: '#ffffcc' })}>$0 - $20K</li>
                </ul >
            </div >
        )

    }
}



export default class OrderStateMapCA extends React.Component {

    setProjection(element, options) {
        var s = 800.7143892268033;
        var t = [100, 0];
        var c = [-96.64103816680374, 60.538257532457976];
        var rotation = [96.64103816680374, 0];
        var bounds = [
            [-141.00285937700158, 41.9714969544088],
            [-52.54374615218809, 83.1480859363606]
        ];
        var projection = d3.geo.conicEqualArea()
            .scale(1)
            .translate([0, 0]);
        var path = d3.geo.path().projection(projection);
        projection.center(c)
            .parallels([bounds[0][1], bounds[1][1]])
            .rotate(rotation);
        projection.scale(s).translate(t);
        return {
            path: path,
            projection: projection
        };
    }

    render() {
        let styles = {
            height: '650px',
            width: '100%',
            position: 'relative'
        };
        const rstate = /[A-Z]{2}/;

        let popupTemplate = function(geography, data) {
            var money = formatMoney(parseInt(data.orderAmount));
            return `<div class="hoverinfo" style="color:black">${geography.properties.name}  ${money}|<i class="shipping icon"></i>${data.orderCount}`;
        }

        var orderObject = this.props.data,
            tmp = {};

        let vector = [], stateData = {};

        if (orderObject && Object.keys(orderObject).length > 0) {
            Object.keys(orderObject).map((key) => {
                var expectColor = mapDepthColorHelper(orderObject[key].orderAmount);
                if (expectColor) {
                    orderObject[key].fillKey = expectColor;
                }
            });
        }

        let fontStyle = {
            position: 'absolute',
            color: '#e9462f',
            fontSize: '5em',
            left: '193px',
            top: '486px',
        };
        return (
            <div style={styles}>
                <Legend />
                <Datamap
                    scope="can"
                    geographyConfig={{
                        highlightBorderColor: '#000000',
                        highlightBorderWidth: 1,
                        borderColor: '#333333',
                        highlightFillColor: '#b10026',
                        highlightOnHover: false,
                        popupOnHover: true,
                        popupTemplate: popupTemplate,
                    }}
                    setProjection={this.setProjection}
                    fills={{
                        'level1': '#ffeda0',
                        'level2': '#fed976',
                        'level3': '#feb24c',
                        'level4': '#fd8d3c',
                        'level5': '#fc4e2a',
                        'level6': '#e31a1c',
                        'level7': '#bd0026',
                        'level8': '#800026',
                        'defaultFill': '#ffffcc'
                    }}
                    data={orderObject}

                    labels={{
                        labelColor: '#1B1C1D'
                    }}
                    />
            </div>
        );
    }
}


function mapDepthColorHelper(v) {
    let level;
    if (v >= 2000000) {
        level = 8;
    } else if (v >= 1000000) {
        level = 7;
    } else if (v >= 700000) {
        level = 6;
    } else if (v >= 400000) {
        level = 5;
    } else if (v >= 200000) {
        level = 4;
    } else if (v >= 100000) {
        level = 3;
    } else if (v >= 50000) {
        level = 2;
    } else if (v >= 20000) {
        level = 1;
    } else {
        return "defaultFill";
    }

    return `level${level}`;

}