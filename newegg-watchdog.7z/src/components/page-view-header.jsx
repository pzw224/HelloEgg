import React from 'react';

export default class PageViewHeader extends React.Component
{
    render() {
        let props = this.props;
        return (
            <h1 className="ui inverted header" style={{position:'relative'}}>
                <img src="./images/Black-Friday-2016.gif" style={{ width: 'auto', height: '160px',verticalAlign: 'bottom',
    display: 'inline-block' }} />
                <iframe src="iframe/ball.html" className="frame" />
            </h1 >
        )
    }
}