import React from 'react';

export default class PageViewHeader extends React.Component {
    render() {
        let logo = require('../images/Black-Friday-2016.a.gif');
        let props = this.props;
        let logoTitle = "BLACK FRIDAY";
        try {
            if (props.header) {
                for (let o in props.header.timeSpan) {
                    let startTime = new Date(props.header.timeSpan[o].startTime).valueOf();
                    let endTime = new Date(props.header.timeSpan[o].endTime).valueOf();
                    let now = Date.now();
                    if (now > startTime && now < endTime) {
                        logoTitle = props.header.timeSpan[o].pageTitle;
                    }
                }
            }
        } catch (e) { }
        let firstFont = logoTitle, secondFont = "";
        const logoTitleArr = logoTitle.split(' '), fontSize = logoTitle.length - 1 > 10 ? { fontSize: '26px' } : { fontSize: '30px' };

        if (logoTitleArr.length > 1) {
            firstFont = logoTitleArr[0];
            secondFont = logoTitleArr[1];
        }
        return (
            <h1 className="ui inverted header" style={{ position: 'relative' }}>
                <span className="logo-style" style={fontSize}><strong>{firstFont}</strong> <strong>{secondFont}</strong></span>
                <img src={logo} style={{
                    width: 'auto', height: '160px', verticalAlign: 'bottom',
                    display: 'inline-block'
                }} />
                <iframe src="iframe/ball.html" className="frame" />
            </h1 >
        )
    }
}