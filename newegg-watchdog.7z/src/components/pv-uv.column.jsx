import React from 'react';
import Column from './column';
import {AreaChart} from './line.d3';
import { getMin, getMax } from '../utils';


export default class PvUv extends React.Component {
    render() {
        
        let data = this.props.data,
            pv = data.find(a => { return a.keyword == "pv"; }),
            uv = data.find(a => { return a.keyword == "uv"; });
        pv = pv ? pv.values : [];
        uv = uv ? uv.values : [];
        let yMax = Math.max(getMax(pv, "y"), getMax(uv, "y")),
            yMin = Math.min(getMin(pv, "y"), getMin(uv, "y")),
            yGap = Math.abs(yMax - yMin);

        return (
            <Column label="PV-UV" titleClass={`${this.props.titleClass}`} extraClass={this.props.size ? `${this.props.size} ` : ""}>
                <svg width="300" height="300">
                    <g>
                        <AreaChart width={300} height={300} points={pv} fill="yellow" yMax={yMax} yMin={yMin} yGap={yGap} />
                        <AreaChart width={300} height={300} points={uv} fill="blue" yMax={yMax} yMin={yMin} yGap={yGap} />
                    </g>
                </svg>
            </Column>
        )
    }
}