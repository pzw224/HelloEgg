import React from 'react';
import Column from './column';
import {AreaChart} from './line.d3';
import { getMin, getMax, dataZipper } from '../utils/';
import '../styles/d3.css';
import * as d3 from 'd3';

export default class PvUv extends React.Component {
    constructor() {
        super(arguments)
        this.yMaxGroup = [];
        this.yAvg = 0;
        this.maxVariance = 0;
        this.yMaxCount = 0;
    }

    pushYMax(value) {
        var variance, outValue;
        if (this.yMaxCount > 10) {
            this.yMaxGroup = [];
            this.yAvg = 0;
            this.maxVariance = 0;
            this.yMaxCount = 0;
        }
        if (typeof value === "number" && !isNaN(value)) {
            variance = Math.abs(this.yAvg - value);
            if (this.yMaxGroup.length < 5) {
                this.yMaxGroup.push(value);
                this.yAvg = (this.yAvg + value) / 2;
                if (variance > this.maxVariance) {
                    this.maxVariance = variance;
                }
            } else if (variance < this.maxVariance) {
                this.maxVariance = this.yMaxGroup.sort((a, b) => {
                    var aVar = Math.abs(a - this.yAvg),
                        bVar = Math.abs(b - this.yAvg);
                    return bVar - aVar;
                });

                outValue = this.yMaxGroup.unshift();
                this.yMaxGroup.push(value);
                this.yAvg = (this.yAvg * 3 - outValue + value) / 3;
                this.maxVariance = Math.abs(this.yMaxGroup[0] - this.yAvg);
                variance = Math.abs(value - this.yAvg);
                if (this.maxVariance > variance) {
                    this.maxVariance = this.maxVariance > variance ? this.maxVariance : variance;
                } else {
                    this.maxVariance = variance;
                    this.yMaxCount++;
                }
            }
        }
    }

    getMaxY() {
        if (this.yMaxGroup.length > 0) {
            return this.yMaxGroup.sort((a, b) => { return b - a; })[0];
        }
        return 0;
    }

    componentDidUpdate() {
        d3.select(this.refs.yAxis).call(this.yAxis);
    }

    componentDidMount() {
        d3.select(this.refs.yAxis).call(this.yAxis).append("text")
            .attr("transform", "rotate(-90)")
            .attr("y", 6)
            .attr("dy", ".71em")
            .style("text-anchor", "end")
            .text("PV/UV");
    }

    render() {

        let data = this.props.data,
            pv = data.find(a => { return a.keyword == "pv"; }),
            uv = data.find(a => { return a.keyword == "uv"; });
        pv = pv ? pv.values : [];
        uv = uv ? uv.values : [];
        pv = dataZipper(pv, 400, true);
        uv = dataZipper(uv, 400, true);

        let yMax = Math.max(getMax(pv, "y"), getMax(uv, "y")),
            yMin = Math.min(getMin(pv, "y"), getMin(uv, "y")),
            yGap = Math.abs(yMax - yMin);


        this.pushYMax(yMax);
        // yMax = this.getMaxY();

        let y = d3.scale.linear().range([230, 0]);
        this.yAxis = d3.svg.axis()
            .scale(y)
            .orient("left");

        y.domain([0, yMax]);

        return (
            <Column label="PV/UV Area Chart" titleClass={`${this.props.titleClass}`} extraClass={this.props.size ? `${this.props.size} ` : ""}>
                <svg width="1100" height="230" style={{ overflow: 'visible' }}>
                    <g>
                        <AreaChart width={1100} height={230} points={pv} fill="#ffeda0" stroke="none" yMax={yMax} yMin={yMin} yGap={yGap} />
                        <AreaChart width={1100} height={230} points={uv} fill="#fd8d3c" stroke="none" yMax={yMax} yMin={yMin} yGap={yGap} />
                        <g className="y axis" ref="yAxis">
                        </g>
                    </g>
                </svg>
            </Column>
        )
    }
}