import React from 'react';

import Datamap from './datamap';
import Column from './column';
import { transition, formatMoney } from '../utils/';
import kMeans from 'kmeans-js';

class Legend extends React.Component {


    render() {

        let styles = {
            borderLeftWidth: '15px',
            borderLeftStyle: 'solid',
            fontSize: '.75em',
            width: '100px',
            paddingLeft: '2px'
        }

        return (

            <div className="datamaps-legend" style={{ top: '0', left: '5px', zIndex: 1 }}>
                <ul className="list-inline" style={{ listStyle: 'none' }}>
                    <li className="key" style={Object.assign({}, styles, { borderLeftColor: '#ffffcc' })}>$0+</li>
                    <li className="key" style={Object.assign({}, styles, { borderLeftColor: '#FFEDA0' })}>$100,000+</li>
                    <li className="key" style={Object.assign({}, styles, { borderLeftColor: '#FED976' })}>$200,000+</li >
                    <li className="key" style={Object.assign({}, styles, { borderLeftColor: '#FEB24C' })}>$500,000+</li>
                    <li className="key" style={Object.assign({}, styles, { borderLeftColor: '#FD8D3C' })}>$1,000,000+</li>
                    <li className="key" style={Object.assign({}, styles, { borderLeftColor: '#FC4E2A' })}>$2,000,000+</li>
                    <li className="key" style={Object.assign({}, styles, { borderLeftColor: '#E31A1C' })}>$5,000,000+</li>
                    <li className="key" style={Object.assign({}, styles, { borderLeftColor: '#BD0026' })}>$1,000,000+</li>
                    <li className="key" style={Object.assign({}, styles, { borderLeftColor: '#800026' })}>$100,000+</li>
                </ul >
            </div >
        )

    }
}



export default class OrderStateMap extends React.Component {

    constructor() {
        super(arguments)
        this.updateCount = -1;
    }

    componentWillUpdate() {
        jQuery('.labels text').remove();
    }

    componentDidUpdate() {
        jQuery('.labels line').remove();
    }

    componentDidMount() {
        jQuery('.labels line').remove();
    }

    shouldComponentUpdate() {
        this.updateCount++;
        if (this.updateCount % 10 === 0) {
            return true;
        }
        return false;
    }

    render() {
        let styles = {
            height: '650px',
            width: '100%',
            position: 'relative'
        };
        const rstate = /[A-Z]{2}/;

        let popupTemplate = function (geography, data) {
            var money = formatMoney(parseInt(data.orderAmount));
            return `<div class="hoverinfo" style="color:black">${geography.properties.name}  ${money}|<i class="shipping icon"></i>${data.orderCount}`;
        }

        var orderObject = this.props.data,
            tmp = {};

        let vector = [], tmpList = [], stateData = {};

        if (orderObject && Object.keys(orderObject).length > 0) {
            Object.keys(orderObject).map((key) => {
                tmpList.push(Object.assign({}, orderObject[key], { state: key }));
                vector.push(
                    [parseInt(orderObject[key].orderAmount)
                        // , parseInt(orderObject[key].orderCount)
                    ]);
            });
        }

        if (vector.length > 0) {
            var km = new kMeans({
                K: 8
            });


            km.cluster(vector);

            while (km.step()) {
                km.findClosestCentroids();
                km.moveCentroids();

                if (km.hasConverged()) break;
            }


            let groupResult = km.clusters.sort((a, b) => {
                if (a.length == 0 || b.length == 0) {
                    return 1;
                } else {
                    return tmpList[b[0]].orderAmount - tmpList[a[0]].orderAmount;
                }
            });


            let level = 9;

            for (let i = 0; i < groupResult.length; i++) {
                let str = "";
                for (let j = 0; j < groupResult.length; j++) {
                    //groupResult[i][j] = tmpList[groupResult[i][j]].orderAmount;

                    let a = tmpList[groupResult[i][j]];
                    if (a) {
                        str += tmpList[groupResult[i][j]].state + ":";
                        str += tmpList[groupResult[i][j]].orderAmount;
                        str += ",";
                    }

                }
            }

            for (let j = 0; j < groupResult.length; j++) {
                if (groupResult[j].length > 0) {
                    level--;
                }
                groupResult[j].map((_idx) => {
                    let _t = tmpList[_idx];
                    stateData[_t.state] = Object.assign({}, _t, { fillKey: `level${level}` });
                });
            }

        }


        return (
            <div style={styles}>

                <Datamap
                    scope="usa"
                    projection="mercator"
                    geographyConfig={{
                        highlightBorderColor: '#000000',
                        highlightBorderWidth: 1,
                        borderColor: '#333333',
                        highlightFillColor: '#b10026',
                        highlightOnHover: false,
                        popupOnHover: true,
                        popupTemplate: popupTemplate
                    }}
                    fills={{
                        'level1': '#ffeda0',
                        'level2': '#fed976',
                        'level3': '#feb24c',
                        'level4': '#fd8d3c',
                        'level5': '#fc4e2a',
                        'level6': '#e31a1c',
                        'level7': '#bd0026',
                        'level8': '#800026',
                        'defaultFill': '#ffffcc'
                    }}
                    data={stateData}

                    labels={{
                        labelColor: '#1B1C1D'
                    }}
                    />
            </div>
        );
    }
}

function mapColorFiller(inputVal, totalVal) {
    let level = 'level',
        value = parseInt(inputVal),
        total = parseInt(totalVal),
        rate = Math.round(inputVal / total * 100);
    if (rate > 10000000) {
        level += '8';
    }
    else if (value > 5000000) {
        level += '7';
    }
    else if (value > 2000000) {
        level += '6';
    } else if (value > 1000000) {
        level += '5';
    } else if (value > 500000) {
        level += '4';
    } else if (value > 200000) {
        level += '3';
    } else if (value > 100000) {
        level += '2';
    } else {
        level += '1';
    }
    return level;
}
