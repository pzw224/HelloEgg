import React from 'react';

import Datamap from './datamap';
import Column from './column';
import { transition, formatMoney } from '../utils/';
import kMeans from 'kmeans-js';
import Count from 'countup.js';

class Legend extends React.Component {
    render() {

        let styles = {
            borderLeftWidth: '15px',
            borderLeftStyle: 'solid',
            fontSize: '1.25em',
            textAlign: 'left',
            display: 'block',
            paddingLeft: '5px',
            color: '#ccc',
            fontFamily: "Lato,'Helvetica Neue',Arial,Helvetica,sans-serif"
        }

        return (
            <div className="datamaps-legend" style={{ top: '30px', left: '0px', zIndex: 1 }}>
                <ul className="list-inline" style={{ listStyle: 'none' }}>
                    <li className="key" style={Object.assign({}, styles, { borderLeftColor: '#800026' })}>$5,000K+</li>
                    <li className="key" style={Object.assign({}, styles, { borderLeftColor: '#BD0026' })}>$2,000K - $5,000K</li>
                    <li className="key" style={Object.assign({}, styles, { borderLeftColor: '#e31a1c' })}>$1,000K - $2,000k</li>
                    <li className="key" style={Object.assign({}, styles, { borderLeftColor: '#fc4e2a' })}>$500K - $1,000K</li>
                    <li className="key" style={Object.assign({}, styles, { borderLeftColor: '#fd8d3c' })}>$250K - $500K</li>
                    <li className="key" style={Object.assign({}, styles, { borderLeftColor: '#feb24c' })}>$125K - $250K</li >
                    <li className="key" style={Object.assign({}, styles, { borderLeftColor: '#fed976' })}>$60K - $125k</li>
                    <li className="key" style={Object.assign({}, styles, { borderLeftColor: '#ffeda0' })}>$30K - $60K</li>
                    <li className="key" style={Object.assign({}, styles, { borderLeftColor: '#ffffcc' })}>$0 - $30K</li>
                </ul >
            </div >
        )

    }
}

export default class OrderStateMap extends React.Component {

    render() {
        let styles = {
            height: '650px',
            width: '100%',
            position: 'relative'
        };

        let popupTemplate = function (geography, data) {
            var money = formatMoney(parseInt(data.orderAmount));
            return `<div class="hoverinfo" style="color:black">${geography.properties.name}  ${money}|<i class="shipping icon"></i>${data.orderCount}`;
        }

        var orderObject = this.props.data,
            tmp = {};

        let vector = [], stateData = {};
        if (orderObject && Object.keys(orderObject).length > 0) {
            Object.keys(orderObject).map((key) => {
                var expectColor = mapDepthColorHelper(orderObject[key].orderAmount);
                if (expectColor) {
                    orderObject[key].fillKey = expectColor;
                }
            });
        }



        return (
            <div style={styles}>
                <Legend />
                <Datamap
                    scope="usa"
                    projection="mercator"
                    geographyConfig={{
                        highlightBorderColor: '#000000',
                        highlightBorderWidth: 1,
                        borderColor: '#333333',
                        highlightFillColor: '#b10026',
                        highlightOnHover: false,
                        popupOnHover: true,
                        popupTemplate: popupTemplate
                    }}
                    fills={{
                        'level1': '#ffeda0',
                        'level2': '#fed976',
                        'level3': '#feb24c',
                        'level4': '#fd8d3c',
                        'level5': '#fc4e2a',
                        'level6': '#e31a1c',
                        'level7': '#bd0026',
                        'level8': '#800026',
                        'defaultFill': '#ffffcc'
                    }}
                    data={orderObject}

                    labels={{
                        labelColor: '#1B1C1D'
                    }}
                    />
            </div>
        );
    }
}


function mapDepthColorHelper(v) {
    let level;
    if (v >= 5000000) {
        level = 8;
    } else if (v >= 2000000) {
        level = 7;
    } else if (v >= 1000000) {
        level = 6;
    } else if (v >= 500000) {
        level = 5;
    } else if (v >= 250000) {
        level = 4;
    } else if (v >= 125000) {
        level = 3;
    } else if (v >= 60000) {
        level = 2;
    } else if (v >= 30000) {
        level = 1;
    } else {
        return "defaultFill";
    }

    return `level${level}`;

}