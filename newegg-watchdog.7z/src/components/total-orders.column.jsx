require("../styles/total-order.css");

import React from 'react';
import Count from  'countup.js';

export default class TotalOrders extends React.Component {
    componentDidUpdate(prevProps, prevState) {
        let currentOrderCount = parseInt(this.props.data.orderCount),
            prevOrderCount = parseInt(prevProps.data.orderCount);

        var easingFn = function (t, b, c, d) {
            var ts = (t /= d) * t;
            var tc = ts * t;
            return b + c * (tc + -3 * ts + 3 * t);
        }
        const totalPrice = new Count(this.refs.totalOrder, prevOrderCount, currentOrderCount, 0, 4,
            {
                useEasing: true,
                easingFn: easingFn,
                useGrouping: true,
                separator: ',',
                decimal: '.',
                prefix: '',
                suffix: ''
            });
        totalPrice.start();
    }

    render() {
        let orderCount = parseInt(this.props.data.orderCount);

        return (
            <div className="ui huge inverted statistic">
                <div className="value" style={{ fontSize: "135px!important" }}>
                    <i className="shipping icon"></i>
                    <span ref="totalOrder"></span>
                </div>
                <div className="label">TOTAL ORDERS</div>
            </div>
        )
    }
}