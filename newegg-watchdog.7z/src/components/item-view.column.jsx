import React from 'react';

import Column from './column';
import { LineChart } from './line.d3';
import { formatMoney } from '../utils'

class ItemViewCell extends React.Component {
    render() {

        return (
            <tr>
                <td>
                    <h4 className="ui image header" >
                        <img className="ui mini rouded image" src={this.props.imageSrc} style={{ borderRadius: "5px" }} />
                        <div className="content" style={{ color: "rgba(255,255,255,.9)" }}>
                            <a style={{color:'#fff'}} target="_blank" href={`http://www.newegg.com/Product/Product.aspx?Item=${this.props.itemNumber}&Tpk=${this.props.itemNumber}`}>{this.props.itemNumber}</a>
                        </div>
                    </h4>
                </td>
                <td>
                    <LineChart points={this.props.points} width="160" height="30" stroke="black" />
                </td>
                <td className="center aligned">{this.props.count}</td>
                <td className="center aligned">
                    {`${formatMoney(this.props.finalPrice)}`}
                    {this.props.percent == 0 ? ("") : (<span style={{ color: 'rgba(251, 189, 8, 0.95)' }}>{`( %${this.props.percent} )`}</span>)}

                </td>
            </tr>
        )
    }
}

export default class ItemView extends React.Component {
    render() {

        let data = this.props.data,
            list = data.slice(0, 5).map(function (item, idx) {
                return (
                    <ItemViewCell
                        key={idx}
                        itemNumber={item.keyword}
                        count={item.totalCount}
                        points={item.values}
                        imageSrc={item.imageSrc}
                        unitCost={item.unitCost}
                        finalPrice={item.unitCost - item.instantRebateAmount}
                        percent={(item.instantRebateAmount / item.unitCost * 100).toFixed(0)}
                        />
                )
            })
        return (
            <Column label="Item Detail View" titleClass={`${this.props.titleClass}`} extraClass={this.props.size ? `${this.props.size} ` : ""}>
                <table className="ui selectable inverted table">
                    <thead>
                        <tr>
                            <th>Item</th>
                            <th>Trend</th>
                            <th>Count</th>
                            <th>FinalPrice/Off</th>
                        </tr>
                    </thead>
                    <tbody>
                        {list}
                    </tbody>
                </table>
            </Column>
        )
    }
}