import React from 'react';

import Column from './column';
import { LineChart } from './line.d3';

class ItemViewCell extends React.Component {
    render() {
        return (
            <tr>
                <td>
                    <LineChart points={this.props.points} width="180" height="30" />
                </td>
                <td>{this.props.itemNumber}</td>
                <td><div className="ui ribbon label red button inverted">{this.props.count}</div></td>
                <td></td>
            </tr>
        )
    }
}

export default class ItemView extends React.Component {
    render() {

        let data = this.props.data,
            list = data.slice(0,8).map(function (item, idx) {
            return (
                <ItemViewCell
                    key={idx}
                    itemNumber={item.keyword}
                    count={item.totalCount}
                    points={item.values}
                    />
            )
        })
        return (
            <Column label="Top Viewed Items" titleClass={`${this.props.titleClass}`} extraClass={this.props.size ? `${this.props.size} ` : ""}>
                <table className="ui selectable inverted table">
                    <thead>
                        <tr>
                            <th>Trend</th>
                            <th>ItemNumber</th>
                            <th>Count</th>
                            <th>Rank</th>
                        </tr>
                    </thead>
                    <tbody>
                        {list}
                    </tbody>
                </table>
            </Column>
        )
    }
}