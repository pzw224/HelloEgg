import React from 'react';
import * as d3 from 'd3';
import {getMin, getMax} from '../utils/';


export class LineChart extends React.Component {

    render() {
        let props = this.props,
            y_min = getMin(props.points, 'y'),
            y_max = getMax(props.points, 'y'),
            x_min = getMin(props.points, 'x'),
            x_max = getMax(props.points, 'x'),
            x_gap = Math.abs(x_max - x_min),
            y_gap = Math.abs(y_max - y_min);

        let drawPath = d3.svg.line()
            .x((d) => (d.x - x_min) / x_gap * props.width)
            .y((d) => props.height - (d.y - y_min) / y_gap * props.height)
            .interpolate("basis");
        return (
            <svg width={props.width} height={props.height}>
                <path d={drawPath(this.props.points) } fill="none" stroke="white" />
            </svg>
        )
    }
}

export class AreaChart extends React.Component {
    render() {

        let props = this.props,
            y_min = props.yMin || getMin(props.points, 'y'),
            y_max = props.yMax || getMax(props.points, 'y'),
            y_gap = props.yGap || Math.abs(y_max - y_min),
            x_min = getMin(props.points, 'x'),
            x_max = getMax(props.points, 'x'),
            x_gap = Math.abs(x_max - x_min),
            fillColor = props.fill || "black",
            strokeColor = props.stroke || "red";

        let drawArea = d3.svg.area()
            .x(d => ((d.x - x_min) / x_gap * props.width))
            .y0(props.height)
            .y1(d => props.height - ((d.y - y_min) / y_gap * props.height))
            .interpolate("basis");

        let d = props.points.length > 0 ? drawArea(props.points) + 'Z' : "";

        return (
            <path d={d } fill={ fillColor } stroke={ strokeColor } />
        )
    }
}