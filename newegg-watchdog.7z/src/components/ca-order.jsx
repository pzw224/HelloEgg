require('normalize.css/normalize.css');
require('flipclock/compiled/flipclock.css');
require('../styles/clock.css');

import React, { Component, PropTypes } from 'react';
import { connect } from 'react-redux';

import { fetchCANOrderIfNeeded, fetchHeaderIfNeeded } from '../actions/actions';

import TotalSells from './total-sells.column';
import TotalOrders from './total-orders.column';
import OrderStateMapCA from './order-state-map.column.ca';

import { timeFormater, dataFormater } from '../utils/';
import { TIME_INTERVAL } from '../config/time';

const TIME_RECALL = 10 * 1000 * 60;


class AppComponent extends Component {

  componentWillMount() {
    const { dispatch } = this.props;
    let nowTime = Date.now(),
      dayGap = this.getCurrentDayTimeSpan();

    dispatch(fetchCANOrderIfNeeded(nowTime - TIME_RECALL - dayGap, nowTime - TIME_RECALL));
    dispatch(fetchHeaderIfNeeded());
    $("body").height(document.body.clientHeight);
    this.timerList = [];
  }

  componentDidUpdate(nextProps, nextState) {

    const { dispatch, network } = this.props;

    let startTime = network.lastUpdateTime;
    let timerList = this.timerList;

    if (timerList.length === 0) {
      timerList.push(
        setTimeout(() => {
          dispatch(fetchCANOrderIfNeeded(startTime, Date.now() - TIME_RECALL))
          timerList.pop();
        }, TIME_INTERVAL)
      )
    }

    this.setClockTime();
  }

  componentDidMount() {
    this.clock = jQuery(this.refs.clock).FlipClock();
    this.setClockTime();
  }

  setClockTime() {
    this.clock.setTime(Math.round(this.getCurrentDayTimeSpan() / 1000));
  }

  getCurrentDayTimeSpan() {
    let date1, date2, timespan;
    date1 = new Date(),
      date2 = new Date(`${date1.getMonth() + 1}/${date1.getDate()}/${date1.getFullYear()}`);

    timespan = (date1.valueOf() - date2.valueOf());

    return timespan;
  }

  render() {
    let { data } = this.props;
    let hasData = 0;
    if (Object.keys(data.map).length > 0) {
      hasData++;
    }
    Object.keys(data.orders).map((key) => {
      if (parseInt(data.orders[key]) > 0) {
        hasData++;
      }
    });

    return (

      <div className="container">
        <div>
          {hasData == 0 ? (
            <div id="loading" className="ui active dimmer">
              <div className="ui text loader">Loading...</div>
            </div>
          ) : (
              ""
            )}
          <div>
            <TotalSells data={data.orders} header={this.props.header} />
          </div >

          <div className="ui grid">

            <div className="ten wide computer three wide tablet six wide mobile column">
              <OrderStateMapCA data={data.map} />
            </div>

            <div className="six wide computer column">
              <TotalOrders data={data.orders} />
              <div className="ui menu inverted " ref="clock" style={{
                width: 'auto',
                position: 'absolute',
                bottom: '60px',
                right: '100px'
              }}></div>
            </div>

          </div>

        </div>
      </div>
    )
  }
}




function mapStateToProps(state) {
  return {
    data: state.data,
    network: state.network,
    header: state.header,
  }
}


export default connect(mapStateToProps)(AppComponent)