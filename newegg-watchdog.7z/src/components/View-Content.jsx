require('normalize.css/normalize.css');
require('../styles/view-content.css');

import React, { Component, PropTypes } from 'react';
import { connect } from 'react-redux';

import { fetchPostsIfNeeded, invalidateSubreddit,fetchHeaderIfNeeded } from '../actions/actions';
import PageViewHeader from './page-view-header';
import ItemView from './item-view.column';
import TotalSells from './total-sells.column';
import PvUv from './pv-uv.column';
import { TagCloud } from './TagCloud/tag-cloud.column';
import { timeFormater, dataFormater } from '../utils/';
import { TIME_INTERVAL, TIME_INIT_GAP, TIME_RECALL } from '../config/time';

class AppComponent extends Component {

    componentWillMount() {
        const { dispatch } = this.props;
        let nowTime = Date.now(),
            startTime = nowTime - TIME_INIT_GAP;

        dispatch(fetchPostsIfNeeded(startTime - TIME_RECALL, nowTime - TIME_RECALL));
        dispatch(fetchHeaderIfNeeded());
        $("body").height(document.body.clientHeight);
    }

    componentDidUpdate(nextProps, nextState) {

        const { dispatch, network } = this.props;

        let startTime = network.lastUpdateTime;

        setTimeout(() => {

            dispatch(fetchPostsIfNeeded(startTime, Date.now() - TIME_RECALL))
        }, TIME_INTERVAL);

    }

    drag(ev) {
        ev.dataTransfer.setData("Text", ev.target.id);
    }

    render() {
        let { data } = this.props;
        let hasData = 0;
        for (let key in data) {
            hasData += data[key] instanceof Array ? data[key].length : 0;
        }

        return (

            <div className="container">
                <div>
                    {hasData == 0 ? (
                        <div id="loading" className="ui active dimmer">
                            <div className="ui text loader">Loading...</div>
                        </div>
                    ) : (
                            ""
                        )}
                    <div><PageViewHeader header={this.props.header} /></div>
                    <div className="ui grid">
                        <div className="sixteen wide computer nine wide tablet six wide mobile column" draggable="true" style={{ paddingLeft: '4rem' }}>
                            <div className="ui segment inverted">
                                <div className="ui grid">
                                    <div className="eight wide computer tablet mobile column">
                                        <ItemView data={data.itemNumber} titleClass="ui tag label orange header" />
                                    </div>

                                    <div className="eight wide computer niew wide tablet six wide mobile column">
                                        <div className="ui segment inverted">
                                            <TagCloud titleClass="ui tag label blue header" data={data.keyword} />
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div id="drag" className="ui inverted segment" draggable="true">
                                <div className="ui grid">

                                    <div className="sixteen wide computer niew wide tablet six wide mobile column">
                                        <div className="ui segment inverted">
                                            <PvUv data={dataFormater(data.pvuv)} titleClass="ui tag label header" />
                                        </div>
                                    </div>


                                </div>
                            </div>

                        </div>

                    </div>

                </div>
            </div>
        )
    }
}




function mapStateToProps(state) {
    return {
        data: state.data,
        network: state.network,
        header: state.header
    }
}


export default connect(mapStateToProps)(AppComponent)