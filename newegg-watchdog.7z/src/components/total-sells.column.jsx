import React from 'react';

import Column from './column';

import Count from  'countup.js';

export default class TotalSells extends React.Component {
    componentDidUpdate(prevProps, prevState) {
        var easingFn = function (t, b, c, d) {
            var ts = (t /= d) * t;
            var tc = ts * t;
            return b + c * (tc + -3 * ts + 3 * t);
        }
        const demo = new Count(this.refs.orderSummary, prevProps.data.money, this.props.data.money, 0, 2,
            {
                useEasing: true,
                easingFn: easingFn,
                useGrouping: true,
                separator: ',',
                decimal: '.',
                prefix: '$',
                suffix: ''
            });
        demo.start();

        const demo2 = new Count(this.refs.orderCount, prevProps.data.orderCount, this.props.data.orderCount, 0, 5,
            {
                useEasing: true,
                easingFn: easingFn,
                useGrouping: true,
                separator: ',',
                decimal: '.',
                prefix: '',
                suffix: ''
            });
        demo2.start();
    }

    render() {
        let props = this.props;
        let text = props.data.money.toLocaleString('en-US', { style: 'currency', currency: 'USD', toFix: 2 });
        return (
            <Column label="Activeness" titleClass={`${this.props.titleClass}`} extraClass={this.props.size ? `${this.props.size} ` : ""}>
                <div>
                    <h3 ref="orderSummary">
                        
                    </h3>
                    <h3 ref="orderCount">
                    </h3>
                </div>
            </Column>
        )
    }
}