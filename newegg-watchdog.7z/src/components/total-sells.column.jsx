import React from 'react';

import Column from './column';

import Count from  'countup.js';

export default class TotalSells extends React.Component {
    componentDidUpdate(prevProps, prevState) {

        var easingFn = function (t, b, c, d) {
            var ts = (t /= d) * t;
            var tc = ts * t;
            return b + c * (tc + -3 * ts + 3 * t);
        }
        const totalPrice = new Count(this.refs.orderSummary, prevProps.data.money, this.props.data.money, 2, 2,
            {
                useEasing: true,
                easingFn: easingFn,
                useGrouping: true,
                separator: ',',
                decimal: '.',
                prefix: '$ ',
                suffix: ''
            });
        totalPrice.start();
    }

    render() {
        let props = this.props;
        let text = props.data.money.toLocaleString('en-US', { style: 'currency', currency: 'USD', toFix: 2 });
        return (
            <h1 className="ui inverted header">
                <img src="./images/blackFriday.gif" style={{ width: 'auto', height: '300px' }} />
                <div className="ui content inverted yellow header" ref="orderSummary" style={{
                    fontSize: '160px', backgroundImage: '-webkit-gradient(linear, 10% 0%, 110% 30%, from(#FBBD08), to(#e63535))', webkitBackgroundClip: 'text',
                    webkitTextFillColor: 'transparent'
                }} >
                </div>
            </h1 >
        )
    }
}