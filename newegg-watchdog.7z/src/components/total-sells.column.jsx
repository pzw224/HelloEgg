import React from 'react';

import Column from './column';

import Count from 'countup.js';

export default class TotalSells extends React.Component {
    componentDidUpdate(prevProps, prevState) {

        var easingFn = function (t, b, c, d) {
            var ts = (t /= d) * t;
            var tc = ts * t;
            return b + c * (tc + -3 * ts + 3 * t);
        }
        const totalPrice = new Count(this.refs.orderSummary, prevProps.data.money, this.props.data.money, 2, 2,
            {
                useEasing: true,
                easingFn: easingFn,
                useGrouping: true,
                separator: ',',
                decimal: '.',
                prefix: '$ ',
                suffix: ''
            });
        totalPrice.start();
    }

    render() {
        let logo= require('../images/blackFriday.gif');
        let props = this.props;
        let logoTitle = "DAILY NEWEGG";
        try {
            if (props.header) {
                for (let o in props.header.timeSpan) {
                    let startTime = new Date(props.header.timeSpan[o].startTime).valueOf();
                    let endTime = new Date(props.header.timeSpan[o].endTime).valueOf();
                    let now = Date.now();
                    if (now > startTime && now < endTime) {
                        logoTitle = props.header.timeSpan[o].pageTitle;
                    }
                }
            }
        } catch (e) { }
        let text = props.data.money.toLocaleString('en-US', { style: 'currency', currency: 'USD', toFix: 2 });
        return (
            <h1 className="ui inverted header" style={{ padding: '10px 0px 50px 0px' }}>
                <div style={{ width: 'auto', display: 'inline-block', margin: '45px 60px 30px 140px' }}>
                    <span style={{ display: 'block', fontSize: '45px', textAlign: 'center', fontWeight: 'bolder', paddingBottom: '5px' }}>{logoTitle}</span>
                    <img src={logo} style={{ width: '370px', height: '90px' }} />
                </div>
                <div className="ui content inverted yellow header" ref="orderSummary" style={{
                    fontSize: '160px', backgroundImage: '-webkit-gradient(linear, 10% 0%, 110% 30%, from(#FBBD08), to(#e63535))', webkitBackgroundClip: 'text',
                    webkitTextFillColor: 'transparent'
                }} >
                </div>
            </h1 >
        )
    }
}