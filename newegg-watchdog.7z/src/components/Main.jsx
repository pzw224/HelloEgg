require('normalize.css/normalize.css');
require('flipclock/compiled/flipclock.css');
require('../styles/clock.css');

import React, {Component, PropTypes} from 'react';
import { connect } from 'react-redux';

import {fetchPostsIfNeeded, invalidateSubreddit} from '../actions/actions';
import StateMap from './state-map.column';
import ItemView from './item-view.column';
import TotalSells from './total-sells.column';
import TotalOrders from './total-orders.column';
import PvUv from './pv-uv.column';
import {TagCloud} from './TagCloud/tag-cloud.column';
import { timeFormater, dataFormater } from '../utils/';
import {TIME_INTERVAL, TIME_INIT_GAP, TIME_RECALL} from '../config/time';


class AppComponent extends Component {

  componentWillMount() {
    const { dispatch } = this.props;
    let nowTime = Date.now(),
      startTime = nowTime - TIME_INIT_GAP;

    dispatch(fetchPostsIfNeeded(startTime - TIME_RECALL, nowTime - TIME_RECALL));
    $("body").height(document.body.clientHeight);
  }

  componentDidUpdate(nextProps, nextState) {

    const { dispatch, network } = this.props;

    let startTime = network.lastUpdateTime;

    setTimeout(() => {

      dispatch(fetchPostsIfNeeded(startTime, Date.now() - TIME_RECALL))
    }, TIME_INTERVAL);

    this.setClockTime();
  }

  componentDidMount() {
    this.clock = jQuery(this.refs.clock).FlipClock();
    this.setClockTime();
  }

  setClockTime() {
    let date1, date2, timespan;
    date1 = new Date(),
      date2 = new Date(`${date1.getMonth() + 1}/${date1.getDate()}/${date1.getFullYear()}`);

    timespan = (date1.valueOf() - date2.valueOf()) - 57600000;
    timespan = timespan > 0 ? timespan : (86400000 + timespan);
    timespan = Math.round(timespan / 1000);

    this.clock.setTime(timespan);
  }

  render() {
    let { data } = this.props;
    let hasData = 0;
    for (let key in data) {
      hasData += data[key] instanceof Array ? data[key].length : 0;
    }
    
    return (

      <div className="container">
        <div>
          {hasData == 0 ? (
            <div id="loading" className="ui active dimmer">
              <div className="ui text loader">Loading...</div>
            </div>
          ) : (
              ""
            ) }
          <div>
            <TotalSells data={data.orders} />
          </div >

          <div className="ui grid">

            <div className="ten wide computer three wide tablet six wide mobile column">
              <StateMap data={dataFormater(data.map) } />
            </div>

            <div className="six wide computer column">
              <TotalOrders data={data.orders} />
              <div className="ui menu inverted " ref="clock" style={{
                width: 'auto',
                position: 'absolute',
                bottom: '60px',
                right: '100px'
              }}></div>
            </div>

          </div>

        </div>
      </div>
    )
  }
}




function mapStateToProps(state) {
  return {
    data: state.data,
    network: state.network
  }
}


export default connect(mapStateToProps)(AppComponent)