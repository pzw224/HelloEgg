require('normalize.css/normalize.css');

import React, {Component, PropTypes} from 'react';
import { connect } from 'react-redux';

import {fetchPostsIfNeeded, invalidateSubreddit} from '../actions/actions';
import StateMap from './state-map.column';
import ItemView from './item-view.column';
import TotalSells from './total-sells.column';
import PvUv from './pv-uv.column';
import {TagCloud} from './TagCloud/tag-cloud.column';
import { timeFormater, dataFormater } from '../utils/';
import {TIME_INTERVAL, TIME_INIT_GAP, TIME_RECALL} from '../config/time';

class AppComponent extends Component {
  /**
   * lifecycle
   */
  componentWillReceiveProps(nextProps) {
    const { dispatch, network } = nextProps;
    // get Real-time data
    // setTimeout(
    //   () => {
    //     let startTime = network.lastUpdateTime;
    //     dispatch(fetchPostsIfNeeded(startTime, Date.now()))
    //   }
    //   , TIME_INTERVAL);
  }

  componentWillMount() {
    const { dispatch } = this.props;
    let nowTime = Date.now(),
      startTime = nowTime - TIME_INIT_GAP;

    dispatch(fetchPostsIfNeeded(startTime - TIME_RECALL, nowTime - TIME_RECALL));
  }

  componentWillUpdate(nextProps, nextState) {

    const { dispatch } = this.props;

    let startTime = nextProps.network.lastUpdateTime;

    setTimeout(() => {
      dispatch(fetchPostsIfNeeded(startTime, Date.now() - TIME_RECALL))
    }, TIME_INTERVAL);

  }

  render() {
    let { data } = this.props;
    let hasData = 0;
    for (let key in data) {
      hasData += data[key] instanceof Array ? data[key].length : 0;
    }

    return (

      <div className="container">
        <div className="ui segment inverted">
          {hasData == 0 ? (
            <div id="loading" className="ui active dimmer">
              <div className="ui text loader">Loading...</div>
            </div>
          ) : (
              ""
            ) }
          <div className="ui two column stackable grid">
            <ItemView size="seven wide" titleClass="ui tag label" data={data.itemNumber} />
            <StateMap size="nine wide" titleClass="ui tag label olive" data={dataFormater(data.map) } />
            <PvUv size="five wide" titleClass="ui tag label red" data={dataFormater(data.pvuv) } />
            <TagCloud size="five wide" titleClass="ui tag label violet" data={data.keyword} />
            <TotalSells size="six wide column" titleClass="ui tag label blue" data={data.orders} />
          </div>
        </div>
      </div >
    );
  }
}

function mapStateToProps(state) {
  return {
    data: state.data,
    network: state.network
  }
}


export default connect(mapStateToProps)(AppComponent)