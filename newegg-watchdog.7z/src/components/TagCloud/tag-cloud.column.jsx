import React from 'react';
import {KeyWord} from './key-word';
import Column from '../column';
import {transition} from '../../utils/';

const KEYWORD_COUNT = 10;
class TagCloud extends React.Component {

    componentDidUpdate() {
        jQuery('#my-canvas').tagcanvas("reload");
        transition('#top-key-word','jiggle');
    }

    componentDidMount() {
        jQuery("#my-canvas").attr("width", jQuery("#my-canvas-container").width());
        if (!jQuery('#my-canvas').tagcanvas({
            textColour: '#ff0000',
            reverse: true,
            depth: 0.8,
            maxSpeed: 0.06,
            minSpeed: 0.1,
            textHeight: 30,
            noSelect: true,
            wheelZoom: false,
            shuffleTags: true
        }, 'tags')) {
            // something went wrong, hide the canvas container
            jQuery('#my-canvas-container').hide();
        }
    }

    render() {
        let arr = [{
            'keyword': 'Google',
            'size': 39
        }, {
                'keyword': 'Fish',
                'size': 36
            }, {
                'keyword': 'Chips',
                'size': 33
            }, {
                'keyword': 'Salt',
                'size': 30
            }, {
                'keyword': 'Vinegar',
                'size': 27
            }, {
                'keyword': 'Vinegar1',
                'size': 24
            }, {
                'keyword': 'Vinegar2',
                'size': 21
            }, {
                'keyword': 'Vinegar3',
                'size': 18
            }, {
                'keyword': 'Vinegar4',
                'size': 15
            }, {
                'keyword': 'Vinegar5',
                'size': 12
            }];

        let formatkeyword = this.props.data;
        let keyword = formatkeyword && formatkeyword.length > KEYWORD_COUNT ? formatkeyword.slice(0, KEYWORD_COUNT) : formatkeyword;
        let count = formatkeyword ? formatkeyword.length : 0;
        if (keyword && count > 0) {
            arr = keyword.map((obj, index) => {
                if (obj) {
                    switch (index) {
                        case 0: obj["size"] = 39; break;
                        case 1: obj["size"] = 36; break;
                        case 2: obj["size"] = 33; break;
                        case 3: obj["size"] = 30; break;
                        case 4: obj["size"] = 27; break;
                        case 5: obj["size"] = 24; break;
                        case 6: obj["size"] = 21; break;
                        case 7: obj["size"] = 18; break;
                        case 8: obj["size"] = 15; break;
                        case 9: obj["size"] = 12; break;
                        default: obj["size"] = 12; break;
                    }

                    return obj;
                }
                return {};
            });
        }
        let style = { position: 'relative', width: '480px' };
        let listStyle = { position: 'absolute', top: '0px', left: '0px' };

        return (
            <Column label="Top Search Keyword" titleClass={`${this.props.titleClass}`} extraClass={this.props.size ? `${this.props.size} ` : ""}>
                <div>
                    <div id="my-canvas-container" style={style}>
                        <div id="top-key-word" className="ui list" style={listStyle}>

                            {
                                arr.slice(0, 3).map((val, index) => {
                                    let color = 'red';
                                    switch (index) {
                                        case 0: color = 'red'; break;
                                        case 1: color = 'orange'; break;
                                        case 2: color = 'olive'; break;
                                    }
                                    return (
                                        <div key={index} style={{ padding: '4px', margin: '0px' }} className={`item ui inverted ${color} statistic mini`}>
                                            <div className="value">{val.totalCount}</div>
                                            <div className="label">{val.keyword}</div>
                                        </div>
                                    );
                                })
                            }
                        </div>
                        <canvas width="300" height="250" id="my-canvas">
                            <p>Anything in here will be replaced on browsers that support the canvas element</p>
                        </canvas>
                    </div>

                    <div id="tags">
                        <ul>
                            {arr.map((value, index, arr) => <KeyWord key={index} index={index} content={value} />) }
                        </ul>
                    </div>
                </div>
            </Column>
        );
    }
}

export {TagCloud}