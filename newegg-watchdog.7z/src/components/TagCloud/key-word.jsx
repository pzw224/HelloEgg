import React from 'react';

class KeyWord extends React.Component {
  constructor(props) {
    super(props);
  }
  
  render() {
    let data={color:'#FF0000',count:this.props.content.size};
    switch(this.props.index){
      case 0: Object.assign(data,{color:'#FF0000'}); break;
      case 1: Object.assign(data,{color:'#FFD39B'}); break;
      case 2: Object.assign(data,{color:'#8B008B'}); break;
      case 3: Object.assign(data,{color:'#EAEAEA'}); break;
      case 4: Object.assign(data,{color:'#009ACD'}); break;
      case 5: Object.assign(data,{color:'#228B22'}); break;
      case 6: Object.assign(data,{color:'#EEEE00'}); break;
      case 7: Object.assign(data,{color:'#8B5742'}); break;
      case 8: Object.assign(data,{color:'#8DEEEE'}); break;
      case 9: Object.assign(data,{color:'#90EE90'}); break;
    }
    return (
      <li><a data-color={data.color} data-count={data.count} href='javascript:void(0)'>{this.props.content.keyword}</a></li>
    )
  }
}

export {KeyWord}