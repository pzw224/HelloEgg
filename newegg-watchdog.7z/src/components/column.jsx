import React from 'react';

export default class Example extends React.Component {

	static propTypes = {
		children: React.PropTypes.element.isRequired,
		label: React.PropTypes.string.isRequired,
		mapStyle: React.PropTypes.object
	};

	render() {
		return (
			<div className={`${this.props.extraClass||""}column`}>
				<h3 className={`${this.props.titleClass}`}>{this.props.label}</h3>
				<div className="ui segment inverted ">
					{React.Children.only(this.props.children)}
				</div>
			</div>
		);
	}

}
