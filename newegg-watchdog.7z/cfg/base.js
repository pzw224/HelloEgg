'use strict';
let path = require('path');
let webpack = require('webpack');
let defaultSettings = require('./defaults');
let BowerWebpackPlugin = require('bower-webpack-plugin');
// Additional npm or bower modules to include in builds
// Add all foreign plugins you may need into this array
// @example:
// let npmBase = path.join(__dirname, '../node_modules');
// let additionalPaths = [ path.join(npmBase, 'react-bootstrap') ];
let additionalPaths = [];

module.exports = {
  additionalPaths: additionalPaths,
  port: defaultSettings.port,
  debug: true,
  devtool: 'eval',
  output: {
    path: path.join(__dirname, '/../dist/assets'),
    filename: '[name].js',
    publicPath: defaultSettings.publicPath
  },
  devServer: {
    contentBase: './src/',
    historyApiFallback: true,
    hot: true,
    port: defaultSettings.port,
    publicPath: defaultSettings.publicPath,
    noInfo: false
  },
  resolve: {
    extensions: ['', '.js', '.jsx'],
    alias: {
      actions: `${defaultSettings.srcPath}/actions/`,
      components: `${defaultSettings.srcPath}/components/`,
      sources: `${defaultSettings.srcPath}/sources/`,
      stores: `${defaultSettings.srcPath}/stores/`,
      styles: `${defaultSettings.srcPath}/styles/`,
      config: `${defaultSettings.srcPath}/config/` + process.env.REACT_WEBPACK_ENV
    },
    modulesDirectories: ['node_modules', 'bower_components']
  },
  module: {},
  externals: [
    {
      "window": "window"
    }
  ],
  plugins: [
    // new BowerWebpackPlugin({
    //   modulesDirectories: ["bower_components"],
    //   manifestFiles: "bower.json",
    //   includes: /.*/,
    //   excludes: [],
    //   searchResolveModulesDirectories: true
    // })
    new webpack.ProvidePlugin({
      $:"jquery",
      jQuery:"jquery",
      d3:"d3/d3.min"
    })
  ]
};
