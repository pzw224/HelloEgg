/*eslint no-console:0 */
'use strict';
require('core-js/fn/object/assign');
const webpack = require('webpack');
const WebpackDevServer = require('webpack-dev-server');
const config = require('./webpack.config');
const open = require('open');

// node API server
const express = require('express');
const routes = require('./src/api/');
const serveStatic = require('serve-static');
var app = express();

new WebpackDevServer(webpack(config), config.devServer)
  .listen(config.port, 'localhost', (err) => {
    if (err) {
      console.log(err);
    }
    console.log('Listening at localhost:' + config.port);
    console.log('Opening your system browser...');
    open('http://localhost:' + config.port + '/webpack-dev-server/');
  });


app.use(serveStatic(__dirname + "/dist"));
app.listen(config.port + 1);
routes(app);