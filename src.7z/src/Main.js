import React from 'react'
import {Hello,Welcomes,Form,Calculator} from './Component/HelloWorld/Index'

//<Hello />
function Main() {
  return (
    <div>     
      <Welcomes />
      <Form />
      <Calculator />
    </div>
  );
}

export {Main}