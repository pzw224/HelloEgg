import React from 'react';
import {LoginButton} from './LoginButton'
import {LogoutButton} from './LogoutButton'



class Welcome extends React.Component {
    constructor(props) {
        super(props);
        this.state = { date: new Date() };

        //The binding is necessary to make `this` work in the callback
        this.handleClick = this.handleClick.bind(this);
        this.handleLogoutClick = this.handleLogoutClick.bind(this);
        this.handleLoginClick = this.handleLoginClick.bind(this);
    }

    handleClick() {
        this.setState(prevState => ({ isToggleOn: !prevState.isToggleOn }));
    }

    handleLogoutClick(){
        this.setState({isLoggedIn:false});
    }

    handleLoginClick(){
        this.setState({isLoggedIn:true});
    }

    logClick(e) {
        console.log("this is:", this,e)
    }

    componentDidMount() {
        this.timerID = setInterval(() => this.tick(), 1000);
    }

    componentWillUnmount() {
        clearInterval(this.timerID);
    }

    tick() {
        this.setState({ date: new Date() });
    }

    render() {
        const isLoggedIn=this.state.isLoggedIn;
        let button=null;
        if(isLoggedIn){
            button= <LogoutButton onClick={this.handleLogoutClick} />;
        }else{
            button=<LoginButton onClick={this.handleLoginClick} />;
        }

        return (
            <div>
                <h1>Hello, {this.props.name}</h1>
                <h2>Time is {this.state.date.toLocaleTimeString() } now</h2>
                <button onClick={this.handleClick}>{this.state.isToggleOn ? 'ON' : 'OFF'}</button>
                <button onClick={(e)=>this.logClick(e)}>log测试</button>
                {button}
            </div>
        )
    }
}

export {Welcome}