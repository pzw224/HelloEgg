import React from 'react'
class Form extends React.Component {
    constructor(props) {
        super(props);
        this.state = { value: '',radioValue:'B' };
        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
        this.radioChange=this.radioChange.bind(this);
        this.radioSubmit=this.radioSubmit.bind(this);
    }

    handleChange(event) {
        this.setState({ value: event.target.value });
    }

    handleSubmit(event) {
        alert('Text field value is: ' + this.state.value);
    }

    radioChange(event){
        this.setState({radioValue:event.target.value});
    }

    radioSubmit(event){
        alert(`radio field value is ${this.state.radioValue}`)
    }

    render() {
        return (
            <div>
                <input type="text"
                    placeholder="Hello!"
                    value={this.state.value}
                    onChange={this.handleChange} />
                <button onClick={this.handleSubmit}>
                    Submit
                </button>
                <hr />
                <label>
                    <input
                        type="radio"
                        name="choice"
                        value="A"
                        onChange={this.radioChange} />
                    Option A
                </label>
                <br />
                <label>
                    <input
                        type="radio"
                        name="choice"
                        value="B"
                        onChange={this.radioChange}
                        defaultChecked={true} />
                    Option B
                </label>
                <br />
                <label>
                    <input
                        type="radio"
                        name="choice"
                        value="C"
                        onChange={this.radioChange} />
                    Option C
                </label>
                <br />
                <br />
                <button onClick={this.radioSubmit}>
                    Submit
                </button>
            </div>
        );
    }
}

export {Form}