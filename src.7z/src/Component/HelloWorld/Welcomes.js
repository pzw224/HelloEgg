import React from 'react'
import {Welcome} from './Welcome'

let arr=['Sara','Cahal','Edite'];
function Welcomes(){
    return (
        <div>
            {arr.map((value,index,arr)=><Welcome key={index} name={`My name is ${value}`} />)}
        </div>
    )
}

export {Welcomes}
