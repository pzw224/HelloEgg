/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */
import {Provider, connect} from 'react-redux';
import myStore from './src/store/index.js';
import React, { Component } from 'react';
import { AppRegistry } from 'react-native';
import AppComponent from './src/app';
import { fetchStoreInit } from './src/actions/actions.js';
let store = myStore();

export default class NeweggProject extends Component {
	constructor(props) {
		super(props);
		fetchStoreInit(store.dispatch);
	}
	render() {
		return (
			<Provider store={ store } >
			<AppComponent />
			< /Provider>
		)
	}
}

AppRegistry.registerComponent('NeweggDailyDeals', () => NeweggProject);