import React, { Component } from 'react';
import { Text, View } from 'react-native';

import Main from './components/main'
import NegNavigator from './negNavigator';
import { HeaderAndroid, HeaderIOS, Header } from './components/common/header'
import { FooterAndroid, FooterIOS, Footer } from './components/common/footer'

export default class AppComponent extends Component {
    render() {
        // <View style={{ flex: 1 }}>
        //     <Header />
        return (
            <NegNavigator />
        )
        //     <Footer />
        // </View>
    }
}