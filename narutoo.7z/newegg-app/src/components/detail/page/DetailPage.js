import React, { Component } from 'react';
import {
    View, Image, ScrollView, Text
} from 'react-native';
import ItemImage from '../../utils/ItemImage';
import styles from '../../styles/mainStyles';
import Swiper from 'react-native-swiper';

var Dimensions = require('Dimensions');
var ScreenWidth = Dimensions.get('window').width;
var ScreenHeight = Dimensions.get('window').height;
const I = "i";
export class DetailPage extends Component {

    render() {
        var {item} = this.props;
        var imageGroup = new ItemImage(item.ItemDetail.Image);
        var imageList = imageGroup.getHttpsImageGroup(1080).map((imagePath, idx) => {
            return (
                <View key={idx} style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
                    <Image source={{ uri: imagePath }} style={styles.imgStyle} />
                </View>
            )
        });
        var promotionText = item.ItemDetail.PromotionInfo && item.ItemDetail.PromotionInfo.PromotionText != "" ?
            (<View style={{ flexDirection: 'row', marginTop: 10, flex: 1 }}>
                <View>
                    <Text style={styles.promo}>{I}</Text>
                </View>
                <View>
                <Text style={{ color: '#f78c1b', fontSize: 20 }}>{item.ItemDetail.PromotionInfo.PromotionText}</Text>
                </View>
            </View>) : (<Text>''</Text>);
        var bulletDescription = item.ItemDetail.Description ? (<Text style={styles.bulletDescription}>{item.ItemDetail.Description.BulletDescription}</Text>) : (<Text>''</Text>);
        var _ScrollChange = function () {

        }
        if (item && item.ItemDetail) {
            return (
                <ScrollView style={[styles.flex1, { backgroundColor: '#ccc', marginTop: 10 }]}>
                    <Swiper height={Dimensions.get('window').width / (1280 / 960)}
                        showsPagination={true}
                        paginationStyle={{ bottom: 10, left: null, right: 10 }}
                        activeDotStyle={{ backgroundColor: '#f78c1b' }}
                        >
                        {imageList}
                    </Swiper>
                    <View style={[styles.pdlWhite, { marginTop: 5, flex: 1 }]}>
                        <Text style={styles.pageTitle}>{item.ItemDetail.Description.LineDescription}</Text>
                        {promotionText}
                        <Text style={{ color: '#333', fontWeight: '900', fontSize: 28 }}>{`$${(item.ItemDetail.UnitCost - item.ItemDetail.InstantRebateAmount).toFixed(2)}`}</Text>
                        {bulletDescription}
                    </View>

                </ScrollView>
            )
        }
    }
}
                    // <ScrollView onContentSizeChange={this._ScrollChange} showsHorizontalScrollIndicator={false} horizontal={true} style={styles.flex1}>
                    //     {imageList}
                    // </ScrollView>