import React, { Component } from 'react';
import { Navigator, Text, View } from 'react-native';
import styles from '../../styles/mainStyles'

export class ReviewPage extends Component {
    render() {
        return (
            <View style={styles.flex1}>
                <Text>Review ...</Text>
            </View>
        )
    }
}