import React, { Component } from 'react';
import {
    Text,
    View,
    StyleSheet
} from 'react-native';
import Button from 'react-native-smart-button';
import Badge from 'react-native-smart-badge';
import styles from '../styles/mainStyles';
import { addToCart } from '../../actions/actions.js'
import { connect } from 'react-redux';
class DetailFooterApp extends Component {

    _AddtoCart() {
        const {dispatch} = this.props;
        addToCart(dispatch, this.props.item.ItemDetail.Item);
    }

    _ShoppingCart(){
    }

    render() {
        var shoppingCartCount = 0;


        return (
            <View style={styles.pageFooter}>
                <View style={[styles.flex1]}>
                    <Button
                        touchableType={Button.constants.touchableTypes.highlight}
                        underlayColor={'#C90000'}
                        style={{ margin: 10, justifyContent: 'center', height: 40, backgroundColor: 'red', borderRadius: 3, borderWidth: StyleSheet.hairlineWidth, borderColor: 'red', justifyContent: 'center', }}
                        textStyle={{ fontSize: 17, color: 'white' }}
                        onPress={this._AddtoCart.bind(this)}
                        >
                        ADD TO CART
                </Button>
                </View>
                <Text style={{ color: '#fff' }}>|</Text>
                <View style={[styles.flex1]}>
                    <Button
                        touchableType={Button.constants.touchableTypes.blur}
                        style={{ margin: 10, justifyContent: 'center', height: 40, backgroundColor: 'red', borderRadius: 3, borderWidth: StyleSheet.hairlineWidth, borderColor: 'red', justifyContent: 'center', }}
                        textStyle={{ fontSize: 17, color: 'white' }}
                        onPress={this._ShoppingCart.bind(this)}
                        >
                        Shopping Cart
                    <Badge
                            style={{ backgroundColor: '#00AAEF', marginLeft: 6, }}
                            textStyle={{ color: '#fff', fontSize: 12, }}>
                            {this.props.cart.length}
                        </Badge>
                    </Button>
                </View>
            </View>
        )
    }
}

function mapStateToProps(state){
    return{
        item:state.item,
        cart:state.cart
    }
}

export default connect(mapStateToProps)(DetailFooterApp);