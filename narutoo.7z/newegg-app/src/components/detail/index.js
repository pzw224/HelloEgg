import React, { Component } from 'react';
import { View, Text, Button } from 'react-native';
import ScrollableTabView, { DefaultTabBar } from 'react-native-scrollable-tab-view';
import { DetailPage, OverViewPage, ReviewPage } from './page/index';
import DetailFooterApp from './DetailFooterApp';
import styles from '../styles/mainStyles';
import data from '../../mock-data/productbase';
import { connect } from 'react-redux';

class Detail extends Component {
    //     <ScrollableTabView style={styles.scrollTabViews} locked={true} renderTabBar={() => <DefaultTabBar tabStyle={{ paddingBottom: 0 }} textStyle={{ fontSize: 16 }} />}
    //     style={{ backgroundColor: 'rgba(0,0,0,0.01)' }} tabBarActiveTextColor="#333"
    //     tabBarUnderlineStyle={{ borderColor: '#f78c1b', borderWidth: 2 }} tabBarTextStyle={{ fontFamily: 'HelveticaNeue-Medium', fontSize: 15 }}>

    //     <OverViewPage tabLabel="OverView" />
    //     <ReviewPage tabLabel="Review" />
    // </ScrollableTabView >

    render() {
        return (
            <View style={styles.flex1}>
                <DetailPage tabLabel="Detail" item={this.props.item} />
                <DetailFooterApp />
            </View>
        )
    }
}

function mapStateToProps(state){
    return{
        item:state.item
    }
}

export default connect(mapStateToProps)(Detail);