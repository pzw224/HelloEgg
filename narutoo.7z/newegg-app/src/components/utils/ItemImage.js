const rSize = /{Size}/
const rImageName = /{ImageName}/
const rHttp = /http:\/\//
const defaultImage = 'empty.jpg';

var ItemImage = function (image) {
    this.hasScene7Image = image.HasScene7Image;
    this.imageInternalCount = image.ImageInternalCount;
    this.imagePathPattern = image.ImagePathPattern instanceof Array && image.ImagePathPattern.map((pattern) => {
        return {
            pathPattern: pattern.PathPattern,
            size: pattern.Size
        };
    });
    this.itemCellImageName = image.ItemCellImageName;
    this.normal = {};
    if (image.Normal) {
        this.normal.DFIS360ImageFlag = image.Normal.DFIS360ImageFlag;
        this.normal.imageName = image.Normal.ImageName;
        this.normal.imageNameList = image.Normal.ImageNameList;
    }
    this.waterMarkFlag = image.WaterMarkFlag;

    return this;
};

ItemImage.prototype.getImageSizePath = function (size = 300) {
    let matchSize, targetIdx, len, idf = Infinity;
    if (this.imagePathPattern && (len = this.imagePathPattern.length) > 0) {
        for (let i = 0; i < len; i++) {
            if (Math.abs(this.imagePathPattern[i].size - size) < idf) {
                targetIdx = i;
                idf = Math.abs(this.imagePathPattern[i].size - size);
            }
        }
        matchSize = this.imagePathPattern[targetIdx].size;
        return sizePath = this.imagePathPattern[targetIdx].pathPattern.replace(rSize, matchSize);
    }
    return false;
};

ItemImage.prototype.getImageGroup = function (size = 300) {
    let imagePathList = [],
        imageSizePath = ItemImage.prototype.getImageSizePath.call(this, size);
    if (imageSizePath && this.normal.imageNameList && this.normal.imageNameList.length > 0) {
        this.normal.imageNameList.split(',').map((imageName) => {
            imagePathList.push(imageSizePath.replace(rImageName, imageName));
        });
    }
    return imagePathList;
};

ItemImage.prototype.getDefaultImage = function (size = 300) {
    let imageSizePath = ItemImage.prototype.getImageSizePath.call(this, size);
    if (imageSizePath) {
        return imageSizePath.replace(rImageName, this.normal.imageName);
    }
    return '';
};

ItemImage.prototype.getHttpsDefaultImage = function (size = 300) {
    return ItemImage.prototype.getDefaultImage.call(this, size)
        .replace(rHttp, "https:\/\/");
}

ItemImage.prototype.getHttpsImageGroup = function (size = 300) {
    return ItemImage.prototype.getImageGroup.call(this, size)
        .map((imagePath) => {
            return imagePath.replace(rHttp, "https:\/\/");
        });
}

export default ItemImage;