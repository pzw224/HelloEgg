const rtag = /(<b>.+<\/b>)/;

var ItemTag = function (viewDescription) {
    return viewDescription.split("<br/>")
        .map((text) => {
            return text.replace(rtag, "");
        })
        .filter((text) => {
            return text.length > 0;
        }).sort((a, b) => {
            return a.length - b.length;
        });
}

export default ItemTag;