import React,{Component} from 'react';
import {View,Text,TextInput} from 'react-native';


export class Footer extends Component{
    render(){
        return(
            <View style={{flex:0,backgroundColor:'steelblue'}}></View>
        )
    }
}


export class FooterAndroid extends Component{
    render(){
        return(
            <View style={{backgroundColor:'powderblue'}}>
                <Text>This is an Android Footer</Text>
            </View>
        )
    }
}


export class FooterIOS extends Component{
    render(){
        return(
            <View style={{backgroundColor:'powderblue'}}>
                <Text>This is an iOS Footer</Text>
            </View>
        )
    }
}