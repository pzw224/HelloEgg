import React,{Component} from 'react';
import {View,Text,TextInput} from 'react-native';


export class Header extends Component{
    render(){
        return(
            <View style={{flex:0,backgroundColor:'powderblue'}}></View>
        )
    }
}

export class HeaderAndroid extends Component{
    render(){
        return(
            <View style={{backgroundColor:'powderblue'}}>
                <Text>This is an Android Header</Text>
            </View>
        )
    }
}


export class HeaderIOS extends Component{
    render(){
        return(
            <View style={{backgroundColor:'powderblue'}}>
                <Text>This is an iOS Header</Text>
            </View>
        )
    }
}