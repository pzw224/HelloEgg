import React,{Component} from 'react';
import {View,Text} from 'react-native';

import {HeaderAndroid,HeaderIOS,Header} from './common/header'
import {FooterAndroid,FooterIOS,Footer} from './common/footer'

export default class Main extends Component{
    render(){
        return(
            <View style={{flex:1}}>    
                <Header />
                <Footer />
            </View>
        )
    }
}