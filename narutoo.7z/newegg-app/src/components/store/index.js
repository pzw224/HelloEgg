import React, { Component } from 'react';
import { View, Text, ListView, ScrollView } from 'react-native';
import ListCell from './ListCell';
// import data from '../../mock-data/';
import { connect } from 'react-redux';
import { fetchStoreInit } from '../../actions/actions.js';

class Store extends Component {
    constructor(props) {
        super(props);
		fetchStoreInit(this.props.dispatch);
        this.ds = new ListView.DataSource({ rowHasChanged: (r1, r2) => r1.ItemNumber !== r2.ItemNumber });
    }
    
    render() {
        debugger;
        console.log(this.props.products);
        let dataSource = this.ds.cloneWithRows(this.props.products);
        return (
            <View style={{ flex: 1 }}>
                <ScrollView>
                    <ListView
                        dataSource={dataSource}
                        renderRow={(rowData) => { return <ListCell navigator={this.props.navigator} item={rowData} /> } }
                        />
                </ScrollView>
            </View>
        )
    }
}

function mapStateToProps(state){
    return{
        products:state.products,
        route:state.route
    }
}

export default connect(mapStateToProps)(Store);