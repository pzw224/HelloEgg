import React, { Component } from 'react';
import { View, Text, StyleSheet } from 'react-native';

const style = StyleSheet.create({
    text: {
        borderColor: 'red',
        padding: 2,
        flex: 1
    }
})

export default class Tag extends Component {
    render() {
        return (
            <View>
                <Text style={style.text}>
                    {this.props.tagText}
                </Text>
            </View>
        )
    }
}