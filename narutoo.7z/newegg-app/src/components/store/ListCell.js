import React, { Component } from 'react';
import {
    View,
    Text,
    Image,
    TouchableHighlight,
    StyleSheet,
    Dimensions,
    BackAndroid,
    Platform
} from 'react-native';

const {width, height} = Dimensions.get('window');

import ItemImage from '../utils/ItemImage';
import ItemTag from '../utils/ItemTag';
import Tag from './Tag';
import { fetchProductInIt } from '../../actions/actions.js';
import { connect } from 'react-redux';


const tagList = function(tags) {
    return tags.slice(0, 2).map((tag, idx) => {
        return <Tag key={idx} tagText={tag} />
    });
}

class ListCell extends Component {
    constructor(props) {
        super(props);
        this.handleBack = this.handleBack.bind(this);
    }
    componentDidMount () {
        if (Platform.OS === 'android') {  
           BackAndroid.addEventListener('hardwareBackPress', this.handleBack);  
        } 
    }
  componentWillUnmount() {  
    if (Platform.OS === 'android') {  
      BackAndroid.removeEventListener('hardwareBackPress', this.handleBack);  
    }  
  }  
  handleBack(){
  var navigator = this.props.navigator;
  if (navigator && navigator.getCurrentRoutes().length > 1) {
    navigator.pop();
    return true;
  }else{
    return false;
  }
}
    render() {
        let item = this.props.item,
            description = item.ItemBase.Description.LineDescription,
            itemImage = new ItemImage(item.ItemBase.Image),
            itemTags = new ItemTag(item.ItemBase.ViewDescription),
            source = itemImage.getHttpsDefaultImage().replace(/ProductImageCompressAll[0-9]+/, "ProductImageCompressAll300");


        return (
            <TouchableHighlight style={{ flex: 1, borderWidth: 0.5, borderColor: '#d6d7da' }} underlayColor='azure' activeOpacity={0.7} onPress={this._handleClick.bind(this)} >
                <View style={{ flex: 1, flexDirection: 'row' }}>
                    <Image source={{ uri: source }} style={styles.image} resizeMode='contain' />
                    <View style={{ flex: 3 }}>
                        <Text style={styles.descriptionText} numberOfLines={2}> {description}</Text>
                        <View style={{ flex: 1, flexDirection: 'row', alignItems: 'flex-end' ,flexWrap:'nowrap'}}>
                            <Text style={styles.finalPriceText}>
                                ${item.ItemBase.FinalPrice.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                                <Text style={styles.unitCostText}>
                                    ${item.ItemBase.UnitCost.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                                </Text>
                            </Text>
                        </View>
                    </View>
                </View>
            </TouchableHighlight>
        );
    }
    _handleClick(e) {
        let {item, dispatch} = this.props;
                   this.props.navigator.push({
                name:"",
                component:"ProductDetail"
            });   
        fetchProductInIt(dispatch, item.ItemNumber);
    }
}

const styles = StyleSheet.create({
    image: {
        flex: 2,
        width: 150,
        height: 112,
        padding: 20
    },
    descriptionText: {
        flex: 3,
        fontWeight: 'bold',
        fontSize: 15
    },
    finalPriceText: {
        flex: 1,
        fontSize: 14,
        fontWeight: 'bold',
        color: 'orange'
    },
    unitCostText: {
        fontSize: 10,
        fontWeight: 'normal',
        textDecorationLine: 'line-through',
        color: 'gray',
        marginLeft: 10
    }
});

function mapStateToProps(state){
	return{
		products:state.products,
        count:state.count,
        route:state.route
	};
}

export default connect(mapStateToProps)(ListCell);
