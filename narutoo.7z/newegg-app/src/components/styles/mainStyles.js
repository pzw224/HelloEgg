import {
    StyleSheet
} from 'react-native';
import Dimensions from 'Dimensions';

const FooterHeight = 100;
export default StyleSheet.create({
    flex1: {
        flex: 1
    },
    flex2: {
        flex: 2
    },
    flex3: {
        flex: 3
    },
    scrollTabViews: {
        height: (Dimensions.get('window').height - FooterHeight),
        backgroundColor: '#ccc'
    },
    imgStyle: {
        // 设置背景颜色
        backgroundColor: '#ccc',
        // 设置宽度
        width: Dimensions.get('window').width,
        // 设置高度
        height: Dimensions.get('window').width / (1280 / 960),
        // 设置图片填充模式
        resizeMode: 'stretch'
    },
    pageTitle: {
        fontWeight: '900',
        fontSize: 20,
        textAlign: 'auto',
        marginTop: 10
    },
    promo: {
        backgroundColor: '#f78c1b',
        color: '#fff',
        width: 18,
        textAlign: 'center',
        fontSize: 18,
        borderRadius: 18,
        fontWeight: '800',
        marginRight: 4,
    },
    priceInfo: {
        paddingLeft: 20,
        marginTop: 10,
        height: 150,
        backgroundColor: '#fff'
    },
    pdlWhite: {
        paddingLeft: 20,
        paddingRight: 20,
        backgroundColor: '#fff'
    },
    bulletDescription: {
        color: '#ccc',
        fontWeight: '900',
        fontSize: 20,
        marginTop: 20,
        marginBottom: 20,
        borderTopWidth: 2,
        borderColor: '#ccc',
        paddingTop:10
    },
    pageFooter: {
        height: FooterHeight,
        flexDirection: 'row',
    },

})