export const STOREINIT = 'INIT';
export const PRODUCTINIT = "PRODUCTINIT";
export const SHIPPINGCART = "SHIPPINGCART"

var myHeader =  {
	method:'Get',
	headers:{
		'Accept':'application/json',
		'Content-Type':'application/json',
	}
}

function receiveStoreDate(json){
	return{
		type:STOREINIT,
		data:json
	}
}

function receiveProductDate(json){
	return{
		type:PRODUCTINIT,
		data:json
	}
}

function receiveAddToCart(item){
	return{
		type:SHIPPINGCART,
		data:item
	}
}

function fetchProductData(dispatch, item){
	var url = 'http://172.16.16.21:8009/api/product/base?IgnoreBuyBoxRanking=false&PriceTypes=0&CompanyCode=1003&CountryCode=USA&LanguageCode=en-US&ItemNumber=' + item;
	fetch(url, myHeader)
	.then(function(response){
		if(response.ok){
			return response.json();
		}
	})
	.then(function(data){
		dispatch(receiveProductDate(data));
	})
}

function fetchStoreData(dispatch){
	fetch('http://172.16.16.21:8802/api/store/base/1/4?CompanyCode=1003&CountryCode=USA&DepaId=1&LanguageCode=en-US&PriceType=1&Tid=-1',myHeader)
	.then(function(response){
		if(response.ok){
			return response.json();
		}
	})
	.then(function(data){
        dispatch(receiveStoreDate(data));
    })
}

export function fetchStoreInit(dispatch){
	fetchStoreData(dispatch);
}

export function fetchProductInIt(dispatch, item){
	fetchProductData(dispatch, item);
}

export function addToCart(dispatch, item){
	dispatch(receiveAddToCart(item));
}