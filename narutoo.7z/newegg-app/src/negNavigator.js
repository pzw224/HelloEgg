import { connect } from 'react-redux';
import React, { Component } from 'react';
import { Platform, View, Navigator } from 'react-native';

import Detail from './components/detail/';
import Store from './components/store/';

class NegNavigator extends Component {
    render() {
        let defaultName = "Newegg";
        let defaultComponent = this.props.route;
        return (
            <Navigator

                initialRoute={{name:defaultName,component:defaultComponent}}
                renderScene={this.renderScene.bind(this)}
                />
        );
    }

    renderScene(route, navigator) {
         debugger;
        if (route.component === "ProductDetail" && this.props.route === "ProductDetail") {
            return <Detail navigator={navigator} />    
        }
          
        return <Store navigator={navigator} />
    }
}

function mapStateToProps(state){
	return{
		products:state.products,
        count:state.count,
        route:state.route
	};
}

export default connect(mapStateToProps)(NegNavigator);
            //navigator.push({index:1});



            