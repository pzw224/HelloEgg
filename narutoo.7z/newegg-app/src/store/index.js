import {createStore} from 'redux';
import { STOREINIT, PRODUCTINIT, SHIPPINGCART } from '../actions/actions';

var reducer = function (state, action) {
	switch (action.type) {
		case STOREINIT:
			let result = Object.assign({}, state);
			if (action.data) {
				result["products"] = action.data["ProductDeals"];
				result["route"] = "Store";
				if (action.data["ProductDeals"] != null) {
					result["count"] = action.data["ProductDeals"].length;
				}
			}
			console.log(result)
			return result;
		case PRODUCTINIT:
			let product = Object.assign({}, state);
			if (action.data) {
				product["item"] = action.data;
				product["route"] = "ProductDetail";
				console.log(product);
			}
			return product;
		case SHIPPINGCART:
			let nextState = Object.assign({}, state);
			if (action.data) {
				nextState.cart = nextState.cart.concat(action.data);
			}
			return nextState;
		default:
			return state;
	}
}

export default function () {
	return createStore(reducer, { products: [], cart: [] });
}