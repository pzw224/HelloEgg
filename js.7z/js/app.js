require.config({
    baseUrl: "js/libs",
    "paths": {
        "THREE": "three.min",
        "TWEEN": "tween.min",
        "jquery": "jquery-1.11.1.min",
        "jquery.rest": "jquery.rest.min",
        "THREE.TrackballControls": "../controls/TrackballControls",
        "THREE.CSS3DRenderer": "../renderers/CSS3DRenderer",
        "redux": "redux.min",
        "data": "../app/data"
    },
    "shim": {
        "THREE.TrackballControls": {
            deps: ["THREE"]
        },
        "THREE.CSS3DRenderer": {
            deps: ["THREE"]
        },
        "jquery.rest": {
            deps: ["jquery"]
        }
    }
});

requirejs(["../app/main"]);