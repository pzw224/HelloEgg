define(['message'],function (Message) {
    var msgHandler;
    
});