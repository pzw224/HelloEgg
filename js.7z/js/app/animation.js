define(['THREE', 'TWEEN'], function (THREE, TWEEN) {
    var emphasis = function (camera, object, options) {
        var c_p = camera.position;
        var vector = new THREE.Vector3(object.position.x, object.position.y, object.position.z);
        var defaultOptions = {
            delay: 5000,    // time for emphasis effect
            zoom: 800,  // camera zoom size
            emphasisEffect: function () { } // do something when camera is focus
        };
        options = Object.assign(defaultOptions, options);
        new TWEEN.Tween(new THREE.Vector3(c_p.x, c_p.y, c_p.z))
            .to({ x: vector.x, y: vector.y, z: options.zoom }, 2000)
            .easing(TWEEN.Easing.Exponential.InOut)
            .onUpdate(function () {
                c_p.set(this.x, this.y, this.z);
            })
            .start()
            .onComplete(function () {
                if (typeof options.emphasisEffect === 'function') {
                    options.emphasisEffect(object);
                }
                setTimeout(
                    function () {
                        new TWEEN.Tween(new THREE.Vector3(c_p.x, c_p.y, c_p.z))
                            .to({ x: 0, y: 0, z: 3500 }, 2000)
                            .easing(TWEEN.Easing.Exponential.InOut)
                            .onUpdate(function () {
                                c_p.set(this.x, this.y, this.z);
                            })
                            .start();
                    }, options.delay
                );
            });
    };

    var rotate = function (render, object, options) {
        var rot = object.rotation;
        var defaultOptions = {
            angle: {
                x: 0,
                y: 4 * Math.PI,
                z: 0
            },
            delay: 3500
        };
        options = Object.assign(defaultOptions, options);
        new TWEEN.Tween(rot)
            .delay(1000)
            .to({
                x: rot._x + options.angle.x,
                y: rot._y + options.angle.y,
                z: rot._z + options.angle.z
            }, options.delay)
            .easing(TWEEN.Easing.Exponential.InOut)
            .onUpdate(render)
            .start();
    };

    return {
        emphasis: emphasis,
        rotate: rotate
    };
});