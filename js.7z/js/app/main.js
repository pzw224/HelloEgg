requirejs([
    "data",
    "../app/animation",
    "../app/client",
    "../app/store",
    "../app/hexagon-css",
    "TWEEN",
    "THREE", "THREE.TrackballControls", "THREE.CSS3DRenderer"]
    , function (
        person,
        animation,
        network,
        store,
        hexCss,
        TWEEN,
        THREE) {

        var camera, scene, renderer;
        var controls;

        var objects = [];
        var activeQueue = [], _msgQueue = [], _checkinQueue = [], _msgHistory = [];
        var targets = { table: [], sphere: [], helix: [], grid: [] };
        var HONEYCOMBO_RATE = 6; // 1 : HONEYCOMBO_RATE
        var HEXAGON_SIZE = 300; // Hexagon width;
        var HEXAGON_PADDING = 6;

        const CAMERA_Z = 3500;
        const MESSAGE_Z = 2000;
        const COEFFICIENT = 3 / 7; // z轴初始系数
        var messageSize = 7; // 字体大小(em)
        const INTERVAL = 250; // 间隔
        const MESSAGEWIDTH = 218; //图片大小
        const MESSAGE_INTERVAL = 3000;
        const CHECKIN_INTERVAL = 15000;
        const SLIENCE_GAP = 60000 / MESSAGE_INTERVAL;
        const SLIENCE_INTERVAL = Math.ceil(10000 / MESSAGE_INTERVAL);

        String.prototype.gblen = function () {
            var len = 0;
            for (var i = 0; i < this.length; i++) {
                if (this.charCodeAt(i) > 127 || this.charCodeAt(i) == 94) {
                    len += 2;
                } else {
                    len++;
                }
            }
            return len;
        };

        function init() {


            camera = new THREE.PerspectiveCamera(45, window.innerWidth / window.innerHeight, 1, 10000);
            camera.position.z = 3500;

            scene = new THREE.Scene();

            // create hexagon stylesheet
            hexCss(HEXAGON_SIZE);
            // table

            for (var i = 0; i < person.length; i++) {

                var element = document.createElement('div');
                element.className = 'hexagon';
                element.innerHTML = '<div class="hexTop"></div><div class="hexBottom"></div>';
                element.style.backgroundImage = `url('${person[i].photo}')`;
                element.style.opacity = '.9';


                var object = new THREE.CSS3DObject(element);
                object.userId = person[i].id;
                object.name = person[i].name;
                object.position.x = Math.random() * 4000 - 2000;
                object.position.y = Math.random() * 4000 - 2000;
                object.position.z = Math.random() * 4000 - 2000;
                scene.add(object);


                objects.push(object);

            }

            // helix

            var vector = new THREE.Vector3();

            for (var i = 0, l = objects.length; i < l; i++) {

                var phi = i * 0.175 + Math.PI;

                var object = new THREE.Object3D();

                object.position.x = 900 * Math.sin(phi);
                object.position.y = - (i * 8);
                object.position.z = 900 * Math.cos(phi);

                vector.x = object.position.x * 2;
                vector.y = object.position.y;
                vector.z = object.position.z * 2;

                object.lookAt(vector);

                targets.helix.push(object);

            }

            //

            // table
            var eRow = Math.round(objects.length / HONEYCOMBO_RATE) || 1,
                eCol = HONEYCOMBO_RATE,
                item_w = HEXAGON_SIZE + HEXAGON_PADDING,
                item_h = Math.round(HEXAGON_SIZE / Math.sqrt(2) / 2 + HEXAGON_SIZE / Math.sqrt(3)) - HEXAGON_PADDING,
                // item_h = HEXAGON_SIZE,
                start_x = -(item_w / 2) * eRow,
                start_y = (item_h / 2) * eCol,
                hexagon_offset_x = item_w / 2,
                hexagon_offset_y = 0;
            for (var i = 0, l = objects.length; i < l; i++) {
                var object = new THREE.Object3D();
                object.position.x = start_x + (i % eRow) * item_w;
                object.position.y = start_y - Math.floor(i / eRow) * item_h;
                if (Math.floor(i / eRow) % 2 === 0) {
                    object.position.x = object.position.x + hexagon_offset_x;
                }
                // object.position.x = 0;
                // object.position.y = 0;


                targets.table.push(object);
            }

            renderer = new THREE.CSS3DRenderer();
            renderer.setSize(window.innerWidth, window.innerHeight);
            renderer.domElement.style.position = 'absolute';
            renderer.domElement.style.backgroundImage = 'url("./bk.jpg")';
            renderer.domElement.style.backgroundSize = 'contain';
            document.getElementById('container').appendChild(renderer.domElement);

            //

            controls = new THREE.TrackballControls(camera, renderer.domElement);
            controls.rotateSpeed = 0.5;
            controls.minDistance = 500;
            controls.maxDistance = 6000;
            controls.addEventListener('change', render);

            transform(targets.table, 2000);

            window.addEventListener('resize', onWindowResize, false);

        }

        var messageCount = 0;

        function sendMessage(id, message) {
            var idx = findUser(id, objects);
            if (idx >= 0) {
                var duration = 2000;

                var element = document.createElement('div');
                element.className = 'message';
                element.style.backgroundImage = `url('${person[idx].photo}')`;
<<<<<<< HEAD
                var messageContent = createMessageContent(message, messageCount);
=======
                var messageContent = createMessageContent(message, messageCount, objects[idx].name);
>>>>>>> baf200b688de5369d7046741d64379cd359c6d35
                element.appendChild(messageContent);

                var object = new THREE.CSS3DObject(element);
                object.userId = person[idx].id;
                object.position.x = targets.table[idx].position.x;
                object.position.y = targets.table[idx].position.y;
                object.position.z = targets.table[idx].position.z;
                scene.add(object);

                var position_y = 400;
                var interval = INTERVAL;
                if (activeQueue.length > 0) {
                    var messageContentDOM = document.querySelectorAll('.message-content');
                    if (messageContentDOM[messageContentDOM.length - 1].clientHeight > MESSAGEWIDTH) {
                        interval = messageContentDOM[messageContentDOM.length - 1].clientHeight + (INTERVAL - MESSAGEWIDTH);
                    }
                    position_y = (activeQueue[activeQueue.length - 1].position.y - interval) * COEFFICIENT / ((CAMERA_Z - MESSAGE_Z) / CAMERA_Z);
                }

                activeQueue.push(object);

                var messageTarget = new THREE.Vector3();
                switch (messageCount % 2) {
                    case 0: {
                        // element.className += ' left';
                        messageTarget.set(-650 / COEFFICIENT * ((CAMERA_Z - MESSAGE_Z) / CAMERA_Z), position_y / COEFFICIENT * ((CAMERA_Z - MESSAGE_Z) / CAMERA_Z), MESSAGE_Z);
                        break;
                    }
                    case 1: {
                        // element.className += ' right';
                        messageTarget.set(650 / COEFFICIENT * ((CAMERA_Z - MESSAGE_Z) / CAMERA_Z), position_y / COEFFICIENT * ((CAMERA_Z - MESSAGE_Z) / CAMERA_Z), MESSAGE_Z);
                        break;
                    }
                }

                new TWEEN.Tween(object.position)
                    .to(messageTarget, duration / 4)
                    .easing(TWEEN.Easing.Exponential.InOut)
                    .start().onComplete(function () {
                        var totalHeight = 0;
                        var content = document.querySelectorAll('.message-content');
                        for (var i = 0; i < content.length; i++) {

                            if (content[i].clientHeight > MESSAGEWIDTH) {
                                totalHeight += content[i].clientHeight;
                            } else {
                                totalHeight += MESSAGEWIDTH;
                            }
                            totalHeight += (INTERVAL - MESSAGEWIDTH);

                        }
                        totalHeight -= (INTERVAL - MESSAGEWIDTH);
                        if (totalHeight >= (INTERVAL * 3 + MESSAGEWIDTH)) {
                            var messageHeight = INTERVAL;
                            if (document.querySelectorAll('.message-content')[activeQueue.length - 1].clientHeight > MESSAGEWIDTH) {
                                messageHeight = document.querySelectorAll('.message-content')[activeQueue.length - 1].clientHeight + (INTERVAL - MESSAGEWIDTH);
                            }
                            if (activeQueue.length > 4) {
                                var deleteObj = activeQueue.shift();
                                scene.remove(deleteObj);
                            }
                            activeQueue.map(function (obj, index) {
                                var newTarget = new THREE.Vector3();
                                newTarget.copy(obj.position);
                                newTarget.y = newTarget.y + messageHeight / COEFFICIENT * ((CAMERA_Z - MESSAGE_Z) / CAMERA_Z);
                                new TWEEN.Tween(obj.position)
                                    .to(newTarget, duration / 2)
                                    .easing(TWEEN.Easing.Exponential.Out)
                                    .start()
                            });

                        }
                    });

                var target = targets.table[idx];
                new TWEEN.Tween(object.rotation)
                    .to({ x: target.rotation.x, y: target.rotation.y, z: target.rotation.z }, duration / 4)
                    .easing(TWEEN.Easing.Exponential.InOut)
                    .start();

                new TWEEN.Tween(this)
                    .to({}, duration * 2)
                    .onUpdate(render)
                    .start();

                messageCount++;

            }
        }

        function getMessageLine(message) {
            var line = [1, 2, 3, 4, 5, 6, 7, 8];
            const MESSAGE_LENGTH = message.gblen();
            if (MESSAGE_LENGTH >= 1 && MESSAGE_LENGTH < 6) {
                return line[0];
            }
            else if (MESSAGE_LENGTH >= 6 && MESSAGE_LENGTH < 12) {
                return line[1];
            }
            else if (MESSAGE_LENGTH >= 12 && MESSAGE_LENGTH < 18) {
                return line[2];
            }
            else if (MESSAGE_LENGTH >= 18 && MESSAGE_LENGTH < 24) {
                return line[3];
            }
            else {
                return 4.4;
            }
        }

        function createMessageContent(message, messageCount) {
            var msg = document.createElement('div');
            //var userName = document.createElement('span');
            //userName.className = 'userName';
            //userName.innerText = name+":";
            //msg.appendChild(userName);
            msg.className = 'message-content';
            var textNode = document.createTextNode(message);
            msg.appendChild(textNode);
            const MESSAGE_LENGTH = message.gblen();
            //if (MESSAGE_LENGTH > 20) {
            msg.style.width = 2000 / MESSAGE_Z * getMessageLine(message) * 100 + '%';
            //}


            if (messageCount % 2 == 0) {
                msg.style.left = '120%';
                msg.className += ' left';
            } else {
                msg.style.right = '120%';
                msg.className += ' right';
            }

            // var arrow = document.createElement('div');
            // arrow.className = 'arrow';
            // arrow.style.position = 'absolute';
            // arrow.style.top = '60px';
            // arrow.style.width = 0;
            // arrow.style.height = 0;
            // arrow.style.fontSize = 0;
            // arrow.style.border = 'solid 40px';
            // if (messageCount % 2 == 0) {
            //     arrow.style.borderColor = 'transparent rgba(255, 255, 255, 0.87) transparent transparent';
            //     arrow.style.left = -80 / (2000 / MESSAGE_Z) + 'px';
            // } else {
            //     arrow.style.borderColor = 'transparent  transparent transparent rgba(255, 255, 255, 0.87)';
            //     arrow.style.right = -80 / (2000 / MESSAGE_Z) + "px";
            // }

            return msg;
        }

        function findUser(userId, ary) {
            var ary = ary || objects;
            return ary.findIndex(function (obj) {
                return obj.userId === userId;
            });
        }

        function transform(targets, duration) {

            TWEEN.removeAll();

            for (var i = 0; i < objects.length; i++) {

                var object = objects[i];
                var target = targets[i];

                new TWEEN.Tween(object.position)
                    .to({ x: target.position.x, y: target.position.y, z: target.position.z }, Math.random() * duration + duration)
                    .easing(TWEEN.Easing.Exponential.InOut)
                    .start();

                new TWEEN.Tween(object.rotation)
                    .to({ x: target.rotation.x, y: target.rotation.y, z: target.rotation.z }, Math.random() * duration + duration)
                    .easing(TWEEN.Easing.Exponential.InOut)
                    .start();

            }

            new TWEEN.Tween(this)
                .to({}, duration * 2)
                .onUpdate(render)
                .start();

        }

        function onWindowResize() {

            camera.aspect = window.innerWidth / window.innerHeight;
            camera.updateProjectionMatrix();

            renderer.setSize(window.innerWidth, window.innerHeight);

            render();

        }
        var angle = 0;
        var span = 2 * Math.PI / 3000;

        function animate() {
            var crossVector = new THREE.Vector3().crossVectors(camera.up, camera.position);

            requestAnimationFrame(animate);

            TWEEN.update();

            myAnimate();

            controls.update();
        }

        function myAnimate() {
        }

        function render() {

            renderer.render(scene, camera);

        }

        function userMessage(id, message) {
            var idx = findUser(id, objects);

            // create message dom
            var domMsg = createMessage(message);


            // create target user animations

            activeQueue.push(objects[idx]);

            moveActiveQueue(activeQueue, domMsg, idx);

            var timer = setTimeout(function () {
                // remove message
                objects[idx].element.lastElementChild.remove();
                activeQueue.shift();

                new TWEEN.Tween(objects[idx].position)
                    .to(targets.helix[idx].position, 2000)
                    .easing(TWEEN.Easing.Exponential.InOut)
                    .start();

                new TWEEN.Tween(objects[idx].rotation)
                    .to({ x: targets.helix[idx].rotation.x, y: targets.helix[idx].rotation.y, z: targets.helix[idx].rotation.z }, 2000)
                    .easing(TWEEN.Easing.Exponential.InOut)
                    .start();
            }, 6000);

        }

        function moveActiveQueue(activeQueue, domMsg, index) {
            if (activeQueue && activeQueue.length > 0) {
                if (activeQueue.length == 1) {
                    new TWEEN.Tween(activeQueue[0].position)
                        .to(new THREE.Vector3(0, 0, 0), 2000)
                        .easing(TWEEN.Easing.Exponential.InOut)
                        .start().onComplete(function () {
                            if (activeQueue[0] && activeQueue[0].element) {
                                activeQueue[0].element.appendChild(domMsg);
                            }
                        });
                    return;
                }
                for (var i in activeQueue) {
                    var NewX = i % 2 == 0 ? -120 * ((i + 1) % 2) : 120 * ((i + 1) % 2);
                    var NewY = Math.floor(i / 2) * 260 - 180;
                    var phi = index * 0.125 + Math.PI;
                    new TWEEN.Tween(activeQueue[i].position)
                        .to(new THREE.Vector3(NewX, NewY, 0), 2000)
                        .easing(TWEEN.Easing.Exponential.InOut)
                        .start().onComplete(function () {
                            if (activeQueue[i] && activeQueue[i].element) {
                                activeQueue[i].element.appendChild(domMsg);
                            }
                        });

                }
            }
        }

        function createMessage(message) {
            var msg = document.createElement('div');
            msg.className = 'message';
            msg.textContent = message;
            msg.style.position = 'absolute';
            msg.style.top = '-75px';
            msg.style.color = '#fff';
            msg.style.width = '100%';
            msg.style.background = 'darkorange';
            msg.style.padding = '5px';
            msg.style.borderRadius = '5px';

            // create arrow
            var arrow = createArrow();

            msg.appendChild(arrow);
            return msg;
        }

        function createArrow() {
            var arrow = document.createElement('div');
            arrow.className = 'arrow';
            arrow.style.position = 'absolute';
            arrow.style.bottom = '-18px';
            // arrow.style.top = '5px';
            arrow.style.width = 0;
            arrow.style.height = 0;
            arrow.style.fontSize = 0;
            arrow.style.border = 'solid 10px';
            arrow.style.borderColor = 'darkorange transparent transparent';
            return arrow;
        }


        // initial data and start interval
        network.userList(function (data) {
            person = data;
            var slienceCount = 0, idx = 0;
            init();
            animate();
<<<<<<< HEAD
            setInterval(function () {
                network.realtime(function (message, checkin) {
                    if (message.length === 0) {
                        slienceCount++;
                        // when no one talks for 60s, get a random msg from history message queue
                        if (slienceCount >= 10 && slienceCount % 2 === 0) {
                            idx = Math.floor(Math.random() * _msgHistory.length);
                            _msgQueue = _msgQueue.concat(_msgHistory[idx]);
=======

            // first realtime api for history message
            network.realtime(function (message) {
                _msgHistory = _msgHistory.concat(message);
                setInterval(function () {
                    network.realtime(function (message, checkin) {
                        if (message.length === 0) {
                            slienceCount++;
                            // when no one talks for 60s, get a random msg from history message queue
                            if (slienceCount >= SLIENCE_GAP && slienceCount % SLIENCE_INTERVAL === 0) {
                                _msgQueue = _msgQueue.concat(_msgHistory[idx]);
                                idx = idx + 1 < _msgHistory.length ? idx + 1 : 0;
                            }
                        } else {
                            slienceCount = 0;
                            idx = 0;
>>>>>>> baf200b688de5369d7046741d64379cd359c6d35
                        }
                        _msgQueue = _msgQueue.concat(message);
                        _msgHistory = _msgHistory.concat(message);
                        if (_msgHistory.length > 30) {
                            var totalMsgCount = _msgHistory.length;
                            _msgHistory = _msgHistory.slice(totalMsgCount - 31, totalMsgCount - 1);
                        }
                        if (checkin.length > 0) {
                            setTimeout(function () {
                                _checkinQueue = _checkinQueue.concat(checkin);
                            }, 3000);
                        }
                    });
                }, 1000);
            });

            setInterval(function () {
                var msgContent = _msgQueue.shift();
                if (msgContent) {
                    sendMessage(msgContent.user.id, msgContent.content);
                }
            }, MESSAGE_INTERVAL);

            setInterval(function () {
                var checkinContent = _checkinQueue.shift();
                if (checkinContent) {
                    var targetObject = objects[findUser(checkinContent.user.id, objects)];
                    animation.emphasis(camera, targetObject);
                    animation.rotate(render,targetObject);
                }
            }, CHECKIN_INTERVAL);
        });
    });