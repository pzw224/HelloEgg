define(function () {
    var styleElem;

    const SCALE_FACTOR = Math.tan(30 * Math.PI / 180);
    const borderWidth = 0;

    var getHeight = function (width) {
        return width / Math.sqrt(3);
    };

    var getOffset = function (width) {
        return width / Math.sqrt(2) / 2;
    };

    var getCapWidth = function (width) {
        return width / Math.sqrt(2);
    };

    var getBorderOffset = function (borderWidth) {
        return borderWidth / Math.sqrt(3);
    };

    var borderRule = function () {

    };

    var shadowRule = function () {

    };

    return function (size) {
        var hexStyle = `
.hexagon{
    position: relative;
    width: ${size}px;
    height: ${getHeight(size).toFixed(2)}px;
    margin: ${(getHeight(size) / 2).toFixed(2)}px 0;
    background-size: auto ${(getHeight(size) * 2 - getBorderOffset(borderWidth) * 4).toFixed(4)}px;
    background-position: center; 
}
.hexTop,
.hexBottom {
    position: absolute;
    z-index: 1;
    width: ${getCapWidth(size).toFixed(2)}px;
    height: ${getCapWidth(size).toFixed(2)}px;
    overflow: hidden;
    -webkit-transform: scaleY(${SCALE_FACTOR.toFixed(4)}) rotate(-45deg);
    -ms-transform: scaleY(${SCALE_FACTOR.toFixed(4)}) rotate(-45deg);
    transform: scaleY(${SCALE_FACTOR.toFixed(4)}) rotate(-45deg);
    background: inherit;
    left: ${((size - getCapWidth(size)) / 2 - borderWidth).toFixed(2)}px;
}
.hexTop:after,
.hexBottom:after  {
    content: "";
    position: absolute;
    width: ${(size - (borderWidth * 2)).toFixed(4)}px;
    height: ${getHeight(size) - (borderWidth * SCALE_FACTOR * 2)}px;
    -webkit-transform:  rotate(45deg) scaleY(${(1 / SCALE_FACTOR).toFixed(4)}) translateY(${(-getHeight(size) / 2 + getBorderOffset(borderWidth)).toFixed(4)}px);
    -ms-transform: rotate(45deg) scaleY(${(1 / SCALE_FACTOR).toFixed(4)}) translateY(${(-getHeight(size) / 2 + getBorderOffset(borderWidth)).toFixed(4)}px);
    transform: rotate(45deg) scaleY(${(1 / SCALE_FACTOR).toFixed(4)}) translateY(${(-getHeight(size) / 2 + getBorderOffset(borderWidth)).toFixed(4)}px);
    -webkit-transform-origin: 0 0;
    -ms-transform-origin: 0 0;
    transform-origin: 0 0;
    background: inherit;
}
.hexTop { 
    top: ${-getOffset(size).toFixed(4)}px; 
}
.hexTop:after {
    background-position: center top;
}
.hexBottom {
    bottom:  ${-getOffset(size).toFixed(4)}px; 
}
.hexBottom:after { 
    background-position: center bottom;
}
.hexagon:after {
    content: "";
    position: absolute;
    top: ${(borderWidth * SCALE_FACTOR).toFixed(4)}px;
    left: 0;
    width: ${(size - borderWidth * 2).toFixed(4)}px;
    height: ${(getHeight(size) - borderWidth * SCALE_FACTOR * 2).toFixed(4)}px;
    z-index: 2;
    background: inherit;
}
.message{
    width:${218}px;
    height: ${218}px;
}
    `;
        if (styleElem = document.getElementById('hex-style')) {
            styleElem.innerHTML = hexStyle;
        } else {
            var style = document.createElement('style');
            style.id = 'hex-style';
            style.type = 'text/css';
            style.innerHTML = hexStyle;
            document.getElementsByTagName('head')[0].appendChild(style);
        }
    };
});
// .hexagon:after,
// .hexTop:after,
// .hexBottom:after{
//     filter:blur(5px);
// }