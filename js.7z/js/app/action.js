define({
    INIT_USER: "INIT_USER",
    NEW_USER: "NEW_USER",
    NEW_MESSAGE: "NEW_MESSAGE",
    initUser: function (userList) {
        return {
            type: INIT_USER,
            data: userList
        };
    },
    newUser: function (user) {
        return {
            type: NEW_USER,
            data: user
        };
    },
    newMessage: function (message) {
        return {
            type: NEW_MESSAGE,
            data: message
        };
    }
});