define(function() {
    var User = function(user) {
        this.id = user.OpenId;
        this.name = user.Remark;
        this.photo = user.HeadImageUrl;
    };

    var Message = function(msg) {
        this.id = msg.Id;
        this.type = msg.SendFrom === "newegg" ? 0 : 1;  // 0:checkin,1:text
        this.content = msg.Content;
        this.user = new User(msg.User);
    };

    return {
        User: User,
        Message: Message
    };
});