define(function () {
    return [
        {
            "id": 1,
            "name": "person1",
            "photo": "./img/01.jpg"
        },
        {
            "id": 2,
            "name": "person2",
            "photo": "./img/02.jpg"
        },
        {
            "id": 3,
            "name": "person3",
            "photo": "./img/03.jpg"
        },
        {
            "id": 4,
            "name": "person4",
            "photo": "./img/04.jpg"
        },
        {
            "id": 5,
            "name": "person5",
            "photo": "./img/05.jpg"
        },
        {
            "id": 6,
            "name": "person6",
            "photo": "./img/06.jpg"
        },
        {
            "id": 7,
            "name": "person7",
            "photo": "./img/07.jpg"
        },
        {
            "id": 8,
            "name": "person8",
            "photo": "./img/08.jpg"
        },
        {
            "id": 9,
            "name": "person9",
            "photo": "./img/01.jpg"
        },
        {
            "id": 10,
            "name": "person10",
            "photo": "./img/10.jpg"
        },
        {
            "id": 11,
            "name": "person11",
            "photo": "./img/11.jpg"
        },
        {
            "id": 12,
            "name": "person12",
            "photo": "./img/12.jpg"
        },
        {
            "id": 13,
            "name": "person13",
            "photo": "./img/13.jpg"
        },
        {
            "id": 14,
            "name": "person14",
            "photo": "./img/14.jpg"
        },
        {
            "id": 15,
            "name": "person15",
            "photo": "./img/15.jpg"
        },
        {
            "id": 16,
            "name": "person16",
            "photo": "./img/16.jpg"
        },
        {
            "id": 17,
            "name": "person17",
            "photo": "./img/17.jpg"
        },
        {
            "id": 18,
            "name": "person18",
            "photo": "./img/18.jpg"
        },
        {
            "id": 19,
            "name": "person19",
            "photo": "./img/19.jpg"
        },
        {
            "id": 20,
            "name": "person20",
            "photo": "./img/20.jpg"
        },
        {
            "id": 21,
            "name": "person21",
            "photo": "./img/21.jpg"
        },
        {
            "id": 22,
            "name": "person22",
            "photo": "./img/22.jpg"
        },
        {
            "id": 23,
            "name": "person23",
            "photo": "./img/23.jpg"
        },
        {
            "id": 24,
            "name": "person24",
            "photo": "./img/24.jpg"
        },
        {
            "id": 25,
            "name": "person25",
            "photo": "./img/25.jpg"
        },
        {
            "id": 26,
            "name": "person26",
            "photo": "./img/26.jpg"
        },
        {
            "id": 27,
            "name": "person27",
            "photo": "./img/27.jpg"
        },
        {
            "id": 28,
            "name": "person28",
            "photo": "./img/28.jpg"
        },
        {
            "id": 29,
            "name": "person29",
            "photo": "./img/29.jpg"
        },
        {
            "id": 30,
            "name": "person30",
            "photo": "./img/30.jpg"
        },
        {
            "id": 31,
            "name": "person31",
            "photo": "./img/31.jpg"
        },
        {
            "id": 32,
            "name": "person32",
            "photo": "./img/32.jpg"
        },
        {
            "id": 33,
            "name": "person33",
            "photo": "./img/33.jpg"
        },
        {
            "id": 34,
            "name": "person34",
            "photo": "./img/34.jpg"
        },
        {
            "id": 35,
            "name": "person35",
            "photo": "./img/35.jpg"
        },
        {
            "id": 36,
            "name": "person36",
            "photo": "./img/36.jpg"
        },
        {
            "id": 37,
            "name": "person37",
            "photo": "./img/37.jpg"
        },
        {
            "id": 38,
            "name": "person38",
            "photo": "./img/38.jpg"
        },
        {
            "id": 39,
            "name": "person39",
            "photo": "./img/39.jpg"
        },
        {
            "id": 40,
            "name": "person40",
            "photo": "./img/40.jpg"
        },
        {
            "id": 41,
            "name": "person41",
            "photo": "./img/41.jpg"
        },
        {
            "id": 42,
            "name": "person42",
            "photo": "./img/42.jpg"
        },
        {
            "id": 43,
            "name": "person43",
            "photo": "./img/43.jpg"
        },
        {
            "id": 44,
            "name": "person44",
            "photo": "./img/44.jpg"
        },
        {
            "id": 45,
            "name": "person45",
            "photo": "./img/45.jpg"
        },
        {
            "id": 46,
            "name": "person46",
            "photo": "./img/46.jpg"
        },
        {
            "id": 47,
            "name": "person47",
            "photo": "./img/47.jpg"
        },
        {
            "id": 48,
            "name": "person48",
            "photo": "./img/48.jpg"
        },
        {
            "id": 49,
            "name": "person49",
            "photo": "./img/49.jpg"
        },
        {
            "id": 50,
            "name": "person50",
            "photo": "./img/50.jpg"
        },
        {
            "id": 51,
            "name": "person51",
            "photo": "./img/51.jpg"
        },
        {
            "id": 52,
            "name": "person52",
            "photo": "./img/52.jpg"
        },
        {
            "id": 53,
            "name": "person53",
            "photo": "./img/53.jpg"
        },
        {
            "id": 54,
            "name": "person54",
            "photo": "./img/54.jpg"
        },
        {
            "id": 55,
            "name": "person55",
            "photo": "./img/55.jpg"
        },
        {
            "id": 56,
            "name": "person56",
            "photo": "./img/56.jpg"
        },
        {
            "id": 57,
            "name": "person57",
            "photo": "./img/57.jpg"
        },
        {
            "id": 58,
            "name": "person58",
            "photo": "./img/58.jpg"
        },
        {
            "id": 59,
            "name": "person59",
            "photo": "./img/59.jpg"
        },
        {
            "id": 60,
            "name": "person59",
            "photo": "./img/60.jpg"
        },
        // {
        //     "id": 1,
        //     "name": "person1",
        //     "photo": "./img/01.jpg"
        // },
        // {
        //     "id": 2,
        //     "name": "person2",
        //     "photo": "./img/02.jpg"
        // },
        // {
        //     "id": 3,
        //     "name": "person3",
        //     "photo": "./img/03.jpg"
        // },
        // {
        //     "id": 4,
        //     "name": "person4",
        //     "photo": "./img/04.jpg"
        // },
        // {
        //     "id": 5,
        //     "name": "person5",
        //     "photo": "./img/05.jpg"
        // },
        // {
        //     "id": 6,
        //     "name": "person6",
        //     "photo": "./img/06.jpg"
        // },
        // {
        //     "id": 7,
        //     "name": "person7",
        //     "photo": "./img/07.jpg"
        // },
        // {
        //     "id": 8,
        //     "name": "person8",
        //     "photo": "./img/08.jpg"
        // },
        // {
        //     "id": 9,
        //     "name": "person9",
        //     "photo": "./img/01.jpg"
        // },
        // {
        //     "id": 10,
        //     "name": "person10",
        //     "photo": "./img/10.jpg"
        // },
        // {
        //     "id": 11,
        //     "name": "person11",
        //     "photo": "./img/11.jpg"
        // },
        // {
        //     "id": 12,
        //     "name": "person12",
        //     "photo": "./img/12.jpg"
        // },
        // {
        //     "id": 13,
        //     "name": "person13",
        //     "photo": "./img/13.jpg"
        // },
        // {
        //     "id": 14,
        //     "name": "person14",
        //     "photo": "./img/14.jpg"
        // },
        // {
        //     "id": 15,
        //     "name": "person15",
        //     "photo": "./img/15.jpg"
        // },
        // {
        //     "id": 16,
        //     "name": "person16",
        //     "photo": "./img/16.jpg"
        // },
        // {
        //     "id": 17,
        //     "name": "person17",
        //     "photo": "./img/17.jpg"
        // },
        // {
        //     "id": 18,
        //     "name": "person18",
        //     "photo": "./img/18.jpg"
        // },
        // {
        //     "id": 19,
        //     "name": "person19",
        //     "photo": "./img/19.jpg"
        // },
        // {
        //     "id": 20,
        //     "name": "person20",
        //     "photo": "./img/20.jpg"
        // },
        // {
        //     "id": 21,
        //     "name": "person21",
        //     "photo": "./img/21.jpg"
        // },
        // {
        //     "id": 22,
        //     "name": "person22",
        //     "photo": "./img/22.jpg"
        // },
        // {
        //     "id": 23,
        //     "name": "person23",
        //     "photo": "./img/23.jpg"
        // },
        // {
        //     "id": 24,
        //     "name": "person24",
        //     "photo": "./img/24.jpg"
        // },
        // {
        //     "id": 25,
        //     "name": "person25",
        //     "photo": "./img/25.jpg"
        // },
        // {
        //     "id": 26,
        //     "name": "person26",
        //     "photo": "./img/26.jpg"
        // },
        // {
        //     "id": 27,
        //     "name": "person27",
        //     "photo": "./img/27.jpg"
        // },
        // {
        //     "id": 28,
        //     "name": "person28",
        //     "photo": "./img/28.jpg"
        // },
        // {
        //     "id": 29,
        //     "name": "person29",
        //     "photo": "./img/29.jpg"
        // },
        // {
        //     "id": 30,
        //     "name": "person30",
        //     "photo": "./img/30.jpg"
        // },
        // {
        //     "id": 31,
        //     "name": "person31",
        //     "photo": "./img/31.jpg"
        // },
        // {
        //     "id": 32,
        //     "name": "person32",
        //     "photo": "./img/32.jpg"
        // },
        // {
        //     "id": 33,
        //     "name": "person33",
        //     "photo": "./img/33.jpg"
        // },
        // {
        //     "id": 34,
        //     "name": "person34",
        //     "photo": "./img/34.jpg"
        // },
        // {
        //     "id": 35,
        //     "name": "person35",
        //     "photo": "./img/35.jpg"
        // },
        // {
        //     "id": 36,
        //     "name": "person36",
        //     "photo": "./img/36.jpg"
        // },
        // {
        //     "id": 37,
        //     "name": "person37",
        //     "photo": "./img/37.jpg"
        // },
        // {
        //     "id": 38,
        //     "name": "person38",
        //     "photo": "./img/38.jpg"
        // },
        // {
        //     "id": 39,
        //     "name": "person39",
        //     "photo": "./img/39.jpg"
        // },
        // {
        //     "id": 40,
        //     "name": "person40",
        //     "photo": "./img/40.jpg"
        // },
        // {
        //     "id": 41,
        //     "name": "person41",
        //     "photo": "./img/41.jpg"
        // },
        // {
        //     "id": 42,
        //     "name": "person42",
        //     "photo": "./img/42.jpg"
        // },
        // {
        //     "id": 43,
        //     "name": "person43",
        //     "photo": "./img/43.jpg"
        // },
        // {
        //     "id": 44,
        //     "name": "person44",
        //     "photo": "./img/44.jpg"
        // },
        // {
        //     "id": 45,
        //     "name": "person45",
        //     "photo": "./img/45.jpg"
        // },
        // {
        //     "id": 46,
        //     "name": "person46",
        //     "photo": "./img/46.jpg"
        // },
        // {
        //     "id": 47,
        //     "name": "person47",
        //     "photo": "./img/47.jpg"
        // },
        // {
        //     "id": 48,
        //     "name": "person48",
        //     "photo": "./img/48.jpg"
        // },
        // {
        //     "id": 49,
        //     "name": "person49",
        //     "photo": "./img/49.jpg"
        // },
        // {
        //     "id": 50,
        //     "name": "person50",
        //     "photo": "./img/50.jpg"
        // },
        // {
        //     "id": 51,
        //     "name": "person51",
        //     "photo": "./img/51.jpg"
        // },
        // {
        //     "id": 52,
        //     "name": "person52",
        //     "photo": "./img/52.jpg"
        // },
        // {
        //     "id": 53,
        //     "name": "person53",
        //     "photo": "./img/53.jpg"
        // },
        // {
        //     "id": 54,
        //     "name": "person54",
        //     "photo": "./img/54.jpg"
        // },
        // {
        //     "id": 55,
        //     "name": "person55",
        //     "photo": "./img/55.jpg"
        // },
        // {
        //     "id": 56,
        //     "name": "person56",
        //     "photo": "./img/56.jpg"
        // },
        // {
        //     "id": 57,
        //     "name": "person57",
        //     "photo": "./img/57.jpg"
        // },
        // {
        //     "id": 58,
        //     "name": "person58",
        //     "photo": "./img/58.jpg"
        // },
        // {
        //     "id": 59,
        //     "name": "person59",
        //     "photo": "./img/59.jpg"
        // },
        // {
        //     "id": 60,
        //     "name": "person59",
        //     "photo": "./img/60.jpg"
        // },
        // {
        //     "id": 1,
        //     "name": "person1",
        //     "photo": "./img/01.jpg"
        // },
        // {
        //     "id": 2,
        //     "name": "person2",
        //     "photo": "./img/02.jpg"
        // },
        // {
        //     "id": 3,
        //     "name": "person3",
        //     "photo": "./img/03.jpg"
        // },
        // {
        //     "id": 4,
        //     "name": "person4",
        //     "photo": "./img/04.jpg"
        // },
        // {
        //     "id": 5,
        //     "name": "person5",
        //     "photo": "./img/05.jpg"
        // },
        // {
        //     "id": 6,
        //     "name": "person6",
        //     "photo": "./img/06.jpg"
        // },
        // {
        //     "id": 7,
        //     "name": "person7",
        //     "photo": "./img/07.jpg"
        // },
        // {
        //     "id": 8,
        //     "name": "person8",
        //     "photo": "./img/08.jpg"
        // },
        // {
        //     "id": 9,
        //     "name": "person9",
        //     "photo": "./img/01.jpg"
        // },
        // {
        //     "id": 10,
        //     "name": "person10",
        //     "photo": "./img/10.jpg"
        // },
        // {
        //     "id": 11,
        //     "name": "person11",
        //     "photo": "./img/11.jpg"
        // },
        // {
        //     "id": 12,
        //     "name": "person12",
        //     "photo": "./img/12.jpg"
        // },
        // {
        //     "id": 13,
        //     "name": "person13",
        //     "photo": "./img/13.jpg"
        // },
        // {
        //     "id": 14,
        //     "name": "person14",
        //     "photo": "./img/14.jpg"
        // },
        // {
        //     "id": 15,
        //     "name": "person15",
        //     "photo": "./img/15.jpg"
        // },
        // {
        //     "id": 16,
        //     "name": "person16",
        //     "photo": "./img/16.jpg"
        // },
        // {
        //     "id": 17,
        //     "name": "person17",
        //     "photo": "./img/17.jpg"
        // },
        // {
        //     "id": 18,
        //     "name": "person18",
        //     "photo": "./img/18.jpg"
        // },
        // {
        //     "id": 19,
        //     "name": "person19",
        //     "photo": "./img/19.jpg"
        // },
        // {
        //     "id": 20,
        //     "name": "person20",
        //     "photo": "./img/20.jpg"
        // },
        // {
        //     "id": 21,
        //     "name": "person21",
        //     "photo": "./img/21.jpg"
        // },
        // {
        //     "id": 22,
        //     "name": "person22",
        //     "photo": "./img/22.jpg"
        // },
        // {
        //     "id": 23,
        //     "name": "person23",
        //     "photo": "./img/23.jpg"
        // },
        // {
        //     "id": 24,
        //     "name": "person24",
        //     "photo": "./img/24.jpg"
        // },
        // {
        //     "id": 25,
        //     "name": "person25",
        //     "photo": "./img/25.jpg"
        // },
        // {
        //     "id": 26,
        //     "name": "person26",
        //     "photo": "./img/26.jpg"
        // },
        // {
        //     "id": 27,
        //     "name": "person27",
        //     "photo": "./img/27.jpg"
        // },
        // {
        //     "id": 28,
        //     "name": "person28",
        //     "photo": "./img/28.jpg"
        // },
        // {
        //     "id": 29,
        //     "name": "person29",
        //     "photo": "./img/29.jpg"
        // },
        // {
        //     "id": 30,
        //     "name": "person30",
        //     "photo": "./img/30.jpg"
        // },
        // {
        //     "id": 31,
        //     "name": "person31",
        //     "photo": "./img/31.jpg"
        // },
        // {
        //     "id": 32,
        //     "name": "person32",
        //     "photo": "./img/32.jpg"
        // },
        // {
        //     "id": 33,
        //     "name": "person33",
        //     "photo": "./img/33.jpg"
        // },
        // {
        //     "id": 34,
        //     "name": "person34",
        //     "photo": "./img/34.jpg"
        // },
        // {
        //     "id": 35,
        //     "name": "person35",
        //     "photo": "./img/35.jpg"
        // },
        // {
        //     "id": 36,
        //     "name": "person36",
        //     "photo": "./img/36.jpg"
        // },
        // {
        //     "id": 37,
        //     "name": "person37",
        //     "photo": "./img/37.jpg"
        // },
        // {
        //     "id": 38,
        //     "name": "person38",
        //     "photo": "./img/38.jpg"
        // },
        // {
        //     "id": 39,
        //     "name": "person39",
        //     "photo": "./img/39.jpg"
        // },
        // {
        //     "id": 40,
        //     "name": "person40",
        //     "photo": "./img/40.jpg"
        // },
        // {
        //     "id": 41,
        //     "name": "person41",
        //     "photo": "./img/41.jpg"
        // },
        // {
        //     "id": 42,
        //     "name": "person42",
        //     "photo": "./img/42.jpg"
        // },
        // {
        //     "id": 43,
        //     "name": "person43",
        //     "photo": "./img/43.jpg"
        // },
        // {
        //     "id": 44,
        //     "name": "person44",
        //     "photo": "./img/44.jpg"
        // },
        // {
        //     "id": 45,
        //     "name": "person45",
        //     "photo": "./img/45.jpg"
        // },
        // {
        //     "id": 46,
        //     "name": "person46",
        //     "photo": "./img/46.jpg"
        // },
        // {
        //     "id": 47,
        //     "name": "person47",
        //     "photo": "./img/47.jpg"
        // },
        // {
        //     "id": 48,
        //     "name": "person48",
        //     "photo": "./img/48.jpg"
        // },
        // {
        //     "id": 49,
        //     "name": "person49",
        //     "photo": "./img/49.jpg"
        // },
        // {
        //     "id": 50,
        //     "name": "person50",
        //     "photo": "./img/50.jpg"
        // },
        // {
        //     "id": 51,
        //     "name": "person51",
        //     "photo": "./img/51.jpg"
        // },
        // {
        //     "id": 52,
        //     "name": "person52",
        //     "photo": "./img/52.jpg"
        // },
        // {
        //     "id": 53,
        //     "name": "person53",
        //     "photo": "./img/53.jpg"
        // },
        // {
        //     "id": 54,
        //     "name": "person54",
        //     "photo": "./img/54.jpg"
        // },
        // {
        //     "id": 55,
        //     "name": "person55",
        //     "photo": "./img/55.jpg"
        // },
        // {
        //     "id": 56,
        //     "name": "person56",
        //     "photo": "./img/56.jpg"
        // },
        // {
        //     "id": 57,
        //     "name": "person57",
        //     "photo": "./img/57.jpg"
        // },
        // {
        //     "id": 58,
        //     "name": "person58",
        //     "photo": "./img/58.jpg"
        // },
        // {
        //     "id": 59,
        //     "name": "person59",
        //     "photo": "./img/59.jpg"
        // },
        // {
        //     "id": 60,
        //     "name": "person59",
        //     "photo": "./img/60.jpg"
        // },
        //  
    ];

})