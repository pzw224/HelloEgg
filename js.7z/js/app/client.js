var randHex = function(digit) {
    var hex = Math.floor((Math.random() * (Math.pow(0x10, digit) - 1))).toString(16);
    while (hex.length < digit) {
        hex = '0' + hex;
    }
    return hex.toUpperCase();
};

var guidCreator = function() {
    return randHex(8)
        + '-' + randHex(4)
        + '-' + randHex(4)
        + '-' + randHex(4)
        + '-' + randHex(12);
};

define(["../app/model", "jquery", "jquery.rest"], function(Model, $) {
    // var neapi = new $.RestClient("/neapi/");
    var _guid = guidCreator();
    return {
        userList: function(fn) {
            var client = new $.RestClient("/neapi/");
            client.add("records")
                .read({ queue: _guid, rand: Date.now() })
                .done(function(data) {
                    fn(data.map(function(user) {
                        return new Model.User(user.User);
                    }));
                });
        },
        realtime: function(fn) {
            var client = new $.RestClient("/neapi/");
            client.add("realtime")
                .read({ queue: _guid, rand: Date.now() })
                .done(function(data) {
                    var list = data.map(function(msg) {
                        return new Model.Message(msg);
                    });
                    fn(
                        list.filter(function(msg) {
                            return msg.type === 1;
                        }),
                        list.filter(function(msg) {
                            return msg.type === 0;
                        })
                    );
                });
        },
        command: function(fn) {
            var client = new $.RestClient("/neapi/");
            client.add("command")
                .read({ queue: _guid, rand: Date.now() })
                .done(function(data) {
                    fn(data);
                });
        },
    };
});
