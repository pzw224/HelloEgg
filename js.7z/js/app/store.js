define(['redux', '../app/action'], function (Redux, ACTION) {
    var userReducer = function (state=[], action) {
        switch (action.type) {
            case ACTION.INIT_USER:
                return state.concat(data);
            case ACTION.NEW_USER:
                return state.concat(data);
            default:
                return state;
        }
    };

    var msgReducer = function (state=[], action) {
        switch (action.type) {
            case ACTION.NEW_MESSAGE:
                return state.concat(action.data);
            default:
                return state;
        }
    };

    var reducer = Redux.combineReducers({
        userList: userReducer,
        messages: msgReducer
    });

    return Redux.createStore(reducer, { userList: [], messages: [] });
});
