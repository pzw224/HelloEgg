var person = [
    {
        "id": 1,
        "name": "person1",
        "photo": "01"
    },
    {
        "id": 2,
        "name": "person2",
        "photo": "02"
    },
    {
        "id": 3,
        "name": "person3",
        "photo": "03"
    },
    {
        "id": 4,
        "name": "person4",
        "photo": "04"
    },
    {
        "id": 5,
        "name": "person5",
        "photo": "05"
    },
    {
        "id": 6,
        "name": "person6",
        "photo": "06"
    },
    {
        "id": 7,
        "name": "person7",
        "photo": "07"
    },
    {
        "id": 8,
        "name": "person8",
        "photo": "08"
    },
    {
        "id": 9,
        "name": "person9",
        "photo": "01"
    },
    {
        "id": 10,
        "name": "person10",
        "photo": "10"
    },
    {
        "id": 11,
        "name": "person11",
        "photo": "11"
    },
    {
        "id": 12,
        "name": "person12",
        "photo": "12"
    },
    {
        "id": 13,
        "name": "person13",
        "photo": "13"
    },
    {
        "id": 14,
        "name": "person14",
        "photo": "14"
    },
    {
        "id": 15,
        "name": "person15",
        "photo": "15"
    },
    {
        "id": 16,
        "name": "person16",
        "photo": "16"
    },
    {
        "id": 17,
        "name": "person17",
        "photo": "17"
    },
    {
        "id": 18,
        "name": "person18",
        "photo": "18"
    },
    {
        "id": 19,
        "name": "person19",
        "photo": "19"
    },
    {
        "id": 20,
        "name": "person20",
        "photo": "20"
    },
    {
        "id": 21,
        "name": "person21",
        "photo": "21"
    },
    {
        "id": 22,
        "name": "person22",
        "photo": "22"
    },
    {
        "id": 23,
        "name": "person23",
        "photo": "23"
    },
    {
        "id": 24,
        "name": "person24",
        "photo": "24"
    },
    {
        "id": 25,
        "name": "person25",
        "photo": "25"
    },
    {
        "id": 26,
        "name": "person26",
        "photo": "26"
    },
    {
        "id": 27,
        "name": "person27",
        "photo": "27"
    },
    {
        "id": 28,
        "name": "person28",
        "photo": "28"
    },
    {
        "id": 29,
        "name": "person29",
        "photo": "29"
    },
    {
        "id": 30,
        "name": "person30",
        "photo": "30"
    },
    {
        "id": 31,
        "name": "person31",
        "photo": "31"
    },
    {
        "id": 32,
        "name": "person32",
        "photo": "32"
    },
    {
        "id": 33,
        "name": "person33",
        "photo": "33"
    },
    {
        "id": 34,
        "name": "person34",
        "photo": "34"
    },
    {
        "id": 35,
        "name": "person35",
        "photo": "35"
    },
    {
        "id": 36,
        "name": "person36",
        "photo": "36"
    },
    {
        "id": 37,
        "name": "person37",
        "photo": "37"
    },
    {
        "id": 38,
        "name": "person38",
        "photo": "38"
    },
    {
        "id": 39,
        "name": "person39",
        "photo": "39"
    },
    {
        "id": 40,
        "name": "person40",
        "photo": "40"
    },
    {
        "id": 41,
        "name": "person41",
        "photo": "41"
    },
    {
        "id": 42,
        "name": "person42",
        "photo": "42"
    },
    {
        "id": 43,
        "name": "person43",
        "photo": "43"
    },
    {
        "id": 44,
        "name": "person44",
        "photo": "44"
    },
    {
        "id": 45,
        "name": "person45",
        "photo": "45"
    },
    {
        "id": 46,
        "name": "person46",
        "photo": "46"
    },
    {
        "id": 47,
        "name": "person47",
        "photo": "47"
    },
    {
        "id": 48,
        "name": "person48",
        "photo": "48"
    },
    {
        "id": 49,
        "name": "person49",
        "photo": "49"
    },
    {
        "id": 50,
        "name": "person50",
        "photo": "50"
    },
    {
        "id": 51,
        "name": "person51",
        "photo": "51"
    },
    {
        "id": 52,
        "name": "person52",
        "photo": "52"
    },
    {
        "id": 53,
        "name": "person53",
        "photo": "53"
    },
    {
        "id": 54,
        "name": "person54",
        "photo": "54"
    },
    {
        "id": 55,
        "name": "person55",
        "photo": "55"
    },
    {
        "id": 56,
        "name": "person56",
        "photo": "56"
    },
    {
        "id": 57,
        "name": "person57",
        "photo": "57"
    },
    {
        "id": 58,
        "name": "person58",
        "photo": "58"
    },
    {
        "id": 59,
        "name": "person59",
        "photo": "59"
    },
    {
        "id": 60,
        "name": "person59",
        "photo": "60"
    },
    {
        "id": 1,
        "name": "person1",
        "photo": "01"
    },
    {
        "id": 2,
        "name": "person2",
        "photo": "02"
    },
    {
        "id": 3,
        "name": "person3",
        "photo": "03"
    },
    {
        "id": 4,
        "name": "person4",
        "photo": "04"
    },
    {
        "id": 5,
        "name": "person5",
        "photo": "05"
    },
    {
        "id": 6,
        "name": "person6",
        "photo": "06"
    },
    {
        "id": 7,
        "name": "person7",
        "photo": "07"
    },
    {
        "id": 8,
        "name": "person8",
        "photo": "08"
    },
    {
        "id": 9,
        "name": "person9",
        "photo": "01"
    },
    {
        "id": 10,
        "name": "person10",
        "photo": "10"
    },
    {
        "id": 11,
        "name": "person11",
        "photo": "11"
    },
    {
        "id": 12,
        "name": "person12",
        "photo": "12"
    },
    {
        "id": 13,
        "name": "person13",
        "photo": "13"
    },
    {
        "id": 14,
        "name": "person14",
        "photo": "14"
    },
    {
        "id": 15,
        "name": "person15",
        "photo": "15"
    },
    {
        "id": 16,
        "name": "person16",
        "photo": "16"
    },
    {
        "id": 17,
        "name": "person17",
        "photo": "17"
    },
    {
        "id": 18,
        "name": "person18",
        "photo": "18"
    },
    {
        "id": 19,
        "name": "person19",
        "photo": "19"
    },
    {
        "id": 20,
        "name": "person20",
        "photo": "20"
    },
    {
        "id": 21,
        "name": "person21",
        "photo": "21"
    },
    {
        "id": 22,
        "name": "person22",
        "photo": "22"
    },
    {
        "id": 23,
        "name": "person23",
        "photo": "23"
    },
    {
        "id": 24,
        "name": "person24",
        "photo": "24"
    },
    {
        "id": 25,
        "name": "person25",
        "photo": "25"
    },
    {
        "id": 26,
        "name": "person26",
        "photo": "26"
    },
    {
        "id": 27,
        "name": "person27",
        "photo": "27"
    },
    {
        "id": 28,
        "name": "person28",
        "photo": "28"
    },
    {
        "id": 29,
        "name": "person29",
        "photo": "29"
    },
    {
        "id": 30,
        "name": "person30",
        "photo": "30"
    },
    {
        "id": 31,
        "name": "person31",
        "photo": "31"
    },
    {
        "id": 32,
        "name": "person32",
        "photo": "32"
    },
    {
        "id": 33,
        "name": "person33",
        "photo": "33"
    },
    {
        "id": 34,
        "name": "person34",
        "photo": "34"
    },
    {
        "id": 35,
        "name": "person35",
        "photo": "35"
    },
    {
        "id": 36,
        "name": "person36",
        "photo": "36"
    },
    {
        "id": 37,
        "name": "person37",
        "photo": "37"
    },
    {
        "id": 38,
        "name": "person38",
        "photo": "38"
    },
    {
        "id": 39,
        "name": "person39",
        "photo": "39"
    },
    {
        "id": 40,
        "name": "person40",
        "photo": "40"
    },
    {
        "id": 41,
        "name": "person41",
        "photo": "41"
    },
    {
        "id": 42,
        "name": "person42",
        "photo": "42"
    },
    {
        "id": 43,
        "name": "person43",
        "photo": "43"
    },
    {
        "id": 44,
        "name": "person44",
        "photo": "44"
    },
    {
        "id": 45,
        "name": "person45",
        "photo": "45"
    },
    {
        "id": 46,
        "name": "person46",
        "photo": "46"
    },
    {
        "id": 47,
        "name": "person47",
        "photo": "47"
    },
    {
        "id": 48,
        "name": "person48",
        "photo": "48"
    },
    {
        "id": 49,
        "name": "person49",
        "photo": "49"
    },
    {
        "id": 50,
        "name": "person50",
        "photo": "50"
    },
    {
        "id": 51,
        "name": "person51",
        "photo": "51"
    },
    {
        "id": 52,
        "name": "person52",
        "photo": "52"
    },
    {
        "id": 53,
        "name": "person53",
        "photo": "53"
    },
    {
        "id": 54,
        "name": "person54",
        "photo": "54"
    },
    {
        "id": 55,
        "name": "person55",
        "photo": "55"
    },
    {
        "id": 56,
        "name": "person56",
        "photo": "56"
    },
    {
        "id": 57,
        "name": "person57",
        "photo": "57"
    },
    {
        "id": 58,
        "name": "person58",
        "photo": "58"
    },
    {
        "id": 59,
        "name": "person59",
        "photo": "59"
    },
    {
        "id": 60,
        "name": "person59",
        "photo": "60"
    },
    //  
];

var camera, scene, renderer;
var controls;

var objects = [];
var activeQueue = [];
var targets = { table: [], sphere: [], helix: [], grid: [] };

init();
animate();

function init() {

    camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 1, 10000);
    camera.position.z = 500;
    scene = new THREE.Scene();

    // table

    // for (var i = 0; i < table.length; i += 5) {
    for (var i = 0; i < person.length; i++) {

        var element = document.createElement('div');
        element.className = 'element';
        element.style.backgroundColor = 'rgba(0,127,127,' + (Math.random() * 0.5 + 0.25) + ')';

        var avatar = document.createElement('img');
        avatar.className = 'avatar';
        avatar.src = `./photos/${person[i].photo}.jpg`;
        avatar.style = 'height:110px;width:110px;border-radius: 55px;margin-top:5px;';
        element.appendChild(avatar);

        var name = document.createElement('div');
        name.className = 'details';
        name.textContent = person[i].name;
        element.appendChild(name);

        var object = new THREE.CSS3DObject(element);
        object.userId = person[i].id;
        object.position.x = Math.random() * 4000 - 2000;
        object.position.y = Math.random() * 4000 - 2000;
        object.position.z = Math.random() * 4000 - 2000;
        scene.add(object);

        objects.push(object);

    }

    // helix

    var vector = new THREE.Vector3();

    for (var i = 0, l = objects.length; i < l; i++) {

        var phi = i * 0.125 + Math.PI;

        var object = new THREE.Object3D();

        object.position.x = 1800 * Math.sin(phi);
        object.position.y = - (i * 8);
        object.position.z = 1800 * Math.cos(phi);

        vector.x = object.position.x * 2;
        vector.y = object.position.y;
        vector.z = object.position.z * 2;

        object.lookAt(vector);

        targets.helix.push(object);

    }

    //

    renderer = new THREE.CSS3DRenderer();
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.domElement.style.position = 'absolute';
    document.getElementById('container').appendChild(renderer.domElement);

    //

    controls = new THREE.TrackballControls(camera, renderer.domElement);
    controls.rotateSpeed = 0.5;
    controls.minDistance = 500;
    controls.maxDistance = 6000;
    controls.addEventListener('change', render);

    transform(targets.helix, 2000);

    window.addEventListener('resize', onWindowResize, false);

}

function transform(targets, duration) {

    TWEEN.removeAll();

    for (var i = 0; i < objects.length; i++) {

        var object = objects[i];
        var target = targets[i];

        new TWEEN.Tween(object.position)
            .to({ x: target.position.x, y: target.position.y, z: target.position.z }, Math.random() * duration + duration)
            .easing(TWEEN.Easing.Exponential.InOut)
            .start();

        new TWEEN.Tween(object.rotation)
            .to({ x: target.rotation.x, y: target.rotation.y, z: target.rotation.z }, Math.random() * duration + duration)
            .easing(TWEEN.Easing.Exponential.InOut)
            .start();

    }

    new TWEEN.Tween(this)
        .to({}, duration * 2)
        .onUpdate(render)
        .start();

}

function onWindowResize() {

    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();

    renderer.setSize(window.innerWidth, window.innerHeight);

    render();

}
var angle = 0;
var span = 2 * Math.PI / 3000;

function animate() {

    requestAnimationFrame(animate);

    TWEEN.update();

    myAnimate();

    activeQueue.map(function (obj) {
        obj.lookAt(camera.position);
    });

    controls.update();
}

function myAnimate() {
}

function render() {

    renderer.render(scene, camera);

}

function findUser(userId, ary) {
    var ary = ary || objects;
    return ary.findIndex(function (obj) {
        return obj.userId === userId;
    });
}

function userMessage(id, message) {
    var idx = findUser(id, objects);

    // create message dom
    var domMsg = createMessage(message);


    // create target user animations

    activeQueue.push(objects[idx]);

    moveActiveQueue(activeQueue, domMsg, idx);

    var timer = setTimeout(function () {
        // remove message
        objects[idx].element.lastElementChild.remove();
        activeQueue.shift();

        new TWEEN.Tween(objects[idx].position)
            .to(targets.helix[idx].position, 2000)
            .easing(TWEEN.Easing.Exponential.InOut)
            .start();

        new TWEEN.Tween(objects[idx].rotation)
            .to({ x: targets.helix[idx].rotation.x, y: targets.helix[idx].rotation.y, z: targets.helix[idx].rotation.z }, 2000)
            .easing(TWEEN.Easing.Exponential.InOut)
            .start();
    }, 5000);

}

function moveActiveQueue(activeQueue, domMsg, index) {
    if (activeQueue && activeQueue.length > 0) {
        for (var i in activeQueue) {
            if (activeQueue.length == 1) {
                new TWEEN.Tween(activeQueue[i].position)
                    .to(new THREE.Vector3(0, 0, 0), 2000)
                    .easing(TWEEN.Easing.Exponential.InOut)
                    .start().onComplete(function () {
                        if (activeQueue[i] && activeQueue[i].element) {
                            activeQueue[i].element.appendChild(domMsg);
                        }
                    });
                return;
            }
            var NewX = i % 2 == 0 ? -120 * ((i + 1) % 2) : 120 * ((i + 1) % 2);
            var NewY = Math.floor(i / 2) * 260 - 180;
            var phi = index * 0.125 + Math.PI;
            new TWEEN.Tween(activeQueue[i].position)
                .to(new THREE.Vector3(NewX, NewY, Math.cos(phi)), 2000)
                .easing(TWEEN.Easing.Exponential.InOut)
                .start().onComplete(function () {
                    if (activeQueue[i] && activeQueue[i].element) {
                        activeQueue[i].element.appendChild(domMsg);
                    }
                });

        }
    }
}

function createMessage(message) {
    var msg = document.createElement('div');
    msg.className = 'message';
    msg.textContent = message;
    msg.style.position = 'absolute';
    msg.style.top = '-75px';
    msg.style.color = '#fff';
    msg.style.width = '100%';
    msg.style.background = 'darkorange';
    msg.style.padding = '5px';
    msg.style.borderRadius = '5px';

    // create arrow
    var arrow = createArrow();

    msg.appendChild(arrow);
    return msg;
}

function createArrow() {
    var arrow = document.createElement('div');
    arrow.className = 'arrow';
    arrow.style.position = 'absolute';
    arrow.style.bottom = '-18px';
    // arrow.style.top = '5px';
    arrow.style.width = 0;
    arrow.style.height = 0;
    arrow.style.fontSize = 0;
    arrow.style.border = 'solid 10px';
    arrow.style.borderColor = 'darkorange transparent transparent';
    return arrow;
}