# 简介
  <p>通过Angular2-seed构建了前端工程化包括开发、测试、发布，替代了原先的SHEC Navigation</p>
  <p>目前在客户端模拟了Ajax请求来获取数据，便于以后将数据维护到数据库中通过Service来获取数据</p>
  <p>UI框架采用了<a href="http://metroui.org.ua/" target="_blank">MetroUI</a>，这是一套Microsoft Metro风格的UI完美贴合win10</p>

# asstes/data.json
  <p>目前将所有的数据都存放在了data.json的文件中，可通过修改该文件对SHEC进行维护</p>
  <p>data.json的数据节点分成了两个打雷，分别为group和item</p>


## group
  group为分组，当一个节点的ParentID为*null*时表明该节点是一个group,其余字段可忽略

```json
{
    "MenuID": 4,                //Group的ID
    "EnableTitle": true,
    "Title": "工作辅助系统",     //改Group的名字
    "Link": null,
    "ParentID": null,           //null，表示该节点为一个Group节点
    "Tile": {
        "BackgroundColor": "blue",
        "FontColor": "white",
        "Size": null,
        "Type": 1,
        "TileIcon": {
            "Icon": "icon mif-cogs"
        },
        "TileImage": {
            "ImageUrl": "",
            "Description": "",
            "EnableDescription": false
        }
    }
}
```

## item
每个item都需要划分在一个Group里面，并且会把详细信息存放在Tile字段内
```json
{
        "MenuID": 108,
        "EnableTitle": false,                                           //是否显示标题
        "Title": "Solrcloud-Admin E3",                                  //当前Tile的标题
        "Link": "http://172.16.14.14:8651/solr/index.html#/~cloud",     //当前Tile的连接
        "ParentID": 100,                                                //当前的group
        "Tile": {
            "BackgroundColor": "blue",                                  //当前Tile的背景色
            "FontColor": "white text-small",                            //当前Tile内使用的字体样式
            "Size": 3,                                                  //表示当前Tile块的大小
            "Type": 2,                                                  //表示当前Tile块的类型
            "TileIcon": null,
            "TileImage": null,
            "TileCarousel": null
        }
    },
```
## item会根据分为三种类型,item会根据Tile内对应的字段获取该Tile所需要的信息


> Type=0: 
> Image(TileImage)——显示一张图片
```json
{
    "TileImage": {
        "ImageUrl": "java-melody.png",                              //图片路径，存放在asstes/images下
        "Description": "JSS-JavaMelody E3",                         //弹出描述
        "EnableDescription": true                                   //是否显示描述
    }
}
```
>Type=1: 
>logo(TileIcon)——一个Tile内有多个滚动的item
    一般用于内容相同属性不同的节点如同一个服务对应不同Service的监测
```json
{
    "TileIcon": {
        "Icon": "icon mif-html5"                                    //支持font-awesome
    }
}
```
>Type=2: 
>滚动(TileCarousel)
```json
{
    "TileCarousel": {                                               //该节点是一个数组
        "Images": [
            {
                "Name": "java-melody-E3.png",                       //图片存放地址
                "Url": "http://172.16.16.45:8850/javamelody",       //连接
                "Description": "JSS-Melody E3",                     //标题
                "EnableDescription": true                           //是否显示标题
            },
            {
                "Name": "java-melody-E4.png",
                "Url": "http://172.16.35.45:8850/javamelody",
                "Description": "JSS-Melody E4",
                "EnableDescription": true
            }
        ]
    }
}
```

## 快速开始
  ```bash
  npm install --安装依赖集
  npm start --启动
  npm build.prod --打包发布

  更多信息请参考package.json
  ```

## 目录结构
```
├── LICENSE
├── README.md
├── gulpfile.ts                               <- gulp tasks
├── package.json                              <- 第三方依赖
├── src                                       <- 应用源文件
│   └── client
│       ├── app
│       │   ├── +components                   <-组件
│       │   │   ├── index.ts
│       │   │   └── ...
│       │   ├── +header
│       │   │   ├── header.component.ts
│       │   │   ├── header.component.html
│       │   ├── +service                      <-数据
│       │   ├── ...
│       │   ├── +models                       <-数据模型
│       │   ├── ...
│       │   ├── shared
│       │   ├── shared
│       │   │   ├── biz
│       │   │   │   ├── entity.manager.ts
│       │   │   │   └── local-storage.manager.ts
│       │   │   └── config
│       │   │       └── env.config.ts
│       │   ├── app.component.ts
│       │   └── main.ts
│       ├── assets
│       │   ├── data.json
│       │   └── svg
│       │       └── more.svg
│       ├── css
│       │   └── main.css
│       └── index.html
├── tools
│   ├── tasks                  <- gulp tasks
│   │     └── ...
│   ├── utils                  <- build utils
│   │     └── ...
│   └── utils.ts
├── typings                    <- typescript 第三方依赖
├── typings.json
└── appveyor.yml
```


## TODO List
1.  `更改主题颜色功能`
    <p> 通过选取颜色后将用户的选择保存在localStorage里面，并且刷新页面 </p>
    <p> 当用户刷新页面时，在渲染页面前会先获取用户localStorage信息来控制颜色 </p>

2.  `Search功能`
    <p>用户可通过搜索获取组群或者是相似的item</p>

3.  `Small Tile Auto Fix Algorithm`
    <p>目前由于MetroUI的问题，导致使用最小方块*TileType=1*时会因流失布局而造成排版混乱，只能认为控制其排列</p>
    <p>通过计算每个组内的各种方块大小实现一套自适应优化算法</p>