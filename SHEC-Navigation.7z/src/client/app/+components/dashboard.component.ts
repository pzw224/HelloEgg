import { Component, Input, OnInit } from '@angular/core';
import { SHECNaviBoard, XMLSHECItem, TileConfig } from '../models/index';
import { DashboardItemComponent } from './dashboard-item.component';
import { EntityManager, LocalStorageManager, LS_USER_CLICK_LIST } from '../shared/index';
import { NaviItemService, BusinessService } from '../+service/index';

enum MetroGroupSize {
    one = 1,
    double = 2,
    triple = 3,
    quadro = 4,
    five = 5,
    six = 6,
    seven = 7
}

const WIDTH_SINGLE_BLOCK = 160;
const WIDTH_BLOCK_GAP = 80;

@Component({
    selector: 'shec-dashboard',
    templateUrl: 'dashboard.component.html',
    directives: [DashboardItemComponent]
})

export class DashboardComponent implements OnInit {
    boardList: Array<SHECNaviBoard> = [];
    xmlList: Array<XMLSHECItem> = [];
    globalConfig: TileConfig = {} as TileConfig;

    constructor(private naviItemService: NaviItemService,
        private businessService: BusinessService,
        private entityManager: EntityManager,
        private ls: LocalStorageManager) {
    }

    ngOnInit() {
        this.getNaviList();
        this.getGlobalConfig();
    }

    getNaviList() {
        this.naviItemService.getNaviList()
            .subscribe(navList => {
                this.boardList = this.entityManager.conver2tree(navList)
                this.sortNaviGroups();
            });
    }

    getGlobalConfig() {
        var self = this;
        var storage = localStorage.getItem('BackgroundColor');
        if (storage) {
            self.globalConfig.BackgroundColor = storage;
        } else {
            this.businessService.getConfig()
                .subscribe(function (data) {
                    // Log data length
                    self.globalConfig = data.json();
                },
                function (err) {
                    // Log the error
                });
        }
    }

    get getWidth() {
        return this.boardList.reduce(
            ((sum, item) => {
                return sum + item.GroupSize * WIDTH_SINGLE_BLOCK + WIDTH_BLOCK_GAP;
            }), WIDTH_BLOCK_GAP);
    };

    GetGroupSizeName(data: SHECNaviBoard) {
        return `tile-group ${MetroGroupSize[data.GroupSize]}`;
    };


    private sortNaviGroups(): void {
        if (this.ls.exist(LS_USER_CLICK_LIST)) {
            var dictionary = this.ls.get(LS_USER_CLICK_LIST);
            this.boardList = this.boardList.sort((a: SHECNaviBoard, b: SHECNaviBoard) => {
                let num1: any, num2: any;
                num1 = dictionary[a.MenuID.toString()] | 0;
                num2 = dictionary[b.MenuID.toString()] | 0;
                return num2 - num1;
            });
        }
    }

    // private sortNaviGroups(a: any, b: any): number {
    //     if (this.ls.exist(LS_USER_CLICK_LIST)) {
    //         // debugger;
    //         var dictionary = this.ls.get(LS_USER_CLICK_LIST);
    //         let num1: any, num2: any;
    //         num1 = dictionary[a.MenuID.toString()] | 0;
    //         num2 = dictionary[a.MenuID.toString()] | 0;
    //         return num1 - num2;
    //     }
    //     return 0;
    // }
}