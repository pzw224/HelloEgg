import { Component, Input } from '@angular/core';

@Component({
    selector: 'search-bar',
    templateUrl: 'search.component.html'
})

export class SearchComponent {

}