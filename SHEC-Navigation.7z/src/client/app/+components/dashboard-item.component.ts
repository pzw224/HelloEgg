import { Component, Input } from '@angular/core';
import { SHECNaviBoard,TileConfig } from '../models/index';
import { DashboardCellComponent } from './dashboard-cell.component';
@Component({
    selector: 'dashboard-item',
    templateUrl: 'dashboard-item.component.html',
    directives:[DashboardCellComponent]
})

export class DashboardItemComponent{
    @Input() item: SHECNaviBoard;
    @Input() globalConfig:TileConfig;
}