import { Component, Input } from '@angular/core';

import { SHECNaviItem, TileConfig, TileSize } from '../models/index';
import { BusinessService } from '../+service/index';
import { LocalStorageManager, LS_USER_CLICK_LIST } from '../shared/index';


@Component({
    selector: 'dashboard-cell',
    templateUrl: 'dashboard-cell.component.html',
    styles: [`
        .carousel-switch-next,
        .carousel-switch-prev{
            display:none;
        }
    `]
})

export class DashboardCellComponent {
    @Input() itemCell: SHECNaviItem;
    @Input() globalConfig: TileConfig;

    constructor(private businessService: BusinessService,
        private ls: LocalStorageManager) {

    }
    get GetIconClassName() {
        return `icon ${this.itemCell.Tile.TileIcon.Icon}`;
    };
    get GetChildrenClassName() {
        return `${this.getMetroSize()}
         bg-${this.itemCell.Tile.BackgroundColor ? this.itemCell.Tile.BackgroundColor : this.globalConfig.BackgroundColor} 
         fg-${this.itemCell.Tile.FontColor} `;
    };
    get GetImageUrl() {
        return `assets/images/${this.itemCell.Tile.TileImage.ImageUrl}`;
    };
    GetItemCellImage(ImageUrl: string) {
        return `assets/images/${ImageUrl}`;;
    };
    RedirectUrl(url: string) {
        this.setRankList();
        window.open(url || this.itemCell.Link, '_blank');
    };

    private getMetroSize(): string {
        switch (this.itemCell.Tile.Size) {
            case TileSize.Tile_70x70:
                return "tile-small";
            case TileSize.Tile_70x150:
                return "tile-small tile-square-y";
            case TileSize.Tile_150x70:
                return "tile-small tile-square-x";
            case TileSize.Tile_150x150:
                return "tile-square";
            case TileSize.Tile_150x310:
                return "tile-square tile-wide-y";
            case TileSize.Tile_310x150:
                return "tile-wide";
            default:
                return "tile-square";
        }
    }

    private setRankList() {
        var dictionary = this.ls.get(LS_USER_CLICK_LIST);
        var key = this.itemCell.ParentID.toString();
        if (dictionary !== null && typeof dictionary !== 'undefined') {
            if (typeof dictionary[key] === 'number') {
                dictionary[key]++;
            } else {
                dictionary[key] = 1;
            }
        } else {
            dictionary = {};
            dictionary[key] = 1;
        }
        this.ls.set(LS_USER_CLICK_LIST, dictionary);
    }
}