import { Component } from '@angular/core';
import { HTTP_PROVIDERS } from '@angular/http';
import { HeaderComponent } from './+header/header.component';
import { DashboardComponent, SearchComponent } from './+components/index';
import { SHECNaviBoard } from './models/index';
import { EntityManager, LocalStorageManager } from './shared/index';

import { NaviItemService, BusinessService } from './+service/index';

@Component({
  selector: 'main-app',
  templateUrl: 'app.component.html',
  directives: [DashboardComponent, HeaderComponent, SearchComponent],
  providers: [NaviItemService, BusinessService, HTTP_PROVIDERS, EntityManager, LocalStorageManager]
})

export class AppComponent {

}

