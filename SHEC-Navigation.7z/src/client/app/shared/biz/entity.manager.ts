import { XMLSHECItem, SHECNaviBoard } from '../../models/index';

export class EntityManager {
    public conver2tree(data: XMLSHECItem[]): Array<SHECNaviBoard> {
        let parents: SHECNaviBoard[] = [], parentMap: any = {};

        data.filter(function (obj) {
            return obj.ParentID == null;
        }).map(function (obj) {
            let _tmp = new SHECNaviBoard();
            _tmp.MenuID = obj.MenuID;
            _tmp.Title = obj.Title;
            _tmp.Children = [];
            parentMap[obj.MenuID] = parents.length;
            parents.push(_tmp);
        });
        data.map(function (obj) {
            if (obj.ParentID != null && parentMap.hasOwnProperty(obj.ParentID)) {
                let _index = parentMap[obj.ParentID];
                parents[_index].Children.push({
                    MenuID: obj.MenuID,
                    Title: obj.Title,
                    Link: obj.Link,
                    Tile: obj.Tile,
                    ParentID: obj.ParentID,
                    EnableTitle: obj.EnableTitle
                });
            }
        });
        return parents;
    }
}