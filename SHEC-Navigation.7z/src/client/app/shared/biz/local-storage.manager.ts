export class LocalStorageManager {

    public get(key: string): any {
        return JSON.parse(localStorage.getItem(key));
    }
    public set(key: string, val: any): void {
        localStorage.setItem(key, JSON.stringify(val));
    }

    public exist(key: string) {
        let val = this.get(key);
        return !(val === null || typeof val === 'undefined');
    }

    public remove(key: string) {
        localStorage.removeItem(key);
    }

}