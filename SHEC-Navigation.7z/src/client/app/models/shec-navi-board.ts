import { SHECNaviItem } from './shec-navi-item';
import { TileSize } from './+tile/index';

export class SHECNaviBoard {
    MenuID: number;
    Title: string;
    Children: Array<SHECNaviItem>;

    get GroupSize(): number {
        let totalCount: number = 0;
        this.Children.map(obj => {
            switch (obj.Tile.Size) {
                case TileSize.Tile_70x70:
                    totalCount += 1;
                    break;
                case TileSize.Tile_70x150:
                case TileSize.Tile_150x70:
                    totalCount += 2;
                    break;
                case TileSize.Tile_150x150:
                    totalCount += 4;
                    break;
                case TileSize.Tile_310x150:
                case TileSize.Tile_150x310:
                    totalCount += 8;
                    break;
            }
        });
        return Math.ceil(totalCount / 12);
    }
}