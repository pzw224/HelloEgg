import {
    TileSize,
    TileType,
    TileIcon,
    TileImage,
    TileCarousel
} from './+tile/index';

export class TileStyle {
    BackgroundColor: string;
    FontColor: string;
    Size: TileSize;
    Type: TileType;
    TileIcon: TileIcon;
    TileImage: TileImage;
    TileCarousel:TileCarousel;
}

export class TileConfig {
    BackgroundColor: string;
    FontColor: string;
    Size: string;
    Type: number;
    Cocktail: string;
}