import { TileStyle } from './tile-style';

export class XMLSHECItem {
    MenuID: number;
    Title: string;
    Link: string;
    Cocktail: any;
    GroupSize: number;
    ParentID: number;
    EnableTitle: boolean;
    Tile: TileStyle;
}