import { TileStyle } from './tile-style';

export class SHECNaviItem {
    MenuID: number;
    Title: string;
    Link: string;
    Tile: TileStyle;
    ParentID: number;
    EnableTitle: boolean;
}