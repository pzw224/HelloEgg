export enum TileSize {
    Tile_70x70 = 0,
    Tile_70x150 = 1,
    Tile_150x70 = 2,
    Tile_150x150 = 3,
    Tile_150x310 = 4,
    Tile_310x150 = 5
}