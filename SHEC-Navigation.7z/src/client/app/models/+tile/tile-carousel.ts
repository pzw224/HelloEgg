import { TileCarouselItem } from './tile-carousel-item';
export class TileCarousel{
    ImageUrls:Array<TileCarouselItem>;
}