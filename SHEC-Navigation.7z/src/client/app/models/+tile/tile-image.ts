export class TileImage{
    ImageUrl:string;
    Description:string;
    EnableDescription:boolean;
}