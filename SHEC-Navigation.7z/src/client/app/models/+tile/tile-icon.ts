export class TileIcon {
    Icon: string;
}