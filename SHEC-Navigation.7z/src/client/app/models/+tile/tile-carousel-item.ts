export class TileCarouselItem {
    Name: string;
    Url: string;
    Description: string;
    EnableDescription: boolean;
}