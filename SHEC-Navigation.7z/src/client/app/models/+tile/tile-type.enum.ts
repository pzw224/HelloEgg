export enum TileType {
    ImageTile = 0,
    IconTile = 1,
    SildeTile = 2
}