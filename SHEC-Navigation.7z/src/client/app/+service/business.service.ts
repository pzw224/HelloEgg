import { Injectable } from '@angular/core';
import { Headers, Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/toPromise';
import { BaseService } from './base.service';
import { TileConfig} from '../models/index'

@Injectable()
export class BusinessService extends BaseService {
    constructor(protected http: Http) { super(http); }

    getConfig(): Observable<Response> {
        return this.http.get('/assets/tile-config.json')
            .catch(this.handleError);
    }

    // public put(obj: any): Promise<TileConfig> {
    //     let headers = new Headers();
    //     debugger;
    //     headers.append('Content-Type', 'application/json');
    //     let url = `/assets/tile-config.json`;
    //     return this.http
    //         .put(url, JSON.stringify(obj), { headers: headers })
    //         .toPromise()
    //         .then(() => obj)
    //         .catch(this.handleError);
    // }
}