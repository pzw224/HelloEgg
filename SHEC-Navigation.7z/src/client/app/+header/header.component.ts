import { Component, Input } from '@angular/core';
// import { NaviItemService, BusinessService } from '../+service/index';

@Component({
    selector: 'shec-header',
    templateUrl: 'header.component.html'
})
export class HeaderComponent {
    // constructor(private businessService: BusinessService) { }

    changeBgclolor(bgcolor: string) {
        localStorage.setItem("BackgroundColor", bgcolor);
        // this.businessService.put({ "BackgroundColor": bgcolor });
    }
}