import { ProjectConfig } from './config/project.config';

const config: ProjectConfig = new ProjectConfig();
export = config;
