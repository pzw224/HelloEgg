export = {
  ENV: 'PROD'
};

