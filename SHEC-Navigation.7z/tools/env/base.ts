export = {
  // Sample API url
  API: 'https://demo.com'
};

